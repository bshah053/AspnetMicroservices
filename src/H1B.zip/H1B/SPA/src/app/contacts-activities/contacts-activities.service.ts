import { Injectable } from '@angular/core';
import {
  SavedReportsService,
  PersistenceType,
  IReportPayload,
} from '../services/save-reports.service';
import {
  IContactSearchFilters,
  IActivitiesSearchFilters,
} from './store/contacts-activities.models';

type Filters = IActivitiesSearchFilters | IContactSearchFilters;

@Injectable({ providedIn: 'root' })
export class ContactsActivitiesService {
  constructor(private savedReports: SavedReportsService) {}

  saveContactSearch(
    userID: string,
    filters: IContactSearchFilters,
    details: Partial<IReportPayload> = {},
    type: PersistenceType = 'Temporary'
  ) {
    const payload: IReportPayload = {
      ...details,
      UserID: userID,
      ReportType: 'Contacts',
      Persistencetype: type,
      SystemReportName: 'Contacts',
      BreadCrumb: 'Contacts & Activities / Contact Search',
      FilterDetail: JSON.stringify({ ...filters }),
      TimeStamp: new Date().toISOString(),
    };

    return this.saveReport(payload);
  }

  saveActivitiesSearch(
    userID: string,
    filters: IActivitiesSearchFilters,
    details: Partial<IReportPayload> = {},
    type: PersistenceType = 'Temporary'
  ) {
    const payload: IReportPayload = {
      ...details,
      UserID: userID,
      ReportType: 'Activities',
      Persistencetype: type,
      SystemReportName: 'Activities',
      BreadCrumb: 'Contacts & Activities / Activities Search',
      FilterDetail: JSON.stringify({ ...filters }),
      TimeStamp: new Date().toISOString(),
    };

    return this.saveReport(payload);
  }

  private saveReport(payload: IReportPayload) {
    return this.savedReports.add(payload);
  }
}
