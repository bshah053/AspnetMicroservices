import { Component, OnInit, Input } from '@angular/core';
import { NavigationService } from '../../services/navigation.service';

@Component({
  selector: 'underwriter',
  templateUrl: './underwriter.component.html',
  styleUrls: ['./underwriter.component.scss'],
  providers: [],
})
export class UnderwriterComponent implements OnInit {
  @Input() user: Object;
  defaultYTD;
  constructor(private navigation: NavigationService) {}

  ngOnInit() {}

  meetingsSeeAllClicked() {
    this.navigation.toMyMeetings();
  }
}
