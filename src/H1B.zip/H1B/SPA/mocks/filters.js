const express = require('express');
const filters = require('./filters/filters.json');
const filterDivisions = require('./filters/filters.divisions.json');
const filterUnits = require('./filters/filters.units.json');
const filterSegments = require('./filters/filters.segments.json');
const filterSubsegments = require('./filters/filters.subsegments.json');
const filterUnderwriters = require('./filters/filters.underwriters.json');
const filterPascodes = require('./filters/filters.pascodes.json');
const filterProducers = require('./filters/filters.producer.json');
const filterAccountingMonth = require('./filters/filters.accountingmonth.json');
const filterAccountingYear = require('./filters/filters.accountingyear.json');
const filterTransactionType = require('./filters/filters.transaction-type');
const filterStatus = require('./filters/filters.status');
const filterProgram = require('./filters/filters.program');
const filterProducerProfileOwners = require('./filters/filters.producer-profileowners');
const fitlerCustomer = require('./filters/filters.customer.json');

module.exports = function filterRoutes() {
  const router = express.Router();

  router.get('/companies', (req, res) => res.json(filters.companies));
  router.post('/currentaccountingyearmonth', (req, res) => {
    const date = new Date(),
      monthNames = [
        'January',
        'February',
        'March',
        'April',
        'May',
        'June',
        'July',
        'August',
        'September',
        'October',
        'November',
        'December',
      ];

    return res.json({
      AccountingMonth: monthNames[date.getMonth()],
      AccountingYear: date.getFullYear(),
    });
  });

  router.post('/companies/divisions', (req, res) => {
    if (req.body && req.body.length) {
      return res.json(
        filterDivisions
          .filter((b) => req.body.includes(b.Company))
          .map(({ Company, ...division }) => division)
      );
    }

    res.json(filterDivisions);
  });

  router.post('/companies/divisions/units', (req, res) => {
    const { Company = [], Division = [] } = req.body;

    if (Company.length || Division.length) {
      return res.json(
        filterUnits
          .filter(
            (b) => Company.includes(b.Company) || Division.includes(b.Division)
          )
          .map(({ Company, Division, ...unit }) => unit)
      );
    }

    res.json(filterUnits);
  });

  router.post('/companies/divisions/units/segments', (req, res) => {
    const { Company = [], Division = [], Unit = [] } = req.body;

    if (Company.length || Division.length || Unit.length) {
      return res.json(
        filterSegments
          .filter(
            (s) =>
              Company.includes(s.Company) ||
              Division.includes(s.Division) ||
              Unit.includes(s.Unit)
          )
          .map(({ Company, Division, Unit, ...segment }) => segment)
      );
    }

    res.json(filterSegments);
  });

  router.post('/companies/divisions/units/segments/subsegments', (req, res) => {
    const { Company = [], Division = [], Unit = [], Segment = [] } = req.body;

    if (Company.length || Division.length || Unit.length || Segment.length) {
      return res.json(
        filterSubsegments
          .filter(
            (s) =>
              Company.includes(s.Company) ||
              Division.includes(s.Division) ||
              Unit.includes(s.Unit) ||
              Segment.includes(s.Segment)
          )
          .map(({ Company, Division, Unit, Segment, ...segment }) => segment)
      );
    }

    res.json(filterSubsegments);
  });

  router.post('/underwriters', (req, res) => res.json(filterUnderwriters));

  router.post('/UWRegion', (req, res) => res.json(filters.regions));

  router.post('/underwritermanager', (req, res) =>
    res.json(
      [{ Text: 'All Underwriters', Value: 'All' }].concat(filterUnderwriters)
    )
  );

  router.post('/creditedregions', (req, res) => res.json(filters.regions));

  router.post('/creditedregion/creditedbranches', (req, res) => {
    if (req.body && req.body.length) {
      return res.json(
        filters.branches
          .filter((b) => req.body.includes(b.Region))
          .map(({ Region, ...branch }) => branch)
      );
    }

    res.json(filters.branches);
  });

  router.post('/PAScode', (req, res) => {
    return res.json(filterPascodes.pascodes);
  });
  router.post('/producer', (req, res) => {
    return res.json(filterProducers.producers);
  });

  [
    'insuredaccounttype',
    'relationshipmanager',
    'companies/divisions/units/segments/portfolioclasses',
    'insuredstates',
    'insuredstate/insuredcities',
    'industries',
    'incumbents',
    'producerregions',
    'producerregion/producerbranches',
    'producerstates',
    'producerstate/producercities',
    'capacities',
    'uwregion/uwbranches',
    'DataSource',
    'MarketingManager',
    'TargetType',
    'tscore',
    'pgroups',
    'tclasses',
    'terrorcoverage',
    'tpa',
  ].forEach((entrypoint) => {
    const data = [];
    for (let i = 1; i < 20; i++) {
      data.push({ Text: `${i}`, Value: `${i}` });
    }
    router.all('/' + entrypoint, (req, res) => res.json(data));
  });

  router.all('/currencies', (req, res) =>
    res.json([
      { Text: 'USD', Value: 'USD' },
      { Text: 'EUR', Value: 'EUR' },
      { Text: 'UAH', Value: 'UAH' },
      { Text: 'PND', Value: 'PND' },
    ])
  );

  router.post('/AccountingMonth', (req, res) =>
    res.json(filterAccountingMonth)
  );

  router.post('/AccountingYear', (req, res) => res.json(filterAccountingYear));

  router.post('/TransactionType', (req, res) =>
    res.json(filterTransactionType)
  );
  router.post('/Status', (req, res) => res.json(filterStatus));
  router.post('/Program', (req, res) => res.json(filterProgram));

  router.post('/producer/profileowner', (req, res) =>
    res.json(filterProducerProfileOwners)
  );

  router.post('/Customer', (req, res) => res.json(fitlerCustomer));

  return router;
};
