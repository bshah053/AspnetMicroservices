export interface DataElementsControlDetailsItem {
  SectionName: string;
  SectionKey: string;
  SectionType: string;
  RowColumnsCount?: number;
  IsExpanded: boolean;
  isOpen: boolean;
  isValidationErrorExist: boolean;
  validationErrorSummary: string;
  DataElementsDetails: DataElementsDetails[];
  DataElementsGroupDetails: DataElementsGroupDetailsItem[];
}

export interface DataElementsGroupDetailsItem {
  GroupIndicatorHeaderName: string;
  GroupIndicator: number;
  IsGroupIndicatorVisible: boolean;
  DataElementsDetails: DataElementsDetails[];
}

export interface DataElementsDetails {
  ControlId: number;
  ControlName: string;
  CascadingControlName: string;
  DataLabel: string;
  ValidationMessage: string;
  ControlType: string;
  SectionName: string;
  SectionKey: string;
  SectionType: string;
  SectionDisplayOrder: number;
  IsExpanded: boolean;
  TableIndicator: string;
  IsSingleValue: boolean;
  DefaultValue: string;
  SelectedValues: string;
  DataType: string;
  IsAuditable: boolean;
  IsVisible: boolean;
  IsRequired: boolean;
  IsReadonly: boolean;
  DisplayOrder: number;
  HyperLinkTooltip: string;
  IsHyperLink: boolean;
  HyperLinkIconType: string;
  MaxLength: number;
  MinLength: number;
  MaxValue: number;
  MinValue: number;
  ControlHint: string;
  ControlTooltip: string;
  ControlGroupIndicator: number;
  ControlGroupHeaderName: string;
  IsControlGroupVisible: boolean;
  PatternTypeName?: string;
  ValidCharRegEx?: string;
  SearchValue?: string;
  Options?: OptionsItems[];
  OptionsUWItems: OptionsUWItems[];
  OptionGroupItems?: OptionsGroupItems[];
  Placeholder?: string;
  RowColumnsCount: number;
  CurrencyType?: string;
  IsQuickSubmission: boolean;
}

export interface OptionsItems {
  parentValue?: string;
  text: string;
  value: any;
  displayOrder?: number;
}

export interface OptionsGroupItems {
  groupName?: string;
  options?: OptionsItems[];
  displayOrder?: number;
  disabled?: boolean;
}

export interface OptionsUWItems {
  text: string;
  value: any;
  email?: string;
  uwBranch?: string;
}
