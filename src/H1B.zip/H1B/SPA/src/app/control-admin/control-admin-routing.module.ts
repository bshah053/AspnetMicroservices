import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MsalGuard } from '@azure/msal-angular';

import { ControlAdminComponent } from './control-admin.component';
import { FormsControlMasterComponent } from './forms-control-master/forms-control-master.component';
import { GenericsFormsMasterComponent } from './generics-forms-master/generics-forms-master.component';

const routes: Routes = [
	{
		path: '',
		canActivate: [MsalGuard],
		canActivateChild: [MsalGuard],
		children: [
			{
				path: 'control-master',
				// canActivate: [MsalGuard],
				component: ControlAdminComponent,
			},
			{
				path: 'forms-control',
				// canActivate: [MsalGuard],
				component: FormsControlMasterComponent,
			},
			{
				path: 'table-admin',
				// canActivate: [MsalGuard],
				component: GenericsFormsMasterComponent,
			},
		],
	},
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule],
})
export class ControlAdminRoutingModule {}
