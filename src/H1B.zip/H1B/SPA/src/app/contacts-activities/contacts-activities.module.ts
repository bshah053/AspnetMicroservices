import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { ContactsActivitiesComponent } from './contacts-activities.component';
import { RelationshipService } from './relationship.service';
import { ContactsComponent } from './contacts/contacts.component';
import { ActivitiesSearchService } from './search/activities-search/activities-search.service';
import { ContactsSearchComponent } from './search/contacts-search/contacts-search.component';
import { ContactsHeaderComponent } from './search/contacts-header/contacts-header.component';
import { RelationshiptypeMenuComponent } from './search/contacts-search/relationshiptype-menu/relationshiptype-menu.component';
import { TopLevelMenuComponent } from './search/contacts-search/top-level-menu/top-level-menu.component';
import { BranchMenuComponent } from './search/contacts-search/branch-menu/branch-menu.component';
import { ContactSearchService } from './search/contacts-search/contact-search.service';
import { ActivitiesSearchComponent } from './search/activities-search/activities-search.component';
import { ActivitiesSearchTableComponent } from './search/activities-search/activities-search-table/activities-search-table.component';
import { ContactsSearchTableComponent } from './search/contacts-search/contacts-search-table/contacts-search-table.component';
import { ActivitiesProducerFiltersComponent } from './search/activities-search/activities-producer-filters/activities-producer-filters.component';
import { ActivitiesAccountFiltersComponent } from './search/activities-search/activities-account-filters/activities-account-filters.component';
import { ContactsActivitiesService } from './contacts-activities.service';
import { ContactActivitiesRoutes } from './contacts-activities.routes';
import { ContactsActivitiesSearchTableComponent } from './search/contacts-activities-search-table/contacts-activities-search-table.component';
import { ContactsActivitiesSearchComponent } from '../contacts-activities/search/contacts-activities-search.component';
import { MoreFiltersComponent } from '../contacts-activities/search/more-filters/more-filters.component';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    SharedModule,
    BsDatepickerModule.forRoot(),
    RouterModule.forChild(ContactActivitiesRoutes),
  ],
  declarations: [
    ContactsActivitiesSearchTableComponent,
    ContactsActivitiesSearchComponent,
    ContactsActivitiesComponent,
    ContactsComponent,
    ActivitiesSearchComponent,
    ActivitiesSearchTableComponent,
    ContactsSearchComponent,
    ContactsSearchTableComponent,
    ContactsHeaderComponent,
    RelationshiptypeMenuComponent,
    BranchMenuComponent,
    TopLevelMenuComponent,
    ActivitiesProducerFiltersComponent,
    ActivitiesAccountFiltersComponent,
    MoreFiltersComponent,
  ],
  exports: [
    ContactsActivitiesComponent,
    ContactsComponent,
    ActivitiesSearchComponent,
    ActivitiesSearchTableComponent,
    ContactsSearchComponent,
    ContactsSearchTableComponent,
    ContactsHeaderComponent,
    RelationshiptypeMenuComponent,
    BranchMenuComponent,
    TopLevelMenuComponent,
    ActivitiesProducerFiltersComponent,
    ActivitiesAccountFiltersComponent,
    MoreFiltersComponent,
  ],
  providers: [
    RelationshipService,
    ActivitiesSearchService,
    ContactSearchService,
    ContactsActivitiesService,
  ],
})
export class ContactsActivitiesModule {}
