import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'cb-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.scss'],
})
export class ButtonComponent implements OnInit {
  @Input() label = 'Button';
  @Input() disabled = false;
  @Input() buttonClass = 'cb-button';
  @Input() type = 'submit';
  @Output() buttonClick = new EventEmitter<MouseEvent>();

  buttonClassName: string;

  constructor() {}

  ngOnInit() {
    this.updateClassName();
  }

  ngOnChange() {
    this.updateClassName();
  }

  updateClassName() {
    this.buttonClassName = [this.buttonClass, this.disabled && 'disabled']
      .filter((s) => !!s)
      .join(' ');
  }

  handleClick(event: MouseEvent) {
    if (!this.disabled) {
      this.buttonClick.next(event);
    }
  }
}
