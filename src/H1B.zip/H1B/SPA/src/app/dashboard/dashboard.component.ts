import { Component } from '@angular/core';
import { DashboardService } from './dashboard.service';
import { combineLatest, Observable } from 'rxjs';
import { Select } from '@ngxs/store';
import { User } from '../user/user.model';
import { UserState } from '../user/user.store';
import { AccountingYearMonth, AccountingYearMonthState } from 'store/accounting-month-year.store';
import { Router, NavigationStart, ActivatedRoute } from '@angular/router';
import { FilterWatchService } from '../services/filter-watch.service';
import { ReportsHeaderModel } from '../tracking-reporting/reports/reports-header/store/reports-header.model';
import { filter } from 'rxjs/operators';
// import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'cb-dashboard-component',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
  providers: [],
})
export class DashboardComponent {
  user: User;
  tabTitle = '';
  showTrackerQueue = false;
  accountingYearMonth: AccountingYearMonth;
  redirectTrackerQueue = false;
  @Select(UserState) public user$: Observable<User>;
  @Select(AccountingYearMonthState)
  public accountingYearMonth$: Observable<AccountingYearMonth>;

  constructor(private dashboardService: DashboardService, private filterWatch: FilterWatchService, private router: Router, private activatedRoute: ActivatedRoute) {
    combineLatest([this.user$, this.accountingYearMonth$]).subscribe(([user, accountingYearMonth]) => {
      this.user = user;
      this.accountingYearMonth = accountingYearMonth;
      this.activatedRoute.queryParams.subscribe((params) => {
        this.redirectTrackerQueue = params.RedirectTrackerQueue;
      });
      this.getDashboardBYuserType(user);
    });
    this.subscribeToTab();

    this.router.events.pipe(filter((event) => event instanceof NavigationStart)).subscribe((e: NavigationStart) => {
      if (e.url === '/dashboard') {
        this.getDashboardBYuserType(this.user);
      } else if (e.url === '/dashboard/tracker-queue?isReportLandingpage=true') {
        this.router.navigate(['/dashboard/tracker-queue'], {
          queryParams: { RedirectTrackerQueue: true },
        });
      } else if (e.url === '/dashboard/tracker-queue') {
        this.router.navigate(['/dashboard/tracker-queue'], {
          queryParams: { RedirectTrackerQueue: true },
        });
      }
    });
  }

  subscribeToTab() {
    if (this.dashboardService.selectedTabAnnounced$) {
      this.dashboardService.selectedTabAnnounced$.subscribe((tabTitle) => {
        this.getBrchMgrRenewalsTable(tabTitle);
      });
    }
  }

  getDashboardBYuserType(user) {
    if (user && user['UserID'] && user['UserType'] !== '') {
      switch (user['UserType']) {
        case 'Underwriter':
          this.handleUnderwriter(user);
          break;
        case 'Underwriter Manager':
          this.handleUnderwriterManager(user);
          break;
        case 'Branch Manager':
          this.getDataForBranchManager();
          break;
        case 'Regional Manager':
          this.getDataForRegionalManager();
          break;
        case 'Market Segment Leader':
          this.handleMSLUser(user);
          break;
        case 'Global Client Executive':
          this.handleGCEUser(user);
          break;
        case 'Manager General':
          this.handleManagerGeneralUser(user);
          break;
        // default:
        //  this.handleDefaultUser();
        //  break;
      }
    }

    if (user && user['UserID'] && user['UserType'] === '') {
      this.handleDefaultUser();
    }
  }

  handleDefaultUser() {
    this.router.navigate(['/error']);
  }

  // ----- Underwriter Dashboard -----

  handleUnderwriter(user) {
    if (user['DynamicUser'] === 'No') {
      this.router.navigate(['/dashboard/tracker-queue']);
    } else {
      this.getDataForUnderwriter();
    }
  }

  // ----- GCE Dashboard -----
  handleGCEUser(user) {
    if (user['DynamicUser'] === 'No') {
      this.router.navigate(['/dashboard/tracker-queue']);
    } else {
      this.getDataForGCE();
    }
  }

  // ----- To handle Manager General -----
  handleManagerGeneralUser(user) {
    if (user['DynamicUser'] === 'Yes' && !this.redirectTrackerQueue) {
      this.dashboardService.getMyUnderwriters(this.user.UserID).subscribe((data) => {
        if (data !== null) {
          this.router.navigate(['/tracking-and-reporting/forecast-detail'], {
            queryParams: {
              filters: this.createFiltersForManagerGeneral(data.map((v) => v.value)),
            },
          });
        }
      });
    } else {
      //
    }
  }

  // ----- MSL Dashboard -----

  handleMSLUser(user) {
    if (user['DynamicUser'] === 'No') {
      this.router.navigate(['/dashboard/tracker-queue']);
    } else {
      this.getDataForMSL();
    }
  }

  handleUnderwriterManager(user) {
    if (user['DynamicUser'] === 'No' && !this.redirectTrackerQueue) {
      this.dashboardService.getMyUnderwriters(this.user.UserID).subscribe((data) => {
        if (data !== null) {
          this.router.navigate(['/tracking-and-reporting/forecast-detail'], {
            queryParams: {
              filters: this.createFiltersForUnderwriterManager(data.map((v) => v.value)),
            },
          });
        }
      });
    } else {
      this.getDataForUnderwriterManager();
    }
  }

  createFiltersForManagerGeneral(underwriters): string {
    return this.createFilters(
      {
        TimeFrame: 'MTD',
        AccountMonth: this.accountingYearMonth.AccountingMonth,
        AcountYear: this.accountingYearMonth.AccountingYear,
        Status: ['Pending', 'Working', 'Quoted', 'Bound'],
        // UnderwriterName: (this.user.LandingPage !== 'Forecast Detailed') ? underwriters : [''],
      },
      {
        browseBy: 'CHUBB',
        // browseByValue: 'underwriters',
      }
    );
  }

  createFiltersForUnderwriterManager(underwriters): string {
    return this.createFilters(
      {
        TimeFrame: 'MTD',
        AccountMonth: this.accountingYearMonth.AccountingMonth,
        AcountYear: this.accountingYearMonth.AccountingYear,
        Status: ['Pending', 'Working', 'Quoted', 'Bound'],
        UnderwriterName: this.user.LandingPage !== 'Forecast Detailed' ? underwriters : [''],
      },
      {
        browseBy: 'CHUBB',
        browseByValue: 'underwriters',
      }
    );
  }

  createFilters(filters, ui): string {
    const serializedFilters = this.filterWatch.serializeFromPayload((filters as any) as ReportsHeaderModel, ui);
    return this.filterWatch.create(serializedFilters);
  }

  // getPipelinesForecast() {
  //   let params = {
  //     UserID: this.user['UserID'],
  //     RetrieveBy: 'EFF',
  //     NoOfDays: 90,
  //   };
  //   this.dashboardService.getPipelinesForecast(params);
  // }

  // getPipelinesNBRenewals() {
  //   let params = {
  //     UserID: this.user['UserID'],
  //     AccountingMonth: 'FEB',
  //     AccountingYear: 2019,
  //     TimeFrame: 'YTD',
  //   };
  //   this.dashboardService.getPipelinesNBRenewals(params);
  // }

  // getMyRenewalsInfo() {
  //   let params = {
  //     UserID: this.user['UserID'],
  //     AccountingMonth: 'JUN',
  //     AccountingYear: 2019,
  //     TimeFrame: 'YTD',
  //   };
  //   this.dashboardService.getMyRenewalsInfo(params);
  // }

  // getRenewalsTable() {
  //   let params = {
  //     UserID: this.user['UserID'],
  //     RetrieveBy: 'EFF',
  //     NoOfDays: 10,
  //     Status: 'Quoted',
  //     PageNumber: 0,
  //     PageSize: 0,
  //     SortBy: 'EffectiveDate',
  //     OrderBy: 'asc',
  //   };
  //   this.dashboardService.getRenewalsTable(params);
  // }

  private defaultYTD() {
    return {
      UserID: this.user.UserID,
      AccountingMonth: this.accountingYearMonth.AccountingMonth,
      AccountingYear: this.accountingYearMonth.AccountingYear,
      TimeFrame: this.user.UserType !== 'Underwriter Manager' && this.user.UserType !== 'Market Segment Leader' && this.user.UserType !== 'Global Client Executive' ? 'YTD' : 'MTD',
    };
  }

  private renewalsTableDefaults(tabTitle) {
    return {
      UserID: this.user.UserID,
      RetrieveBy: 'EFF',
      NoOfDays: 120,
      Status: tabTitle || 'Quoted',
      PageNumber: 0,
      PageSize: 25,
      SortBy: 'EffectiveDate',
      OrderBy: 'asc',
    };
  }

  getOpenTargets() {
    this.dashboardService.getOpenTargets({
      UserID: this.user.UserID,
      PageNumber: 1,
      //PageSize: 5,//TRKR-4343
      SortBy: 'EffectiveDate',
      OrderBy: 'asc',
    });
  }

  // ----- Branch Manager Dashboard -----

  getForecastVsPlan() {
    this.dashboardService.getForecastVsPlan(this.defaultYTD());
  }

  getBrchMgrNewBusiness() {
    this.dashboardService.getPipelinesForecast({
      UserID: this.user.UserID,
      RetrieveBy: 'EFF',
      NoOfDays: 90,
    });
  }

  getBrchMgrNBRenewals() {
    this.dashboardService.getPipelinesNBRenewals(this.defaultYTD());
  }

  getNewBusinessGraphs() {
    this.dashboardService.getNewBusinessGraphs(this.defaultYTD());
  }

  getUWMNewBusinessGraphs(Underwriter = []) {
    this.dashboardService.getUWMNewBusinessGraphs({
      ...this.defaultYTD(),
      Underwriter,
    });
  }

  getBrchMgrRenewalsTable(tab) {
    this.dashboardService.getRenewalsTable(this.renewalsTableDefaults(tab ? tab.status : null));
  }

  // getRenewalToPlanInfo() {
  //   let params = {
  //     UserID: this.user['UserID'],
  //     AccountingMonth: this.month,
  //     AccountingYear: this.year,
  //     TimeFrame: 'ytd',
  //   };
  //   this.dashboardService.getRenewalsToPlan(params);
  // }

  getRMrenewalsTable(tabTitle) {
    tabTitle = tabTitle ? tabTitle.replace(/[^A-Za-z]/g, '') : null;
    this.dashboardService.getRMrenewalsTable(this.renewalsTableDefaults(tabTitle));
  }

  // getRenewalsRatioInfo() {
  //   let params = {
  //     UserID: this.user['UserID'],
  //     AccountingMonth: this.month,
  //     AccountingYear: this.year,
  //     TimeFrame: 'ytd',
  //   };
  //   this.dashboardService.getRenewalsRatio(params);
  // }

  getTopCustomerTargets() {
    this.dashboardService.getTopCustomerTargets(this.defaultYTD());
  }

  getTopProducerTargets() {
    this.dashboardService.getTopProducerTargets(this.defaultYTD());
  }

  getDataForUnderwriter() {
    // this.getPipelinesForecast();
    // this.getPipelinesNBRenewals();
    // this.getMyRenewalsInfo();
    // this.getRenewalsTable();
    this.getOpenTargets();
  }

  getDataForUnderwriterManager() {
    this.getUWMNewBusinessGraphs();
  }

  getDataForBranchManager() {
    this.getForecastVsPlan();
    this.getBrchMgrNewBusiness();
    // this.getBrchMgrNBRenewals();
    this.getNewBusinessGraphs();
    // this.getBrchMgrRenewalsTable(this.tabTitle);
    // this.getRenewalToPlanInfo();
  }

  getDataForRegionalManager() {
    this.getForecastVsPlan();
    // this.getPipelinesForecast();
    // this.getPipelinesNBRenewals();
    // this.getRegionalManagerRenewalsInfo();
    this.getRMrenewalsTable(this.tabTitle);
    // this.getRenewalsRatioInfo();
    this.getNewBusinessGraphs();
    this.getTopCustomerTargets();
    this.getTopProducerTargets();
  }

  getDataForMSL() {
    this.getMSLNewBusinessGraphs();
    this.getMSLOpenTargets();
  }

  getMSLOpenTargets() {
    this.dashboardService.getMSLOpenTargets({
      UserID: this.user.UserID,
      RetrieveBy: 'eff',
      NoOfDays: 90,
      Branch: [''],
      PageNumber: 0,
      PageSize: 0,
      SortBy: 'Forecast',
      OrderBy: 'desc',
    });
  }

  getMSLNewBusinessGraphs() {
    this.dashboardService.getMSLNewBusinessGraphs(this.defaultYTD());
  }

  getDataForGCE() {
    this.getGCENewBusinessGraphs();
  }

  getGCENewBusinessGraphs() {
    this.dashboardService.getGCENewBusinessGraphs(this.defaultYTD());
  }

  // navigateToReturnUrl() {
  //   if (this.cookieService.check('app_return_url')) {
  //     this.router.navigate(['/select-navigation']);
  //     return false;
  //   }
  //   return true;
  // }
}
