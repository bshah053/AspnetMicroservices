import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewEncapsulation,
} from '@angular/core';
import { ListItem } from '../radio-list/radio-list.component';

@Component({
  selector: 'cb-dropdown-checkbox-list',
  templateUrl: './dropdown-checkbox-list.component.html',
  styleUrls: ['./dropdown-checkbox-list.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DropdownCheckboxListComponent implements OnInit {
  @Input() name = 'Dropdown Menu';
  @Input() open = false;
  @Input() placeholder = 'Type name';
  @Input() items: Array<ListItem>;
  @Input() selectedValues: Array<any> = [];
  @Output() selectedValuesChange = new EventEmitter<Array<any>>();
  @Output() openChange = new EventEmitter<boolean>();
  @Input() segregated = true;
  @Input() style = null;

  constructor() {}

  ngOnInit() {}

  get hasValues() {
    return this.selectedValues && !!this.selectedValues.length;
  }

  get valueList() {
    return (this.selectedValues || [])
      .map((value) => {
        const foundItem = (this.items || []).find((v) => v.value === value);
        if (foundItem) {
          return foundItem.text;
        }
        return value;
      })
      .join(', ');
  }

  get isOpened() {
    return this.open;
  }

  handleToggleOpen() {
    this.open = !this.open;
    this.openChange.next(this.open);
  }

  handleHide() {
    this.open = false;
  }

  onSelectedValuesChange(selectedValues: any[]) {
    this.selectedValues = selectedValues;
    this.selectedValuesChange.emit(this.selectedValues);
  }
}
