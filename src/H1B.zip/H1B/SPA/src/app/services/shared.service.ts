import { Injectable } from '@angular/core';
import { Observable, Subject, BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class SharedService {
  private subject = new Subject<any>();
  // private showLoadingSubject$  = new BehaviorSubject(null);
  // showLoading$ = this.showLoadingSubject$.asObservable();
  private showLoading$ = new Subject<any>();
  private showDBLoading$ = new Subject<any>();
  private hideLoading$ = new Subject<any>();
  private hideDBLoading$ = new Subject<any>();
  private showExportIcon$ = new Subject<any>();
  private submissionValueChanges$ = new Subject<any>();
  private loadingChanges$ = new Subject<any>();
  private userAdminValueChanges$ = new Subject<any>();
  private ctrlsChanges$ = new Subject<any>();
  private trackerQueueReloadRequest$ = new Subject<any>();
  private subCopyDeleteStatus$ = new Subject<any>();
  private headerVisibility$ = new Subject<boolean>();

  sendRefreshFetchGoals() {
    this.subject.next();
  }

  refreshFetchGoals(): Observable<any> {
    return this.subject.asObservable();
  }

  // showLoading() {
  //   this.showLoadingSubject$.next(null);
  // }

  sendDBShowLoading() {
    this.showDBLoading$.next();
  }

  showDBGridLoading(): Observable<any> {
    return this.showDBLoading$.asObservable();
  }

  sendDBHideLoading() {
    this.hideDBLoading$.next();
  }

  hideDBGridLoading(): Observable<any> {
    return this.hideDBLoading$.asObservable();
  }

  sendShowLoading() {
    this.showLoading$.next();
  }

  showGridLoading(): Observable<any> {
    return this.showLoading$.asObservable();
  }

  sendHideLoading() {
    this.hideLoading$.next();
  }

  hideGridLoading(): Observable<any> {
    return this.hideLoading$.asObservable();
  }

  sendShowOrHideExportIcon(showCustomerProfiles) {
    this.showExportIcon$.next(showCustomerProfiles);
  }

  updateShowOrHideExportIcon(): Observable<any> {
    return this.showExportIcon$.asObservable();
  }

  sendSubmissionValueChanges(saveDetails) {
    this.submissionValueChanges$.next(saveDetails);
  }

  setSubmissionValueChanges(): Observable<any> {
    return this.submissionValueChanges$.asObservable();
  }

  sendLoading(isLoading) {
    this.loadingChanges$.next(isLoading);
  }

  setLoading(): Observable<any> {
    return this.loadingChanges$.asObservable();
  }

  sendUAValueChanges(saveDetails) {
    this.userAdminValueChanges$.next(saveDetails);
  }

  setUAValueChanges(): Observable<any> {
    return this.userAdminValueChanges$.asObservable();
  }

  sendCTRLSChanges(ctrlsDetails) {
    this.ctrlsChanges$.next(ctrlsDetails);
  }

  setCTRLSChanges(): Observable<any> {
    return this.ctrlsChanges$.asObservable();
  }

  sendTQReloadRequest() {
    this.trackerQueueReloadRequest$.next();
  }

  setTQReloadRequest(): Observable<any> {
    return this.trackerQueueReloadRequest$.asObservable();
  }

  sendSubmissionCopyDeleteStatus(sucessStatus) {
    this.subCopyDeleteStatus$.next(sucessStatus);
  }

  setSubmissionCopyDeleteStatus(): Observable<any> {
    return this.subCopyDeleteStatus$.asObservable();
  }

  sendHeaderVisibilityStatus(isVisible) {
    this.headerVisibility$.next(isVisible);
  }

  setHeaderVisibilityStatus(): Observable<boolean> {
    return this.headerVisibility$.asObservable();
  }
}
