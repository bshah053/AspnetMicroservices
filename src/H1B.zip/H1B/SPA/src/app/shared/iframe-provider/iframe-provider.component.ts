import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'cb-iframe-provider',
  templateUrl: './iframe-provider.component.html',
  styleUrls: ['./iframe-provider.component.scss'],
})
export class IframeProviderComponent {
  @Input()
  get url(): string {
    return this._url;
  }
  set url(val: string) {
    this._url = val;
    this.content = this.printIframe(val);
  }

  @Input()
  get width(): string {
    return this._width;
  }
  set width(val: string) {
    this._width = val;
    this.content = this.printIframe(val);
  }

  @Input()
  get height(): string {
    return this._height;
  }
  set height(val: string) {
    this._height = val;
    this.content = this.printIframe(val);
  }

  _url: string;
  _width: string = '100%';
  _height: string = '700px';

  content: any;

  printIframe(url: string): any {
    return `
      <iframe src="${url}" width="${this.width}" height="${
      this.height
    }"></iframe>`;
  }
}
