import { Component, HostListener, Inject, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';

import { ReportingService } from 'tracking-reporting/services/reporting.service';
import { Helper } from 'utilities/common-helper';

@Component({
  selector: 'cb-search-bar-dialog',
  templateUrl: './search-bar-dialog.component.html',
  styleUrls: ['./search-bar-dialog.component.scss'],
})
export class SearchBarDialogComponent implements OnInit {
  insuredNameList;
  isLoading: boolean = false;
  isShowContent: boolean = false;
  isError: boolean = false;
  searchFormGroup: FormGroup;

  constructor(private reportService: ReportingService, public dialogRef: MatDialogRef<SearchBarDialogComponent>, @Inject(MAT_DIALOG_DATA) public data: any) {}

  @HostListener('window:keyup.esc')
  onKeyUp() {
    this.dialogRef.close();
  }

  ngOnInit(): void {
    this.searchFormGroup = new FormGroup({
      searchValue: new FormControl(''),
    });
    this.enableControlValueChange();
  }

  handleClose() {
    this.dialogRef.close();
  }

  loadSearchDetails(searchValue) {
    this.reportService.getInsuredWildcardSearchOptions(searchValue).subscribe(
      (data) => {
        if (data && data !== null) {
          this.isLoading = false;
          this.isShowContent = true;
          this.insuredNameList = data;
        } else {
          this.isLoading = false;
          this.isShowContent = false;
          this.isError = true;
          this.insuredNameList = [];
        }
      },
      (err) => {
        this.isLoading = false;
        this.isShowContent = false;
        this.isError = true;
        this.insuredNameList = [];
      }
    );
  }

  enableControlValueChange() {
    this.searchFormGroup
      .get('searchValue')
      .valueChanges.pipe(debounceTime(300), distinctUntilChanged())
      .subscribe((controlValue) => {
        this.isLoading = true;
        this.isShowContent = false;
        this.isError = false;
        if (Helper.isStringNotNullAndEmpty(controlValue)) {
          this.loadSearchDetails(controlValue);
        } else {
          this.isLoading = false;
          this.isShowContent = false;
          this.isError = false;
          this.insuredNameList = [];
        }
      });
  }

  handleSelectedItem(item) {
    const selectedItem = {
      searchType: item.parentValue,
      searchValue: item.text,
    };
    this.dialogRef.close(selectedItem);
  }

  wildCardSearch() {
    const wildcardSearchValue: string = this.searchFormGroup.get('searchValue').value;
    if (Helper.isStringNotNullAndEmpty(wildcardSearchValue) && wildcardSearchValue.length > 0) {
      const selectedItem = {
        searchType: '',
        searchValue: wildcardSearchValue,
      };
      this.dialogRef.close(selectedItem);
    }
  }
}
