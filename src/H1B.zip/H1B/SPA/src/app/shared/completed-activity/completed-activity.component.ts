import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChange, TemplateRef, ViewChild } from '@angular/core';
import { ColDef } from 'ag-grid-community';
import { NavigationService } from '../../services/navigation.service';
import { UrlHelper } from '../../utilities/url.helper';
import { ContactsActivitiesHelper } from '../../utilities/contacts-activities.helper';
import { AgGridTemplateRendererComponent } from '../ag-grid-utils/ag-grid-template-renderer.component';
import { ModalService } from '../modal/modal.service';
import Utilities from '../utilities';

export interface ICompletedActivity {
	RelatedTo: string;
	Subject: string;
	StartDate: string;
	EndDate: string;
	Location: string;
	RequiredAttendees: string;
	OptionalAttendees: string;
	MeetingTime: string;
	Attendees: string;
	Owner: string;
	MeetingGUID: string;
	RelatedToGUID: string;
	OwnerGUID: string;
	AttendeesGUID: string;
	AttendeesEmail: string;
	AccountType: string;
	ProducerName: string;
	ProducerRegion: string;
	ProducerBranch: string;
	ClientID: string;
	Date: string;
	DueDate?: string;
	Task: string;
	Topics: string;
	Name: string;
	LastModified: string;
	AssignedTo?: string;
	CompletedActivitesGUID?: string;
	CrmAccountGUID?: string;
	AccountName: string;
}

interface ActivityVM extends ICompletedActivity {
	AttendeesList: { name: string; email: string; guid: string }[];
}

@Component({
	selector: 'cb-completed-activities-table',
	templateUrl: './completed-activity.component.html',
	styleUrls: ['./completed-activity.component.scss'],
})
export class CompletedActivityComponent implements OnInit, OnChanges {
	@Input() activities: ICompletedActivity[];
	@Input() error: string;
	@Input() showLinks = false;
	@Input() mode: 'Default' | 'ContactsAndActivities' | 'CustomerProfile' = 'Default';
	@Output() refreshActivities = new EventEmitter();
	@Output() topLinkClicked = new EventEmitter();

	@ViewChild('relatedToCell', { static: true })
	private relatedToCell: TemplateRef<any>;
	@ViewChild('subjectCell', { static: true })
	private subjectCell: TemplateRef<any>;
	@ViewChild('attendeesCell', { static: true })
	private attendeesCell: TemplateRef<any>;
	@ViewChild('ownerCell', { static: true })
	private ownerCell: TemplateRef<any>;

	columns: ColDef[];
	activitiesVM: ActivityVM[];

	constructor(private modalService: ModalService, private navigation: NavigationService) {}

	ngOnInit() {
		this.defineColumns();
	}

	ngOnChanges(changes: { [key in keyof CompletedActivityComponent]: SimpleChange }) {
		if (changes.activities && Array.isArray(this.activities)) {
			this.activitiesVM = (this.activities || []).map(ContactsActivitiesHelper.toViewModel);
		}
	}

	private defineColumns() {
		switch (this.mode) {
			case 'CustomerProfile':
				this.columns = [
					{
						headerName: 'Related To',
						headerTooltip: 'Related To',
						field: 'RelatedTo',
						tooltipValueGetter: (params) => params.value,
						width: 208,
						suppressSizeToFit: true,
					},
					{
						headerName: 'Subject',
						headerTooltip: 'Subject',
						field: 'Subject',
						tooltipValueGetter: (params) => params.value,
						width: 310,
						suppressSizeToFit: true,
						cellRendererFramework: AgGridTemplateRendererComponent,
						cellRendererParams: { ngTemplate: this.subjectCell },
					},
					{
						headerName: 'Attendees',
						headerTooltip: 'Attendees',
						width: 402,
						cellRendererFramework: AgGridTemplateRendererComponent,
						cellRendererParams: { ngTemplate: this.attendeesCell },
						suppressSizeToFit: true,
						sortable: false,
					},
					{
						headerName: 'Date',
						field: 'Date',
						cellClass: 'date',
						valueFormatter: Utilities.dateFormatter,
						tooltipValueGetter: (params) => params.valueFormatted,
						width: 151,
						suppressSizeToFit: true,
					},

					{
						headerName: 'Task',
						field: 'Task',
						width: 98,
						cellRenderer: this.renderTaskColumn(),
						suppressSizeToFit: true,
					},
					{
						headerName: 'Owner',
						field: 'Owner',
						width: 150,
						suppressSizeToFit: true,
						cellRendererFramework: AgGridTemplateRendererComponent,
						cellRendererParams: { ngTemplate: this.ownerCell },
					},
				];
				break;
			case 'ContactsAndActivities':
				this.columns = [
					{
						headerName: 'Related To',
						headerTooltip: 'Related To',
						field: 'RelatedTo',
						tooltipValueGetter: (params) => params.value,
						width: 208,
						suppressSizeToFit: true,
						cellRendererFramework: AgGridTemplateRendererComponent,
						cellRendererParams: { ngTemplate: this.relatedToCell },
					},
					{
						headerName: 'Subject',
						headerTooltip: 'Subject',
						field: 'Subject',
						tooltipValueGetter: (params) => params.value,
						width: 310,
						suppressSizeToFit: true,
						cellRendererFramework: AgGridTemplateRendererComponent,
						cellRendererParams: { ngTemplate: this.subjectCell },
					},
					{
						headerName: 'Attendees',
						headerTooltip: 'Attendees',
						width: 402,
						cellRendererFramework: AgGridTemplateRendererComponent,
						cellRendererParams: { ngTemplate: this.attendeesCell },
						suppressSizeToFit: true,
						sortable: false,
					},
					{
						headerName: 'Date',
						field: 'Date',
						cellClass: 'date',
						valueFormatter: Utilities.dateFormatter,
						tooltipValueGetter: (params) => params.valueFormatted,
						width: 151,
						suppressSizeToFit: true,
					},

					{
						headerName: 'Task',
						field: 'Task',
						width: 98,
						cellRenderer: this.renderTaskColumn(),
						suppressSizeToFit: true,
					},
				];
				break;

			default:
				this.columns = [
					{
						headerName: 'Related To',
						field: 'RelatedTo',
						width: 170,
					},
					{
						headerName: 'Subject',
						field: 'Subject',
						width: 400,
						cellRendererFramework: AgGridTemplateRendererComponent,
						cellRendererParams: { ngTemplate: this.subjectCell },
					},
					{
						headerName: 'Date',
						field: 'Date',
						cellClass: 'date',
						valueFormatter: Utilities.dateFormatter,
						width: 200,
					},
					{
						headerName: 'Task',
						field: 'Task',
						width: 100,
						cellRenderer: this.renderTaskColumn(),
					},
					{
						headerName: 'Assigned To',
						field: 'AssignedTo',
						width: 300,
					},
				];
		}
	}

	private openModal(url) {
		this.modalService.openBrowserWindow(url).then(() => this.refreshActivities.next());
	}

	renderTaskColumn() {
		return (cell) => {
			const template = `
          <div class="icon-box flag">
            <div class="top"></div>
            <div class="left"></div>
            <div class="right"></div>
            <div class="bottom"></div>
          </div>
        `;

			return this.isTask(cell.data) ? template : ' ';
		};
	}

	openRelatedTo(activity: ICompletedActivity) {
		ContactsActivitiesHelper.openRelatedTo(activity, this.navigation);
	}

	openActivity(activity: ICompletedActivity) {
		const url = ContactsActivitiesHelper.activityUrl(activity);
		this.openModal(url);
	}

	private isTask(activity: ICompletedActivity) {
		return (activity.Task || '').toLowerCase() === 'task';
	}

	topLinkClickHandler() {
		this.topLinkClicked.emit();
	}

	openAttendee(attendeeId) {
		this.openModal(UrlHelper.dynamicsEditContactUrl(attendeeId));
	}

	openOwner(ownerId) {
		this.openModal(UrlHelper.dynamicsOwnerUrl(ownerId));
	}
}
