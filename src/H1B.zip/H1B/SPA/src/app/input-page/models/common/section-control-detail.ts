export class SectionControlDetail {
  ControlDetail: SubmissionControlDetail[] = [];
  SectionDetail: SubmissionSectionDetail[] = [];
}

export class SubmissionControlDetail {
  ControlName: string;
  ControlType: string;
  SectionName: string;
  SectionType: string;
  TableIndicator: string;
  PatternTypeName?: string;
  MandatoryYN: string;
  VisibleYN: string;
  EditableYN: string;
}

export class SubmissionSectionDetail {
  SectionKey: string;
  SectionName: string;
}
