import { Component, Input, OnInit } from '@angular/core';
import { Select, Store } from '@ngxs/store';
import { CellClickedEvent, ColDef, ICellRendererParams } from 'ag-grid-community';
import { combineLatest, Observable } from 'rxjs';
import { AccountingYearMonth, AccountingYearMonthState } from 'store/accounting-month-year.store';
import { NavigationService } from '../../../services/navigation.service';
import { DateFilterItem, DateFilterSelection } from '../../../shared/date-filter/date-filter.component';
import { MonthName } from '../../../tracking-reporting/reports/reports-header/store/reports-header.model';
import { User } from '../../../user/user.model';
import { DashboardService } from '../../dashboard.service';

@Component({
  selector: 'cb-top-targets',
  templateUrl: './top-targets.component.html',
  styleUrls: ['./top-targets.component.scss'],
})
export class TopTargetsComponent implements OnInit {
  @Input() user: User;
  @Input() includeBranches = false;
  @Input() branches: any[] = [];

  defaultColDef: any = { sortable: true, resizable: true, unSortIcon: true };
  showCustomersBranchList = false;
  showProducerBranchList = false;

  topCustomerTargets: any;
  topProducerTargets: any;

  topCustomerBranch = 'All Branches';
  topProducerBranch = 'All Branches';

  topCustomerBranchList: any[] = [];
  topProducerBranchList: any[] = [];

  customerDateFilter: DateFilterSelection;
  producerDateFilter: DateFilterSelection;

  topCustomerColumns: ColDef[] = [
    {
      headerName: 'Customer',
      headerTooltip: 'Customer',
      field: 'Customer',
      width: 300,
      suppressMovable: true,
      suppressSizeToFit: true,
      tooltipField: 'Customer',
      cellClass: 'cell-wrap-text',
      cellRenderer: (cell: ICellRendererParams) => {
        if (cell.data.ClientID) {
          return `<a href="javascript:void(0);" rel="noopener">${cell.value}</a>`;
        } else {
          return cell.value;
        }
      },
      autoHeight: true,
    },
    {
      headerName: 'Forecast',
      headerTooltip: 'Forecast',
      field: 'Forecast',
      valueFormatter: currencyFormatter,
      tooltipValueGetter: (params) => params.valueFormatted,
      width: 150,
      cellClass: 'numeric currency',
      suppressMovable: true,
      suppressSizeToFit: true,
    },
    {
      headerName: 'Target Count',
      headerTooltip: 'Target Count',
      field: 'TargetCount',
      cellClass: 'numeric',
      headerClass: 'multiline',
      width: 115,
      suppressMovable: true,
      suppressSizeToFit: true,
      tooltipField: 'TargetCount',
    },
  ];

  topProducerColumns: ColDef[] = [
    {
      headerName: 'Producer',
      headerTooltip: 'Producer',
      field: 'Producer',
      width: 300,
      suppressMovable: true,
      suppressSizeToFit: true,
      tooltipField: 'Producer',
      cellClass: 'cell-wrap-text',
      cellRenderer: (params: ICellRendererParams) => `<a href="javascript:void(0);" rel="noopener">${params.value}</a>`,
      autoHeight: true,
    },
    {
      headerName: 'Forecast',
      headerTooltip: 'Forecast',
      field: 'Forecast',
      valueFormatter: currencyFormatter,
      tooltipValueGetter: (params) => params.valueFormatted,
      width: 150,
      cellClass: 'numeric currency',
      suppressMovable: true,
      suppressSizeToFit: true,
    },
    {
      headerName: 'Target Count',
      headerTooltip: 'Target Count',
      field: 'TargetCount',
      width: 115,
      headerClass: 'multiline',
      cellClass: 'numeric',
      suppressMovable: true,
      suppressSizeToFit: true,
      tooltipField: 'TargetCount',
    },
  ];

  dateListPipeline: DateFilterItem[] = [
    { title: 'Next 30 Days', value: 30 },
    { title: 'Next 60 Days', value: 60 },
    { title: 'Next 90 Days', value: 90 },
    { title: 'Next 120 Days', value: 120 },
  ];

  currentDateFilterPipelineIndex = 0;

  producerLoading = false;
  customerLoading = false;

  @Select(AccountingYearMonthState) public accountingYearMonth$: Observable<AccountingYearMonth>;
  accountingYearMonth: AccountingYearMonth;

  constructor(private dashboardService: DashboardService, private store: Store, private navigate: NavigationService) {}

  ngOnInit() {
    combineLatest([this.accountingYearMonth$]).subscribe(([accountingYearMonth]) => {
      this.accountingYearMonth = accountingYearMonth;
      const defaultFilter: DateFilterSelection = {
        month: accountingYearMonth.AccountingMonth as MonthName,
        year: accountingYearMonth.AccountingYear,
        frame: 'MTD',
      };
      this.customerDateFilter = { ...defaultFilter };
      this.producerDateFilter = { ...defaultFilter };
      const payload = {
        Branch: 'All Branches',
        TimeFrame: 'MTD',
        UserID: this.user.UserID,
        ...accountingYearMonth,
        SortBy: '',
        OrderBy: '',
      };
      if (this.isGCE) {
        delete payload.Branch;
        payload.SortBy = 'Forecast';
        payload.OrderBy = 'desc';
        this.dashboardService.getGCETopProducerTargets(payload);
        this.dashboardService.getGCETopCustomerTargets(payload);
      } else {
        this.dashboardService.getTopProducerTargets(payload);
        this.dashboardService.getTopCustomerTargets(payload);
      }
      this.fetchTopCustomers();
      this.fetchTopProducers();
    });
  }

  handleProducerCellClick(e: CellClickedEvent) {
    const colId = e.column.getColId();

    if (colId === 'Producer') {
      const producerName = e.value;
      const ProducerRegion = this.user.CreditedRegion;

      this.navigate.toProducerProfile(producerName, {
        ...(this.includeBranches && this.topProducerBranch != 'All Branches' ? { ProducerBranch: [this.topProducerBranch] } : { ProducerBranch: this.user.CreditedBranch || [] }),
        ProducerRegion,
        showBrowseBy: false,
        extraFilters: {
          ...this.accountingYearMonth,
          TimeFrame: this.producerDateFilter.frame,
        },
      });
    }
  }

  handleCustomerCellClick(e) {
    if (e.data.ClientID) {
      this.navigate.toCustomer(e.data.ClientID, e.data.Customer, {
        showBrowseBy: true,
      });
    }
  }

  showBranches(type) {
    if (type === 'producer') {
      this.showProducerBranchList = !this.showProducerBranchList;
    } else {
      this.showCustomersBranchList = !this.showCustomersBranchList;
    }
  }

  branchSelected(branch, type) {
    let payload;

    if (type === 'producer') {
      payload = this.makePayload(this.producerDateFilter, branch.Branch);

      this.topProducerBranch = branch.Branch;
      this.dashboardService.getTopProducerTargets(payload);
      this.fetchTopProducers();
    } else {
      payload = this.makePayload(this.customerDateFilter, branch.Branch);

      this.topCustomerBranch = branch.Branch;
      this.dashboardService.getTopCustomerTargets(payload);
      this.fetchTopCustomers();
    }
  }

  customerDateFilterSelected(data) {
    const payload = this.makePayload(data, this.topCustomerBranch);
    this.customerDateFilter = data;
    if (this.isGCE) {
      this.dashboardService.getGCETopCustomerTargets(payload);
    } else {
      this.dashboardService.getTopCustomerTargets(payload);
    }
    this.fetchTopCustomers();
  }

  producerDateFilterSelected(data) {
    const payload = this.makePayload(data, this.topProducerBranch);

    this.producerDateFilter = data;
    if (this.isGCE) {
      this.dashboardService.getGCETopProducerTargets(payload);
    } else {
      this.dashboardService.getTopProducerTargets(payload);
    }
    this.fetchTopProducers();
  }

  fetchTopProducers() {
    this.producerLoading = true;
    this.dashboardService.topProducerTargets.subscribe(
      (data) => {
        if (data !== null) {
          this.topProducerTargets = data;
        } else {
          this.topProducerTargets = undefined;
        }
        this.producerLoading = false;
      },
      (err) => {
        this.topProducerTargets = undefined;
        this.producerLoading = false;
      }
    );
  }

  fetchTopCustomers() {
    this.customerLoading = true;
    this.dashboardService.topCustomerTargets.subscribe(
      (data) => {
        if (data !== null) {
          this.topCustomerTargets = data;
        } else {
          this.topCustomerTargets = undefined;
        }
        this.customerLoading = false;
      },
      (err) => {
        this.topCustomerTargets = undefined;
        this.customerLoading = false;
      }
    );
  }

  makePayload(date: DateFilterSelection, branch: string = '') {
    if (this.isGCE) {
      return {
        UserID: this.user.UserID,
        ...this.accountingYearMonth,
        TimeFrame: date.frame,
        SortBy: 'Forecast',
        OrderBy: 'desc',
      };
    } else {
      return {
        UserID: this.user.UserID,
        ...this.accountingYearMonth,
        TimeFrame: date.frame,
        Branch: branch,
      };
    }
  }

  get isGCE() {
    return this.user.UserType === 'Global Client Executive';
  }
}

function currencyFormatter(params) {
  return '$' + formatNumber(params.value);
}

function formatNumber(number) {
  return Math.floor(number)
    .toString()
    .replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
}
