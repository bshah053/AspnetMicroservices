import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { RegionalManagerComponent } from './regional-manager.component';

describe('RegionalManagerComponent', () => {
	let component: RegionalManagerComponent;
	let fixture: ComponentFixture<RegionalManagerComponent>;

	beforeEach(
		waitForAsync(() => {
			TestBed.configureTestingModule({
				declarations: [RegionalManagerComponent],
			}).compileComponents();
		})
	);

	beforeEach(() => {
		fixture = TestBed.createComponent(RegionalManagerComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
