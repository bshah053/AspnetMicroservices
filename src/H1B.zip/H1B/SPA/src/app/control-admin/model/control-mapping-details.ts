export class ControlMappingDetails {
  MappingID?: number;
  Division: string;
  Units: string;
  Segments: string;
  SubGroup: string;
  GroupName: string;
  IsVisible?: Boolean;
  IsRequired?: Boolean;
  CondShowHide?: Boolean;
  ControlLabel: string;
  Comments: string;
  DefaultValue: string;
  IsUpd: string;
  SectionID?: number;
  SectionName: string;
  SectionDisplayOrder?: number;
  ControlDisplayOrder?: number;
  LockEdit: string;
  LockEditDescription: string;
}
