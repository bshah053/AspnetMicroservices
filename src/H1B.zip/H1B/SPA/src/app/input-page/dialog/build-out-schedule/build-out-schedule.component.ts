import { DatePipe } from '@angular/common';
import { Component, OnInit, Inject, HostListener } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators, FormControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FilterType, InputPageService } from 'input-page/services/input-page.service';
import * as moment from 'moment';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { ConfirmationDialogComponent } from 'shared/confirmation-dialog/confirmation-dialog.component';
import { SubmissionPageType } from 'utilities/common-enum-const';
import { Helper } from 'utilities/common-helper';
import { BuildOutScheduleDetails } from './model/build-out-schedule-details';
import { BuildOutScheduleItems } from './model/build-out-schedule-items';

@Component({
  selector: 'build-out-schedule',
  templateUrl: './build-out-schedule.component.html',
  styleUrls: ['./build-out-schedule.component.scss'],
})
export class BuildOutScheduleComponent implements OnInit {
  headerName = '';
  buildOutDetailsFormGroup: FormGroup;
  buildOutScheduleSaveDetails: BuildOutScheduleItems[] = [];
  errorMessage = '';
  accountingMonth: FilterType[] = [];
  accountingYear: FilterType[] = [];
  totalMonthsCount: number;

  constructor(
    private formBuilder: FormBuilder,
    private inputPageService: InputPageService,
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<BuildOutScheduleComponent>,
    @Inject(MAT_DIALOG_DATA)
    public buildOutScheduleDetails: BuildOutScheduleDetails,
    public datepipe: DatePipe
  ) {
    this.buildOutDetailsFormGroup = this.formBuilder.group({
      TotalForecastDisplay: new FormControl({ disabled: true, value: 0 }, { validators: [Validators.nullValidator] }),
      TotalForecast: new FormControl({ disabled: false, value: 0 }, { validators: [Validators.required, Validators.min(1)] }),
      BuildOutDetailsList: this.formBuilder.array([]),
    });
  }

  @HostListener('window:keyup.esc')
  onKeyUp() {
    this.dialogRef.close(null);
  }

  async ngOnInit(): Promise<void> {
    if (this.buildOutScheduleDetails && this.buildOutScheduleDetails.EffectiveDate && this.buildOutScheduleDetails.ExpirationDate) {
      this.headerName = this.buildOutScheduleDetails.ForecastType === 'C' ? 'Custom Build-Out Schedule' : 'Build-Out Schedule';
      await this.loadAllLookUpData();
    }
  }

  public getDifferenceInMonths(): number {
    return Helper.toNumber(Helper.dateDifference('m', this.buildOutScheduleDetails.EffectiveDate, this.buildOutScheduleDetails.ExpirationDate)) + this.getMonthCounts;
  }

  public get getMonthCounts(): number {
    return this.buildOutScheduleDetails.PageType === SubmissionPageType.Construction ? 0 : 3;
  }

  private async loadAllLookUpData() {
    this.totalMonthsCount = this.getDifferenceInMonths();
    this.addPolicyControls();
    this.setMonthYearLookup();
    this.setMonthYearValue();
    this.setMonthYearForecastForCustomType();
    this.enableControlValueChange();
  }

  private setMonthYearLookup() {
    let effectiveDate: any = this.buildOutScheduleDetails.EffectiveDate;
    // let effectiveDate1: any = this.buildOutScheduleDetails.EffectiveDate;
    const totalMonthRequired: number = this.totalMonthsCount < 12 ? this.totalMonthsCount : 11;
    for (let rowIndex = 0; rowIndex <= totalMonthRequired; rowIndex++) {
      const monthName = this.datepipe.transform(effectiveDate, 'MMMM');
      this.accountingMonth.push({ text: monthName, value: monthName });
      effectiveDate = moment(effectiveDate).add(1, 'M');
      // const monthName = this.datepipe.transform(new Date(effectiveDate.setMonth(effectiveDate1.getMonth() + 1)), 'MMMM');
    }

    const expirationDate = this.buildOutScheduleDetails.ExpirationDate;
    const nYears: number = Helper.toNumber(Helper.dateDifference('yyyy', this.buildOutScheduleDetails.EffectiveDate, moment(expirationDate).add(this.getMonthCounts, 'M')));
    const effectiveDateYear: number = Helper.toNumber(this.datepipe.transform(this.buildOutScheduleDetails.EffectiveDate, 'yyyy'));
    if (nYears > 0) {
      for (let index = 0; index <= nYears; index++) {
        this.accountingYear.push({
          text: String(effectiveDateYear + index),
          value: String(effectiveDateYear + index),
        });
      }
    } else {
      this.accountingYear.push({
        text: String(effectiveDateYear),
        value: String(effectiveDateYear),
      });
    }
  }

  private setMonthYearValue() {
    let effectiveDate: any = this.buildOutScheduleDetails.EffectiveDate;
    for (let rowIndex = 0; rowIndex <= this.totalMonthsCount; rowIndex++) {
      const monthName = moment(effectiveDate).format('MMMM');
      const monthYear = moment(effectiveDate).format('YYYY');
      this.setControlsValue(rowIndex, 0, monthName, monthYear);
      effectiveDate = moment(effectiveDate).add(1, 'M');
      if (this.buildOutScheduleDetails.BuildOutSchedule.length > 0) {
        this.setForecastRecordNumberByMonthYear(rowIndex, monthName, monthYear);
      } else {
        this.setControlsValue(rowIndex, 0, monthName, monthYear);
      }
    }
  }

  private setMonthYearForecastForCustomType() {
    if (this.buildOutScheduleDetails.BuildOutSchedule.length > 0) {
      if (this.buildOutScheduleDetails.ForecastType === 'C') {
        for (let rowIndex = 0; rowIndex < this.buildOutScheduleDetails.BuildOutSchedule.length; rowIndex++) {
          this.setControlsValue(rowIndex, this.buildOutScheduleDetails.BuildOutSchedule[rowIndex].RecordNumber, this.buildOutScheduleDetails.BuildOutSchedule[rowIndex].AccountingMonth, this.buildOutScheduleDetails.BuildOutSchedule[rowIndex].AccountingYear, this.buildOutScheduleDetails.BuildOutSchedule[rowIndex].Forecast);
        }
      }
      this.setTotalForecast();
    }
  }

  private setForecastRecordNumberByMonthYear(rowIndex, monthName, monthYear) {
    const filteredValueList: BuildOutScheduleItems[] = this.buildOutScheduleDetails.BuildOutSchedule.filter((element) => {
      return element.AccountingMonth === monthName && element.AccountingYear === monthYear;
    });
    if (filteredValueList && filteredValueList.length > 0) {
      this.setControlsValue(rowIndex, filteredValueList[0].RecordNumber, monthName, monthYear, filteredValueList[0].Forecast);
    } else {
      this.setControlsValue(rowIndex, 0, monthName, monthYear, 0);
    }
  }

  private setControlsValue(rowIndex: number, recordNumber: number = 0, monthName: string, monthYear: string, forecast: number = 0) {
    if (rowIndex < this.buildOutDetails.length) {
      this.buildOutDetails.controls[rowIndex].patchValue(
        {
          RecordNumber: recordNumber,
          AccountingMonth: monthName,
          AccountingYear: monthYear,
          Forecast: forecast,
        },
        { emitEvent: false }
      );
    }
  }

  enableControlValueChange() {
    const valueChangedControls = ['Forecast', 'AccountingMonth', 'AccountingYear'];
    for (let controlIndex = 0; controlIndex < this.buildOutDetails.length; controlIndex++) {
      valueChangedControls.forEach((controlName) => {
        this.buildOutDetails.controls[controlIndex]
          .get(controlName)
          .valueChanges.pipe(debounceTime(100), distinctUntilChanged())
          .subscribe((controlValue) => {
            this.customValidation(controlName, controlIndex);
          });
      });
    }
  }

  private customValidation(controlName: string, controlIndex: number) {
    if (controlName === 'Forecast') {
      this.setTotalForecast();
    } else if (controlName === 'AccountingMonth' || controlName === 'AccountingYear') {
      this.validateMonthYearUnique(controlIndex, true);
    }
  }

  private setTotalForecast() {
    let totalForecastValue: number = this.BuildOutDetailsList.map((element) => element.Forecast).reduce((a, b) => {
      return a + b;
    });

    this.buildOutDetailsFormGroup.patchValue(
      {
        TotalForecast: totalForecastValue,
        TotalForecastDisplay: totalForecastValue,
      },
      { emitEvent: false }
    );
  }

  validateMonthYearUnique(controlIndex: number, isMonthOrYearChange: boolean = false) {
    this.errorMessage = '';
    const filteredValueList = this.BuildOutDetailsList.filter((element) => {
      return element.AccountingMonth === this.buildOutDetails.controls[controlIndex].get('AccountingMonth').value && element.AccountingYear === this.buildOutDetails.controls[controlIndex].get('AccountingYear').value;
    });
    if (filteredValueList && filteredValueList.length > 1) {
      this.setControlsValue(controlIndex, 0, '', '');
      if (isMonthOrYearChange) {
        this.errorMessage = 'Forecast values should be Unique';
      }
    }
  }

  addPolicyControls() {
    if (this.buildOutScheduleDetails.ForecastType === 'C' && this.buildOutScheduleDetails.BuildOutSchedule.length > 0) {
      for (let index = 0; index <= this.buildOutScheduleDetails.BuildOutSchedule.length - 1; index++) {
        this.buildOutDetails.push(this.createBuildOutDetails());
      }
    } else if (this.buildOutScheduleDetails.ForecastType === 'M') {
      for (let index = 0; index <= this.totalMonthsCount; index++) {
        this.buildOutDetails.push(this.createBuildOutDetails());
      }
    } else {
      this.buildOutDetails.push(this.createBuildOutDetails());
    }
  }

  get buildOutDetails() {
    return this.buildOutDetailsFormGroup.get('BuildOutDetailsList') as FormArray;
  }

  get BuildOutDetailsList(): BuildOutScheduleItems[] {
    return this.buildOutDetailsFormGroup.getRawValue().BuildOutDetailsList;
  }

  addBuildOutDetails() {
    this.errorMessage = '';
    if (this.totalMonthsCount >= this.buildOutDetails.length) {
      this.buildOutDetails.push(this.createBuildOutDetails());
      this.enableControlValueChange();
      const controlIndex = this.buildOutDetails.length - 1;
      let effectiveDate: any = this.buildOutScheduleDetails.EffectiveDate;
      const monthName = moment(effectiveDate)
        .add(controlIndex, 'M')
        .format('MMMM');
      const monthYear = moment(effectiveDate)
        .add(controlIndex, 'M')
        .format('YYYY');
      this.setControlsValue(controlIndex, 0, monthName, monthYear);
      this.validateMonthYearUnique(controlIndex);
    } else {
      this.errorMessage = 'Forecast values should be valid based on the Eff date and Exp date';
    }
  }

  removeBuildOutDetails(controlIndex) {
    this.errorMessage = '';
    if (this.buildOutDetails.length > 1) {
      if (this.buildOutScheduleDetails.RecordNumber > 0 && this.buildOutScheduleDetails.RecordNumber === this.buildOutDetails.controls[controlIndex].get('RecordNumber').value) {
        this.errorMessage = 'The Accounting month row which you are trying to delete is mapped to this currently opened active record. Deleting this row might lead to record conflicts. Kindly open a different accounting month record for the same policy and try to perform the row delete.';
      } else {
        const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
          width: '510px',
          data: { Action: 'Delete' },
          hasBackdrop: true,
          backdropClass: 'backdropBackground',
        });

        dialogRef.afterClosed().subscribe((result) => {
          if (result && Helper.isStringNotNullAndEmpty(result.Action)) {
            if (result.Action === 'Delete confirm') {
              this.buildOutDetails.removeAt(controlIndex);
              this.setTotalForecast();
              this.enableControlValueChange();
            }
          }
        });
      }
    }
  }

  createBuildOutDetails() {
    return this.formBuilder.group({
      RecordNumber: new FormControl({
        disabled: true,
        value: 0,
      }),
      AccountingMonth: new FormControl(
        {
          disabled: this.buildOutScheduleDetails.ForecastType === 'M' ? true : false,
          value: '',
        },
        {
          validators: [Validators.required],
        }
      ),
      AccountingYear: new FormControl(
        {
          disabled: this.buildOutScheduleDetails.ForecastType === 'M' ? true : false,
          value: '',
        },
        {
          validators: [Validators.required],
        }
      ),
      Forecast: new FormControl(0, {
        validators: this.buildOutScheduleDetails.ForecastType === 'C' ? [Validators.required, Validators.min(1)] : [Validators.nullValidator],
        updateOn: 'change',
      }),
      BaseRecordFlag: new FormControl({
        disabled: true,
        value: 0,
      }),
    });
  }

  handleCancel(): void {
    this.dialogRef.close(null);
  }

  handleClear() {
    this.errorMessage = '';
    this.buildOutDetailsFormGroup.patchValue(
      {
        TotalForecast: 0,
        TotalForecastDisplay: 0,
      },
      { emitEvent: false }
    );
    for (let rowIndex = 0; rowIndex < this.buildOutDetails.length; rowIndex++) {
      this.buildOutDetails.controls[rowIndex].patchValue(
        {
          Forecast: 0,
        },
        { emitEvent: false }
      );
    }
    this.buildOutDetailsFormGroup.markAsPristine();
    this.buildOutDetailsFormGroup.markAsUntouched();
  }

  handleSave() {
    this.errorMessage = '';
    console.log(this.buildOutDetailsFormGroup.getRawValue());
    if (this.buildOutDetailsFormGroup.invalid) {
      if (this.buildOutScheduleDetails.ForecastType === 'C') {
        for (let rowIndex = 0; rowIndex < this.buildOutDetails.length; rowIndex++) {
          if (this.buildOutDetails.controls[rowIndex].get('AccountingMonth').invalid) {
            this.errorMessage = 'Accounting Month value cannot be empty';
            return;
          } else if (this.buildOutDetails.controls[rowIndex].get('AccountingYear').invalid) {
            this.errorMessage = 'Accounting Year value cannot be empty';
            return;
          } else if (this.buildOutDetails.controls[rowIndex].get('Forecast').invalid) {
            this.errorMessage = 'Forecast values cannot be zero/empty';
            return;
          }
        }
      } else {
        this.errorMessage = 'Forecast values cannot be zero/empty';
        return;
      }
    }
    this.buildOutScheduleSaveDetails = this.BuildOutDetailsList;
    this.dialogRef.close(this.buildOutScheduleSaveDetails);
  }
}
