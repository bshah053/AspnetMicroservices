import { Route } from '@angular/router';
import { MsalGuard } from '@azure/msal-angular';

import { ContactsActivitiesComponent } from '../contacts-activities/contacts-activities.component';
import { ActivitiesSearchComponent } from '../contacts-activities/search/activities-search/activities-search.component';
import { ContactsSearchComponent } from '../contacts-activities/search/contacts-search/contacts-search.component';

export const ContactActivitiesRoutes: Route[] = [
	{
		path: '',
		canActivate: [MsalGuard],
		canActivateChild: [MsalGuard],
		children: [
			{
				path: '',
				component: ContactsActivitiesComponent,
			},
			{
				path: 'search',
				component: ActivitiesSearchComponent,
			},
			{
				path: 'contact-search',
				component: ContactsSearchComponent,
			},
		],
	},
];
