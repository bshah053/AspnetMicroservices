import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'cb-form-container',
  templateUrl: './form-container.component.html',
  styleUrls: ['./form-container.component.scss'],
})
export class FormContainerComponent implements OnInit {
  @Input() isShowContent: boolean = false;
  constructor() {}

  ngOnInit(): void {}
}
