import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

import { SharedService } from 'services/shared.service';
import { UrlService } from 'services/url.service';

@Component({
  selector: 'cb-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.scss'],
})
export class LandingPageComponent implements OnInit {
  previousUrl: Observable<string> = this.urlService.previousUrl$;

  constructor(private router: Router, private urlService: UrlService, private sharedService: SharedService) {
    // this.sharedService.sendHeaderVisibilityStatus(true);
  }

  ngOnInit(): void {
    console.log('redirecting to dashboard Page');
    this.urlService.previousUrl$.subscribe((previousUrl: string) => {
      console.log('currentUrl: ', this.router.url);
      console.log('previous url: ', previousUrl);
      if (this.router.url === '/' && previousUrl === null) {
        // this.sharedService.sendHeaderVisibilityStatus(false);
        this.router.navigate(['/dashboard']);
      } else {
        // this.sharedService.sendHeaderVisibilityStatus(false);
      }
    });
  }
}
