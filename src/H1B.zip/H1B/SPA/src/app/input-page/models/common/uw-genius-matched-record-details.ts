export interface UWGeniusMatchedRecordDetails {
  RecordNumber?: number;
  GroupName: string;
  SubGroup: string;
  Division: string;
  Insured: string;
  EffectiveDate: Date;
  Type: string;
  Status: string;
  Product: string;
  Producer: string;
}
