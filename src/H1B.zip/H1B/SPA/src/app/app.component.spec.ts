import { TestBed, ComponentFixture, waitForAsync } from '@angular/core/testing';
import { AppComponent } from './app.component';
import { ComponentsModule } from './components/components.module';

describe('AppComponent', () => {
	let component: AppComponent;
	let fixture: ComponentFixture<AppComponent>;

	beforeEach(
		waitForAsync(() => {
			TestBed.configureTestingModule({
				declarations: [AppComponent],
				imports: [ComponentsModule],
			}).compileComponents();
		})
	);

	beforeEach(() => {
		fixture = TestBed.createComponent(AppComponent);
		component = fixture.debugElement.componentInstance;
	});

	test(
		`should create the app`,
		waitForAsync(() => {
			expect(1).toBe(1);
			expect(component).toBeTruthy();
		})
	);

	test(
		`should have as title 'app'`,
		waitForAsync(() => {
			expect(component.title).toEqual('app');
		})
	);

	test(
		`should render welcome card title in a 'crux-card-header-title' tag`,
		waitForAsync(() => {
			const compiled = fixture.debugElement.nativeElement;
			expect(compiled.querySelector('crux-card-header-title').textContent).toContain('Welcome to CRUX');
		})
	);

	test(
		`should render welcome card subtitle in a 'crux-card-header-sub-title' tag`,
		waitForAsync(() => {
			const compiled = fixture.debugElement.nativeElement;
			expect(compiled.querySelector('crux-card-header-sub-title').textContent).toContain('CRUX (Chubb Responsive User Experience)');
		})
	);

	test(
		`should render welcome card content in 'crux-card-content' tag`,
		waitForAsync(() => {
			const compiled = fixture.debugElement.nativeElement;
			const welcomeCardContent = ['Component Documentation', 'Component Development Guidelines', 'Roadmap', 'Feature Development Workflow'];

			for (const content of welcomeCardContent) {
				expect(compiled.querySelector('crux-card-content').textContent).toContain(content);
			}
		})
	);
});
