import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';

import { UrlHelper } from '../../utilities/url.helper';
import { environment } from '../../../environments/environment';
import { ReportFilters } from '../../tracking-reporting/reports/reports-header/reports-header.component';
import { FilterWatchService } from '../../services/filter-watch.service';
import { ReportingService } from '../../tracking-reporting/services/reporting.service';
import { SharedService } from 'services/shared.service';
import { User } from 'user/user.model';
import { GraphService } from 'services/graph.service';
import { MatDialog } from '@angular/material/dialog';
import { SearchBarDialogComponent } from 'shared/header/search-bar-dialog/search-bar-dialog.component';
import { Helper } from 'utilities/common-helper';
import { MoreFilters } from 'tracking-reporting/reports/more-filters/more-filters.component';

@Component({
  selector: 'cb-header-component',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  providers: [],
})
export class HeaderComponent implements OnInit {
  @Input() user: User;
  @Output() sidenavToggle = new EventEmitter<void>();
  imageUrl: any;
  open;
  isSelected;
  loading = false;
  sharedServiceSub$: Subscription;
  adminUrl = `${environment.tracker1Url}/Admin/Admin_User_Configuration.aspx`;
  editUrl = `${environment.tracker1Url}/MyTracker/Edit_profile_Tracker2.aspx`;
  filters: ReportFilters = {} as ReportFilters;
  moreFilters?: Partial<MoreFilters> = {};
  headSelected;
  insuredNameList;
  activeLink = [true, false, false];

  constructor(private router: Router, private filterWatch: FilterWatchService, private reportService: ReportingService, private sharedService: SharedService, private graphService: GraphService, public dialog: MatDialog) {
    this.sharedServiceSub$ = this.sharedService.setLoading().subscribe((isLoading) => {
      setTimeout(() => {
        this.loading = isLoading;
      }, 0);
    });
  }

  ngOnInit(): void {
    this.graphService.getUserPhoto().subscribe((imageUrl) => (this.imageUrl = imageUrl));
  }

  get tracker1Login() {
    return UrlHelper.tracker1LoginUrl();
  }

  get isNotDynamicUser() {
    return this.user['DynamicUser'] === 'No';
  }

  get isDynamicUser() {
    return this.user['DynamicUser'] === 'Yes';
  }

  get isUserTypeUM() {
    return this.user['UserType'] === 'Underwriter Manager';
  }

  get isUserTypeMG() {
    return this.user['UserType'] === 'Manager General';
  }

  get isOpened(): boolean {
    return this.open;
  }

  get isUserAdmin(): boolean {
    let userRole = this.user['MenuMapDetails'].filter((element) => element.MenuDescription == 'User Admin')[0];
    return userRole && userRole.IsUserPermissible == 'Y' ? true : false;
  }

  get isControlAdmin(): boolean {
    let userRole = this.user['MenuMapDetails'].filter((element) => element.MenuDescription == 'Control Admin')[0];
    return userRole && userRole.IsUserPermissible == 'Y' ? true : false;
  }

  handleToggleOpen(): void {
    this.open = !this.open;
    if (this.open) this.isSelected = true;
    else this.isSelected = false;
  }

  handleHide(): void {
    this.open = this.isSelected;
  }

  handleSelection(): void {
    this.open = false;
  }

  showSearchBarDialog() {
    const dialogRef = this.dialog.open(SearchBarDialogComponent, {
      width: '900px',
      maxHeight: '500px',
      position: { right: '50px', top: '50px' },
      hasBackdrop: true,
      backdropClass: 'backdropBackground',
    });

    dialogRef.afterClosed().subscribe((selectedItem) => {
      if (selectedItem !== null) {
        this.toInsuredSearchReport(selectedItem.searchValue, selectedItem.searchType);
      }
    });
  }

  toInsuredSearchReport(searchValue: string, searchType: string) {
    if (Helper.isStringNotNullAndEmpty(searchValue)) {
      this.filters.InsuredName = [];
      this.filters.PolicyNumber = [];
      this.moreFilters.RecordNo = '';
      this.filters.InsulLogic = 'Y';
      this.filters.WildCardSearchText = '';
      this.filters.moreFilters = this.moreFilters;
      if (searchType == 'Insured Name') {
        this.filters.InsuredName = [searchValue];
      } else if (searchType == 'Policy Number') {
        this.filters.PolicyNumber = [searchValue];
      } else if (searchType == 'Record Number') {
        // this.filters.RecordNo = Number(searchValue);
        this.moreFilters.RecordNo = searchValue;
        this.filters.moreFilters = this.moreFilters;
      } else {
        this.filters.WildCardSearchText = searchValue;
      }

      this.router.navigate(['/tracking-and-reporting/insured-search'], {
        queryParams: {
          filters: this.filterWatch.create(this.filters),
          showBrowseBy: true,
        },
        queryParamsHandling: 'merge',
      });
    }
  }
}
