import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { AdvancedSortPopupComponent } from './advanced-sort-popup.component';

describe('AdvancedSortPopupComponent', () => {
	let component: AdvancedSortPopupComponent;
	let fixture: ComponentFixture<AdvancedSortPopupComponent>;

	beforeEach(
		waitForAsync(() => {
			TestBed.configureTestingModule({
				declarations: [AdvancedSortPopupComponent],
			}).compileComponents();
		})
	);

	beforeEach(() => {
		fixture = TestBed.createComponent(AdvancedSortPopupComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
