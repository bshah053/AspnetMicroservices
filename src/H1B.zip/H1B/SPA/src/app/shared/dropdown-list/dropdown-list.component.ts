import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChange,
  ViewEncapsulation,
} from '@angular/core';
import { ListItem } from '../radio-list/radio-list.component';

@Component({
  selector: 'cb-dropdown-list',
  templateUrl: './dropdown-list.component.html',
  styleUrls: ['./dropdown-list.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class DropdownListComponent implements OnInit, OnChanges {
  @Output() selectItem: EventEmitter<ListItem> = new EventEmitter<ListItem>();

  @Input() items: Array<ListItem> = [];
  @Input() defaultItem: ListItem;
  @Input() value = null;
  @Input() display: 'text' | 'value' = 'text';
  @Input() isReportHeaderBar = false;
  text: string;

  constructor() {}

  ngOnInit() {}

  ngOnChanges(
    changes: { [key in keyof DropdownListComponent]: SimpleChange }
  ): void {
    if (changes.value || changes.items) {
      const item =
        this.items.find(
          (i) => i.value === this.value || i.text === '' + this.value
        ) || this.defaultItem;
      this.text = item ? item[this.display] : this.text;
    }
  }

  onSelectItem(event, item: ListItem) {
    this.value = item.value;
    this.text = item[this.display];
    this.selectItem.next(item);
  }
}
