export interface EscalationDetailItem {
  EscalateComments: string;
  IsEscalate: string;
}
