export interface SubmissionHelperResponseItem {
  BrokerBranch: string;
  BrokerCity: string;
  BrokerRegion: string;
  ServiceRegion: string;
  DnBSICDescription: string;
  ExpiringNetForecast?: number;
  ForecastType: string;
  GrossPremium?: number;
  IndustryPractice: string;
  IndustryPracticeDescription: string;
  NetForecast?: number;
  PortFolioClass: string;
  PrimaryIndustry: string;
  Product: string;
  REHIndicator?: number;
  RiskSICDescription: string;
  SubSegment: string;
  TargetType?: string;
  UWRegion: string;
  Unit: string;
  RateChange?: number;
  ExposureChange?: number;
}
