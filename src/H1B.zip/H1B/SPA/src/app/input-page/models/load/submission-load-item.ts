import {
  DataElementsControlDetailsItem,
  DataElementsDetails,
} from './data-elements-control-details-item';
import { HeaderDetailsItem } from './header-details-item';
import { FooterDetailsItem } from './footer-details-item';
import { MetadataDetailsItem } from './metadata-details-item';
import { LookupDataElementItem } from '../lookup/lookup-data-element-item';

export interface SubmissionLoadItem {
  DataElementsControlDetailsItem: DataElementsControlDetailsItem[];
  ControlsElementsDetails: DataElementsDetails[];
  HeaderDetailsItem: HeaderDetailsItem;
  FooterDetailsItem: FooterDetailsItem;
  MetadataDetailsItem: MetadataDetailsItem;
  LookupDetailsItem: LookupDataElementItem[];
}
