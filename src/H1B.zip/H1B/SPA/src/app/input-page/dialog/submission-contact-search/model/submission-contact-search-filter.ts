export interface SubmissionContactSearchFilter {}
