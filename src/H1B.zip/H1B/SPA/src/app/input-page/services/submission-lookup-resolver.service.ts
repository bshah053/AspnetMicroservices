import { Inject, Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { Select } from '@ngxs/store';
import { combineLatest, Observable } from 'rxjs';

import { FilterWatchService } from 'services/filter-watch.service';
import { User } from 'user/user.model';
import { UserState } from 'user/user.store';
import { InputPageService } from './input-page.service';

@Injectable({
  providedIn: 'root',
})
export class SubmissionLookupResolverService implements Resolve<any> {
  storedFilters;
  private _routedFrom: string;
  public get routedFrom(): string {
    return this._routedFrom;
  }
  public set routedFrom(value: string) {
    this._routedFrom = value;
  }
  @Select(UserState) public user$: Observable<User>;
  user: User;

  constructor(
    private inputPageService: InputPageService,
    @Inject(FilterWatchService) private filterWatch: FilterWatchService
  ) {
    combineLatest([this.user$]).subscribe(([user]) => {
      this.user = user;
    });
  }

  resolve(activatedRoute: ActivatedRouteSnapshot): Observable<any> {
    // this.storedFilters = this.filterWatch.getByHash(
    //   activatedRoute.queryParams.filters
    // );
    // this.routedFrom = activatedRoute.queryParams.routedFrom;
    // console.log(this.storedFilters);
    // const payload = this.generatePayload();
    // return this.inputPageService.getAllLookUp(payload);
    return null;
  }

  private generatePayload() {
    if (this.storedFilters) {
      return {
        UserID: this.user.UserID || this.storedFilters.UserID,
        Division: this.storedFilters.Division
          ? this.storedFilters.Division[0]
          : '',
        Unit: this.storedFilters.Unit ? this.storedFilters.Unit[0] : '',
        Segment: this.storedFilters.Segment
          ? this.storedFilters.Segment[0]
          : '',
        RecordNumber: this.storedFilters.RecordNo
          ? this.storedFilters.RecordNo
          : 0,
        GeniusPipeID: this.storedFilters.GeniusPipeID
          ? this.storedFilters.GeniusPipeID
          : 0,
        RoutedFrom: this.routedFrom,
      };
    } else {
      return {};
    }
  }
}
