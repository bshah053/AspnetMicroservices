import { Injectable, Optional, Inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';

const httpOptions = {
  headers: new HttpHeaders({
    Accept: 'application/json',
    'Content-Type': 'application/json',
  }),
};

type Method = 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH' | 'OPTIONS';

@Injectable({
  providedIn: 'root',
})
export class ApiService {
  constructor(
    private httpClient: HttpClient,
    @Optional()
    @Inject('')
    public prefix?: string
  ) {}

  private endpoint(resourceUrl: string) {
    return [environment.apiUrl, this.prefix, resourceUrl].join('');
  }

  private request(
    method: Method,
    resourceUrl: string,
    params?,
    payload?,
    options = httpOptions
  ) {
    options['body'] = payload;
    options['params'] = params;
    return this.httpClient.request(method, this.endpoint(resourceUrl), options);
  }

  public get(resourceUrl: string, params?, options?) {
    return this.request('GET', resourceUrl, params, options);
  }

  public post(resourceUrl: string, params?, payload?, options?) {
    return this.request('POST', resourceUrl, params, payload, options);
  }

  public put(resourceUrl: string, params?, payload?, options?) {
    return this.request('PUT', resourceUrl, params, payload, options);
  }

  public delete(resourceUrl: string, params?, options?) {
    return this.request('DELETE', resourceUrl, params, options);
  }

  public options(resourceUrl: string, params?, options?) {
    return this.request('OPTIONS', resourceUrl, params, options);
  }
  public getFile(resourceUrl: string, payload) {
    return this.httpClient.post(this.endpoint(resourceUrl), payload, {
      responseType: 'blob',
      reportProgress: true,
      observe: 'events',
    });
  }
}
