import { SegmentsOptionsItems } from './segments-items';

export interface SegmentsOptionsGroupItems {
  groupName?: string;
  options?: SegmentsOptionsItems[];
  displayOrder?: number;
  disabled?: boolean;
}
