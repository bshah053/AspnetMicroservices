import { Component, EventEmitter, Input, Output } from '@angular/core';
import { ModalService } from '../../shared/modal/modal.service';
import { UrlHelper } from '../../utilities/url.helper';
import { IContact } from '../models/contact';
import { Router } from '@angular/router';
import { SetContactSearchFilters } from '../store/contacts-activities.actions';
import { Store } from '@ngxs/store';

@Component({
  selector: 'cb-contacts',
  templateUrl: './contacts.component.html',
  styleUrls: ['./contacts.component.scss'],
})
export class ContactsComponent {
  @Input() loading: boolean;
  @Input() list: IContact[] = [];
  @Output() search = new EventEmitter<string>();
  @Input() showAdd = true;

  searchQuery = '';

  get dynamicsLink() {
    return UrlHelper.dynamicsContactUrl();
  }

  constructor(
    private store: Store,
    private router: Router,
    private modalService: ModalService
  ) {}

  seeAll() {
    this.store.dispatch(
      new SetContactSearchFilters({
        ContactName: this.searchQuery,
      })
    );
    this.router.navigate(['/contacts-and-activities/contact-search']);
  }

  searchBy(query: string): void {
    this.searchQuery = query;
    this.list = [];
    this.emitSearch();
  }

  private emitSearch() {
    if (this.searchQuery) {
      this.search.emit(this.searchQuery);
    }
  }

  addNewContact() {
    this.openUrlWithRefreshOnClose(this.dynamicsLink);
  }

  openContact(contactId) {
    this.openUrlWithRefreshOnClose(UrlHelper.dynamicsEditContactUrl(contactId));
  }

  openUrlWithRefreshOnClose(url) {
    this.modalService.openBrowserWindow(url).then(() => this.emitSearch());
  }
}
