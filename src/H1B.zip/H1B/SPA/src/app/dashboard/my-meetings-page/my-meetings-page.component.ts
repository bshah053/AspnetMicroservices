import { Component, AfterViewInit } from '@angular/core';
import { Select } from '@ngxs/store';
import { Observable } from 'rxjs';
import { User } from '../../user/user.model';
import { UserState } from '../../user/user.store';
import { RelationshipService } from '../../contacts-activities/relationship.service';
import { IMeeting } from '../../shared/meetings/models';
import { ListItem } from '../../shared/radio-list/radio-list.component';
import * as moment from 'moment';
import { CalendarMeetingModel } from './calendar-view/calendar-view.component';
import { ModalService } from '../../shared/modal/modal.service';
import { UrlHelper } from '../../utilities/url.helper';

export type MyMeetingsViewByType =
  | 'My Branch'
  | 'My Region'
  | 'My Underwriters'
  | 'My Meetings';
export type MyMeetingsSortByType = 'Today' | 'Tomorrow' | '5days';

export interface IMyMeetingsPayload {
  UserID: string;
  ViewBy: MyMeetingsViewByType;

  SortBy?: MyMeetingsSortByType;

  PageNumber: number;
  PageSize: number;
}
export interface ICalendarMeetingsPayload {
  UserID: string;
  FromDate: string;
  ToDate: string;
}

interface CalendarMeetingsResponse {
  MeetingGUID: string;
  StartDate: string;
  EndDate: string;
  Subject: string;
  Location: string;
  OptionalAttendees: string;
  RequiredAttendees: string;
}

@Component({
  selector: 'cb-my-meeting-page',
  templateUrl: './my-meetings-page.component.html',
  styleUrls: ['./my-meetings-page.component.scss'],
})
export class MyMeetingsPageComponent implements AfterViewInit {
  @Select(UserState) public user$: Observable<User>;

  user: User;

  selectedWeekStart: moment.Moment = moment(Date.now()).day(0);
  selectedDate: moment.Moment = moment(Date.now());
  selectedMonth: moment.Moment = moment(Date.now());
  today: moment.Moment = moment(Date.now());

  meetingsLoading = true;
  meetingsError = '';

  meetingsPayload: IMyMeetingsPayload;
  meetingsList: IMeeting[];
  meetingsViewBy;
  meetingsSortBy = [
    { text: '5 Days', value: '5days' },
    { text: 'Tomorrow', value: 'Tomorrow' },
    { text: 'Today', value: 'Today' },
  ];

  viewByUserType = {
    'Regional Manager': 'My Region',
    'Underwriter Manager': 'My Underwriters',
    'Branch Manager': 'My Branch',
  };

  calendarMeetings: CalendarMeetingModel[] = [];
  monthMeetings: CalendarMeetingModel[] = [];

  constructor(
    private relationshipService: RelationshipService,
    private modalService: ModalService
  ) {
    this.user$.subscribe((user) => {
      this.user = user;

      this.meetingsPayload = this.createInitialPayloadForMeetings();
      this.meetingsViewBy = this.createViewByList(user.UserType);

      this.fetchPageData();
    });
  }

  ngAfterViewInit(): void {
    window.scrollTo(0, 0);
  }

  private fetchPageData(): void {
    this.fetchMyMeetings();
    this.loadCalendarMeetings();
    this.loadMonthMeetings();
  }

  private createInitialPayloadForMeetings(): IMyMeetingsPayload {
    const payload: IMyMeetingsPayload = {
      UserID: this.user.UserID,
      ViewBy: this.viewByUserType[this.user.UserType] || 'My Meetings',
      SortBy: '5days',
      PageNumber: 0,
      PageSize: 0,
    };

    return payload;
  }

  private createViewByList(userType: string) {
    const item = this.viewByUserType[userType];

    if (!item) {
      return;
    }

    return [
      { value: item, text: item },
      { value: 'My Meetings', text: 'My Meetings' },
    ];
  }

  meetingsViewByChanged(item: ListItem) {
    this.meetingsPayload.ViewBy = item.value;
    this.fetchMyMeetings();
  }

  meetingsSortByChanged(item: ListItem) {
    this.meetingsPayload.SortBy = item.value;
    this.fetchMyMeetings();
  }

  fetchMyMeetings() {
    this.meetingsLoading = true;
    this.meetingsError = '';

    this.relationshipService
      .getMeetingsForMyMeetingsPage(this.meetingsPayload)
      .subscribe(
        (data: IMeeting[]) => {
          if (data !== null) {
            this.meetingsLoading = false;
            this.meetingsList = data;
          } else {
            this.meetingsLoading = false;
            this.meetingsList = [];
          }
        },
        (err) => {
          this.meetingsLoading = false;
          this.meetingsError = 'You have no meetings';
          this.meetingsList = undefined;
        }
      );
  }

  refresh() {
    this.fetchPageData();
  }

  addMeeting() {
    this.modalService
      .openBrowserWindow(UrlHelper.dynamicsMeetingUrl())
      .then(() => {
        this.fetchPageData();
      });
  }
  handleOpenMeeting(guid: string) {
    this.modalService
      .openBrowserWindow(UrlHelper.dynamicsEditMeetingUrl(guid))
      .then(() => {
        this.fetchPageData();
      });
  }
  handleWeekStartChange(date: moment.Moment) {
    this.selectedWeekStart = date;
    this.loadCalendarMeetings();
  }
  handleSelectedDateChange(date: moment.Moment) {
    this.selectedDate = date;
    const weekStart = moment(date).day(0);
    if (!weekStart.isSame(this.selectedWeekStart, 'day')) {
      this.selectedWeekStart = weekStart;
      this.loadCalendarMeetings();
    }
    if (!date.isSame(this.selectedMonth, 'month')) {
      this.selectedMonth = date;
      this.loadMonthMeetings();
    }
  }
  handleSelectedMonthChange(date: moment.Moment) {
    this.selectedMonth = date;
    this.loadMonthMeetings();
  }
  loadCalendarMeetings() {
    this.relationshipService
      .getCalendarMeetings({
        UserID: this.user.UserID,
        FromDate: moment(this.selectedWeekStart)
          .day(0)
          .format('MM/DD/YYYY'),
        ToDate: moment(this.selectedWeekStart)
          .day(7)
          .format('MM/DD/YYYY'),
      })
      .subscribe((meetings: CalendarMeetingsResponse[]) => {
        if (meetings !== null) {
          this.calendarMeetings = this.mapMeetingsResponse(meetings);
        } else {
          this.calendarMeetings = [];
        }
      });
  }
  loadMonthMeetings() {
    this.relationshipService
      .getCalendarMeetings({
        UserID: this.user.UserID,
        FromDate: moment(this.selectedMonth)
          .date(1)
          .format('MM/DD/YYYY'),
        ToDate: moment(this.selectedMonth)
          .endOf('month')
          .add(1, 'day')
          .format('MM/DD/YYYY'),
      })
      .subscribe((meetings: CalendarMeetingsResponse[]) => {
        if (meetings !== null) {
          this.monthMeetings = this.mapMeetingsResponse(meetings);
        } else {
          this.monthMeetings = [];
        }
      });
  }
  private mapMeetingsResponse(
    meetings: CalendarMeetingsResponse[]
  ): CalendarMeetingModel[] {
    return meetings.map((m) => ({
      id: m.MeetingGUID,
      from: m.StartDate,
      to: m.EndDate,
      subject: m.Subject,
      location: m.Location,
      attendees: {
        required: m.RequiredAttendees ? m.RequiredAttendees.split(',') : [],
        optional: m.OptionalAttendees ? m.OptionalAttendees.split(',') : [],
      },
    }));
  }
}
