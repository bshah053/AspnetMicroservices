export interface BuildOutScheduleItems {
  RecordNumber?: number;
  AccountingMonth?: string;
  AccountingYear?: string;
  Forecast?: number;
  BaseRecordFlag?: number;
}
