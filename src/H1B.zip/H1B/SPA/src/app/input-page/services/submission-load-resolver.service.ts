import { Inject, Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { Select } from '@ngxs/store';
import { combineLatest, Observable, of } from 'rxjs';
import { catchError, map, finalize } from 'rxjs/operators';

import { SubmissionLoadItem } from 'input-page/models/load/submission-load-item';
import { ResolvedSubmissionLoad } from 'input-page/models/load/resolved-submissionload.model';
import { FilterWatchService } from 'services/filter-watch.service';
import { SharedService } from 'services/shared.service';
import { User } from 'user/user.model';
import { UserState } from 'user/user.store';
import { InputPageService } from './input-page.service';

@Injectable({
  providedIn: 'root',
})
export class SubmissionLoadResolver implements Resolve<ResolvedSubmissionLoad> {
  storedFilters;
  routedFrom: string;
  @Select(UserState) public user$: Observable<User>;
  user: User;

  constructor(private sharedService: SharedService, private inputPageService: InputPageService, @Inject(FilterWatchService) private filterWatch: FilterWatchService) {
    combineLatest([this.user$]).subscribe(([user]) => {
      this.user = user;
    });
  }

  resolve(activatedRoute: ActivatedRouteSnapshot): Observable<ResolvedSubmissionLoad> {
    // this.sharedService.sendLoading(true);
    if (activatedRoute.queryParams.filters) {
      this.storedFilters = this.filterWatch.getByHash(activatedRoute.queryParams.filters);
      this.routedFrom = activatedRoute.queryParams.routedFrom;
      const payload = this.generatePayload();
      return this.inputPageService.getInputPageControlsDetails(payload).pipe(
        map((submissionLoad) => new ResolvedSubmissionLoad(submissionLoad)),
        catchError((err: any) => of(new ResolvedSubmissionLoad(null, err)))
        // finalize(() => this.sharedService.sendLoading(false))
      );
    }
  }

  private generatePayload() {
    if (this.storedFilters) {
      return {
        UserID: this.user.UserID || this.storedFilters.UserID,
        Division: this.storedFilters.Division ? this.storedFilters.Division[0] : '',
        Unit: this.storedFilters.Unit ? this.storedFilters.Unit[0] : '',
        Segment: this.storedFilters.Segment ? this.storedFilters.Segment[0] : '',
        RecordNumber: this.storedFilters.RecordNo ? this.storedFilters.RecordNo : 0,
        GeniusPipeID: this.storedFilters.GeniusPipeID ? this.storedFilters.GeniusPipeID : 0,
        RoutedFrom: this.routedFrom,
      };
    } else {
      return {};
    }
  }
}
