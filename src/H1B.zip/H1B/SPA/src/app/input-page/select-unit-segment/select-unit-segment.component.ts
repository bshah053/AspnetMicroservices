import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Select, Store } from '@ngxs/store';
import { combineLatest, Observable } from 'rxjs';
import { map, startWith, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { FormControl, Validators, ValidatorFn, AbstractControl } from '@angular/forms';

import { User } from '../../user/user.model';
import { UserState } from '../../user/user.store';
import { UnitSegmentDetailsItem } from '../models/common/unit-segment-details-item';
import { InputPageService, FilterType } from '../services/input-page.service';
import { FilterWatchService } from '../../services/filter-watch.service';
import { ReportsHeaderModel } from '../../tracking-reporting/reports/reports-header/store/reports-header.model';
import { RoutedFrom } from '../../shared/utilities';
import { UrlHelper } from '../../utilities/url.helper';
import { Helper } from 'utilities/common-helper';

@Component({
  selector: 'cb-select-unit-segment',
  templateUrl: './select-unit-segment.component.html',
  styleUrls: ['./select-unit-segment.component.scss'],
})
export class SelectUnitSegmentComponent implements OnInit {
  @Select(UserState) public user$: Observable<User>;
  user: User;
  selectedValue = '';
  unitSegmentList: FilterType[] = [];
  unitSegmentControl = new FormControl();
  submitted = false;
  storedFilters;

  private _filteredUnitSegmentList: Observable<FilterType[]>;
  public get filteredUnitSegmentList(): Observable<FilterType[]> {
    return this._filteredUnitSegmentList;
  }
  public set filteredUnitSegmentList(value: Observable<FilterType[]>) {
    this._filteredUnitSegmentList = value;
  }

  constructor(private inputPageService: InputPageService, private router: Router, private activatedRoute: ActivatedRoute, private filterWatch: FilterWatchService) {
    combineLatest([this.user$]).subscribe(([user]) => {
      this.user = user;
      if (this.user && Helper.isStringNotNullAndEmpty(this.user.UserID) && this.unitSegmentList && this.unitSegmentList.length === 0) {
        this.getUnitSegmentDetailsByUserID();
      }
    });
    this.activatedRoute.queryParams.subscribe((params) => {
      if (params.filters) {
        this.storedFilters = this.filterWatch.getByHash(params.filters);
      }
    });
  }

  ngOnInit() {}

  displayFn(filterType: FilterType): string {
    return filterType && filterType.text ? filterType.text : '';
  }

  private _filter(text: string): FilterType[] {
    const filterValue = text.toLowerCase();
    return this.unitSegmentList.filter((option) => option.text.toLowerCase().includes(filterValue));
  }

  getUnitSegmentDetailsByUserID() {
    this.inputPageService.getUnitSegmentDetailsByUserID(this.user.UserID).subscribe((data: UnitSegmentDetailsItem[]) => {
      if (data !== null) {
        this.unitSegmentList = data.map((filter: { Unit: string; UnitValue: string }) => {
          return {
            text: filter.Unit,
            value: filter.UnitValue,
          };
        });

        const unitSegmentTarget = {
          text: 'Regional Target',
          value: 'RegionalTarget * RegionalTarget * RegionalTarget * Input_Target.asp * N * N * N * Y',
        };

        this.unitSegmentList.push(unitSegmentTarget);

        this.unitSegmentControl = new FormControl(null, [Validators.required, forbiddenNamesValidator(this.unitSegmentList)]);

        this.unitSegmentControl.valueChanges.pipe(debounceTime(300), distinctUntilChanged()).subscribe((controlValue) => {
          if (this.unitSegmentControl.value.value === undefined) {
            const selectedUnitValue = this.unitSegmentList.filter((ele) => ele.text === this.unitSegmentControl.value);
            if (selectedUnitValue && selectedUnitValue.length > 0) {
              this.unitSegmentControl.setValue(selectedUnitValue[0], {
                emitEvent: false,
              });
            }
          }
        });

        this._filteredUnitSegmentList = this.unitSegmentControl.valueChanges.pipe(
          startWith<string | FilterType>(''),
          map((value) => (typeof value === 'string' ? value : '')),
          map((text) => (text ? this._filter(text) : this.unitSegmentList.slice()))
        );
      } else {
        this.unitSegmentList = [];
      }
    });
  }

  handleNavigation(event) {
    if (event === 'Next') {
      this.submitted = true;
      if (this.unitSegmentControl.invalid) {
        return;
      }
      this.submitted = false;
      if (this.unitSegmentControl.valid) {
        this.selectedValue = this.unitSegmentControl.value.value;
        const queryParams = this.selectedValue.split('*');
        if (queryParams != null && queryParams.length > 0) {
          if (queryParams.length === 9 && queryParams[8].trim() === 'T1') {
            this.navigateToInputPage(queryParams);
          } else {
            this.navigateToSubmissionPage(queryParams);
          }
        }
      }
    }
  }

  private navigateToSubmissionPage(queryParams: string[]) {
    const payload = <ReportsHeaderModel>{
      Division: [queryParams[0] ? queryParams[0].trim() : ''],
      Unit: [queryParams[1] ? queryParams[1].trim() : ''],
      Segment: [queryParams[2] ? queryParams[2].trim() : ''],
      UserID: this.user.UserID,
      UnderwriterName: [this.user.UserID],
      GeniusPipeID: this.storedFilters && this.storedFilters.GeniusPipeID ? this.storedFilters.GeniusPipeID : 0,
      IsGenius: this.storedFilters && this.storedFilters.GeniusPipeID > 0 ? 'Y' : 'N',
      DYN: queryParams[4] ? queryParams[4].trim() : '',
      IYN: queryParams[5] ? queryParams[5].trim() : '',
      LYNE: queryParams[6] ? queryParams[6].trim() : '',
    };

    const serializedFilters = this.filterWatch.serializeFromPayload(payload);
    this.router.navigate(['/submission/input-page'], {
      queryParams: {
        filters: this.filterWatch.create(serializedFilters),
        routedFrom: RoutedFrom.SelectUnit,
      },
    });
  }

  private navigateToInputPage(queryParams: string[]) {
    const redirectUrlQueryParams = UrlHelper.generateInputPageQueryParams(queryParams);
    if (redirectUrlQueryParams !== '') {
      const redirectUrl = UrlHelper.getInputPageLink(redirectUrlQueryParams);

      this.router.navigate([]).then((result) => {
        window.open(redirectUrl, '_blank');
      });
    }
  }

  resetSelection() {
    this.selectedValue = '';
    this.unitSegmentControl.setValue('');
  }

  closePage() {
    window.history.back();
  }
}

export function forbiddenNamesValidator(unitSegmentList: FilterType[]): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } | null => {
    if (!control.value) {
      return null;
    }
    const userInputValue = typeof control.value === 'object' ? control.value.text : control.value;
    const pickedOrNot = unitSegmentList.filter((element) => element.text.toLowerCase() === userInputValue.toLowerCase());

    if (pickedOrNot.length > 0) {
      return null;
    } else {
      return {
        forbiddenNames: { text: userInputValue },
      };
    }
  };
}
