import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output,
  QueryList,
  ViewChild,
  ViewChildren,
  ViewEncapsulation,
  TemplateRef,
} from '@angular/core';
import { CheckboxComponent } from '../checkbox/checkbox.component';
import { FilteredCheckboxListComponent } from '../filtered-checkbox-list/filtered-checkbox-list.component';
import { ListItem } from '../radio-list/radio-list.component';

export interface SelectedEvent {
  type: string;
  list: ListItem[];
}

@Component({
  selector: 'cb-date-filter-dropdown',
  templateUrl: './date-filter-dropdown.component.html',
  styleUrls: ['./date-filter-dropdown.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DateFilterDropdownComponent {
  @ViewChildren(CheckboxComponent) checkboxes: QueryList<CheckboxComponent>;

  @Input() name: string;
  @Input() enabled: boolean;
  @Input() list: ListItem[];
  @Input() selectedValues: string[];
  @Output() selectedValuesChange = new EventEmitter<Array<string | any>>();
  @Input() showFilter = false;
  @Input() filterPlaceholder: string;
  @Input() singleSelect = false;
  @Input() template: TemplateRef<any>;

  @ViewChild(FilteredCheckboxListComponent)
  private filteredCheckboxList: FilteredCheckboxListComponent;

  @Input() selectedTitle: string;
  @Input() opened = false;

  private makeTitleString(): void {
    if (this.selectedTitle) {
      const selectedList = this.list.filter((i) =>
        this.filteredCheckboxList.isSelected(i)
      );

      this.selectedTitle = selectedList.map((item) => item.text).join(', ');
    }
  }

  public handleToggleOpen() {
    if (this.enabled) {
      this.opened = !this.opened;
    }
  }

  public handleHide() {
    this.opened = false;
  }

  onSelectedValuesChange(selectedValues: string[]) {
    this.selectedValues = selectedValues;
    this.selectedValuesChange.emit(this.selectedValues);

    this.makeTitleString();
  }
}
