export interface SubmissionCommonFilter {
  UserID: string;
  Unit: string;
  Segment: string;
  Division: string;
  RecordNumber?: number;
  GeniusPipeID?: number;
  RoutedFrom: string;
}
