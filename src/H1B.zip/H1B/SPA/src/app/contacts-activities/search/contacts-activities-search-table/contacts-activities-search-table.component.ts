import { Component, Input, TemplateRef, ViewChild, OnChanges, AfterViewInit, Output, EventEmitter, SimpleChange } from '@angular/core';
import { Router } from '@angular/router';
import { ColDef } from 'ag-grid-community';
import { FilterWatchService } from '../../../services/filter-watch.service';
import { ReportsHeaderModel } from '../../../tracking-reporting/reports/reports-header/store/reports-header.model';
import { UrlHelper } from '../../../utilities/url.helper';
import { ContactsActivitiesHelper } from '../../../utilities/contacts-activities.helper';
import { AgGridTemplateRendererComponent } from '../../../shared/ag-grid-utils/ag-grid-template-renderer.component';
import Utilities from '../../../shared/utilities';
import { ModalService } from '../../../shared/modal/modal.service';
import { NavigationService } from '../../../services/navigation.service';
import { User } from '../../../user/user.model';

export interface IActivitySearch {
	RelatedTo: string;
	Subject: string;
	StartDate: string;
	EndDate: string;
	Location: string;
	RequiredAttendees: string;
	OptionalAttendees: string;
	MeetingTime: string;
	Attendees: string;
	Owner: string;
	MeetingGUID: string;
	RelatedToGUID: string;
	OwnerGUID: string;
	AttendeesGUID: string;
	AttendeesEmail: string;
	AttendeesList?: { name: string; email: string; guid: string }[];
	AccountType: string;
	ProducerName: string;
	ProducerRegion: string;
	ProducerBranch: string;
	ClientID: string;
	Date: string;
	Task: string;
	Topics: string;
	Name: string;
	LastModified: string;
	AccountName: string;
}

@Component({
	selector: 'cb-contacts-activities-search-table',
	templateUrl: './contacts-activities-search-table.component.html',
	styleUrls: ['./contacts-activities-search-table.component.scss'],
})
export class ContactsActivitiesSearchTableComponent implements OnChanges, AfterViewInit {
	@Input() data: IActivitySearch[];
	@Input() error: string;
	@Input() user: User;

	@Output() resort = new EventEmitter();

	@ViewChild('relatedToCell', { static: true })
	private relatedToCell: TemplateRef<any>;
	@ViewChild('subjectCell', { static: true })
	private subjectCell: TemplateRef<any>;
	@ViewChild('attendeesCell', { static: true })
	private attendeesCell: TemplateRef<any>;
	@ViewChild('ownerCell', { static: true })
	private ownerCell: TemplateRef<any>;

	activities: IActivitySearch[];
	columns: ColDef[];

	sort = {
		opened: false,
		current: { text: 'Related To', value: 'Related To' },
		list: [{ text: 'Related To', value: 'RelatedTo' }, { text: 'Subject', value: 'Subject' }, { text: 'Attendee', value: 'Attendee' }, { text: 'Date', value: 'Date' }, { text: 'Task', value: 'Task' }, { text: 'Owner', value: 'Owner' }],
	};

	ngOnChanges(changes: { [key in keyof ContactsActivitiesSearchTableComponent]: SimpleChange }): void {
		if (changes.data && Array.isArray(this.data)) {
			this.activities = this.data.map(ContactsActivitiesHelper.toViewModel);
		}
	}

	ngAfterViewInit(): void {
		this.columns = [
			{
				headerName: 'Related To',
				headerTooltip: 'Related To',
				field: 'ProducerName',
				tooltipValueGetter: (params) => params.value,
				width: 208,
				suppressSizeToFit: true,
				cellRendererFramework: AgGridTemplateRendererComponent,
				cellRendererParams: { ngTemplate: this.relatedToCell },
			},
			{
				headerName: 'Subject',
				headerTooltip: 'Subject',
				tooltipValueGetter: (params) => params.value,
				width: 310,
				suppressSizeToFit: true,
				cellRendererFramework: AgGridTemplateRendererComponent,
				cellRendererParams: { ngTemplate: this.subjectCell },
			},
			{
				headerName: 'Attendees',
				field: 'Attendees',
				headerTooltip: 'Attendees',
				width: 402,
				suppressSizeToFit: true,
				sortable: false,
				cellRendererFramework: AgGridTemplateRendererComponent,
				cellRendererParams: { ngTemplate: this.attendeesCell },
			},
			{
				headerName: 'Date',
				field: 'Date',
				cellClass: 'date',
				valueFormatter: Utilities.dateFormatter,
				tooltipValueGetter: (params) => params.valueFormatted,
				width: 151,
				suppressSizeToFit: true,
			},

			{
				headerName: 'Task',
				field: 'Task',
				width: 98,
				cellRenderer: this.renderTaskColumn(),
				suppressSizeToFit: true,
			},

			{
				headerName: 'Owner',
				field: 'Owner',
				width: 150,
				suppressSizeToFit: true,
				cellRendererFramework: AgGridTemplateRendererComponent,
				cellRendererParams: { ngTemplate: this.ownerCell },
			},
		];
	}

	constructor(private filterWatch: FilterWatchService, private modalService: ModalService, private navigation: NavigationService, private router: Router) {}

	renderTaskColumn() {
		return (cell) => {
			const isTask = ['Task', 'task'].indexOf(cell.data.Task) > -1,
				template = `
          <div class="icon-box flag">
            <div class="top"></div>
            <div class="left"></div>
            <div class="right"></div>
            <div class="bottom"></div>
          </div>
        `;

			return isTask ? template : ' ';
		};
	}

	addNewEntity(type: 'meeting' | 'task') {
		const link = type === 'meeting' ? UrlHelper.dynamicsMeetingUrl() : UrlHelper.dynamicsTaskUrl();

		this.modalService.openBrowserWindow(link);
	}

	handleSaveReport(data) {}

	sortBy(item) {
		this.sort.current = item;
		this.sort.opened = false;

		this.resort.emit(item);
	}

	private navigateToCustomer(clientName: string, clientId: string) {
		const filters = this.filterWatch.serializeFromPayload(
			<ReportsHeaderModel>{
				ClientID: [clientId + ''],
				ClientName: [clientName],
			},
			{ browseByProducer: 'Insured Search', browseByValue: 'none' }
		);

		this.router
			.navigate(['tracking-and-reporting/customer'], {
				queryParams: {
					filters: this.filterWatch.create(filters),
					showBrowseBy: false,
				},
			})
			.then(() => {});
	}

	private navigateToProducer(producerName: string) {
		const filters = this.filterWatch.serializeFromPayload(
			<ReportsHeaderModel>{
				ProducerName: [producerName],
			},
			{ browseByProducer: 'Producers', browseByValue: 'producerName' }
		);

		this.router
			.navigate(['tracking-and-reporting/producer-profile'], {
				queryParams: {
					filters: this.filterWatch.create(filters),
					showBrowseBy: false,
				},
			})
			.then(() => {});
	}

	openActivity(entity: IActivitySearch) {
		const url = ContactsActivitiesHelper.activityUrl(entity);
		this.modalService.openBrowserWindow(url);
	}

	openRelatedTo(activity: IActivitySearch) {
		ContactsActivitiesHelper.openRelatedTo(activity, this.navigation);
	}

	openAttendee(attendeeId) {
		this.modalService.openBrowserWindow(UrlHelper.dynamicsEditContactUrl(attendeeId));
	}

	openOwner(ownerId) {
		this.modalService.openBrowserWindow(UrlHelper.dynamicsOwnerUrl(ownerId));
	}
}
