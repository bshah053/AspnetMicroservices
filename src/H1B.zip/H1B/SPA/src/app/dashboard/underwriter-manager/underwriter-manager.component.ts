import { Component, OnInit, Input } from '@angular/core';
import { DashboardService } from '../dashboard.service';
import { Observable } from 'rxjs';
import { User } from '../../user/user.model';
import { NavigationService } from '../../services/navigation.service';

@Component({
  selector: 'underwriter-manager',
  styleUrls: ['./underwriter-manager.component.scss'],
  templateUrl: './underwriter-manager.component.html',
  providers: [],
})
export class UnderwriterManagerComponent implements OnInit {
  @Input() user: User;
  underwriters$: Observable<any>;

  constructor(
    private dashboardService: DashboardService,
    private navigation: NavigationService
  ) {}

  ngOnInit() {
    this.underwriters$ = this.dashboardService.getMyUnderwriters(
      this.user.UserID
    );
  }

  meetingsSeeAllClicked() {
    this.navigation.toMyMeetings();
  }
}
