import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { Select } from '@ngxs/store';
import { UserState } from '../../../user/user.store';
import { Observable, combineLatest } from 'rxjs';
import { User } from '../../../user/user.model';
import { MoreFilters } from '../more-filters/more-filters.component';

@Component({
  selector: 'cb-contacts-header',
  templateUrl: './contacts-header.component.html',
  styleUrls: ['./contacts-header.component.scss'],
})
export class ContactsHeaderComponent implements OnInit {
  @Select(UserState) public user$: Observable<User>;
  @Input() title = 'Contacts';
  @Output() navigateToReport = new EventEmitter();
  @Output()
  applyFilters: EventEmitter<Partial<MoreFilters>> = new EventEmitter();
  @Output() clearAllMoreFilters: EventEmitter<boolean> = new EventEmitter();
  @Input() selectedOwnerUnits: Array<string> = [];
  @Input() showMoreFilters = false;
  @Input() moreFiltersValues: Partial<MoreFilters>;
  _user;
  @Input()
  set user(val) {
    this._user = val;
  }
  get user() {
    return this._user;
  }
  @Input() reportName: any;

  moreFilters?: Partial<MoreFilters>;

  constructor() {
    combineLatest([this.user$]).subscribe(([user]) => {
      this.user = user;
    });
  }
  //moreFilterSelection = ['Ownerunit', 'EventType'];
  ngOnInit() {}

  handleNavigateToReport(data) {
    this.navigateToReport.next(data);
  }

  handleMoreFiltersClick() {
    this.showMoreFilters = !this.showMoreFilters;
  }

  handleClearMoreFilters() {
    this.moreFiltersValues = {};
    this.clearAllMoreFilters.emit(true);
  }

  handleApplyMoreFilters(filters) {
    debugger;
    this.showMoreFilters = false;
    this.moreFiltersValues = filters;
    if (this.reportName == 'Activities Search') {
      this.applyFilters.emit({
        Ownerunit: this.moreFiltersValues.Ownerunit,
        EventType: this.moreFiltersValues.EventType,
      });
    } else {
      this.applyFilters.emit({
        ProductSpecialization: this.moreFiltersValues.ProductSpecialization,
        IndustrySpecialization: this.moreFiltersValues.IndustrySpecialization,
        Cornerstone: this.moreFiltersValues.Cornerstone,
      });
    }
  }

  get moreFiltersSelectedCount() {
    return Object.keys(this.moreFiltersValues).filter((key) => !!this.moreFiltersValues[key] && this.moreFiltersValues[key].length).length;
  }
}
