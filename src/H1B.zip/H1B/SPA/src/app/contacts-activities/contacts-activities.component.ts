import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Select, Store } from '@ngxs/store';
import { combineLatest, Observable } from 'rxjs';
import { finalize, tap } from 'rxjs/operators';
import { ICompletedActivity } from '../shared/completed-activity/completed-activity.component';
import { Task } from '../shared/tasks/tasks.component';
import { User } from '../user/user.model';
import { UserState } from '../user/user.store';
import { IContact } from './models/contact';
import { RelationshipService } from './relationship.service';
import { SetActivitiesSearchFilters } from './store/contacts-activities.actions';

@Component({
  templateUrl: './contacts-activities.component.html',
  styleUrls: ['./contacts-activities.component.scss'],
})
export class ContactsActivitiesComponent implements OnInit {
  @Select(UserState) public user$: Observable<User>;

  user: User;

  contacts = {
    list: <IContact[]>[],
    loading: false,
  };

  completedActivities: ICompletedActivity[];
  completedActivitiesError: string;

  tasks = {
    list: <Task[]>[],
    loading: false,
  };

  constructor(private relationshipService: RelationshipService, private store: Store, private router: Router) {
    combineLatest([this.user$]).subscribe(([user]) => {
      this.user = user;
    });
  }

  ngOnInit(): void {
    this.fetchPageData();
  }

  fetchPageData() {
    this.fetchCompletedActivities();
    this.fetchTasks();
  }

  searchContacts(name: string) {
    this.contacts.loading = true;
    this.contacts.list = [];

    this.relationshipService
      .searchContacts(name)
      .pipe(
        tap((contacts) => {
          if (contacts !== null) {
            this.contacts.list = contacts;
          } else {
            this.contacts.list = [];
          }
        }),
        finalize(() => (this.contacts.loading = false))
      )
      .subscribe();
  }

  fetchCompletedActivities() {
    this.completedActivities = [];
    this.completedActivitiesError = undefined;

    this.relationshipService.getCompletedActivities(this.user.UserID, 1, 100).subscribe(
      (data) => {
        if (data !== null) {
          this.completedActivities = data;
        } else {
          this.completedActivities = [];
        }
      },
      (err) => {
        this.completedActivities = [];
        this.completedActivitiesError = err.error && typeof err.error === 'string' && err.error;
      },
      () => {
        if (!this.completedActivitiesError) {
          if (!this.completedActivities || !this.completedActivities.length) {
            this.completedActivitiesError = 'No data provided';
          }
        }
      }
    );
  }

  fetchTasks() {
    this.tasks.list = [];
    this.tasks.loading = true;

    this.relationshipService
      .getTasks(this.user.UserID, 1, 100)
      .pipe(finalize(() => (this.tasks.loading = false)))
      .subscribe((data) => {
        if (data !== null) {
          this.tasks.list = data;
        } else {
          this.tasks.list = [];
        }
      });
  }

  seeAllUpcomingActivitiesClickHandler(type: 'Task' | 'Meeting') {
    this.store.dispatch(
      new SetActivitiesSearchFilters({
        ActivityType: [type],
        StartDate: new Date().toISOString(),
        OwnerContact: [
          <IContact>{
            Email: this.user.Email,
            FullName: this.user.UserFirstName + ' ' + this.user.UserLastName,
          },
        ],
      })
    );
    this.router.navigate(['/contacts-and-activities/search']);
  }

  seeAllCompletedActivitiesClickHandler() {
    this.store.dispatch(
      new SetActivitiesSearchFilters({
        EndDate: new Date().toISOString(),
        OwnerContact: [
          <IContact>{
            Email: this.user.Email,
            FullName: this.user.UserFirstName + ' ' + this.user.UserLastName,
          },
        ],
      })
    );
    this.router.navigate(['/contacts-and-activities/search']);
  }
}
