import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { FormsControlMasterComponent } from './forms-control-master.component';

describe('FormsControlMasterComponent', () => {
	let component: FormsControlMasterComponent;
	let fixture: ComponentFixture<FormsControlMasterComponent>;

	beforeEach(
		waitForAsync(() => {
			TestBed.configureTestingModule({
				declarations: [FormsControlMasterComponent],
			}).compileComponents();
		})
	);

	beforeEach(() => {
		fixture = TestBed.createComponent(FormsControlMasterComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
