import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { ApiService } from '../../services/api.service';
import {
  IContactsActivitiesSearchPayload,
  IContactsActivitiesSearchResponse,
} from './contacts-activities-search.component';

@Injectable({ providedIn: 'root' })
export class ContactsActivitiesSearchService extends ApiService {
  constructor(httpClient: HttpClient) {
    super(httpClient, environment.apiRelationship);
  }

  fetchContactsActivitiesSearch(
    payload: IContactsActivitiesSearchPayload
  ): Observable<IContactsActivitiesSearchResponse> {
    return <Observable<IContactsActivitiesSearchResponse>>(
      this.post('/dynamics/search/activities', null, payload)
    );
  }
}
