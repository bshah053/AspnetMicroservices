import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { map, share } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { ApiService } from '../services/api.service';
import { UnderwriterManagerGoal } from './models/underwriter-manager-goal';

@Injectable({
  providedIn: 'root',
})
export class DashboardService {
  constructor(private api: ApiService) {}

  //dashboard <-> children communication

  // 1. communication sources
  private selectedTab = new BehaviorSubject<object>({});
  //private selectedTab = new BehaviorSubject<string>('');

  // 2. observable streams
  selectedTabAnnounced$ = this.selectedTab.asObservable();

  // 3. communication methods
  announceTab(tab: object) {
    this.selectedTab.next(tab);
  }

  //underwriter
  //pipelinesForecast: Observable<object>;
  //pipelinesNBRenewals: Observable<object>;
  newBusinessGoals: Observable<object>;
  travelGoals: Observable<object>;
  myNewBusinessInfo: Observable<object>;
  myNewBusinessTable: Observable<object>;
  myRenewalsInfo: Observable<object>;
  myRenewalsTable: Observable<object>;
  myRenewalsTableForRegionalManager: Observable<object>;
  // myRenewalsTable = new BehaviorSubject<any>('');
  myOpenTargets: Observable<object>;

  //branch manager
  // forecastVsPlan: Observable<object>;
  brchMgrNewBusiness: Observable<object>;
  brchMgrNBRenewals: Observable<object>;
  brchMgrNewBusinessGraphs: Observable<object>;
  newBusinessForecastVsPlan: Observable<object>;
  //renewalToPlan: Observable<object>;

  //regional manager
  renewalsRatio: Observable<object>;
  // renewalsRatioTable = new BehaviorSubject<any>('');
  renewalsRatioTable: Observable<object>;
  renewalsRationTableForRefionalManager: Observable<object>;
  topCustomerTargets: Observable<object>;
  topProducerTargets: Observable<object>;

  //Global Client Executive
  gceNewBusinessGraphs: Observable<object>;
  gceMyAccounts: Observable<object>;
  //underwriter manager
  undwrtrMgrNewBusinessGraphs: Observable<object>;
  undwrtrMgrNewBusinessForecastVsPlan: Observable<object>;
  //tracker queue
  trackerQueue: Observable<object>;

  mslNewBusinessGraphs: Observable<object>;

  endpoint(resourceUri: string) {
    return [environment.apiDashboard, resourceUri].join('');
  }

  reportingEndpoint(resourceUri: string) {
    return [environment.apiReporting, resourceUri].join('');
  }

  post(resourceUri: string, params?: any, payload?: any) {
    return this.api.post(this.endpoint(resourceUri), params, payload);
  }

  get(resourceUri: string, params?: any, payload?: any) {
    return this.api.get(this.endpoint(resourceUri), params, payload);
  }

  // ----- Shared Among Dashboards -----

  getPipelinesForecast(params) {
    return this.post('/pipelines/forecast', null, params).pipe(share());
  }

  getPipelinesNBRenewals(params) {
    return this.post(
      '/pipelines/nbrenewals/overviewbyaccountingmonth',
      null,
      params
    ).pipe(share());
  }

  getPipelinesNBRenewalsByTermDate(params) {
    return this.post(
      '/pipelines/nbrenewals/overviewbytermdate',
      null,
      params
    ).pipe(share());
  }

  getMyRenewalsStatusByAccountingMonth(params) {
    return this.post(
      '/pipelines/renewals/statusbyaccountingmonth',
      null,
      params
    ).pipe(share());
  }

  getGCEMyRenewalsStatusByAccountingMonth(params) {
    return this.post(
      '/pipelines/gce/renewals/statusbyaccountingmonth',
      null,
      params
    ).pipe(share());
  }

  getMyRenewalsInfoByTermDate(params) {
    return this.post('/pipelines/renewals/statusbytermdate', null, params).pipe(
      share()
    );
  }

  getRenewalsTable(params) {
    return this.post('/pipelines/renewalsbytermdate', null, params).pipe(
      share()
    );
  }

  getRenewalsTableByMonth(params) {
    return this.post('/pipelines/renewalsbyaccountingmonth', null, params).pipe(
      share()
    );
  }

  getGCERenewalsTable(params) {
    return this.post(
      '/pipelines/gce/renewalsbyaccountingmonth',
      null,
      params
    ).pipe(share());
  }

  getRenewalsTableForRegionalManager(params) {
    return this.post(
      '/pipelines/regionalmanager/renewalsbyaccountingmonth',
      null,
      params
    ).pipe(share());
  }

  getRenewalsTableForUndewriterManagerByMonth(params) {
    return this.post(
      '/pipelines/uwmanager/renewalsbyaccountingmonth',
      null,
      params
    ).pipe(share());
  }

  getRenewalsTableForGCEManagerByMonth(params) {
    return this.post(
      '/pipelines/gce/renewalsbyaccountingmonth',
      null,
      params
    ).pipe(share());
  }

  getGCERenewalStatusByAccountingMonth(params) {
    return this.post(
      '/pipelines/gce/renewals/statusbyaccountingmonth ',
      null,
      params
    ).pipe(share());
  }

  getGCEMyAccounts(params) {
    this.gceMyAccounts = this.post(
      '/gce/myaccountsbyaccountingmonth',
      null,
      params
    ).pipe(share());
  }

  getRenewalsStatusForUndewriterManager(params) {
    return this.post(
      '/pipelines/renewals/statusbyaccountingmonth',
      null,
      params
    ).pipe(share());
  }

  // getRenewalsTable(params) {
  //   let response = this.post('/pipelines/renewalsbytermdate', null, params);
  //   this.myRenewalsTable.next(response);
  // }

  // ----- UW Dashboard -----

  getNBGoals(params) {
    return this.post('/users/goals/newbusiness', null, params).pipe(share());
  }

  setNBGoals(UserID: string, GoalAmount: number) {
    return this.api.post(
      this.reportingEndpoint('/reports/underwriters/savegoals/NewBusiness'),
      { UserID, GoalAmount }
    );
  }

  getTravelGoals(params) {
    return this.post('/users/goals/travel', null, params).pipe(share());
  }

  setTravelGoals(UserID: string, GoalAmount: number, VisitType = 'Producer') {
    return this.api.post(
      this.reportingEndpoint('/reports/underwriters/savegoals/travel'),
      { UserID, GoalAmount, VisitType }
    );
  }

  getMyNewBusinessInfo(params) {
    return this.post(
      '/pipelines/newbusiness/statusbyaccountingmonth',
      null,
      params
    ).pipe(share());
  }

  getMyNewBusinessTable(params) {
    return this.post(
      '/pipelines/newbusinessbyaccountingmonth',
      null,
      params
    ).pipe(share());
  }

  getOpenTargets(params) {
    this.myOpenTargets = this.post('/pipelines/opentargets', null, params).pipe(
      share()
    );
  }
  // ----- UW Manager Dashboard -----

  getUWMGoals(params: {
    UserID: string;
    AccountingYear: number;
    AccountingMonth: string;
    TimeFrame: string;
  }): Observable<UnderwriterManagerGoal[]> {
    return this.post('/pipelines/uwmanager/goals', null, params).pipe(
      share()
    ) as Observable<UnderwriterManagerGoal[]>;
  }

  // ----- Branch Manager Dashboard -----

  getForecastVsPlan(params) {
    return this.post('/pipelines/forecastvsplanoverview', null, params).pipe();
  }

  getBMRatios(params) {
    return this.post('/pipelines/NewBusiness/Ratio', null, params).pipe(
      share()
    );
  }

  getNewBusinessGraphs(params) {
    this.brchMgrNewBusinessGraphs = this.getBMRatios(params);
  }

  getNBForecastVsPlan(params) {
    this.newBusinessForecastVsPlan = this.post(
      '/pipelines/nbforecastvsplan',
      null,
      params
    ).pipe(share());
  }

  getRenewalsToPlan(params) {
    return this.post('/pipelines/renewals/toplan', null, params).pipe(share());
  }

  // ----- Regional Manager Dashboard -----

  getRMrenewalsTable(params) {
    this.renewalsRatioTable = this.post(
      '/pipelines/regionalmanager/renewalsbyaccountingmonth',
      null,
      params
    );
    // this.renewalsRatioTable.next(response);
  }

  getGCERenewalsRatio(params) {
    return this.post('/pipelines/gce/renewalratios', null, params).pipe(
      share()
    );
  }

  getRenewalsRatio(params) {
    return this.post('/pipelines/renewalratios', null, params).pipe(share());
  }

  getGCETopCustomerTargets(params) {
    this.topCustomerTargets = this.post(
      '/pipelines/gce/topcustomertargetsbyaccountingmonth',
      null,
      params
    ).pipe(share());
  }

  getTopCustomerTargets(params) {
    this.topCustomerTargets = this.post(
      '/pipelines/topcustomertargetsbyaccountingmonth',
      null,
      params
    ).pipe(share());
  }

  getGCETopProducerTargets(params) {
    this.topProducerTargets = this.post(
      '/pipelines/gce/topproducertargetsbyaccountingmonth',
      null,
      params
    ).pipe(share());
  }

  getTopProducerTargets(params) {
    this.topProducerTargets = this.post(
      '/pipelines/topproducertargetsbyaccountingmonth',
      null,
      params
    ).pipe(share());
  }

  // Underwriter Manager
  getUWMRatios(params) {
    return this.post('/pipelines/uwmanagernewbusiness/ratio', null, params);
  }
  getUWMNewBusinessGraphs(params) {
    this.undwrtrMgrNewBusinessGraphs = this.getUWMRatios(params);
  }
  getMyUnderwriters(UserID: string) {
    return this.post('/filters/underwritermanager', { UserID }).pipe(
      map((data: any[]) => {
        const underwriters = data.map((d) => ({
          title: d.Text,
          value: d.Value,
        }));
        const allIndex = underwriters.findIndex((d) => d.value === 'All');
        if (allIndex !== -1) {
          underwriters.splice(allIndex, 1);
        }
        return underwriters;
      })
    );
  }
  getUWMForecastVsPlan(params) {
    return this.post(
      '/pipelines/uwmanager/forecastvsplanoverview',
      null,
      params
    ).pipe();
  }
  getUWMNBForecastVsPlan(params) {
    this.undwrtrMgrNewBusinessForecastVsPlan = this.post(
      '/pipelines/uwmanager/nbforecastvsplan',
      null,
      params
    ).pipe(share());
  }
  getGeniusSubmissionsCount(UserID: string) {
    return this.post('/users/GeniusSubmissions', { UserID });
  }
  // Tracker Queue
  getTrackerQueue(params) {
    return this.api.post(
      this.reportingEndpoint('/reports/trackerqueue'),
      null,
      params
    );
  }

  // Meetings

  getMyMeetings(userID, pageNumber, pageSize) {
    return this.get(
      '/dynamics/users/' +
        userID +
        '/appointments/' +
        pageNumber +
        '/' +
        pageSize,
      null,
      null
    );
  }

  getBranchMeetings(payload) {
    return this.post('/dynamics/branch/appointments', null, payload);
  }

  getUnderwritersMeetings(userID, pageNumber = 1, pageSize = 3) {
    return this.get(
      `/dynamics/users/${userID}/underwriterappointments/${pageNumber}/${pageSize}`
    );
  }

  getCurrentAccountingYearMonth() {
    // return this.post('/filters/currentaccountingyearmonth').pipe(share());
    return this.post('/filters/currentaccountingyearmonth').pipe();
  }

  getMSLOpenTargets(params) {
    this.myOpenTargets = this.post(
      '/pipelines/msl/opentargets',
      null,
      params
    ).pipe(share());
  }

  getMSLNewBusinessGraphs(params) {
    this.mslNewBusinessGraphs = this.getMSLRatios(params);
  }

  getMSLRatios(params) {
    return this.post('/pipelines/msl/NewBusiness/Ratio', null, params).pipe(
      share()
    );
  }

  getGCENewBusinessGraphs(params) {
    this.gceNewBusinessGraphs = this.getGCERatios(params);
  }

  getGCERatios(params) {
    return this.post('/pipelines/gcenewbusiness/ratio', null, params).pipe(
      share()
    );
  }

  getMSLForecastvsPlan(params) {
    return this.post(
      '/pipelines/msl/forecastvsplanoverview',
      null,
      params
    ).pipe(share());
  }

  getMSLPipelinesForecast(params) {
    return this.post('/pipelines/forecast', null, params).pipe(share());
  }

  getMSLMyNewBusinessInfo(params) {
    return this.post(
      '/pipelines/msl/newbusiness/statusbyaccountingmonth',
      null,
      params
    ).pipe(share());
  }

  getMSLMyRenewalsStatusByAccountingMonth(params) {
    return this.post(
      '/pipelines/msl/renewals/statusbyaccountingmonth',
      null,
      params
    ).pipe(share());
  }

  getMSLRenewalsTableByMonth(params) {
    return this.post(
      '/pipelines/msl/renewalsbyaccountingmonth',
      null,
      params
    ).pipe(share());
  }

  getMSLMyNewBusinessTable(params) {
    return this.post(
      '/pipelines/msl/newbusinessbyaccountingmonth',
      null,
      params
    ).pipe(share());
  }

  getGCEMyClientName(userID) {
    return this.post('/filters/gce/Account', { userID }).pipe(
      map(
        (data: { Text: string; Value: string }[]) =>
          !data
            ? []
            : data.map((filter) => ({ text: filter.Text, value: filter.Value }))
      )
    );
  }

  getHelpDetails(UserID: string) {
    return this.api.post(this.reportingEndpoint('/help'), { UserID });
  }

  getHelpFile(FilePath: string) {
    return this.api.post(this.reportingEndpoint('/helpDetails/download'), {
      FilePath,
    });
  }
}
