import { QuickSubVisibilityPipe } from './pipes/quick-sub-visibility.pipe';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxMaskModule, IConfig } from 'ngx-mask';
import { MatMomentDateModule, MAT_MOMENT_DATE_ADAPTER_OPTIONS } from '@angular/material-moment-adapter';

import { MaterialModule } from '../material-module';
import { InputPageRoutingModule } from './input-page-routing.module';
import { NumbersOnlyDirective } from './directives/numbers-only.directive';
import { AlphaNumericDirective } from './directives/alphanumeric.directive';
import { FocusInvalidControlDirective } from './directives/focusinvalidcontrol.directive';
import { DefaultCurrentDateDirective } from './directives/onfocus-default.directive';
import { SharedModule } from '../shared/shared.module';
import { UtilitiesModule } from '../utilities/utilities.module';
import { InputPageComponent } from './input-page.component';
import { UwGeniusQueueComponent } from './uw-genius-queue/uw-genius-queue.component';
import { UwGeniusQueueDetailsComponent } from './uw-genius-queue-details/uw-genius-queue-details.component';
import { UwGeniusQueueViewComponent } from './uw-genius-queue-details/uw-genius-queue-view/uw-genius-queue-view.component';
import { SelectUnitSegmentComponent } from './select-unit-segment/select-unit-segment.component';
import { InputFormPopupComponent } from './dialog/input-form-popup/input-form-popup.component';
import { LayerDetailsComponent } from './dialog/layer-details/layer-details.component';
import { SubmissionLookupResolverService } from './services/submission-lookup-resolver.service';
import { SubmissionContactSearchComponent } from './dialog/submission-contact-search/submission-contact-search.component';
import { SubmissionContactSearchTableComponent } from './dialog/submission-contact-search/submission-contact-search-table/submission-contact-search-table.component';
import { SubmissionContactSearchMiniComponent } from './dialog/submission-contact-search-mini/submission-contact-search-mini.component';
import { BuildOutScheduleComponent } from './dialog/build-out-schedule/build-out-schedule.component';
import { InputPageService } from './services/input-page.service';
import { ValidationSummaryComponent } from './validation-summary/validation-summary.component';

export const options: Partial<IConfig> = {
  thousandSeparator: ',',
};

const maskConfigFunction: () => Partial<IConfig> = () => {
  return {
    validation: false,
  };
};

@NgModule({
  declarations: [
    InputPageComponent,
    SelectUnitSegmentComponent,
    UwGeniusQueueComponent,
    UwGeniusQueueDetailsComponent,
    UwGeniusQueueViewComponent,
    InputFormPopupComponent,
    NumbersOnlyDirective,
    AlphaNumericDirective,
    FocusInvalidControlDirective,
    DefaultCurrentDateDirective,
    LayerDetailsComponent,
    SubmissionContactSearchComponent,
    SubmissionContactSearchTableComponent,
    SubmissionContactSearchMiniComponent,
    BuildOutScheduleComponent,
    ValidationSummaryComponent,
    QuickSubVisibilityPipe,
  ],
  imports: [CommonModule, InputPageRoutingModule, FormsModule, ReactiveFormsModule, NgxMaskModule.forRoot(maskConfigFunction), MaterialModule, MatMomentDateModule, SharedModule, UtilitiesModule],
  providers: [InputPageComponent, InputPageService, SelectUnitSegmentComponent, UwGeniusQueueComponent, UwGeniusQueueDetailsComponent, UwGeniusQueueViewComponent, SubmissionLookupResolverService, { provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: { useUtc: true } }],
})
export class InputPageModule {}
