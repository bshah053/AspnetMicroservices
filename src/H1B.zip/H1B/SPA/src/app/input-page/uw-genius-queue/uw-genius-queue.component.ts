import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Select } from '@ngxs/store';
import { combineLatest, Observable } from 'rxjs';
import { User } from 'user/user.model';
import { UserState } from 'user/user.store';
import Utilities from 'shared/utilities';
import { InputPageService } from '../services/input-page.service';
import { UWGeniusQueueDetails } from '../models/common/uw-genius-queue-details';
import { ConfirmationDialogComponent } from 'shared/confirmation-dialog/confirmation-dialog.component';
import { Router } from '@angular/router';
import { finalize } from 'rxjs/operators';

@Component({
  selector: 'uw-genius-queue',
  templateUrl: './uw-genius-queue.component.html',
  styleUrls: ['./uw-genius-queue.component.scss'],
})
export class UwGeniusQueueComponent implements OnInit {
  constructor(public dialog: MatDialog, private inputPageService: InputPageService, private router: Router) {
    combineLatest([this.user$]).subscribe(([user]) => {
      this.user = user;
    });
  }

  @Select(UserState) public user$: Observable<User>;
  user: User;
  uwGeniusQueueDetails: UWGeniusQueueDetails[];
  selectedRowsDetails: UWGeniusQueueDetails[];
  rowSelection = 'multiple';
  loading = false;
  isEmpty = false;
  initial = false;

  columns = [
    {
      headerName: 'Delete',
      field: '',
      width: 87,
      headerCheckboxSelection: false,
      checkboxSelection: true,
      suppressSizeToFit: true,
      resizable: true,
      sortable: false,
    },
    {
      headerName: 'Insured Name',
      headerTooltip: 'Insured Name',
      field: 'InsuredName',
      tooltipValueGetter: (params) => params.value,
      width: 250,
      cellClass: 'multiline',
      suppressSizeToFit: true,
      autoHeight: true,
      cellRenderer: this.renderLinkInsideColumn,
      valueGetter: (params) => params.data.InsuredName,
    },
    {
      headerName: 'Inception Date',
      field: 'EffectiveDate',
      cellClass: 'date',
      valueFormatter: Utilities.dateFormatter,
      tooltipValueGetter: (params) => params.valueFormatted,
      width: 155,
      headerClass: 'multiline',
      suppressSizeToFit: true,
      cellRenderer: Utilities.restrictCellTextRenderer(),
    },
    {
      headerName: 'Policy Type',
      field: 'Type',
      tooltipValueGetter: (params) => params.value,
      width: 130,
      cellClass: 'multiline',
      suppressSizeToFit: true,
      cellRenderer: Utilities.restrictCellTextRenderer(),
    },
    {
      headerName: 'Broker Name',
      field: 'BrokerName',
      tooltipValueGetter: (params) => params.value,
      width: 245,
      cellClass: 'multiline',
      suppressSizeToFit: true,
      cellRenderer: Utilities.restrictCellTextRenderer(),
    },
    {
      headerName: 'Underwritter Name',
      field: 'UnderwriterName',
      tooltipValueGetter: (params) => params.value,
      width: 200,
      cellClass: 'multiline',
      suppressSizeToFit: true,
      cellRenderer: Utilities.restrictCellTextRenderer(),
    },
    {
      headerName: 'Submission ID',
      field: 'SubmissionID',
      tooltipValueGetter: (params) => params.value,
      width: 140,
      suppressSizeToFit: true,
      cellRenderer: Utilities.restrictCellTextRenderer(),
    },
  ];

  ngOnInit(): void {
    this.getUWGeniusQueueDetails();
  }

  getUWGeniusQueueDetails() {
    this.loading = true;
    this.inputPageService
      .getUWGeniusQueueDetails(this.user.UserID)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe((data: UWGeniusQueueDetails[]) => {
        if (data != null) {
          this.uwGeniusQueueDetails = data;
        } else {
          this.uwGeniusQueueDetails = null;
        }
      });
  }

  geniusUWQueueStatusUpdate(payload) {
    this.inputPageService.geniusUWQueueStatusUpdate(payload).subscribe((data: string) => {
      console.log(data);
      if (data != null) {
        this.getUWGeniusQueueDetails();
      } else {
      }
    });
  }

  handleSelectedRow(rows) {
    this.selectedRowsDetails = rows;
  }

  handleDelete() {
    if (this.selectedRowsDetails && this.selectedRowsDetails.length > 0) {
      let payload = {
        PipeID: this.selectedRowsDetails.map((pipe) => pipe.PipeID),
        UserID: this.user.UserID,
      };

      const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
        width: '510px',
        data: { Action: 'Delete' },
        hasBackdrop: true,
        backdropClass: 'backdropBackground',
      });

      dialogRef.afterClosed().subscribe((result) => {
        console.log('The Confirmation Copy/Delete dialog was closed');
        console.log(result);
        if (result && result.Action === 'Delete confirm') {
          this.geniusUWQueueStatusUpdate(payload);
        }
      });
    }
  }

  handleBack() {
    history.back();
  }

  cellClickHandler(rowData) {
    if (rowData.column.colId === 'InsuredName' && rowData.data.PipeID) {
      this.router.navigate(['/submission/uw-genius-queue-details'], {
        queryParams: { PipeID: rowData.data.PipeID },
      });
    }
  }

  private renderLinkInsideColumn(cell) {
    if (cell.data) {
      return `<a href="javascript:void(0);" rel="noopener">${cell.value}</a>`;
    } else {
      return cell.value;
    }
  }
}
