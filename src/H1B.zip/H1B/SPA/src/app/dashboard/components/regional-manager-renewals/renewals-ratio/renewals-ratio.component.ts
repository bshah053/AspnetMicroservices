import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { DashboardService } from '../../../../dashboard/dashboard.service';
import Utilities from '../../../../shared/utilities';
import { DateFilterSelection, DateFilterItem } from '../../../../shared/date-filter/date-filter.component';
import { Observable } from 'rxjs';
import { AccountingYearMonth, AccountingYearMonthState } from 'store/accounting-month-year.store';
import { Select } from '@ngxs/store';

@Component({
  selector: 'cb-renewals-ratio',
  templateUrl: './renewals-ratio.component.html',
  styleUrls: ['./renewals-ratio.component.scss'],
})
export class RenewalsRatioComponent implements OnInit, OnDestroy {
  @Input() user: any;

  addCommaToNumber = Utilities.addCommasToNumber;
  round = Math.round;

  renewalsRatioSubscription: any;
  renewalsRatioData: Object;

  overYearDoughnutConfig: Object;
  overYearPercentage: number;
  overYearRenewals: number;
  overYearRetained: number;

  forecastBarConfig: Object;
  previousForecast: number;
  currentForecast: number;
  forecastBarWidth: number;
  forecastPercentage: number;

  toPlanBarConfig: Object;
  toPlan_forecast: number;
  toPlan_plan: number;
  toPlanBarWidth: number;
  toPlan_percentage: number;

  frame: any = 'YTD';

  dateListRenwalsRatio: DateFilterItem[] = [
    { title: 'MTD', value: 'MTD' },
    { title: '3 Months', value: 'R3' },
    { title: 'YTD', value: 'YTD' },
    { title: 'R12', value: 'R12' },
  ];

  currentDateFilterRenewalsRatioIndex = 2;

  @Select(AccountingYearMonthState)
  public accountingYearMonth$: Observable<AccountingYearMonth>;
  accountingYearMonth: AccountingYearMonth;

  constructor(private dashboardService: DashboardService) {
    this.accountingYearMonth$.subscribe((accountingYearMonth) => {
      this.accountingYearMonth = accountingYearMonth;
    });
  }

  get userWithAccountingYearMonth() {
    return {
      UserID: this.user.UserID,
      ...this.accountingYearMonth,
    };
  }

  get defaultPayload() {
    return {
      ...this.userWithAccountingYearMonth,
      TimeFrame: 'MTD',
    };
  }

  getRenwalsData(updatedPayload?) {
    const payload = updatedPayload || this.defaultPayload;
    this.renewalsRatioSubscription = this.dashboardService.getRenewalsRatio(payload).subscribe((data) => {
      if (data !== null) {
        this.renewalsRatioData = data;

        this.overYearRenewals = data['RenewalCount'];
        this.overYearRetained = data['RetainedCount'];
        this.overYearPercentage = Math.round(data['YOY_Count']);

        this.overYearDoughnutConfig = this.setDoughnutGraphConfig([this.overYearPercentage, 100 - this.overYearPercentage], ['#6e27c5', '#e2d5f3']);

        this.previousForecast = data['PreviousForecast'];
        this.currentForecast = data['CurrentForecast'];
        this.forecastPercentage = data['ForecastPercentage'];

        this.forecastBarConfig = this.setBarGraphConfig(this.forecastPercentage, '#7acb00');

        this.toPlan_forecast = data['Forecast'];
        this.toPlan_plan = data['PlanValue'];
        this.toPlan_percentage = data['ForecastVsPlanPercentage'];

        this.toPlanBarConfig = this.setBarGraphConfig(this.toPlan_percentage);
      }
    });
  }

  getRenwalsGCEData(updatedPayload?) {
    const payload = updatedPayload || this.defaultPayload;
    this.renewalsRatioSubscription = this.dashboardService.getGCERenewalsRatio(payload).subscribe((data) => {
      if (data !== null) {
        this.renewalsRatioData = data;

        this.overYearRenewals = data['RenewalCount'];
        this.overYearRetained = data['RetainedCount'];
        this.overYearPercentage = Math.round(data['YOY_Count']);

        this.overYearDoughnutConfig = this.setDoughnutGraphConfig([this.overYearPercentage, 100 - this.overYearPercentage], ['#6e27c5', '#e2d5f3']);

        this.previousForecast = data['PreviousForecast'];
        this.currentForecast = data['CurrentForecast'];
        this.forecastPercentage = data['ForecastPercentage'];

        this.forecastBarConfig = this.setBarGraphConfig(this.forecastPercentage, '#7acb00');
      }
    });
  }

  setBarStyleWidth(percentage: number) {
    return percentage < 0 ? 100 : 100 - this.round(percentage);
  }

  setBarContainerWidth(percentage: number) {
    return percentage < 0 ? this.round(100 + percentage) : 100;
  }

  setDoughnutGraphConfig(dashData: any[], color: any[]) {
    const doughnutConfig = {
      type: 'doughnut',
      datasets: [
        {
          data: dashData,
          backgroundColor: color,
          borderWidth: 0,
        },
      ],
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutoutPercentage: 72,
        tooltips: { enabled: false },
        hover: { mode: null },
      },
    };
    return doughnutConfig;
  }

  setBarGraphConfig(percentageData: any, color?: string) {
    const barConfig = {
      showIndicator1: false,
      showIndicator2: false,
      barWrapper: {
        height: 18,
      },
      barContainer: {
        background: color ? color : '#5cd7e4',
        height: 100,
        opacity: 1,
        width: this.setBarContainerWidth(percentageData),
      },
      barStyle: {
        width: this.setBarStyleWidth(percentageData),
        height: 100,
        background: color ? color : '#150fc5',
        top: -36,
      },
    };

    return barConfig;
  }

  dateFilterRenewalsRatioSelected(data: DateFilterSelection): void {
    this.frame = data.frame;
    const payload = {
      ...this.userWithAccountingYearMonth,
      TimeFrame: data.frame,
    };
    if (this.isGCE) {
      this.getRenwalsGCEData(payload);
    } else {
      this.getRenwalsData(payload);
    }
  }

  ngOnInit() {
    if (this.user.UserType === 'Regional Manager') {
      this.frame = 'MTD';
      this.currentDateFilterRenewalsRatioIndex = 0;
      this.getRenwalsData();
    } else if (this.isGCE) {
      this.frame = 'MTD';
      this.currentDateFilterRenewalsRatioIndex = 0;
      this.getRenwalsGCEData();
    }
  }

  ngOnDestroy() {
    if (this.renewalsRatioSubscription) {
      this.renewalsRatioSubscription.unsubscribe();
    }
  }

  get isGCE() {
    return this.user.UserType === 'Global Client Executive';
  }
}
