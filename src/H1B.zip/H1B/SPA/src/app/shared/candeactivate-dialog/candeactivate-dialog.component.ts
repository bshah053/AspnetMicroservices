import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';

@Component({
  selector: 'cb-candeactivate-dialog',
  templateUrl: './candeactivate-dialog.component.html',
  styleUrls: ['./candeactivate-dialog.component.scss'],
})
export class CandeactivateDialogComponent implements OnInit {
  constructor(
    public dialogRef: MatDialogRef<CandeactivateDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  handleClick(val): void {
    this.dialogRef.close(val);
  }

  ngOnInit(): void {}
}
