import { Pipe, PipeTransform } from '@angular/core';

import { DataElementsDetails } from 'input-page/models/load/data-elements-control-details-item';

@Pipe({ name: 'qsvisible' })
export class QuickSubVisibilityPipe implements PipeTransform {
  transform(items: DataElementsDetails[], isQuickSub: boolean, sectionKey: string = '') {
    if (isQuickSub) {
      return items.filter((item) => {
        return item.IsVisible && item.IsQuickSubmission;
      });
    } else {
      return items;
    }
  }
}
