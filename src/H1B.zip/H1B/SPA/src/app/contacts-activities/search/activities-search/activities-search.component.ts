import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Select } from '@ngxs/store';

import { combineLatest, Observable } from 'rxjs';
import { IReportPayload, PersistenceType } from '../../../services/save-reports.service';
import { IPaginationState } from '../../../shared/pagination-controls/pagination-controls.component';
import Utilities from '../../../shared/utilities';
import { ReportingService } from '../../../tracking-reporting/services/reporting.service';
import { User } from '../../../user/user.model';
import { UserState } from '../../../user/user.store';
import { ContactsActivitiesService } from '../../contacts-activities.service';
import { ISaveReportAs } from '../../models/saveReports';
import { ContactsActivitiesModel, IActivitiesSearchFilters } from '../../store/contacts-activities.models';
import { ContactsActivitiesState } from '../../store/contacts-activities.store';
import { AccountChangeEvent } from './activities-account-filters/activities-account-filters.component';
import { ProducerChangeEvent } from './activities-producer-filters/activities-producer-filters.component';
import { IActivitySearch } from './activities-search-table/activities-search-table.component';
import { ActivitiesSearchService } from './activities-search.service';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { FilterWatchService } from '../../../services/filter-watch.service';
import { ReportFilters } from '../../../tracking-reporting/reports/reports-header/reports-header.component';
import { RelationshipService } from '../../../contacts-activities/relationship.service';
import { HttpEvent, HttpEventType } from '@angular/common/http';
import { IContact } from '../../models/contact';
import { MoreFilters } from '../more-filters/more-filters.component';
import * as moment from 'moment';

export interface IActivitiesSearchPayload extends IActivitiesSearchFilters {
  PageNumber?: number;
  PageSize?: number;
  OrderBy?: string;
}

export interface IActivitiesSearchResponse {
  MeetingDetailsInfoOutputModels: IActivitySearch[];
  PaginationModel: { PageNumber: number; PageSize: number; TotalCount: number };
}

@Component({
  templateUrl: './activities-search.component.html',
  styleUrls: ['./activities-search.component.scss'],
})
export class ActivitiesSearchComponent implements OnInit {
  @Select(UserState) public user$: Observable<User>;
  @Select(ContactsActivitiesState)
  private state$: Observable<ContactsActivitiesModel>;
  moreFiltersSample?: Partial<MoreFilters> = {
    Ownerunit: [],
    EventType: [],
  };
  user: User;
  reportName: string = 'Activities Search';
  selectedAccountTypes: string[] = [];
  selectedAccountNames: string[] = [];
  selectedIndustryPractice: string[] = [];
  contactsActivities: IActivitySearch[];
  savedReport = {};
  fullNameCollections: IContact[] = [];
  ownerEmailIds: string[];

  state = { loading: false, empty: true, initial: true, error: '' };

  producerFilterCount = 0;

  totalcount: string; //TRKR-5236

  StartDate: string;
  EndDate: string;
  SortBy?: string;
  OrderBy?: string;
  isMorefilter: boolean = false;
  downloadInProgress = false;
  xlData: HttpEvent<Blob>;
  downloadError = null;
  pagesize: number;
  pagination: IPaginationState = this.createInitialPaginationState();
  //Test Auto deployment 07092020
  payload = {
    applied: <IActivitiesSearchPayload>{},
    current: <IActivitiesSearchPayload>{},
  };

  bottomFilters = {
    Date: {
      name: 'Date',
      value: 'Date',
      StartDate: '',
      EndDate: '',
    },
    Type: {
      name: 'Type',
      value: 'Type',
      items: [],
      selected: [],
    },
    CallType: {
      name: 'Call Type',
      value: 'CallType',
      items: [],
      selected: [],
    },
    OwnerCompany: {
      name: 'Owner Company',
      value: 'OwnerCompany',
      items: [],
      selected: [],
    },
    AttendeeOwner: {
      name: 'Attendee/Owner',
      value: 'AttendeeOwner',
      items: [],
      selected: [],
    },
  };

  producer = {
    filters: {
      National: {
        selected: [],
      },
      Region: {
        selected: [],
      },
      Branch: {
        selected: [],
      },
      PAScodes: {
        selected: [],
      },
    },
  };

  filterKeys: Array<keyof IActivitiesSearchFilters> = ['StartDate', 'EndDate', 'Producer', 'ProducerRegion', 'ProducerBranch', 'Customer', 'AccountType', 'CallType', 'CompanyOwnerType', 'ActivityType', 'Owner', 'OwnerUnit', 'IndustryPractice', 'EventType'];

  startDateValue: any;
  endDateValue: any;
  datelabel: any;
  IsOpened = false;
  constructor(private router: Router, private activatedRoute: ActivatedRoute, private filterWatch: FilterWatchService, private reportingService: ReportingService, private activitiesService: ActivitiesSearchService, private contactsActivitiesService: ContactsActivitiesService, private relationshipService: RelationshipService, private cdRef: ChangeDetectorRef) {
    combineLatest([this.user$, this.state$]).subscribe(([user, state]) => {
      this.user = user;
      const storeFilters = { ...state.activitiesSearch };
      this.initializeReport(this.activatedRoute.snapshot.queryParams, storeFilters);
    });

    this.fetchBottomFilters();
  }

  ngOnInit() {
    const payload = this.createInitialPayloadObject();
    if (this.bottomFilters.Date.StartDate) this.startDateValue = this.ISOtoDate(this.bottomFilters.Date.StartDate);
    if (this.bottomFilters.Date.EndDate) this.endDateValue = this.ISOtoDate(this.bottomFilters.Date.EndDate);

    this.setDateLabel();

    if (!Utilities.isEmptyPayload(payload, this.filterKeys)) {
      this.handleApplyFilters();
    }
  }

  initializeReport(queryParams: Params, defaultFilters: IActivitiesSearchFilters = {}) {
    const queryFitlers = this.readQueryParams(this.filterWatch.getByHash(queryParams.filters));

    const filters = !Utilities.isEmptyPayload(queryFitlers) ? queryFitlers : defaultFilters;

    this.selectedAccountNames = filters.Customer || [];
    this.selectedAccountTypes = filters.AccountType || [];
    this.producer.filters.National.selected = filters.Producer || [];
    this.producer.filters.Region.selected = filters.ProducerRegion || [];
    this.producer.filters.Branch.selected = filters.ProducerBranch || [];
    this.bottomFilters.Type.selected = filters.ActivityType || [];
    this.bottomFilters.Date.StartDate = filters.StartDate || '';
    this.bottomFilters.Date.EndDate = filters.EndDate || '';
    this.bottomFilters.CallType.selected = filters.CallType || [];
    this.bottomFilters.OwnerCompany.selected = filters.CompanyOwnerType || [];
    this.ownerEmailIds = filters.Owner;
    this.selectedIndustryPractice = filters.IndustryPractice || [];
    if (filters.OwnerContact !== undefined) {
      this.bottomFilters.AttendeeOwner.selected = (filters.OwnerContact || []).map((c) => c.Email);
      this.bottomFilters.AttendeeOwner.items = filters.OwnerContact || [];
      this.SortBy = filters.SortBy;
    } else {
      this.bottomFilters.AttendeeOwner.selected = filters.Owner || [];
      this.getAttendeeFullName();
    }
    if (filters.OwnerUnit !== undefined) {
      this.isMorefilter = true;
      this.moreFiltersSample.Ownerunit = filters.OwnerUnit || [];
    }
    if (filters.EventType !== undefined) {
      this.isMorefilter = true;
      this.moreFiltersSample.EventType = filters.EventType || [];
    }
  }

  private getAttendeeFullName() {
    const OwnerContact = [];
    if (this.ownerEmailIds !== undefined) {
      this.ownerEmailIds.forEach((value) => {
        this.relationshipService.searchChubbContacts(value).subscribe((data) => {
          if (data !== null) {
            OwnerContact.push({
              FullName: data[0].FullName,
              Email: data[0].Email,
            });
            // this.bottomFilters.AttendeeOwner.selected = (
            //   OwnerContact || []
            // ).map((c) => c.Email);
            this.bottomFilters.AttendeeOwner.items = OwnerContact || [];
          } else {
            this.bottomFilters.AttendeeOwner.items = [];
          }
        });
      });
    }
  }

  fetchBottomFilters() {
    this.reportingService.getActivityTypeFilters().subscribe(
      (data: any) => (this.bottomFilters.Type.items = data),
      (err) => (this.bottomFilters.Type.items = [])
    );
    this.reportingService.getCallTypeFilters().subscribe(
      (data: any) => (this.bottomFilters.CallType.items = data),
      (err) => (this.bottomFilters.CallType.items = [])
    );
    this.reportingService.getOwnerCompanyFilters().subscribe(
      (data: any) => (this.bottomFilters.OwnerCompany.items = data),
      (err) => (this.bottomFilters.OwnerCompany.items = [])
    );
  }

  handleAccountTypesChange(values: AccountChangeEvent) {
    const { accountTypes, accountNames, industrypractice } = values;

    this.selectedAccountTypes = accountTypes;
    this.selectedAccountNames = accountNames;
    this.selectedIndustryPractice = industrypractice;
  }

  handleProducerFilterChange(values: ProducerChangeEvent) {
    const { national, region, branch, pasCodes } = values;

    this.producer.filters.National.selected = national;
    this.producer.filters.Region.selected = region;
    this.producer.filters.Branch.selected = branch;
    this.producer.filters.PAScodes.selected = pasCodes;
  }

  get filterCount() {
    const { filters } = this.producer;

    return filters.National.selected.length + filters.Region.selected.length + filters.Branch.selected.length + filters.PAScodes.selected.length;
  }

  handleApplyFilters(pagination?: IPaginationState) {
    this.payload.applied = this.createInitialPayloadObject();
    this.pagination = pagination || this.createInitialPaginationState();
    this.contactsActivities = [];
    this.state.loading = true;
    this.state.initial = false;
    this.state.empty = false;
    this.state.error = '';

    this.saveActivitiesReport({ UserReportName: 'Activities Search' });

    this.activitiesService.fetchContactsActivitiesSearch(this.payload.applied).subscribe(
      (data: IActivitiesSearchResponse) => this.handleResponseSuccessForContactActivitiesSearch(data),
      (err) => this.handleResponseErrorForContactsActivitiesSearch(err)
    );
  }

  handleSaveReport(info: ISaveReportAs) {
    const details = {
      UserReportName: info.reportName,
      ReportNotes: info.reportNotes,
      FilterId: info.filterId ? Number.parseInt(info.filterId) : undefined,
    };

    this.saveActivitiesReport(details, 'Permanent');
  }

  handleLoadReport(info: ISaveReportAs) {
    this.savedReport = info;
  }

  exportReport($event) {
    this.downloadInProgress = true;
    if ($event.ExportType.format) {
      this.payload.applied.PageNumber = 0;
      this.payload.applied.PageSize = this.pagesize;
      const payload = {
        ...this.payload.applied,
      };
      this.relationshipService.getActivitiesReportFile(payload).subscribe(
        (data) => {
          this.xlData = data;
          switch (data.type) {
            case HttpEventType.Response:
              const filename = `activities.${data.body.type === 'application/pdf' ? 'pdf' : 'xlsx'}`;
              const downloadedFile = new Blob([data.body], {
                type: data.body.type,
              });
              if (navigator.msSaveBlob) {
                navigator.msSaveBlob(downloadedFile, filename);
              } else {
                const a = document.createElement('a');
                a.setAttribute('style', 'display:none;');
                document.body.appendChild(a);
                a.download = filename;
                a.href = URL.createObjectURL(downloadedFile);
                a.target = '_blank';
                a.click();
                document.body.removeChild(a);
              }
              this.downloadInProgress = false;
              break;
          }
        },
        (err) => {
          // console.log('File Report Error:', err);
          this.downloadInProgress = false;
          this.downloadError = 'An Error Occurred while processing your request';
        }
      );
    }
  }

  saveActivitiesReport(details: Partial<IReportPayload>, type: PersistenceType = 'Temporary') {
    const filters = this.payload.applied;
    this.contactsActivitiesService.saveActivitiesSearch(this.user.UserID, filters, details, type).subscribe((data) => {
      this.savedReport = type === 'Permanent' ? data : this.savedReport;
      this.router.navigate([], {
        relativeTo: this.activatedRoute,
        queryParams: {
          filters: this.filterWatch.create(filters as ReportFilters),
          showBrowseBy: false,
        },
        queryParamsHandling: 'merge',
      });
    });
  }

  resortTableData($event) {
    this.SortBy = $event.value;
    this.handleApplyFilters(this.pagination);
  }

  readQueryParams(params: Partial<ReportFilters> = {}): IActivitiesSearchFilters {
    const filters: IActivitiesSearchFilters = Object.keys(params || {})
      .filter((key: keyof IActivitiesSearchFilters) => this.filterKeys.includes(key))
      .reduce((searchFilters: IActivitiesSearchFilters, key: keyof IActivitiesSearchFilters) => {
        //@ts-ignore
        searchFilters[key] = params[key];
        return searchFilters;
      }, {} as IActivitiesSearchFilters);

    return filters;
  }

  handleSortChanged(sort: { column: string; direction: 'asc' | 'desc' }) {
    if (sort) {
      this.SortBy = sort.column;
      this.OrderBy = this.OrderBy === 'asc' ? 'desc' : 'asc';
    } else {
      this.SortBy = undefined;
      this.OrderBy = undefined;
    }

    this.handleApplyFilters(this.pagination);
  }

  refreshData() {
    this.handleApplyFilters(this.pagination);
  }

  get dateFilterLabel() {
    const label = this.bottomFilters.Date.name;
    const count = [this.bottomFilters.Date.StartDate, this.bottomFilters.Date.EndDate].filter((v) => !!v).length;
    return count ? `${label} (${count})` : label;
  }

  dateFieldChange(field: string, e: Event) {
    const target = e.target as HTMLInputElement;
    const seconds = Date.parse(target.value);
    if (seconds) {
      const date = new Date(seconds);
      const utcDate = new Date(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), -date.getTimezoneOffset() / 60, 0, 0);
      this.bottomFilters.Date[field] = utcDate.toISOString();
    } else {
      target.value = '';
      delete this.bottomFilters.Date[field];
    }
  }

  formatDateForInput(dateStr?: string) {
    if (!dateStr) {
      return '';
    }
    const seconds = Date.parse(dateStr);
    if (!seconds) {
      return '';
    }
    const date = new Date(seconds);
    const formated = `${addZero(date.getUTCMonth() + 1)}/${addZero(date.getUTCDate())}/${date.getUTCFullYear()}`;
    return formated;

    function addZero(number: number) {
      if (number < 10) {
        return `0${number}`;
      }
      return `${number}`;
    }
  }

  pageChanged($event) {
    this.payload.applied.PageNumber = $event;
    this.contactsActivities = [];

    this.state.loading = true;

    this.activitiesService.fetchContactsActivitiesSearch(this.payload.applied).subscribe(
      (data: IActivitiesSearchResponse) => this.handleResponseSuccessForContactActivitiesSearch(data),
      (err) => this.handleResponseErrorForContactsActivitiesSearch(err)
    );
  }

  ownerAttendeeChanged(contacts) {
    this.bottomFilters.AttendeeOwner.items = contacts;
    this.bottomFilters.AttendeeOwner.selected = contacts.map((i) => i.Email);
  }

  onDateChange(field, newDate: any) {
    this.setDateLabel();
    if (!newDate) {
      this.bottomFilters.Date[field] = '';
      return;
    }

    if (field === 'StartDate') this.IsOpened = true;
    else {
      this.IsOpened = false;
      this.cdRef.detectChanges();
    }
    const date = new Date(newDate);
    const utcDate = new Date(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), -date.getTimezoneOffset() / 60, 0, 0);
    this.bottomFilters.Date[field] = moment(newDate).format(); //.toISOString(false); //utcDate.toISOString();
  }

  setDateLabel() {
    var count = 0,
      scount = 0,
      ecount = 0;

    if (this.startDateValue) count++;
    if (this.endDateValue) count++;

    this.datelabel = count > 0 ? `Date (${count})` : 'Date';
  }

  private ISOtoDate(dateString) {
    if (!dateString) return;

    var date = new Date(dateString);
    var year = date.getFullYear();
    var month: any = date.getMonth() + 1;
    var dt: any = date.getDate();

    if (dt < 10) {
      dt = `0${dt}`;
    }
    if (month < 10) {
      month = `0${month}`;
    }

    return `${month}/${dt}/${year}`;
  }

  private createInitialPaginationState(): IPaginationState {
    return {
      current: 1,
      size: 10,
      total: 0,

      frame: 6,
    };
  }

  private createInitialPayloadObject(): IActivitiesSearchPayload {
    return {
      StartDate: this.bottomFilters.Date.StartDate,
      EndDate: this.bottomFilters.Date.EndDate,

      Producer: this.producer.filters.National.selected,
      ProducerRegion: this.producer.filters.Region.selected,
      ProducerBranch: this.producer.filters.Branch.selected,

      Customer: this.selectedAccountNames,
      AccountType: this.selectedAccountTypes,

      CallType: this.bottomFilters.CallType.selected,
      CompanyOwnerType: this.bottomFilters.OwnerCompany.selected,
      ActivityType: this.bottomFilters.Type.selected,

      Owner: this.bottomFilters.AttendeeOwner.selected,
      OwnerUnit: this.isMorefilter == true ? this.moreFiltersSample.Ownerunit : [],
      EventType: this.isMorefilter == true ? this.moreFiltersSample.EventType : [],
      IndustryPractice: this.selectedIndustryPractice,
      OrderBy: this.OrderBy || 'Desc',
      SortBy: this.SortBy || 'Date',
      PageNumber: 1,
      PageSize: 10,
    };
  }

  handleLoadSavedReport(data) {
    this.initializeReport(data.queryParams);
    this.handleApplyFilters();
  }

  private remapTextValueWithLowerCase(data) {
    return data.map((i) => ({ text: i.Text, value: i.Value }));
  }

  private handleResponseSuccessForContactActivitiesSearch(data: IActivitiesSearchResponse) {
    if (data !== null) {
      this.contactsActivities = data.MeetingDetailsInfoOutputModels;
      const { PageNumber, PageSize, TotalCount } = data.PaginationModel;

      this.checkPaginationState(PageNumber, PageSize, TotalCount);
      this.state.loading = false;
      this.state.empty = false;
      this.pagesize = data.PaginationModel.TotalCount;
      this.totalcount = 'Count(' + data.PaginationModel.TotalCount + ')'; //TRKR-5236
    } else {
      this.handleResponseErrorForContactsActivitiesSearch(null);
    }
  }

  private checkPaginationState(current, size, total) {
    if (current !== this.pagination.current || total !== this.pagination.current) {
      this.pagination = {
        ...this.pagination,
        total: Math.ceil(total / size),
        current,
      };
    }
  }

  private handleResponseErrorForContactsActivitiesSearch(err) {
    this.contactsActivities = undefined;
    this.state.loading = false;
    this.state.empty = true;
  }

  handleClearAllMoreFilters() {
    this.moreFiltersSample = {};
  }
  onApplyFiltersClick(filters) {
    this.isMorefilter = true;
    this.moreFiltersSample = filters;
    this.handleApplyFilters();
  }
}
