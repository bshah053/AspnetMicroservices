import { Component, Input, OnInit } from '@angular/core';
import { environment } from '../../../environments/environment';

@Component({
	selector: 'cb-help-table',
	templateUrl: './help-table.component.html',
	styleUrls: ['./help-table.component.scss'],
})
export class HelpTableComponent implements OnInit {
	@Input() HelpList = [];
	@Input() category;
	rowHeight: Number = 30;
	headerHeight: Number = 40;
	rowData;

	columns = [
		{
			headerName: 'Detail',
			field: 'FileID',
			cellRenderer: this.renderDetailsColumn(),
			width: 120,
			suppressSizeToFit: true,
			resizable: true,
			sortable: false,
		},
		{
			headerName: 'File Name',
			field: 'FileDetails',
			tooltip: (params) => params.FileDetails,
			width: 1050,
			suppressSizeToFit: true,
			sortable: false,
		},
	];

	constructor() {}

	ngOnInit() {
		this.rowData = this.HelpList.filter((r) => r.Category === this.category);
	}

	private renderDetailsColumn() {
		return (cell, _col) => {
			if (cell && cell.value) {
				const fileID = cell.value;
				const url = `${environment.apiUrl}${environment.apiReporting}/help/${fileID}/Document`;
				console.log('Help-url');
				console.log(url);
				return `<i class="fas fa-file"></i> <a href="${url}" target="_blank" rel="noopener">View</a>`;
			}
			return 'View';
		};
	}
}
