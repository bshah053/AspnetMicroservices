import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { TrackerQueueComponent } from './tracker-queue.component';

describe('TrackerQueueComponent', () => {
	let component: TrackerQueueComponent;
	let fixture: ComponentFixture<TrackerQueueComponent>;

	beforeEach(
		waitForAsync(() => {
			TestBed.configureTestingModule({
				declarations: [TrackerQueueComponent],
			}).compileComponents();
		})
	);

	beforeEach(() => {
		fixture = TestBed.createComponent(TrackerQueueComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
