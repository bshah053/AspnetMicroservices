import { Directive, ElementRef, HostListener, Input } from '@angular/core';
import { Helper } from '../../utilities/common-helper';

@Directive({
  selector: 'input[defaultCurrentDate]',
})
export class DefaultCurrentDateDirective {
  @Input() controlName = '';
  constructor(private el: ElementRef) {}

  @HostListener('focus', ['$event'])
  public onInputFocus(event) {
    this.setDateNow();
  }

  @HostListener('mouseenter')
  onMouseEnter() {
    this.setDateNow();
  }

  private setDateNow() {
    if ([''].includes(this.controlName)) {
      this.el.nativeElement.value = Helper.setDateNow();
    }
  }
}
