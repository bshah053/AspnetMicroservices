import { Component, Input, Output, EventEmitter } from '@angular/core';

type SimpleAdvanced = 'simple' | 'advanced';

export type ExportFileType = 'Pdf' | 'Excel' | 'Custom';
export interface ExportEvent {
  type: SimpleAdvanced;
  format?: ExportFileType;
}

@Component({
  selector: 'cb-export-report-popup',
  templateUrl: './export-report-popup.component.html',
  styleUrls: ['./export-report-popup.component.scss'],
})
export class ExportReportPopupComponent {
  // add two types as input (simple, advanced)
  @Input() name = '';
  @Input() open: boolean = false;
  @Input() type: SimpleAdvanced = 'advanced';
  @Output() export: EventEmitter<ExportEvent> = new EventEmitter();

  get isOpened(): boolean {
    return this.open;
  }

  get isAdvanced(): boolean {
    return this.type === 'advanced';
  }

  get isSimple(): boolean {
    return this.type === 'simple';
  }

  handleToggleOpen(): void {
    if (this.isSimple) {
      this.open = !this.open;
    } else {
      this.export.emit({
        type: this.type,
      });
    }
  }

  handleHide() {
    this.open = false;
  }

  exportAs(format: ExportFileType): void {
    this.export.emit({
      type: 'simple',
      format,
    });
  }
}
