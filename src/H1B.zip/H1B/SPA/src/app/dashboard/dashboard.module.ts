import { TopTargetsComponent } from './regional-manager/top-targets/top-targets.component';
import { NgModule } from '@angular/core';
import { AgGridModule } from 'ag-grid-angular';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { DashboardComponent } from './dashboard.component';
import { UwmGoalsComponent } from './underwriter-manager/uwm-goals/uwm-goals.component';
import { UnderwriterComponent } from './underwriter/underwriter.component';
import { UnderwriterManagerComponent } from './underwriter-manager/underwriter-manager.component';
import { BranchManagerComponent } from './branch-manager/branch-manager.component';
import { DashboardService } from '../dashboard/dashboard.service';
import { RegionalManagerComponent } from './regional-manager/regional-manager.component';
import { RegionalManagerRenewalsComponent } from './components/regional-manager-renewals/regional-manager-renewals.component';
import { RenewalsRatioComponent } from './components/regional-manager-renewals/renewals-ratio/renewals-ratio.component';
import { RouterModule, Routes } from '@angular/router';
import { TrackerQueueComponent } from './tracker-queue/tracker-queue.component';
import { DashboardLandingComponent } from './landing/landing.component';
import { InfoBoxComponent } from './components/info-box/info-box.component';
import { MyMeetingsPageComponent } from './my-meetings-page/my-meetings-page.component';
import { CalendarViewComponent } from './my-meetings-page/calendar-view/calendar-view.component';
import { MonthViewComponent } from './my-meetings-page/month-view/month-view.component';
import { MSLComponent } from './msl/msl.component';
import { GCEComponent } from './gce/gce.component';
import { MyAccountsComponent } from './gce/my-accounts/my-accounts.component';
import { ViewUnitPopupComponent } from './tracker-queue/view-unit-popup/view-unit-popup.component';
import { ReportingService } from '../tracking-reporting/services/reporting.service';
import { RelationshipService } from '../contacts-activities/relationship.service';
import { TrackerQueueTableComponent } from './tracker-queue/tracker-queue-table/tracker-queue-table.component';
import { PostMortemUpdateComponent } from '../shared/post-mortem-update/post-mortem-update.component';
import { ConfirmationDialogBoxComponent } from '../shared/confirmation-dialog-box/confirmation-dialog-box.component';
import { HelpComponent } from '../help/help.component';
import { HelpTableComponent } from '../help/help-table/help-table.component';
import { DashboardRoutingModule } from '../dashboard/dashboard-routing.module';

@NgModule({
  imports: [
    DashboardRoutingModule,
    CommonModule,
    SharedModule,
    AgGridModule,
    RouterModule,
  ],
  declarations: [
    DashboardComponent,
    DashboardLandingComponent,
    MyMeetingsPageComponent,
    InfoBoxComponent,
    UnderwriterComponent,
    UnderwriterManagerComponent,
    BranchManagerComponent,
    RegionalManagerComponent,
    RegionalManagerRenewalsComponent,
    RenewalsRatioComponent,
    TopTargetsComponent,
    TrackerQueueComponent,
    UwmGoalsComponent,
    CalendarViewComponent,
    MonthViewComponent,
    MSLComponent,
    GCEComponent,
    MyAccountsComponent,
    ViewUnitPopupComponent,
    TrackerQueueTableComponent,
    PostMortemUpdateComponent,
    ConfirmationDialogBoxComponent,
    HelpComponent,
    HelpTableComponent,
  ],
  providers: [DashboardService, ReportingService, RelationshipService],
  exports: [PostMortemUpdateComponent, ConfirmationDialogBoxComponent],
})
export class DashboardModule {}
