import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'cb-advanced-sort-popup',
  templateUrl: './advanced-sort-popup.component.html',
  styleUrls: ['./advanced-sort-popup.component.scss'],
})
export class AdvancedSortPopupComponent implements OnInit {
  @Output() advancedSorting: EventEmitter<any> = new EventEmitter();
  open;
  isSelected;
  @Input() name;

  constructor() {}

  ngOnInit() {}

  get isOpened(): boolean {
    return this.open;
  }

  handleToggleOpen(): void {
    this.open = !this.open;
    if (this.open) {
      this.isSelected = true;
    } else {
      this.isSelected = false;
    }
  }

  handleHide(): void {
    this.open = this.isSelected;
  }

  handleAdvancedSorting($event) {
    this.handleToggleOpen();
    this.advancedSorting.next($event);
  }

  handleCancel($event) {
    this.handleToggleOpen();
  }
}
