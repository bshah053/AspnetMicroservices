export class CollectionDeletedItems {
  sectionKey: string;
  id?: string;
  // controlName?: string;
}
