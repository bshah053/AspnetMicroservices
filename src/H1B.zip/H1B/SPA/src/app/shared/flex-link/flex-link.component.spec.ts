import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { FlexLinkComponent } from './flex-link.component';

describe('FlexLinkComponent', () => {
	let component: FlexLinkComponent;
	let fixture: ComponentFixture<FlexLinkComponent>;

	beforeEach(
		waitForAsync(() => {
			TestBed.configureTestingModule({
				declarations: [FlexLinkComponent],
			}).compileComponents();
		})
	);

	beforeEach(() => {
		fixture = TestBed.createComponent(FlexLinkComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
