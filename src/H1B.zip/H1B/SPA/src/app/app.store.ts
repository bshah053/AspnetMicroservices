import { ReportBtnEntitiesState } from './shared/report-tabs/store/report-entity.store';
import { UserState } from './user/user.store';
import { ReportsHeaderState } from './tracking-reporting/reports/reports-header/store/reports-header.store';
import { AccountingYearMonthState } from './store/accounting-month-year.store';
import { ContactsActivitiesState } from './contacts-activities/store/contacts-activities.store';
import { TargetProgressionState } from './tracking-reporting/reports/reports-page/target-progression/store/target-progression.store';

export const AppStore = [UserState, ReportBtnEntitiesState, ReportsHeaderState, AccountingYearMonthState, ContactsActivitiesState, TargetProgressionState];
