import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  SimpleChanges,
  OnChanges,
} from '@angular/core';
import { ReportingService } from '../../tracking-reporting/services/reporting.service';
import { ListItem } from '../radio-list/radio-list.component';

@Component({
  selector: 'cb-advanced-sort',
  templateUrl: './advanced-sort.component.html',
  styleUrls: ['./advanced-sort.component.scss'],
})
export class AdvancedSortComponent implements OnInit, OnChanges {
  @Output() finalSortQuery: EventEmitter<any> = new EventEmitter<any>();
  @Output() cancelPopup: EventEmitter<any> = new EventEmitter<any>();
  @Input() sortReportName;

  sortByColumn: string;
  sortByColumn1: string;
  sortByColumn2: string;
  sortByColumn3: string;
  orderByValue: string; // asc/desc
  orderByValue1: string;
  orderByValue2: string;
  orderByValue3: string;
  preSelectedValue: string;
  advancedSortList: any = [];
  validationMessage: string;
  preselected: number;
  radioSelected: string;

  constructor(private reportingService: ReportingService) {
    // this.fetchFiltersData('');
    this.preSelectedValue = 'Select One';
    this.radioSelected = '';
  }

  ngOnInit() {
    this.resetSelection();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.sortReportName !== undefined) {
      console.log('changes.sortReportName.currentValue');
      console.log(changes.sortReportName.currentValue);
      this.fetchFiltersData(changes.sortReportName.currentValue);
    }
  }

  private resetSelection() {
    this.sortByColumn = '';
    this.sortByColumn1 = '';
    this.sortByColumn2 = '';
    this.sortByColumn3 = '';
    this.orderByValue = '';
    this.orderByValue1 = '';
    this.orderByValue2 = '';
    this.orderByValue3 = '';
  }

  advancedSort() {
    const payload = {
      OrderBy1: this.orderByValue1,
      OrderBy2: this.orderByValue2,
      OrderBy3: this.orderByValue3,
      OrderBy: this.orderByValue,
      SortBy1: this.sortByColumn1,
      SortBy2: this.sortByColumn2,
      SortBy3: this.sortByColumn3,
      SortBy: this.sortByColumn,
    };
    this.validation(payload);
  }

  private validation(payload: {
    OrderBy1: string;
    OrderBy2: string;
    OrderBy3: string;
    OrderBy: string;
    SortBy1: string;
    SortBy2: string;
    SortBy3: string;
    SortBy: string;
  }) {
    if (
      (this.sortByColumn !== '' &&
        this.sortByColumn !== 'Select One' &&
        this.orderByValue !== '') ||
      (this.sortByColumn1 !== '' &&
        this.sortByColumn1 !== 'Select One' &&
        this.orderByValue1 !== '') ||
      (this.sortByColumn2 !== '' &&
        this.sortByColumn2 !== 'Select One' &&
        this.orderByValue2 !== '') ||
      (this.sortByColumn3 !== '' &&
        this.sortByColumn3 !== 'Select One' &&
        this.orderByValue3 !== '')
    ) {
      this.validationMessage = '';
      this.finalSortQuery.next(payload);
    } else {
      this.validationMessage = 'Please select at least one column for sorting.';
    }
  }

  reset() {
    this.resetSelection();
    this.preSelectedValue = 'Select One';
    this.preselected = 0;
    this.radioSelected = '-1';
  }
  cancel($event) {
    this.cancelPopup.next($event);
  }

  AdvancedSortOrder() {
    return [
      {
        value: 'asc',
        text: 'Ascending',
      },
      {
        value: 'desc',
        text: 'Descending',
      },
    ];
  }

  fetchFiltersData(name) {
    const reportName = name !== '' ? name : 'Detail Report';
    this.reportingService
      .getAdvancedSortingColumns(reportName)
      .subscribe((data) => (this.advancedSortList = data));
  }

  handleSortOrderByChange(selected: ListItem, columnNumber: number) {
    this.preselected = -1;
    switch (columnNumber) {
      case 1: {
        this.sortByColumn =
          selected.value === 'Select One' ? '' : selected.value;
        break;
      }
      case 2: {
        this.sortByColumn1 =
          selected.value === 'Select One' ? '' : selected.value;
        break;
      }
      case 3: {
        this.sortByColumn2 =
          selected.value === 'Select One' ? '' : selected.value;
        break;
      }
      case 4: {
        this.sortByColumn3 =
          selected.value === 'Select One' ? '' : selected.value;
        break;
      }
      default: {
        this.sortByColumn = this.sortByColumn1 = this.sortByColumn2 = this.sortByColumn3 =
          '';
      }
    }
  }

  handleAscDescChange(selectedValue: string, columnNumber: number) {
    this.preselected = -1;
    this.radioSelected = '';
    switch (columnNumber) {
      case 1: {
        this.orderByValue = selectedValue;
        break;
      }
      case 2: {
        this.orderByValue1 = selectedValue;
        break;
      }
      case 3: {
        this.orderByValue2 = selectedValue;
        break;
      }
      case 4: {
        this.orderByValue3 = selectedValue;
        break;
      }
      default: {
        this.orderByValue = this.orderByValue1 = this.orderByValue2 = this.orderByValue3 =
          '';
      }
    }
  }
}
