import {
  Component,
  Input,
  Output,
  EventEmitter,
  TemplateRef,
} from '@angular/core';
import { ListItem } from '../radio-list/radio-list.component';

@Component({
  selector: 'cb-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.scss'],
})
export class DropdownComponent {
  @Input() open: boolean = false;
  @Input() readonly: boolean = false;
  @Input() preselected: number = 0;
  @Input() isAdvancePopup: boolean = false;
  headSelected;
  @Input()
  get list(): ListItem[] {
    return this._list;
  }
  set list(val: ListItem[]) {
    if (!val) {
      return;
    }

    this._list = val;
    this.current = val[this.preselected ? this.preselected : 0].text;
  }
  stringval: any;
  @Output() selected = new EventEmitter();

  _list: ListItem[];
  current: string;

  get isOpened(): boolean {
    return this.open;
  }

  get isReadonly(): boolean {
    return this.readonly;
  }

  ngOnChanges() {
    this.current = this._list[this.preselected ? this.preselected : 0].text;
  }

  handleToggleOpen(): void {
    this.open = !this.open;
  }

  handleHide(): void {
    this.open = false;
  }

  handleSelection(item: ListItem): void {
    this.current = item.text;
    this.selected.emit(item);
    this.open = false;
  }
}
