import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { map } from 'rxjs/operators';

import { environment } from '../../environments/environment';
import { ApiService } from './api.service';
import { Injectable } from '@angular/core';

export type ReportType =
  | 'Chubb'
  | 'Customer'
  | 'Producer'
  | 'Contacts'
  | 'Activities';
export type PersistenceType = 'Temporary' | 'Permanent';

export interface IReport {
  UserID: string;
  Persistencetype: PersistenceType;
  UserReportName?: string;
  EfilterName?: string;
  ReportNotes?: string;
  MoreFilterDetails?: string;
  TimeStamp?: string;
}

export interface IReportPayload extends IReport {
  BreadCrumb: string;
  FilterDetail: string;
  ReportType: ReportType;
  SystemReportName: string;
  FilterId?: number;
}

export interface IReportRequest extends IReport {
  ReportType?: ReportType;
  SystemReportName?: string;
  FilterID: number;
  PageNumber: number;
  PageSize: number;
}

@Injectable({
  providedIn: 'root',
})
export class SavedReportsService extends ApiService {
  private _reports = new BehaviorSubject<any>([]);
  readonly reports = this._reports.asObservable();

  constructor(httpClient: HttpClient) {
    super(httpClient, environment.apiReporting);
  }

  add(payload: IReportPayload) {
    return this.post('/reports/savefilters', null, payload).pipe(
      map((report) => {
        this.refreshSavedReports({
          UserID: payload.UserID,
          PersistenceType: 'Temporary',
        });
        return report;
      })
    );
  }

  retrieve(payload: IReportRequest): Observable<IReportPayload[]> {
    return this.post('/reports/recentlyviewed', null, payload).pipe(
      map((reports: IReportPayload[]) => reports)
    );
  }

  remove(reportID: string) {
    return this.post('/reports/deletesavefilter', null, reportID);
  }

  refreshSavedReports(payload) {
    return this.retrieve(payload).subscribe((data) => {
      this._reports.next(data);
    });
  }
}
