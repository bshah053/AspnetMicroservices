import { ErrorHandler, Injectable, Injector, NgZone } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { LoggingService } from 'services/logging.service';
import { ErrorService } from 'services/error.service';
import { Router } from '@angular/router';
import { ErrorDialogService } from 'shared/error/error-dialog.service';

@Injectable()
export class GlobalErrorHandler implements ErrorHandler {
  constructor(
    private router: Router,
    private injector: Injector,
    private errorDialogService: ErrorDialogService,
    private zone: NgZone
  ) {}

  handleError(error: Error | HttpErrorResponse) {
    let message = '';
    let stackTrace = '';
    const errorService = this.injector.get(ErrorService);
    const logger = this.injector.get(LoggingService);
    if (error instanceof HttpErrorResponse) {
      // Server error
      message = errorService.getServerErrorMessage(error);
      stackTrace = errorService.getServerErrorStack(error);
      console.log(`error status : ${error.status} ${error.statusText}`);
      if (error.status === 0) {
        // this.router.navigate(['/error']);
        this.zone.run(() =>
          this.errorDialogService.openDialog(
            'The application server is down, please reach Tracker support team!!!'
          )
        );
      } else {
        logger.logError(message, stackTrace);
      }
    } else {
      // Client Error
      message = errorService.getClientErrorMessage(error);
      stackTrace = errorService.getClientErrorStack(error);
      logger.logError(message, stackTrace);
    }
    console.error(error);
  }
}
