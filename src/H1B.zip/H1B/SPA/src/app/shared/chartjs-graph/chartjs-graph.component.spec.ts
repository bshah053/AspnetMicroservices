import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { ChartjsGraphComponent } from './chartjs-graph.component';

describe('ChartjsGraphComponent', () => {
	let component: ChartjsGraphComponent;
	let fixture: ComponentFixture<ChartjsGraphComponent>;

	beforeEach(
		waitForAsync(() => {
			TestBed.configureTestingModule({
				declarations: [ChartjsGraphComponent],
			}).compileComponents();
		})
	);

	beforeEach(() => {
		fixture = TestBed.createComponent(ChartjsGraphComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
