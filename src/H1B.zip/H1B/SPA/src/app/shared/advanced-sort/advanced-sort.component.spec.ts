import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { AdvancedSortComponent } from './advanced-sort.component';

describe('AdvancedSortComponent', () => {
	let component: AdvancedSortComponent;
	let fixture: ComponentFixture<AdvancedSortComponent>;

	beforeEach(
		waitForAsync(() => {
			TestBed.configureTestingModule({
				declarations: [AdvancedSortComponent],
			}).compileComponents();
		})
	);

	beforeEach(() => {
		fixture = TestBed.createComponent(AdvancedSortComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
