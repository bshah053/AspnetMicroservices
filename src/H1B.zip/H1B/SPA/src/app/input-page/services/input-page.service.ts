import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map, publishReplay, refCount } from 'rxjs/operators';
import { ApiService } from '../../services/api.service';
import { environment } from '../../../environments/environment';
import { UnitSegmentDetailsItem } from '../models/common/unit-segment-details-item';
import { SubmissionLoadItem } from '../models/load/submission-load-item';
import { SubmissionSaveOutputModel } from '../models/save/submission-save-output-model';
import { AuditTrailDetailsItem } from '../models/common/audit-trail-details-item';
import { EscalationDetailItem } from '../models/common/escalation-details-item';
import { DNBCompanyDetailsItem } from '../models/common/dnb-company-details-item';
import { LookupDataElementItem } from '../models/lookup/lookup-data-element-item';
import { SubmissionHelperResponseItem } from '../models/common/submission-helper-response-item';
import { ProducerCodeSearchItem } from '../../shared/submission-producer-lookup/model/producer-code-search-item';
import { UWGeniusQueueDetails } from '../models/common/uw-genius-queue-details';
import { UWGeniusMatchedRecordDetails } from '../models/common/uw-genius-matched-record-details';
import { UWGeniusQueueDetailedItems } from '../models/common/uw-genius-queue-detailed-items';
import { UWGeniusNewRecordDetails } from '../models/common/uw-genius-new-record-details';
import { LayerDetailsItem } from '../dialog/layer-details/model/layer-details-item';
import { SubmissionPolicyDetails } from 'input-page/models/common/policy-details';
import { BuildOutScheduleItems } from 'input-page/dialog/build-out-schedule/model/build-out-schedule-items';
import { AviationDetails } from 'input-page/models/common/aviation-details';
import { OptionsUWItems } from 'input-page/models/load/data-elements-control-details-item';

export interface FilterType {
  // parentValue?: string;
  text: string;
  value: any;
  displayOrder?: number;
}

export interface OptionsResponse {
  // ParentValue?: string;
  Text: string;
  Value: any;
  DisplayOrder?: number;
}

export interface OptionsUWResponseAC {
  Text: string;
  Value: any;
  Email?: string;
  UWBranch?: string;
}

@Injectable({
  providedIn: 'root',
})
export class InputPageService extends ApiService {
  constructor(httpClient: HttpClient, private http: HttpClient) {
    super(httpClient, environment.apiSubmissions);
  }

  unitSegmentDetailsItem$: Observable<UnitSegmentDetailsItem[]>;

  getUnitSegmentDetailsByUserID(userID: string): Observable<UnitSegmentDetailsItem[]> {
    if (!this.unitSegmentDetailsItem$) {
      this.unitSegmentDetailsItem$ = this.get(`/policies/submission/${userID}/getunitsegment`).pipe(
        map((data: UnitSegmentDetailsItem[]) => data),
        publishReplay(1),
        refCount()
      );
    }
    return this.unitSegmentDetailsItem$;
  }

  getInputPageControlsDetails(payload): Observable<SubmissionLoadItem> {
    return this.post('/policies/submission/loadlookup', null, payload).pipe(
      map((data: SubmissionLoadItem) => data),
      catchError(this.handleError)
    );
  }

  getProducerCodeSearchDetails(payload): Observable<ProducerCodeSearchItem[]> {
    return this.post('/policies/submission/producercodesearch', null, payload).pipe(map((data: ProducerCodeSearchItem[]) => data));
  }

  getAllLookUp(payload) {
    return this.post('/policies/submission/lookup', null, payload);
  }

  saveSubmission(payload): Observable<SubmissionSaveOutputModel> {
    return this.post('/policies/submission/save', null, payload).pipe(
      map((data: SubmissionSaveOutputModel) => data),
      catchError(this.handleError)
    );
  }

  sendErrorEmail(payload): Observable<string> {
    return this.post('/policies/submission/senderroremail', null, payload).pipe(map((data: string) => data));
  }

  getAuditTrailDetails(userID, recordNumber): Observable<AuditTrailDetailsItem[]> {
    return this.get('/policies/submission/audittrail', {
      userID,
      recordNumber,
    }).pipe(map((data: any[]) => data));
  }

  getEscalationDetails(userID, recordNumber): Observable<EscalationDetailItem> {
    return this.get('/policies/Submission/Escalate', {
      userID,
      recordNumber,
    }).pipe(map((data: any) => data));
  }

  getDnBCompanyDetails(userID, companyName, stateCode): Observable<DNBCompanyDetailsItem[]> {
    return this.get('/policies/submission/search/DNBCompany', {
      userID,
      companyName,
      stateCode,
    }).pipe(map((data: any) => data));
  }

  getLookupDataDetails(payload): Observable<LookupDataElementItem[]> {
    return this.post('/policies/submission/lookup', null, payload).pipe(map((data: LookupDataElementItem[]) => data));
  }

  getLookupDataByControlName(userID, controlName): Observable<FilterType[]> {
    const payload = {
      UserID: userID,
      Division: '',
      Segment: '',
      Unit: '',
      Childcontrolmaster: '',
      ControlName: [controlName],
      RoutedFrom: '',
    };

    return this.getLookupDataDetails(payload).pipe(
      map((data: LookupDataElementItem[]) =>
        !data
          ? []
          : data
              .filter((lookup) => lookup.ControlName === controlName)
              .map((filter) => ({
                text: filter.DataText,
                value: filter.DataValue,
              }))
      )
    );
  }

  getSubmissionHelperDetails(payload): Observable<SubmissionHelperResponseItem> {
    return this.post('/policies/submission/helper', null, payload).pipe(map((data: SubmissionHelperResponseItem) => data));
  }

  // getSectionControlDetail(payload): Observable<SectionControlDetail> {
  //   return this.post(
  //     '/policies/submission/sectioncontroldetail',
  //     null,
  //     payload
  //   ).pipe(map((data: SectionControlDetail) => data));
  // }

  getUWGeniusQueueDetails(userID): Observable<UWGeniusQueueDetails[]> {
    return this.get('/policies/submission/uwgeniusqueue', {
      userID,
    }).pipe(map((data: UWGeniusQueueDetails[]) => data));
  }

  geniusUWQueueStatusUpdate(payload): Observable<string> {
    return this.post('/policies/submission/uwgeniusqueue/delete', null, payload).pipe(map((data: string) => data));
  }

  getUWGeniusMatchedRecordDetails(userID, pipeID): Observable<UWGeniusMatchedRecordDetails[]> {
    return this.get('/policies/submission/uwgeniusqueue/match', {
      userID,
      pipeID,
    }).pipe(map((data: UWGeniusMatchedRecordDetails[]) => data));
  }

  getUWGeniusNewRecordDetails(userID): Observable<UWGeniusNewRecordDetails> {
    return this.get('/policies/submission/uwgeniusqueue/new', {
      userID,
    }).pipe(map((data: UWGeniusNewRecordDetails) => data));
  }

  getUWGeniusQueueDetailsByPipeId(userID, pipeID): Observable<UWGeniusQueueDetailedItems> {
    return this.get('/policies/submission/uwgeniusqueue/detail', {
      pipeID,
      userID,
    }).pipe(map((data: UWGeniusQueueDetailedItems) => data));
  }

  getLayerDetails(userID, recordNumber): Observable<LayerDetailsItem> {
    return this.get('/policies/submission/layerdetails', {
      userID,
      recordNumber,
    }).pipe(map((data: LayerDetailsItem) => data));
  }

  getPortfolioClassLookupDetails(payload): Observable<FilterType[]> {
    return this.post('/policies/submission/portfolioclass/lookup', null, payload).pipe(
      map((data: OptionsResponse[]) =>
        !data
          ? []
          : data.map((filter) => ({
              text: filter.Text,
              value: filter.Text,
              displayOrder: filter.DisplayOrder,
            }))
      )
    );
  }

  getConstPolicyDetails(userID, recordNumber): Observable<SubmissionPolicyDetails[]> {
    return this.get('/policies/submission/construction/policydetails', {
      userID,
      recordNumber,
    }).pipe(map((data: SubmissionPolicyDetails[]) => data));
  }

  getAviationDetails(userID, recordNumber): Observable<AviationDetails[]> {
    return this.get('/policies/submission/aviationdetails', {
      userID,
      recordNumber,
    }).pipe(map((data: AviationDetails[]) => data));
  }

  getBuildOutScheduleDetails(userID, recordNumber): Observable<BuildOutScheduleItems[]> {
    return this.get('/policies/submission/buildoutscheduledetails', {
      userID,
      recordNumber,
    }).pipe(map((data: BuildOutScheduleItems[]) => data));
  }

  errorLog(payload): Observable<any> {
    return this.post('/policies/submission/errorlog', null, payload).pipe(map((data: any) => data));
  }

  getUSDConvertedForecast(payload): Observable<number> {
    return this.post('/policies/submission/USDForecastConvertor', null, payload).pipe(map((data: any) => data));
  }

  getUnderWriterNameSearch(underwriterName): Observable<OptionsUWItems[]> {
    return this.get(`/filters/${underwriterName}/UnderWriterNameSearch`).pipe(
      map((data: OptionsUWResponseAC[]) =>
        !data
          ? []
          : data.map((filter) => ({
              text: filter.Text,
              value: filter.Value,
              email: filter.Email,
              uwBranch: filter.UWBranch,
            }))
      )
    );
  }

  getCascadingDropdownLookup(payload): Observable<FilterType[]> {
    return this.post('/policies/load/cascadingdropdown', null, payload).pipe(map((data: OptionsResponse[]) => (!data ? [] : data.map((filter) => ({ text: filter.Text, value: filter.Text })))));
  }

  getSubmissionVisibilityByUserID(userID): Observable<string> {
    return this.get(`/profile/${userID}/submissionvisibility`).pipe(map((data: string) => data));
  }

  saveSubmissionComments(payload): Observable<any> {
    return this.post('/policies/submission/savecomments', null, payload).pipe(map((data: any) => data));
  }

  private handleError(err: HttpErrorResponse): Observable<never> {
    let errorMessage: string = '';
    if (err.error instanceof ErrorEvent) {
      errorMessage = `Client Side Error : ${err.error.message}`;
    } else {
      errorMessage = `Server Side Error : ${err.status}: ${err.url}`;
    }
    if (err && err.error && err.error === 'UserID not passed for the request') {
      return throwError('The current session got expired. Please try login again!!!');
    } else if (err && err.error) {
      return throwError(err.error);
    } else {
      return throwError('There is a problem with the service. Kindly reach out Tracker Support Team or try again after sometime!!!');
    }
  }
}
