import { Component, OnInit, Input } from '@angular/core';
import { NavigationService } from '../../services/navigation.service';

@Component({
  selector: 'regional-manager',
  templateUrl: './regional-manager.component.html',
  styleUrls: ['./regional-manager.component.scss'],
})
export class RegionalManagerComponent implements OnInit {
  @Input() user: Object;

  branches: any[] = [];

  constructor(private navigation: NavigationService) {}

  ngOnInit() {}

  handleBranchesUpdate(data) {
    this.branches = data.filter((b: any) => b.Branch !== 'Total');
  }

  meetingsSeeAllClicked() {
    this.navigation.toMyMeetings();
  }
}
