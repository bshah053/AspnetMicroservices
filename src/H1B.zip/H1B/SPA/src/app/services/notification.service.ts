import { Injectable, NgZone } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';

@Injectable({
  providedIn: 'root',
})
export class NotificationService {
  constructor(public snackBar: MatSnackBar, private zone: NgZone) {}

  showSuccess(message: string, durationInSeconds: number = 5): void {
    this.zone.run(() => {
      this.snackBar.open(message, 'Ok', {
        panelClass: ['sucess-msg'],
        horizontalPosition: 'center',
        verticalPosition: 'bottom',
        duration: durationInSeconds * 1000,
      });
    });
  }

  showError(message: string, durationInSeconds: number = 5): void {
    this.zone.run(() => {
      this.snackBar.open(message, 'Ok', {
        panelClass: ['error-msg'],
        horizontalPosition: 'center',
        verticalPosition: 'bottom',
        duration: durationInSeconds * 1000,
      });
    });
  }

  showWarning(message: string, durationInSeconds: number = 5): void {
    this.zone.run(() => {
      this.snackBar.open(message, 'Ok', {
        panelClass: ['error-msg'],
        horizontalPosition: 'center',
        verticalPosition: 'bottom',
        duration: durationInSeconds * 1000,
      });
    });
  }
}
