import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { ApiService } from '../services/api.service';
import { ICompletedActivity } from '../shared/completed-activity/completed-activity.component';
import { Task } from '../shared/tasks/tasks.component';
import { IContact } from './models/contact';
import { IActivitiesSearchResponse } from './search/activities-search/activities-search.component';
import {
  IMyMeetingsPayload,
  ICalendarMeetingsPayload,
} from '../dashboard/my-meetings-page/my-meetings-page.component';

@Injectable({ providedIn: 'root' })
export class RelationshipService extends ApiService {
  constructor(httpClient: HttpClient) {
    super(httpClient, environment.apiRelationship);
  }

  getMyMeetings(userID, pageNumber = 1, pageSize = 100) {
    return this.get(
      `/dynamics/users/${userID}/appointments/${pageNumber}/${pageSize}`
    );
  }

  getAttendeeOwnerFilters() {
    return this.get('/filters/dynamics/contacts');
  }

  searchContacts(
    name: string,
    pageIndex = 1,
    pageSize = 100
  ): Observable<IContact[]> {
    return <Observable<IContact[]>>(
      this.get(
        `/dynamics/search/contacts/${pageIndex}/${pageSize}?Name=${name}`
      )
    );
  }

  searchChubbContacts(
    name: string,
    pageIndex = 1,
    pageSize = 100
  ): Observable<IContact[]> {
    return <Observable<IContact[]>>(
      this.post(
        '/dynamics/search/chubbemployeecontacts',
        null,
        {
          Name: [name],
          PageNumber: pageIndex,
          PageSize: pageSize,
        }
      )
    );
  }

  getCompletedActivities(
    userId: string,
    pageIndex = 1,
    pageSize = 100
  ): Observable<ICompletedActivity[]> {
    return <Observable<ICompletedActivity[]>>this.post(
      '/dynamics/users/completedactivities',
      null,
      {
        UserID: userId,
        PageNumber: pageIndex,
        PageSize: pageSize,
      }
    ).pipe(
      map(
        (res: IActivitiesSearchResponse) => res.MeetingDetailsInfoOutputModels
      )
    );
  }

  getTasks(userId: string, pageIndex = 1, pageSize = 100): Observable<Task[]> {
    return <Observable<Task[]>>(
      this.get(`/dynamics/users/${userId}/tasks/${pageIndex}/${pageSize}`)
    );
  }

  getMeetingsForMyMeetingsPage(payload: IMyMeetingsPayload) {
    return this.post('/dynamics/mymeetings/appointments', null, payload);
  }

  getCalendarMeetings(payload: ICalendarMeetingsPayload) {
    return this.post(
      '/dynamics/mymeetings/calendarappointments',
      null,
      payload
    );
  }

  getActivitiesReportFile(payload) {
    return this.getFile('/dynamics/search/activities/excel', payload);
  }
  getContactReportFile(payload) {
    return this.getFile('/dynamics/search/contactdetails/excel', payload);
  }

}

