import { Component, HostListener, Inject, Input } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'cb-input-form-popup',
  templateUrl: './input-form-popup.component.html',
  styleUrls: ['./input-form-popup.component.scss'],
})
export class InputFormPopupComponent {
  constructor(public dialogRef: MatDialogRef<InputFormPopupComponent>, @Inject(MAT_DIALOG_DATA) public data: any) {}

  @HostListener('window:keyup.esc')
  onKeyUp() {
    this.dialogRef.close();
  }

  handleClick(action: string): void {
    if (action === 'Ok') {
      this.dialogRef.close('close');
    } else {
      this.dialogRef.close('stay');
    }
  }

  handleRedirect(recordNumber) {
    this.dialogRef.close(recordNumber);
  }

  handleNotify() {
    this.dialogRef.close('Notify');
  }
}
