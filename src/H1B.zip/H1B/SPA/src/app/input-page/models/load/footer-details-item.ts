export interface FooterDetailsItem {
  SaveYN: string;
  CloseYN: string;
  DeleteYN: string;
  CopyYN: string;
  NextTermYN: string;
  ResetYN: string;
  AuditTrailYN: string;
  PostMortemYN: string;
}
