import {
  IContactSearchFilters,
  IActivitiesSearchFilters,
} from './contacts-activities.models';

export class SetContactSearchFilters {
  public static type = 'SetContactSearchFilters';
  constructor(public readonly payload: IContactSearchFilters) {}
}

export class SetActivitiesSearchFilters {
  public static type = 'SetActivitiesSearchFilters';
  constructor(public readonly payload: IActivitiesSearchFilters) {}
}
