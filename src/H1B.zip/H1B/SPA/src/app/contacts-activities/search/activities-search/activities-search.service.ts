import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { ApiService } from '../../../services/api.service';
import {
  IActivitiesSearchPayload,
  IActivitiesSearchResponse,
} from './activities-search.component';

@Injectable({ providedIn: 'root' })
export class ActivitiesSearchService extends ApiService {
  constructor(httpClient: HttpClient) {
    super(httpClient, environment.apiRelationship);
  }

  fetchContactsActivitiesSearch(
    payload: IActivitiesSearchPayload
  ): Observable<IActivitiesSearchResponse> {
    return <Observable<IActivitiesSearchResponse>>(
      this.post('/dynamics/search/activities', null, payload)
    );
  }
}
