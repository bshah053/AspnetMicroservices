import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { ContactsActivitiesComponent } from './contacts-activities.component';

describe('ContactsActivitiesComponent', () => {
	let component: ContactsActivitiesComponent;
	let fixture: ComponentFixture<ContactsActivitiesComponent>;

	beforeEach(
		waitForAsync(() => {
			TestBed.configureTestingModule({
				declarations: [ContactsActivitiesComponent],
			}).compileComponents();
		})
	);

	beforeEach(() => {
		fixture = TestBed.createComponent(ContactsActivitiesComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
