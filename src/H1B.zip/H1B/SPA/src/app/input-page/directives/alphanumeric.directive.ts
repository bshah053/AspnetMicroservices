import { Directive, ElementRef, HostListener, Input } from '@angular/core';

@Directive({
  selector: 'input[allowAlphaNumeric]',
})
export class AlphaNumericDirective {
  @Input() controlName = '';
  constructor() {}

  @HostListener('keydown', ['$event'])
  onkeydown(event) {
    const charCode = event.keyCode;
    if (['RiskSICCode', 'DBSIC'].includes(this.controlName)) {
      if (
        !(
          charCode === 8 ||
          (charCode >= 48 && charCode <= 57) ||
          (charCode >= 96 && charCode <= 105) ||
          (charCode >= 65 && charCode <= 90) ||
          charCode === 9 ||
          charCode === 39 ||
          charCode === 46
        )
      ) {
        event.preventDefault();
      }
    }
  }
}
