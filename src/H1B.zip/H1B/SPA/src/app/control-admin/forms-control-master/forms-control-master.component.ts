import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'forms-control-master',
  templateUrl: './forms-control-master.component.html',
  styleUrls: ['./forms-control-master.component.scss'],
})
export class FormsControlMasterComponent implements OnInit {
  isShowContent = false;
  isLoading = true;
  constructor() {}

  ngOnInit(): void {}
}
