import { CopyDeleteRequestModel } from './../model/copydelete-request-model';
import { MatDialog } from '@angular/material/dialog';

import { ConfirmationDialogComponent } from 'shared/confirmation-dialog/confirmation-dialog.component';
import { Injectable } from '@angular/core';
import { ReportingService } from 'tracking-reporting/services/reporting.service';
import { Status } from 'utilities/common-enum-const';
import { SharedService } from './shared.service';
import { InputFormPopupComponent } from 'input-page/dialog/input-form-popup/input-form-popup.component';

@Injectable({
  providedIn: 'root',
})
export class CopyDeleteService {
  constructor(public dialog: MatDialog, private reportingService: ReportingService, private sharedService: SharedService) {}

  showConfirmationDelete(copyDeleteRequest: CopyDeleteRequestModel) {
    copyDeleteRequest.Action = 'Delete';
    this.showConfirmation(copyDeleteRequest);
  }

  showConfirmationCopy(copyDeleteRequest: CopyDeleteRequestModel) {
    copyDeleteRequest.Action = 'Copy';
    this.showConfirmation(copyDeleteRequest);
  }

  private showConfirmation(copyDeleteRequest: CopyDeleteRequestModel) {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '510px',
      data: {
        Action: copyDeleteRequest.Action,
        label: copyDeleteRequest.Action,
        Message: '',
        IsTarget: this.setCopyTargetStatus(copyDeleteRequest),
      },
      hasBackdrop: true,
      backdropClass: 'backdropBackground',
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result && result !== null) {
        copyDeleteRequest.Action = result.Action;
        copyDeleteRequest.Type = result.Type;
        this.handleSubmissionCopyDelete(copyDeleteRequest);
      }
    });
  }

  private setCopyTargetStatus(copyRequest: CopyDeleteRequestModel): boolean {
    if (copyRequest.Action === 'Copy' && !this.isSubmissionLinked(copyRequest.LinkedRecordNumber) && (copyRequest.Status === Status.Target || copyRequest.Status === Status.TargetClosed) && ['Major Accounts Division', 'Commercial Insurance Division', 'Small Retail Division'].includes(copyRequest.Company)) {
      return true;
    } else {
      return false;
    }
  }

  handleSubmissionCopyDelete(copyDeleteRequest: CopyDeleteRequestModel) {
    switch (copyDeleteRequest.Action) {
      case 'Delete confirm':
        this.handleDeleteSubmission(copyDeleteRequest);
        break;
      case 'Copy confirm':
        this.handleCopySubmission(copyDeleteRequest);
        break;
    }
  }

  handleDeleteSubmission(deleteRequest: CopyDeleteRequestModel) {
    let dialogRef;
    if (deleteRequest.Source === 'TQ') {
      this.sharedService.sendShowLoading();
    } else {
      dialogRef = this.dialog.open(InputFormPopupComponent, {
        data: {
          loader: true,
        },
      });
    }
    this.reportingService.deleteTransactionByRecordNo(deleteRequest.RecordNumber, deleteRequest.UserID).subscribe(
      (data: any) => {
        if (deleteRequest.Source === 'TQ') {
          this.sharedService.sendHideLoading();
          this.sharedService.sendTQReloadRequest();
        } else {
          dialogRef.close();
          this.deleteSuccessDialog(data);
        }
      },
      (err) => {
        if (deleteRequest.Source === 'TQ') {
          this.sharedService.sendHideLoading();
        }
      }
    );
  }

  handleCopySubmission(copyRequest: CopyDeleteRequestModel) {
    let dialogRef;
    if (copyRequest.Source === 'TQ') {
      this.sharedService.sendShowLoading();
    } else {
      dialogRef = this.dialog.open(InputFormPopupComponent, {
        data: {
          loader: true,
        },
      });
    }

    if (copyRequest.Type === 'Target') {
      this.reportingService.copySubmission(copyRequest.RecordNumber, copyRequest.UserID).subscribe(
        (data: any) => {
          if (copyRequest.Source === 'TQ') {
            this.sharedService.sendHideLoading();
            this.sharedService.sendTQReloadRequest();
          } else {
            dialogRef.close();
            this.copySuccessDialog(data, copyRequest.Type);
          }
        },
        (err) => {
          if (copyRequest.Source === 'TQ') {
            this.sharedService.sendHideLoading();
          } else {
            dialogRef.close();
          }
        }
      );
    } else if (copyRequest.Type === 'Submission') {
      this.reportingService.copyLinkedSubmission(copyRequest.RecordNumber, copyRequest.UserID).subscribe(
        (data: any) => {
          if (copyRequest.Source === 'TQ') {
            this.sharedService.sendHideLoading();
            this.sharedService.sendTQReloadRequest();
          } else {
            dialogRef.close();
            this.copySuccessDialog(data, copyRequest.Type);
          }
        },
        (err) => {
          if (copyRequest.Source === 'TQ') {
            this.sharedService.sendHideLoading();
          } else {
            dialogRef.close();
          }
        }
      );
    }
  }

  isSubmissionLinked(linkedRecordNumber) {
    if (linkedRecordNumber && linkedRecordNumber > 0) {
      return true;
    } else {
      return false;
    }
  }

  private copySuccessDialog(data: any, type: string) {
    let dialogRef = this.dialog.open(InputFormPopupComponent, {
      data: {
        Message: data != null && data > 0 ? 'Record Copied Successfully !' : 'There is an occured while copying the record!!!',
        IsSuccess: data != null && data > 0 ? true : false,
        loader: false,
        RecordNumber: data != null && data > 0 ? data : 0,
        Action: 'Copy',
        OkLabel: 'Stay',
        RedirectLabel: 'Go to this Record',
      },
    });
    dialogRef.afterClosed().subscribe((result) => {
      result = {
        Action: result,
        Type: type,
        RecordNumber: data != null && data > 0 ? data : 0,
      };
      this.sharedService.sendSubmissionCopyDeleteStatus(result);
    });
  }

  deleteSuccessDialog(data: any) {
    let dialogRef = this.dialog.open(InputFormPopupComponent, {
      data: {
        Message: data != null ? 'Record deleted Successfully !' : 'There is an issue while deleting the record!!!',
        IsSuccess: data != null ? true : false,
        loader: false,
        RecordNumber: 0,
        Action: 'Delete',
        OkLabel: 'Ok',
        RedirectLabel: '',
      },
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result && result === 'close') {
        result = {
          Action: result,
        };
        this.sharedService.sendSubmissionCopyDeleteStatus(result);
      }
    });
  }
}
