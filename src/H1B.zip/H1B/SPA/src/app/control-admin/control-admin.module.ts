import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ControlAdminRoutingModule } from './control-admin-routing.module';
import { ControlAdminComponent } from './control-admin.component';
import { ControlAdminService } from './services/control-admin.service';
import { MaterialModule } from '../material-module';
import { SharedModule } from 'shared/shared.module';
import { UtilitiesModule } from 'utilities/utilities.module';
import { FormsControlMasterComponent } from './forms-control-master/forms-control-master.component';
import { GenericsFormsMasterComponent } from './generics-forms-master/generics-forms-master.component';
import { EditHierarchyComponent } from './dialog/edit-hierarchy/edit-hierarchy.component';

@NgModule({
  declarations: [
    ControlAdminComponent,
    FormsControlMasterComponent,
    GenericsFormsMasterComponent,
    EditHierarchyComponent,
  ],
  imports: [
    CommonModule,
    ControlAdminRoutingModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    UtilitiesModule,
  ],
  providers: [ControlAdminService],
})
export class ControlAdminModule {}
