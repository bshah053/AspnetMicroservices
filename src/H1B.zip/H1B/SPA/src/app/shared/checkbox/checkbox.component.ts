import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'cb-checkbox',
  templateUrl: './checkbox.component.html',
  styleUrls: ['./checkbox.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CheckboxComponent implements OnInit {
  @Input() id: string;
  @Input() className = 'defaultCheckbox';
  @Input() label: string = '';
  @Input() checked: boolean = false;
  @Input() value: any = null;
  @Input() disabled: boolean = false;

  @Output() change = new EventEmitter<any>();

  constructor() {}

  ngOnInit() {}

  handleChange(event: MouseEvent) {
    event.stopPropagation();
    this.checked = !this.checked;
    this.change.next({ value: this.value, selected: this.checked });
  }
}
