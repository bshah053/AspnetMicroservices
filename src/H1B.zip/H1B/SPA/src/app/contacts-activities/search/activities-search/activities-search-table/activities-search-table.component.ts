import { Component, Input, TemplateRef, ViewChild, OnChanges, AfterViewInit, Output, EventEmitter, SimpleChange } from '@angular/core';
import { Router } from '@angular/router';
import { ColDef } from 'ag-grid-community';
import { FilterWatchService } from '../../../../services/filter-watch.service';
import { ReportsHeaderModel } from '../../../../tracking-reporting/reports/reports-header/store/reports-header.model';
import { UrlHelper } from '../../../../utilities/url.helper';
import { ContactsActivitiesHelper } from '../../../../utilities/contacts-activities.helper';
import { AgGridTemplateRendererComponent } from '../../../../shared/ag-grid-utils/ag-grid-template-renderer.component';
import Utilities from '../../../../shared/utilities';
import { ModalService } from '../../../../shared/modal/modal.service';
import { NavigationService } from '../../../../services/navigation.service';
import { User } from '../../../../user/user.model';
import { ISaveReportAs } from '../../../../contacts-activities/models/saveReports';

export interface IActivitySearch {
	RelatedTo: string;
	Subject: string;
	StartDate: string;
	EndDate: string;
	Location: string;
	RequiredAttendees: string;
	OptionalAttendees: string;
	MeetingTime: string;
	Attendees: string;
	Owner: string;
	MeetingGUID: string;
	RelatedToGUID: string;
	OwnerGUID: string;
	AttendeesGUID: string;
	AttendeesEmail: string;
	AttendeesList?: { name: string; email: string; guid: string }[];
	AccountType: string;
	ProducerName: string;
	ProducerRegion: string;
	ProducerBranch: string;
	ClientID: string;
	Date: string;
	Task: string;
	Topics: string;
	Name: string;
	LastModified: string;
	AccountName: string;
	// OwnerCompany: string;
}

@Component({
	selector: 'cb-activities-search-table',
	templateUrl: './activities-search-table.component.html',
	styleUrls: ['./activities-search-table.component.scss'],
})
export class ActivitiesSearchTableComponent implements OnChanges {
	@Input() data: IActivitySearch[];
	@Input() error: string;
	@Input() user: User;
	@Input() savedReportId: number;
	@Input() sortByProperty: string;
	@Input() actvityType: string[];
	@Input() count: number; //TRKR-5236
	@Output() resort = new EventEmitter();
	@Output() saveReport = new EventEmitter<ISaveReportAs>();
	@Output() loadedReport = new EventEmitter<ISaveReportAs>();
	@Output() refresh = new EventEmitter();
	@Output() exportReport: EventEmitter<any> = new EventEmitter();

	@ViewChild('relatedToCell') private relatedToCell: TemplateRef<any>;
	@ViewChild('subjectCell') private subjectCell: TemplateRef<any>;
	@ViewChild('attendeesCell') private attendeesCell: TemplateRef<any>;
	@ViewChild('ownerCell') private ownerCell: TemplateRef<any>;
	@ViewChild('DescriptioCell') private DescriptioCell: TemplateRef<any>;
	@ViewChild('AccountNameCell') private AccountNameCell: TemplateRef<any>;
	@ViewChild('CallTypeCell') private CallTypeCell: TemplateRef<any>;
	@ViewChild('OwnerCompanyCell') private OwnerCompanyCell: TemplateRef<any>;
	@ViewChild('OwnerUnitCell') private OwnerUnitCell: TemplateRef<any>;
	@ViewChild('PurposeCell') private PurposeCell: TemplateRef<any>;
	@ViewChild('MeetingresultsCell') private MeetingResultsCell: TemplateRef<any>;

	name = 'Activities Search';

	activities: IActivitySearch[];
	columns: ColDef[];
	totalCount: number; //TRKR-5236

	sort = {
		opened: false,
		current: { text: 'Related To', value: 'Related To' },
		list: [
			{ text: 'Related To', value: 'RelatedTo' },
			{ text: 'Subject', value: 'Subject' },
			{ text: 'Attendee', value: 'Attendee' },
			{ text: 'Date', value: 'Date' },
			{ text: 'Task', value: 'Task' },
			{ text: 'Owner', value: 'Owner' },
			{ text: 'Description', value: 'Topics' },
			{ text: 'Meeting With (Company/Customer)', value: 'AccountName' },
			{ text: 'Call Type', value: 'CallType' },
			{ text: 'Owner Company', value: 'OwnerCompany' },
			{ text: 'Owner Unit', value: 'OwnerUnit' },
			{ text: 'Purpose', value: 'Purpose' },
			{ text: 'Meeting Results', value: 'MeetingResults' },
		],
	};

	constructor(private filterWatch: FilterWatchService, private modalService: ModalService, private navigation: NavigationService, private router: Router) {}

	ngOnChanges(changes: { [key in keyof ActivitiesSearchTableComponent]: SimpleChange }): void {
		if (changes.data && Array.isArray(this.data)) {
			this.activities = this.data.map(ContactsActivitiesHelper.toViewModel);
		}
		if (changes.sortByProperty) {
			this.updateSortBy(changes.sortByProperty.currentValue);
		}
		this.columns = [
			{
				headerName: 'Related To',
				headerTooltip: 'Related To',
				field: 'RelatedTo',
				tooltipValueGetter: (params) => params.value,
				width: 208,
				suppressSizeToFit: true,
				cellRendererFramework: AgGridTemplateRendererComponent,
				cellRendererParams: { ngTemplate: this.relatedToCell },
			},
			{
				headerName: 'Subject',
				headerTooltip: 'Subject',
				field: 'Subject',
				tooltipValueGetter: (params) => params.value,
				width: 310,
				suppressSizeToFit: true,
				cellRendererFramework: AgGridTemplateRendererComponent,
				cellRendererParams: { ngTemplate: this.subjectCell },
				sortable: true,
			},
			{
				headerName: 'Attendees',
				field: 'Attendees',
				headerTooltip: 'Attendees',
				width: 402,
				suppressSizeToFit: true,
				sortable: false,
				cellRendererFramework: AgGridTemplateRendererComponent,
				cellRendererParams: { ngTemplate: this.attendeesCell },
			},
			{
				headerName: 'Date',
				field: 'Date',
				cellClass: 'date',
				valueFormatter: Utilities.dateFormatter,
				tooltipValueGetter: (params) => params.valueFormatted,
				width: 151,
				suppressSizeToFit: true,
			},

			{
				headerName: 'Task',
				field: 'Task',
				width: 98,
				cellRenderer: this.renderTaskColumn(),
				suppressSizeToFit: true,
			},

			{
				headerName: 'Owner',
				field: 'Owner',
				width: 150,
				suppressSizeToFit: true,
				cellRendererFramework: AgGridTemplateRendererComponent,
				cellRendererParams: { ngTemplate: this.ownerCell },
			},
			{
				headerName: 'Description',
				field: 'Topics',
				headerTooltip: 'Topics',
				width: 402,
				suppressSizeToFit: true,
				sortable: false,
				cellRendererFramework: AgGridTemplateRendererComponent,
				cellRendererParams: { ngTemplate: this.DescriptioCell },
			},
			{
				headerName: 'Meeting With (Company/Customer)',
				field: 'AccountName',
				headerTooltip: 'Meeting With (Company/Customer)',
				width: 402,
				suppressSizeToFit: true,
				sortable: true,
				hide: this.actvityType.indexOf('Task') > -1 ? true : false,
				cellRendererFramework: AgGridTemplateRendererComponent,
				cellRendererParams: { ngTemplate: this.AccountNameCell },
			},
			{
				headerName: 'Call Type',
				field: 'CallType',
				headerTooltip: 'Call Type',
				width: 402,
				suppressSizeToFit: true,
				sortable: true,
				hide: this.actvityType.indexOf('Task') > -1 ? true : false,
				cellRendererFramework: AgGridTemplateRendererComponent,
				cellRendererParams: { ngTemplate: this.CallTypeCell },
			},
			{
				headerName: 'Owner Company',
				field: 'OwnerCompany',
				headerTooltip: 'Owner Company',
				width: 402,
				suppressSizeToFit: true,
				sortable: true,
				hide: this.actvityType.indexOf('Task') > -1 ? true : false,
				cellRendererFramework: AgGridTemplateRendererComponent,
				cellRendererParams: { ngTemplate: this.OwnerCompanyCell },
			},
			{
				headerName: 'Owner Unit',
				field: 'OwnerUnit',
				headerTooltip: 'Owner Unit',
				width: 402,
				suppressSizeToFit: true,
				sortable: true,
				hide: this.actvityType.indexOf('Task') > -1 ? true : false,
				cellRendererFramework: AgGridTemplateRendererComponent,
				cellRendererParams: { ngTemplate: this.OwnerUnitCell },
			},
			{
				headerName: 'Purpose',
				field: 'Purpose',
				headerTooltip: 'Purpose',
				width: 402,
				suppressSizeToFit: true,
				sortable: true,
				hide: this.actvityType.indexOf('Task') > -1 ? true : false,
				cellRendererFramework: AgGridTemplateRendererComponent,
				cellRendererParams: { ngTemplate: this.PurposeCell },
			},
			{
				headerName: 'Meeting Results',
				field: 'MeetingResults',
				headerTooltip: 'Meeting results',
				width: 402,
				suppressSizeToFit: true,
				sortable: true,
				hide: this.actvityType.indexOf('Task') > -1 ? true : false,
				cellRendererFramework: AgGridTemplateRendererComponent,
				cellRendererParams: { ngTemplate: this.MeetingResultsCell },
			},
		];
		this.totalCount = this.count; //TRKR-5236
	}

	renderTaskColumn() {
		return (cell) => {
			const isTask = ['Task', 'task'].indexOf(cell.data.Task) > -1,
				template = `
          <div class="icon-box flag">
            <div class="top"></div>
            <div class="left"></div>
            <div class="right"></div>
            <div class="bottom"></div>
          </div>
        `;

			return isTask ? template : ' ';
		};
	}

	addNewEntity(type: 'meeting' | 'task') {
		const link = type === 'meeting' ? UrlHelper.dynamicsMeetingUrl() : UrlHelper.dynamicsTaskUrl();

		this.modalService.openBrowserWindow(link).then((_) => this.refresh.emit());
	}

	handleSaveReport(data: ISaveReportAs) {
		this.saveReport.next(data);
	}

	exportReportHandler($event) {
		this.exportReport.emit({
			ExportType: $event,
			ScreenName: 'Activities Search',
		});
	}

	handleSortChanged(sort: { column: string; direction: 'asc' | 'desc' }) {
		this.resort.next(sort);
	}

	sortBy(item) {
		this.sort.current = item;
		this.sort.opened = false;

		this.handleSortChanged({ column: item.value, direction: 'asc' });
	}

	private updateSortBy(property: string) {
		this.sort.current = this.sort.list.find((item) => item.value === property) || this.sort.list[0];
	}

	private navigateToCustomer(clientName: string, clientId: string) {
		const filters = this.filterWatch.serializeFromPayload(
			<ReportsHeaderModel>{
				ClientID: [clientId + ''],
				ClientName: [clientName],
			},
			{ browseByProducer: 'Insured Search', browseByValue: 'none' }
		);

		this.router
			.navigate(['tracking-and-reporting/customer'], {
				queryParams: {
					filters: this.filterWatch.create(filters),
					showBrowseBy: false,
				},
			})
			.then(() => {});
	}

	private navigateToProducer(producerName: string) {
		const filters = this.filterWatch.serializeFromPayload(
			<ReportsHeaderModel>{
				ProducerName: [producerName],
			},
			{ browseByProducer: 'Producers', browseByValue: 'producerName' }
		);

		this.router
			.navigate(['tracking-and-reporting/producer-profile'], {
				queryParams: {
					filters: this.filterWatch.create(filters),
					showBrowseBy: false,
				},
			})
			.then(() => {});
	}

	openActivity(entity: IActivitySearch) {
		const url = ContactsActivitiesHelper.activityUrl(entity);
		this.modalService.openBrowserWindow(url).then((_) => this.refresh.emit());
	}

	openRelatedTo(activity: IActivitySearch) {
		ContactsActivitiesHelper.openRelatedTo(activity, this.navigation);
	}

	openAttendee(attendeeId) {
		this.modalService.openBrowserWindow(UrlHelper.dynamicsEditContactUrl(attendeeId)).then((_) => this.refresh.emit());
	}

	openOwner(ownerId) {
		this.modalService.openBrowserWindow(UrlHelper.dynamicsOwnerUrl(ownerId)).then((_) => this.refresh.emit());
	}

	handleLoadReport(data: ISaveReportAs) {
		this.loadedReport.next(data);
	}
}
