import { Component, OnInit } from '@angular/core';
import { Store, Select } from '@ngxs/store';
import { Observable } from 'rxjs';
import { UserService } from '../../user/user.service';
import { UserState } from '../../user/user.store';
import { User } from '../../user/user.model';

@Component({
  selector: 'dashboard-landing-component',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.scss'],
  providers: [],
})
export class DashboardLandingComponent implements OnInit {
  user: User;

  @Select(UserState) public user$: Observable<User>;

  constructor(private store: Store) {}

  getUserState() {
    this.user$.subscribe((user) => {
      this.user = user;
    });
  }

  ngOnInit() {
    this.getUserState();
  }
}
