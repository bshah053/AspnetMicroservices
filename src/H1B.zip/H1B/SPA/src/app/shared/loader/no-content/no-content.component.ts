import {
  Component,
  ViewEncapsulation,
  Input,
  TemplateRef,
} from '@angular/core';

@Component({
  selector: 'cb-no-content',
  templateUrl: './no-content.component.html',
  styleUrls: ['./no-content.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class NoContentComponent {
  @Input() template: TemplateRef<any>;
  @Input() message: TemplateRef<any>;
  @Input() initial: boolean = true;
}
