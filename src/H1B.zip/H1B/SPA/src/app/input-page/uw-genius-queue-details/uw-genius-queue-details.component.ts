import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Select, Store } from '@ngxs/store';
import { combineLatest, Observable } from 'rxjs';

import { User } from 'user/user.model';
import { UserState } from 'user/user.store';
import { RoutedFrom } from 'shared/utilities';
import Utilities from 'shared/utilities';
import { InputPageService, FilterType } from '../services/input-page.service';
import { ActivatedRoute, Router } from '@angular/router';
import { UWGeniusMatchedRecordDetails } from '../models/common/uw-genius-matched-record-details';
import { ReportsHeaderModel } from '../../tracking-reporting/reports/reports-header/store/reports-header.model';
import { FilterWatchService } from '../../services/filter-watch.service';
import { UWGeniusNewRecordDetails } from '../models/common/uw-genius-new-record-details';
import { finalize } from 'rxjs/operators';

@Component({
	selector: 'cb-uw-genius-queue-details',
	templateUrl: './uw-genius-queue-details.component.html',
	styleUrls: ['./uw-genius-queue-details.component.scss'],
})
export class UwGeniusQueueDetailsComponent implements OnInit {
	constructor(public dialog: MatDialog, private inputPageService: InputPageService, private router: Router, private activatedRoute: ActivatedRoute, private filterWatch: FilterWatchService) {
		combineLatest([this.user$]).subscribe(([user]) => {
			this.user = user;
		});
	}

	@Select(UserState) public user$: Observable<User>;
	user: User;
	uwGeniusMatchedRecordDetails: UWGeniusMatchedRecordDetails[];
	uwGeniusSelectedRow: UWGeniusMatchedRecordDetails;
	uwGeniusNewRecordDetails: UWGeniusNewRecordDetails;
	pipeID = 0;
	recordNo = 0;
	loading = false;
	isEmpty = false;
	initial = false;

	columns = [
		{
			headerName: 'Select',
			field: '',
			width: 80,
			headerCheckboxSelection: false,
			checkboxSelection: true,
			suppressSizeToFit: true,
			resizable: true,
			sortable: false,
		},
		{
			headerName: 'Insured',
			field: 'Insured',
			tooltipValueGetter: (params) => params.value,
			width: 220,
			cellClass: 'multiline',
			suppressSizeToFit: true,
			cellRenderer: Utilities.restrictCellTextRenderer(),
		},
		{
			headerName: 'Eff Date',
			field: 'EffectiveDate',
			cellClass: 'date',
			valueFormatter: Utilities.dateFormatter,
			tooltipValueGetter: (params) => params.valueFormatted,
			width: 100,
			headerClass: 'multiline',
			suppressSizeToFit: true,
			cellRenderer: Utilities.restrictCellTextRenderer(),
		},
		{
			headerName: 'Type',
			field: 'Type',
			tooltipValueGetter: (params) => params.value,
			width: 90,
			cellClass: 'multiline',
			suppressSizeToFit: true,
			cellRenderer: Utilities.restrictCellTextRenderer(),
		},
		{
			headerName: 'Status',
			field: 'Status',
			tooltipValueGetter: (params) => params.value,
			width: 90,
			cellClass: 'multiline',
			suppressSizeToFit: true,
			cellRenderer: Utilities.restrictCellTextRenderer(),
		},
		{
			headerName: 'Segment',
			field: 'Division',
			tooltipValueGetter: (params) => params.value,
			width: 220,
			cellClass: 'multiline',
			suppressSizeToFit: true,
			cellRenderer: Utilities.restrictCellTextRenderer(),
		},
		{
			headerName: 'Product',
			field: 'Product',
			tooltipValueGetter: (params) => params.value,
			width: 150,
			cellClass: 'multiline',
			suppressSizeToFit: true,
			cellRenderer: Utilities.restrictCellTextRenderer(),
		},
		{
			headerName: 'Broker',
			field: 'Producer',
			tooltipValueGetter: (params) => params.value,
			width: 265,
			cellClass: 'multiline',
			suppressSizeToFit: true,
			cellRenderer: Utilities.restrictCellTextRenderer(),
		},
	];

	ngOnInit(): void {
		this.recordNo = 0;
		this.pipeID = 0;
		this.activatedRoute.queryParams.subscribe((params) => {
			if (params.PipeID) {
				this.pipeID = params.PipeID;
			}
		});
		if (this.pipeID && this.pipeID > 0 && this.user.UserID) {
			this.getUWGeniusMatchedRecordDetails();
			this.getUWGeniusNewRecordDetails();
		}
	}

	getUWGeniusNewRecordDetails() {
		this.inputPageService.getUWGeniusNewRecordDetails(this.user.UserID).subscribe((data: UWGeniusNewRecordDetails) => {
			console.log(data);
			if (data != null) {
				this.uwGeniusNewRecordDetails = data;
			} else {
				this.uwGeniusNewRecordDetails = null;
			}
		});
	}

	getUWGeniusMatchedRecordDetails() {
		this.loading = true;
		this.uwGeniusSelectedRow = null;
		this.inputPageService
			.getUWGeniusMatchedRecordDetails(this.user.UserID, this.pipeID)
			.pipe(finalize(() => (this.loading = false)))
			.subscribe((data: UWGeniusMatchedRecordDetails[]) => {
				console.log(data);
				if (data != null) {
					this.uwGeniusMatchedRecordDetails = data;
				} else {
					this.uwGeniusMatchedRecordDetails = null;
				}
			});
	}

	handleMatchRecord() {
		if (this.uwGeniusSelectedRow) {
			this.navigateToSubmissionPage();
		}
	}

	handleSelectedRow(rows) {
		console.warn(rows);
		this.uwGeniusSelectedRow = null;
		if (rows && rows.length === 1) {
			this.uwGeniusSelectedRow = rows[0];
		}
	}

	private navigateToSubmissionPage() {
		const payload = <ReportsHeaderModel>{
			Division: [this.uwGeniusSelectedRow.GroupName ? this.uwGeniusSelectedRow.GroupName : ''],
			Unit: [this.uwGeniusSelectedRow.SubGroup ? this.uwGeniusSelectedRow.SubGroup : ''],
			Segment: [this.uwGeniusSelectedRow.Division ? this.uwGeniusSelectedRow.Division : ''],
			UnderwriterName: [this.user.UserID],
			GeniusPipeID: this.pipeID ? this.pipeID : 0,
			RecordNo: this.uwGeniusSelectedRow.RecordNumber ? this.uwGeniusSelectedRow.RecordNumber : 0,
		};
		console.log(payload);
		const serializedFilters = this.filterWatch.serializeFromPayload(payload);
		this.router.navigate(['/submission/input-page'], {
			queryParams: {
				filters: this.filterWatch.create(serializedFilters),
				routedFrom: RoutedFrom.GeniusQueue,
			},
		});
	}

	handleNewRecord() {
		if (this.uwGeniusNewRecordDetails && this.pipeID && this.pipeID > 0) {
			this.navigateToSelectUnit();
		}
	}

	private navigateToSelectUnit() {
		if (this.uwGeniusNewRecordDetails && this.uwGeniusNewRecordDetails.EditableAccessCount === 1) {
			const payload = <ReportsHeaderModel>{
				Division: [this.uwGeniusNewRecordDetails.Division ? this.uwGeniusNewRecordDetails.Division : ''],
				Unit: [this.uwGeniusNewRecordDetails.Unit ? this.uwGeniusNewRecordDetails.Unit : ''],
				Segment: [this.uwGeniusNewRecordDetails.Segment ? this.uwGeniusNewRecordDetails.Segment : ''],
				UnderwriterName: [this.user.UserID],
				GeniusPipeID: this.pipeID ? this.pipeID : 0,
			};

			console.log(payload);
			const serializedFilters = this.filterWatch.serializeFromPayload(payload);
			this.router.navigate(['/submission/input-page'], {
				queryParams: {
					filters: this.filterWatch.create(serializedFilters),
					routedFrom: RoutedFrom.SelectUnit,
				},
			});
		} else if (this.uwGeniusNewRecordDetails && this.uwGeniusNewRecordDetails.EditableAccessCount > 1) {
			const payload = <ReportsHeaderModel>{
				UnderwriterName: [this.user.UserID],
				GeniusPipeID: this.pipeID ? this.pipeID : 0,
			};
			console.log(payload);
			const serializedFilters = this.filterWatch.serializeFromPayload(payload);
			this.router.navigate(['/submission/select-unit-segment'], {
				queryParams: {
					filters: this.filterWatch.create(serializedFilters),
					routedFrom: RoutedFrom.GeniusQueue,
				},
			});
		}
	}

	handleBack() {
		history.back();
	}
}
