export interface IContact {
  FirstName: string;
  LastName: string;
  FullName: string;
  Email: string;
  MobileNumber: string;
  BusinessNumber: string;
  Address1: string;
  City: string;
  StateCode: string;
  RegionCode: string;
  ZipCode: string;
  JobTitle: string;
  JobRole: string;
  FullAddress: string;
  ContactGUID: string;
  AccountName: string;
  RelatedToGUID: string;
}
