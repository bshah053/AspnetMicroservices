import { Component, OnInit, Input, TemplateRef } from '@angular/core';

@Component({
  selector: 'cb-loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.scss'],
})
export class LoaderComponent implements OnInit {
  @Input() loading = false;
  @Input() empty = false;
  @Input() initial: boolean = true;
  @Input() message: TemplateRef<any>;

  constructor() {}

  ngOnInit() {}
}
