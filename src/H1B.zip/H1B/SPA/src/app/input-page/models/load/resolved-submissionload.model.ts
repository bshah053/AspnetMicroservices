import { SubmissionLoadItem } from './submission-load-item';

export class ResolvedSubmissionLoad {
  constructor(public submissionLoadItem: SubmissionLoadItem, public error: any = null) {}
}
