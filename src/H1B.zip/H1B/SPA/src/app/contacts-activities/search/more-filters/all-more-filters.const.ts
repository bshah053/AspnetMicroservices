type AllOptions =
  | 'Ownerunit'
  | 'EventType'
  | 'ProductSpecialization'
  | 'IndustrySpecialization'
  | 'Cornerstone';

export interface FilterOption {
  id: AllOptions;
  title: string;
  type: string;
  singleValue?: boolean;
  reportsAvailability: ['Activities Search' | 'Contacts Search'];
}
export interface FilterGroup {
  title: string;
  options: FilterOption[];
}

export const ALL_MORE_FILTERS: FilterGroup[] = [
  {
    title: 'Activities Search',
    options: [
      {
        id: 'Ownerunit',
        title: 'Owner Unit',
        type: 'dropdown',
        reportsAvailability: ['Activities Search'],
      },
      {
        id: 'EventType',
        title: 'Event',
        type: 'dropdown',
        reportsAvailability: ['Activities Search'],
      },
    ],
  },
  {
    title: 'Contacts Search',
    options: [
      {
        id: 'ProductSpecialization',
        title: 'Product Specialization',
        type: 'dropdown',
        reportsAvailability: ['Contacts Search'],
      },
      {
        id: 'IndustrySpecialization',
        title: 'Industry Specialization',
        type: 'dropdown',
        reportsAvailability: ['Contacts Search'],
      },
      {
        id: 'Cornerstone',
        title: 'CornerStone',
        type: 'dropdown',
        reportsAvailability: ['Contacts Search'],
      },
    ],
  },
];
