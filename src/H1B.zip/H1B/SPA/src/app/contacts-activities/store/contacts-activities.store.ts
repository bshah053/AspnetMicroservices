import { Action, Selector, State, StateContext } from '@ngxs/store';
import { Injectable } from '@angular/core';
import { ContactsActivitiesModel } from './contacts-activities.models';
import {
  SetContactSearchFilters,
  SetActivitiesSearchFilters,
} from './contacts-activities.actions';

@State<ContactsActivitiesModel>({
  name: 'ContactActivitiesStore',
  defaults: {
    contactSearch: {},
    activitiesSearch: {},
  },
})
@Injectable()
export class ContactsActivitiesState {
  @Selector()
  public static getData(
    state: ContactsActivitiesModel
  ): ContactsActivitiesModel {
    return state;
  }

  @Action(SetContactSearchFilters)
  public setContactSearchFilters(
    ctx: StateContext<ContactsActivitiesModel>,
    { payload }: SetContactSearchFilters
  ) {
    const state = ctx.getState();
    ctx.setState({ ...state, contactSearch: { ...payload } });
  }

  @Action(SetActivitiesSearchFilters)
  public setActivitiesSearchFilters(
    ctx: StateContext<ContactsActivitiesModel>,
    { payload }: SetActivitiesSearchFilters
  ) {
    const state = ctx.getState();
    ctx.setState({ ...state, activitiesSearch: { ...payload } });
  }
}
