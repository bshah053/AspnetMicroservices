import { Component, OnInit } from '@angular/core';

import { SharedService } from 'services/shared.service';

@Component({
  selector: 'cb-pagenotfound',
  templateUrl: './pagenotfound.component.html',
  styleUrls: ['./pagenotfound.component.scss'],
})
export class PageNotFoundComponent implements OnInit {
  constructor(private sharedService: SharedService) {
    this.sharedService.sendHeaderVisibilityStatus(true);
  }

  ngOnInit() {}
}
