import { Injectable } from '@angular/core';
import {
  CanActivate,
  CanLoad,
  Router,
  Route,
  UrlSegment,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  UrlTree,
} from '@angular/router';
import { combineLatest, Observable } from 'rxjs';
import { Select } from '@ngxs/store';

import { User } from '../user/user.model';
import { UserState } from '../user/user.store';

@Injectable({
  providedIn: 'root',
})
export class AuthGuardService implements CanLoad {
  @Select(UserState) public user$: Observable<User>;
  user: User;

  constructor(private router: Router) {
    combineLatest([this.user$]).subscribe(([user]) => {
      this.user = user;
    });
  }

  canLoad(
    route: Route,
    segments: UrlSegment[]
  ): boolean | Observable<boolean> | Promise<boolean> {
    return this.isControlAdmin;
  }

  get isControlAdmin(): boolean {
    let userRole = this.user['MenuMapDetails'].filter(
      (element) => element.MenuDescription == 'Control Admin'
    )[0];
    console.log(userRole);
    return userRole && userRole.IsUserPermissible == 'Y' ? true : false;
  }
}
