# CRUX Frontend 

[![Conventional Commits](https://img.shields.io/badge/Conventional%20Commits-1.0.0-yellow.svg)](https://conventionalcommits.org)

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.7.3.

## Development Setup

Fork this repo by clicking on Fork button on the right hand top section of this repo.

Once forked, clone the forked repo to your local machine :

```
git clone git@nausp-aapp0001.aceins.com:<user name/org>/crux-frontend.git
```

Navigate to the project directory and install Node modules :

```
cd crux-frontend
npm i
```

CRUX Components, Services and Themes are included as dependency in `package.json`, so you will no longer need to install them manually. 

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Development Server with local proxy

Often times during Frontend development, engineers require to make calls to APIs from their components. It's always a best practice to have environment specific API definitions where one could have different URIs for a specific API in different environments.

In order to accomplish independent frontend engineering, CRUX Frontend offers ability to run a mock server (using `json-server`) alongside the webpack dev server which serves the Angular app.

#### How to mock an API?

Create a new property in `mocks/data.json` for your API. For instance, when you want to fetch data for an API `/api/test` (it's recommended to have API prefixes with `/api` in local environment) add a property `test` (without a trailing `/`) in `mocks/data.json` as below :

```js
{
  ...rest,
  "test": {
    // Data Response here.
  }
  
}
```

Once you've added the property `test` in `mocks/data.json`, start the app with a proxy server using 

```
npm run start:proxy
```

You should see an output like this with the resources listed:

![Mock Server](https://nausp-aapp0001.aceins.com/na-digital-apps/crux-frontend/blob/master/doc-assets/Mock%20Server.png?raw=true)

Now navigate to `http://localhost:3000/test` to see the output from mock server. Since we'd want to use it as part of CRUX Frontend, navigate to `http://localhost:4200/api/test` and you should see the same output as you did for `http://localhost:3000/test`.

Make sure you fetch the API URI from environment in your component so that you can point your component to the actual API URI when running in **staging** or **production**.

Note: Requests to `/api` in the CRUX Frontend are proxied and rewritten as `/`. `http://localhost:4200/api/test` gets rewritten to `http://localhost:3000/test`. 

## Code scaffolding

Run `ng generate component components/component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `-prod` flag for a production build (Optimized build).

## Running unit tests

Unit tests will be executed via [Jest](https://facebook.github.io/jest/).

Know more on how to unit test Angular through Jest [here](https://village.chubb.com/groups/crux/blog/2018/04/02/testing-angular-with-jest).

## Running end-to-end tests

e2e tests are not yet ready and we will be using [Puppeteer](https://github.com/GoogleChrome/puppeteer) for headless e2e testing.
