export class SubmissionSaveOutputModel {
  RecordNumber: number;
  ScheduleNumber?: number;
  SubmissionID: string;
  Message: string;
  ErrorLogID?: number;
}
