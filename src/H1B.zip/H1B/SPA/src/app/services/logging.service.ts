import { Injectable } from '@angular/core';
import { InputPageService } from 'input-page/services/input-page.service';
import { User } from 'user/user.model';
import { ErrorLogDetailsItem } from '../errors/model/errorlog-details-item';
import { combineLatest, Observable, zip } from 'rxjs';
import { UserState } from 'user/user.store';
import { Select } from '@ngxs/store';
import { environment } from 'environments/environment';

@Injectable({
  providedIn: 'root',
})
export class LoggingService {
  @Select(UserState) public user$: Observable<User>;
  user: User;

  constructor(private inputPageService: InputPageService) {
    combineLatest([this.user$]).subscribe(([user]) => {
      this.user = user;
    });
  }

  logError(message: string = '', stack: string = '') {
    if (!['development'].includes(environment.envName)) {
      // Send errors to server here
      console.log('Logging Service: ' + message);
      const payload: ErrorLogDetailsItem = {
        UserID: this.user.UserID,
        ErrorSource: 'T2UI',
        ErrorMessage: message,
        ErrorStackTrace: stack,
        ErrorPayload: '',
      };
      console.error({ payload });
      // this.inputPageService.errorLog(payload).subscribe((data: any) => {
      //   if (data && data !== null) {
      //     console.log({ data });
      //   }
      // });
    }
  }

  saveError(err, payload) {
    const errorMessage = err.error && (err.error.Message || err.error);
    const errorLogDetail: ErrorLogDetailsItem = {
      UserID: this.user.UserID,
      ErrorSource: 'T2UI',
      ErrorMessage: errorMessage,
      ErrorStackTrace: '',
      ErrorPayload: JSON.stringify(payload),
    };
    this.inputPageService.errorLog(errorLogDetail).subscribe((data: any) => {
      if (data && data !== null) {
        console.log({ data });
      }
    });
  }
}
