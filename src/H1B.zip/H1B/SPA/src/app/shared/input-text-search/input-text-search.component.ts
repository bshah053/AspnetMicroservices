import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'cb-input-text-search',
  templateUrl: './input-text-search.component.html',
  styleUrls: ['./input-text-search.component.scss'],
})
export class InputTextSearchComponent implements OnInit {
  @Input() placeholder = 'Search...';
  @Input() searchValue = '';
  @Input('class') klass = '';
  @Output() searchChange = new EventEmitter<string>();

  constructor() {}

  ngOnInit() {
    this.searchValue = this.searchValue || '';
  }

  setSearch(value: string) {
    this.searchChange.next(value);
  }
}
