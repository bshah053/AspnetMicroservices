import { BuildOutScheduleItems } from './build-out-schedule-items';

export class BuildOutScheduleDetails {
  BuildOutSchedule?: BuildOutScheduleItems[] = [];
  EffectiveDate?: Date;
  ExpirationDate?: Date;
  ForecastType?: string;
  RecordNumber?: number;
  PageType?: string;
}
