const express = require('express'),
  glance = require('./reports/glance.json'),
  renewalsDetails = require('./reports/renewals-details-total.json'),
  totalForecast = require('./reports/total-forecast-details.json'),
  newBusiness = require('./reports/new-business-details-total.json'),
  detailed = require('./reports/reports.detail.json'),
  forecast = require('./reports/reports.forecast.summary.detail2.json'),
  region = require('./reports/reports.forecast.region.details.json'),
  producerSummary = require('./reports/producer-summary.json'),
  insured = require('./reports/insured'),
  scorecardRenewals = require('./reports/scorecards-renewals.json'),
  scorecardNewBusiness = require('./reports/scorecards-newbusiness.json'),
  scorecardDivisionsForecast = require('./reports/scorecards-divisions-forecast.json'),
  coreElements = require('./reports/coreelements'),
  nonCoreElements = require('./reports/noncoreelements');

module.exports = function detailedReport() {
  const router = express.Router();

  router.post('/details', (req, res) => res.json(detailed));
  router.post('/forecastsummarydetailstotal', (req, res) => res.json(forecast));
  router.post('/forecastregiondetailstotal', (req, res) => res.json(region));

  router.post('/Summary/NewBusinessDetailsTotal', (req, res) =>
    res.json(newBusiness.data)
  );
  router.post('/Summary/TotalForecastDetailsTotal', (req, res) =>
    res.json(totalForecast.data)
  );
  router.post('/Summary/RenewalDetailsTotal', (req, res) =>
    res.json(renewalsDetails.data)
  );
  router.post('/summary/glance', (req, res) => res.json([glance.data]));

  router.post('/producers', (req, res) => {
    const {
      ProducerName = [],
      ProducerBranch = [],
      ProducerRegion = [],
    } = req.body;

    const isSingleProducer =
      ProducerName.length === 1 &&
      ProducerBranch.length === 1 &&
      ProducerRegion.length === 1;

    if (isSingleProducer) {
      res.json([producerSummary.data[0]]);
    } else {
      res.json(producerSummary.data);
    }
  });

  router.post('/producerprofile', (req, res) => {
    res.json([producerSummary.data[0]]);
  });

  router.post('/Insured', (req, res) => res.json(insured));

  router.post('/scorecards/renewals', (req, res) =>
    res.json(scorecardRenewals)
  );
  router.post('/scorecards/newbusiness', (req, res) =>
    res.json(scorecardNewBusiness)
  );
  router.post('/scorecards/divisions/forecasts', (req, res) =>
    res.json(scorecardDivisionsForecast)
  );

  router.post('/coreelements', (req, res) => res.json(coreElements));

  router.post('/noncoreelements', (req, res) => res.json(nonCoreElements));

  return router;
};
