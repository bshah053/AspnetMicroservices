import { Component, OnInit, Input } from '@angular/core';
import { NavigationService } from '../../services/navigation.service';

@Component({
  selector: 'gce',
  templateUrl: './gce.component.html',
  styleUrls: ['./gce.component.scss'],
  providers: [],
})
export class GCEComponent implements OnInit {
  @Input() user: Object;

  constructor(private navigation: NavigationService) { }

  ngOnInit() { }

  meetingsSeeAllClicked() {
    this.navigation.toMyMeetings();
  }
}
