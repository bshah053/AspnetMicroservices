import { ChangeDetectorRef, Component, Injector, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Select } from '@ngxs/store';
import { combineLatest, Observable, Subscription } from 'rxjs';

import { ControlConfigurationService } from 'services/control-configuration.service';
import { NavigationService } from 'services/navigation.service';
import { NotificationService } from 'services/notification.service';
import { SharedService } from 'services/shared.service';
import { ConfirmationDialogComponent } from 'shared/confirmation-dialog/confirmation-dialog.component';
import { CtrlTemplateComponent } from 'shared/templates/ctrl-template/ctrl-template.component';
import { User } from 'user/user.model';
import { UserState } from 'user/user.store';
import { Helper } from 'utilities/common-helper';
import { DataElements } from '../../user-admin/model/forms-controls-data-elements';
import { ControlAdminService, Options } from '../services/control-admin.service';

@Component({
  selector: 'generics-forms-master',
  templateUrl: './generics-forms-master.component.html',
  styleUrls: ['./generics-forms-master.component.scss'],
})
export class GenericsFormsMasterComponent implements OnInit {
  @Select(UserState) public user$: Observable<User>;
  user: User;
  @ViewChild('ctrlTemplate') ctrlTemplate: CtrlTemplateComponent;
  controlsTemplate: TemplateRef<any>;
  isShowContent = false;
  isLoading = false;
  masterFormGroup: FormGroup;
  filterFormGroup: FormGroup;
  submitted = false;
  currencyType = 'USD';
  notifier;
  sharedService$: Subscription;
  optionsItems: Options[] = [];
  searchValue = '';

  private _dataElements: DataElements[];
  public get dataElements(): DataElements[] {
    return this._dataElements;
  }
  public set dataElements(value: DataElements[]) {
    this._dataElements = value;
  }

  constructor(private sharedService: SharedService, private configService: ControlConfigurationService, private navigation: NavigationService, private controlAdminService: ControlAdminService, private injector: Injector, public dialog: MatDialog, private masterFormBuilder: FormBuilder, private cdRef: ChangeDetectorRef) {
    try {
      combineLatest([this.user$]).subscribe(([user]) => {
        this.user = user;
        if (this.user && Helper.isStringNotNullAndEmpty(this.user.UserID)) {
          if (this.isControlAdmin) {
            this.getMasterTableDetails();
            this.notifier = this.injector.get(NotificationService);
            this.ctrlsTemplateChanges();
          } else {
            this.navigation.toErrorPage();
          }
        }
      });
    } catch (error) {
      console.log({ error });
    }
  }

  ngOnInit(): void {
    try {
      this.createFormGroup();
      setTimeout(() => {
        this.getTemplate();
      }, 10);
    } catch (error) {
      console.log({ error });
    }
  }

  ngOnDestroy() {
    try {
    } catch (error) {
      console.log({ error });
    }
  }

  getTemplate() {
    if (this.ctrlTemplate) {
      this.controlsTemplate = this.ctrlTemplate.getTemplate('ctrlsTemplate');
    }
  }

  public controlById(index, control) {
    if (!control) return null;
    return control.ControlId;
  }

  ctrlsTemplateChanges() {
    this.sharedService$ = this.sharedService.setCTRLSChanges().subscribe((ctrlsDetails: DataElements) => {});
  }

  onBlurMethod() {
    if (Helper.isStringNotNullAndEmpty(this.searchValue)) {
      this.searchValue = '';
    }
  }

  get isControlAdmin(): boolean {
    let userRole = this.user['MenuMapDetails'].filter((element) => element.MenuDescription == 'Control Admin')[0];
    return userRole && userRole.IsUserPermissible == 'Y' ? true : false;
  }

  get masterDetails() {
    return this.masterFormGroup.get('Master') as FormArray;
  }

  get showResetMasterDetails() {
    if (this.masterFormGroup && this.masterDetails && this.masterDetails.length > 0) {
      return true;
    } else {
      return false;
    }
  }

  get showAddRow() {
    const totalRecords = this.filterFormGroup.get('NoOfRows').value;
    if (Helper.isNumberNotNullAndEmpty(totalRecords) && this.filterFormGroup.get('TableName').valid && this.masterFormGroup && this.masterDetails && this.masterDetails.length > 0) {
      return true;
    } else {
      return false;
    }
  }

  private createFormGroup() {
    this.filterFormGroup = this.masterFormBuilder.group({
      TableName: new FormControl('', Validators.compose([Validators.required])),
      NoOfRows: new FormControl('', Validators.compose([Validators.nullValidator, Validators.min(1)])),
    });
    console.log(this.filterFormGroup);
  }

  private addDefaultMappingControls(isReset: boolean = false) {
    if (isReset) {
      this.masterFormGroup = this.masterFormBuilder.group({
        Master: this.masterFormBuilder.array([]),
      });
    } else {
      this.masterFormGroup = this.masterFormBuilder.group({
        Master: this.masterFormBuilder.array([this.getFormsGroup()]),
      });
    }
  }

  addNewMasterControls() {
    if (this.dataElements && this.dataElements.length > 0) {
      this.masterDetails.push(this.getFormsGroup());
    }
  }

  private addNewMasterControlRowsyUser() {
    const totalRecords = this.filterFormGroup.get('NoOfRows').value;
    if (Helper.isNumberNotNullAndEmpty(totalRecords)) {
      for (let rowIndex = 0; rowIndex < totalRecords; rowIndex++) {
        this.masterDetails.push(this.getFormsGroup());
      }
    } else {
      this.notifier.showWarning('Please enter no of Rows value ', 10);
    }
  }

  removeMasterControls(rowIndex: number) {
    if (this.masterDetails.length > 1) {
      const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
        width: '510px',
        data: { Action: 'Delete' },
        hasBackdrop: true,
        backdropClass: 'backdropBackground',
      });

      dialogRef.afterClosed().subscribe((result) => {
        if (result && Helper.isStringNotNullAndEmpty(result.Action)) {
          if (result.Action === 'Delete confirm') {
            this.masterDetails.removeAt(rowIndex);
          }
        }
      });
    } else {
      const message = 'One row should be retained!!!';
      this.notifier.showError(message);
    }
  }

  getFormsGroup(): FormGroup {
    const formGroup = this.masterFormBuilder.group({});
    this.dataElements
      .filter((ele) => ele.ControlType !== 'keycolumn')
      .forEach((element) => {
        if (Helper.isStringNotNullAndEmpty(element.ControlName)) {
          formGroup.addControl(element.ControlName, this.configService.setControlConfig(element));
        }
      });
    return formGroup;
  }

  validationOnLoad() {}

  getColumnNames(): string[] {
    if (this.dataElements && this.dataElements.length > 0) {
      return this.dataElements.map((ele) => ele.ControlName);
    } else {
      return null;
    }
  }

  getKeyColumnName(): string {
    if (this.dataElements && this.dataElements.length > 0) {
      const filteredElements = this.dataElements
        .filter((element) => {
          return element.ControlType === 'keycolumn';
        })
        .map((ele) => ele.ControlName);
      if (filteredElements && filteredElements.length > 0) {
        return filteredElements[0];
      } else {
        return '';
      }
    } else {
      return '';
    }
  }

  generateMasterControl() {
    if (this.filterFormGroup.get('TableName').valid) {
      this.getControlDetailsByName();
    }
  }

  getControlDetailsByName() {
    try {
      this.isLoading = true;
      this.isShowContent = false;
      const tableID = this.filterFormGroup.get('TableName').value.value;
      this.controlAdminService
        .getControlElementDetailsByName(this.user.UserID, tableID)
        .pipe()
        .subscribe(
          (data: DataElements[]) => {
            if (data != null) {
              this._dataElements = data
                .filter((filter) => filter.ControlType !== null)
                .sort((a: any, b: any) => {
                  return a.ControlDisplayOrder - b.ControlDisplayOrder;
                });
              console.log(this.dataElements);
              this.addDefaultMappingControls();
              console.log(this.masterFormGroup);
              setTimeout(() => {
                this.isShowContent = true;
                this.isLoading = false;
              }, 0);
            }
          },
          (err) => {
            this.isLoading = false;
            this.isShowContent = false;
            console.error(err);
          }
        );
    } catch (error) {
      this.isLoading = false;
      this.isShowContent = false;
      console.error(error);
    }
  }

  getMasterTableDetails() {
    try {
      this.controlAdminService
        .getMasterTableDetails(this.user.UserID)
        .pipe()
        .subscribe(
          (data: Options[]) => {
            if (data != null) {
              this.optionsItems = data;
            }
          },
          (err) => {
            this.optionsItems = [];
            console.error(err);
          }
        );
    } catch (error) {
      this.optionsItems = [];
      console.error(error);
    }
  }

  closePage() {
    window.history.back();
  }

  resetMasterControls() {
    this._dataElements = null;
    this.filterFormGroup.get('NoOfRows').setValue('');
    this.filterFormGroup.get('TableName').setValue('');
    this.addDefaultMappingControls(true);
    this.cdRef.detectChanges();
  }

  resetMasterControlsData() {
    this.cdRef.detectChanges();
  }

  generateScript(action) {
    try {
      console.log(this.masterFormGroup.value);
      console.log(this.masterDetails);
      if (action === 'save') {
        this.submitted = true;
        if (this.masterFormGroup.invalid) {
          return;
        }
        this.submitted = false;
        console.log(this.masterFormGroup.value);
        console.log(this.masterDetails);
        const columnsName: string[] = this.getColumnNames();
        const keyColumnName = this.getKeyColumnName();
        const totalColumnCount = columnsName.length - 1;
        if (columnsName && columnsName.length > 0) {
          const tableName = this.filterFormGroup.get('TableName').value.text;
          let tableInsertQuery = 'INSERT INTO ' + tableName + '(' + columnsName.toString() + ') VALUES \n';
          let tableInsertValues = '';
          const saveMasterValueDetails: any[] = this.masterFormGroup.value.Master;
          const totalRowCount = saveMasterValueDetails.length - 1;
          saveMasterValueDetails.forEach((controlValue, rowIndex) => {
            columnsName.forEach((name, columnIndex) => {
              if (columnIndex === 0) {
                Helper.isStringNotNullAndEmpty(keyColumnName) ? (tableInsertValues += '(@' + keyColumnName + ",'" + controlValue[name] + "',") : (tableInsertValues += '(' + "'" + controlValue[name] + "',");
              } else if (columnIndex < totalColumnCount) {
                tableInsertValues += "'" + controlValue[name] + "',";
              } else {
                tableInsertValues += "'" + controlValue[name] + "')";
              }
            });
            if (rowIndex < totalRowCount) {
              tableInsertValues += ',\n';
            } else {
              tableInsertValues += '\n';
            }
          });

          const lastEnd = Helper.isStringNotNullAndEmpty(keyColumnName) ? 'END\n' : '';
          const finalInsertQuery = this.setGenerateKeyValue(tableName, keyColumnName) + 'BEGIN\n' + tableInsertQuery + tableInsertValues + 'END\n' + lastEnd;
          console.log(finalInsertQuery);
          const filename = 'InsertScriptFor' + tableName + '.sql';
          this.generateSQLScriptFile(finalInsertQuery, filename);
        }
      }
    } catch (error) {
      throw error;
    }
  }

  setGenerateKeyValue(tableName: string = '', keyColumnName: string = ''): string {
    let keyColumnQuery = '';
    if (Helper.isStringNotNullAndEmpty(keyColumnName)) {
      keyColumnQuery = 'BEGIN \n' + 'DECLARE @' + keyColumnName + ' BIGINT=0; \n' + 'SELECT @' + keyColumnName + ' = (MAX(' + keyColumnName + ')+1) FROM ' + tableName + ' \n' + 'IF(@' + keyColumnName + ' > 0) \n';
    }
    return keyColumnQuery;
  }

  private generateSQLScriptFile(text, filename: string) {
    const downloadedFile = new Blob([text], { type: 'text/plain' });
    this.navigation.toFileDownload(filename, downloadedFile);
    // let textFile = null;
    // if (textFile !== null) {
    //   window.URL.revokeObjectURL(textFile);
    // }
    // textFile = window.URL.createObjectURL(data);

    // const a = document.createElement('a');
    // a.setAttribute('style', 'display:none;');
    // document.body.appendChild(a);
    // a.download = filename;
    // a.href = textFile;
    // a.target = '_blank';
    // a.click();
    // document.body.removeChild(a);
  }
}
