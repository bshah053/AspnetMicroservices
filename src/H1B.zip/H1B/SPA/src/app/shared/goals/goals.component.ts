import { Component, Input, OnInit } from '@angular/core';
import { DashboardService } from '../../dashboard/dashboard.service';
import Utilities from '../../shared/utilities';
import { User } from '../../user/user.model';
import { AccountingYearMonth, AccountingYearMonthState } from 'store/accounting-month-year.store';
import { Observable } from 'rxjs';
import { Select } from '@ngxs/store';
import { SharedService } from '../../services/shared.service';

@Component({
  selector: 'cb-goals',
  templateUrl: './goals.component.html',
  styleUrls: ['./goals.component.scss'],
})
export class GoalsComponent implements OnInit {
  @Input() user: User;
  @Input() selected;
  @Input() currentDateFilterIndex = 0;
  updateError = false;
  editNewBusiness = false;
  editTravel = false;
  newBusinessGoalValue = 0;
  newTravelGoalValue = 0;
  currentTimeFrame = 'MTD';

  @Select(AccountingYearMonthState)
  public accountingYearMonth$: Observable<AccountingYearMonth>;
  accountingYearMonth: AccountingYearMonth;

  dateList = [
    { title: 'MTD', value: 'MTD' },
    { title: '3 Months', value: 'R3' },
    { title: 'YTD', value: 'YTD' },
    { title: 'R12', value: 'R12' },
  ];

  producerVisitsList = ['Producer', 'Customer', 'All'];

  newBusinessGoals: any;
  travelGoals: any;
  newBusinessGoalGraphLabels;
  newBusinessGoalGraphData;
  newBusinessGoalGraphType;
  newBusinessGoalGraphOptions;
  newBusinessGoalBarConfig: Object;
  travelGoalBarConfig: Object;
  addCommasToNumber = Utilities.addCommasToNumber;

  open = false;
  producerVisits = this.producerVisitsList[0];

  newBusinessGoalsSubscription: any;
  travelGoalsSubscription: any;

  get defaultPayload() {
    return {
      UserID: this.user && this.user['UserID'],
      ...this.accountingYearMonth,
      TimeFrame: 'MTD',
    };
  }

  constructor(private dashboardService: DashboardService, private sharedService: SharedService) {
    this.accountingYearMonth$.subscribe((accountingYearMonth) => {
      this.accountingYearMonth = accountingYearMonth;
    });
  }

  getNBGoals(updatedPayload?) {
    const payload = updatedPayload || this.defaultPayload;
    this.newBusinessGoalsSubscription = this.dashboardService.getNBGoals(payload).subscribe((goals) => {
      if (goals !== null) {
        this.newBusinessGoals = goals[0];
        this.setNewBusinessGoalGraph(goals[0]);
      }
    });
  }

  getTravelGoals(updatedPayload?, item?) {
    const defaultPayload = {
      ...this.defaultPayload,
      VisitType: this.producerVisits,
    };
    const payload = updatedPayload || defaultPayload;

    if (item) {
      payload.VisitType = item;
    }

    this.travelGoalsSubscription = this.dashboardService.getTravelGoals(payload).subscribe((data) => {
      if (data !== null) {
        this.travelGoals = data;
        this.setTravelGoalGraph(data);
      }
    });
  }

  setNewBusinessGoalGraph(data: any) {
    const color = '#01c1d6';
    this.newBusinessGoalBarConfig = {
      barWrapper: {
        width: 524,
      },
      barContainer: {
        background: color,
      },
      indicator1LeftPosition: (data.GoalsToBeAcheived / data.YearlyGoal) * 100,
      barStyle: {
        width: data.YearlyGoalPercentage,
        background: color,
      },
    };
  }

  setTravelGoalGraph(data: any) {
    const color = '#1505ce';
    this.travelGoalBarConfig = {
      barWrapper: {
        width: 524,
      },
      barContainer: {
        background: color,
      },
      indicator1LeftPosition: (data.GoalsToBeAchieved / data.YearlyGoal) * 100,
      barStyle: {
        width: data.YearlyGoalPercentage,
        background: color,
      },
    };
  }

  dateFilterSelected(data) {
    const params = {
      ...this.defaultPayload,
      TimeFrame: data.frame,
      VisitType: this.producerVisits,
    };
    this.currentTimeFrame = data.frame || 'MTD';
    this.getNBGoals(params);
    this.getTravelGoals(params);
  }

  get isOpened(): boolean {
    return this.open;
  }

  handleToggleOpen(): void {
    this.open = !this.open;
  }

  handleHide(): void {
    this.open = false;
  }

  handleSelection(item): void {
    this.producerVisits = item;
    this.open = false;
    this.getTravelGoals(null, item);
  }

  toggleEditNewBusiness() {
    this.editNewBusiness = !this.editNewBusiness;
    this.newBusinessGoalValue = this.newBusinessGoals.YearlyGoal || 0;
  }

  toggleEditTravel() {
    this.editTravel = !this.editTravel;
    this.newTravelGoalValue = this.travelGoals.YearlyGoal || 0;
  }

  handleNBGoalUpdate(value) {
    this.newBusinessGoalValue = value;
  }

  handleTravelGoalUpdate(value) {
    this.newTravelGoalValue = value;
  }

  setNewBusinessGoal() {
    this.dashboardService.setNBGoals(this.user.UserID, this.newBusinessGoalValue).subscribe(
      (_) => {},
      (err) => {
        this.setUpdateError(err);
        this.toggleEditNewBusiness();
        this.getNBGoals();
      },
      () => {
        this.toggleEditNewBusiness();
        this.getNBGoals();
      }
    );
    if (this.isUWM) {
      this.sharedService.sendRefreshFetchGoals();
    }
  }

  setNewTravelGoal() {
    this.dashboardService.setTravelGoals(this.user.UserID, this.newTravelGoalValue).subscribe(
      (_) => {},
      (err) => {
        this.setUpdateError(err);
        this.toggleEditTravel();
        this.getTravelGoals();
      },
      () => {
        this.toggleEditTravel();
        this.getTravelGoals();
      }
    );
    if (this.isUWM) {
      this.sharedService.sendRefreshFetchGoals();
    }
  }

  setUpdateError(err) {
    console.error(err);
    this.updateError = true;
    setTimeout(() => (this.updateError = false), 5000);
  }

  ngOnInit() {
    this.getNBGoals();
    this.getTravelGoals();
  }

  get isUWM() {
    return this.user.UserType === 'Underwriter Manager';
  }
}
