import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'chartjs-graph',
  templateUrl: './chartjs-graph.component.html',
  styleUrls: ['./chartjs-graph.component.scss'],
})
export class ChartjsGraphComponent implements OnInit {
  @Input() config: Object;
  chartData;
  lineData;
  chartType;
  chartOptions;
  chartLabels;

  constructor() {}

  ngOnInit() {}

  ngOnChanges() {
    if (this.config) {
      this.setUpChart(this.config);
    }
  }

  setUpChart(config: any) {
    this.chartType = config.type;
    this.chartData = config.datasets;
    this.chartLabels = config.labels;
    this.chartOptions = config.options;
  }
}
