import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { SelectUnitSegmentComponent } from './select-unit-segment.component';

describe('SelectUnitSegmentComponent', () => {
	let component: SelectUnitSegmentComponent;
	let fixture: ComponentFixture<SelectUnitSegmentComponent>;

	beforeEach(
		waitForAsync(() => {
			TestBed.configureTestingModule({
				declarations: [SelectUnitSegmentComponent],
			}).compileComponents();
		})
	);

	beforeEach(() => {
		fixture = TestBed.createComponent(SelectUnitSegmentComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
