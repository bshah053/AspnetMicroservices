import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Select } from '@ngxs/store';
import { combineLatest, Observable } from 'rxjs';
import { skip } from 'rxjs/operators';
import { AccountingYearMonth, AccountingYearMonthState } from 'store/accounting-month-year.store';
import { FilterWatchService } from '../../../services/filter-watch.service';
import { ITabMeta, TabComponent } from '../../../shared/tabs/tab/tab.component';
import { TabsComponent } from '../../../shared/tabs/tabs.component';
import Utilities from '../../../shared/utilities';
import { MonthName, TimeFrameType } from '../../../tracking-reporting/reports/reports-header/store/reports-header.model';
import { User } from '../../../user/user.model';
import { DashboardService } from '../../dashboard.service';
import { NavigationService } from '../../../services/navigation.service';
import { ReportingService } from '../../../tracking-reporting/services/reporting.service';
import { PathLocationStrategy } from '@angular/common';

@Component({
  selector: 'cb-regional-manager-renewals',
  templateUrl: './regional-manager-renewals.component.html',
  styleUrls: ['./regional-manager-renewals.component.scss'],
})
export class RegionalManagerRenewalsComponent implements OnInit {
  @Input() user: User;
  @Output() branchesUpdated = new EventEmitter();

  addComasToNumber = Utilities.addCommasToNumber;
  round = Math.round;

  status = 'Quoted';
  renewalsInfo: any;
  renewalsByTermDate: any;
  renewalsTableSubscription: any;
  currentDateFilterIndex = 2;
  workingInfo: any;
  quotedInfo: any;
  boundInfo: any;
  timeFrame: TimeFrameType = 'YTD';
  currentFilters: any = {}; // TODO: FIXME:
  accountingYearMonth: AccountingYearMonth;
  tableType = 'renewals';
  clientIDCollections = [];
  clientNameCollections = [];

  dateListYTD = [
    { title: 'MTD', value: 'MTD' },
    { title: '3 Months', value: 'R3' },
    { title: 'YTD', value: 'YTD' },
    { title: 'R12', value: 'R12' },
  ];

  selectedBranch = '';
  branchlist = [];

  get regionName() {
    return this.user.CreditedRegion[0];
  }

  @Select(AccountingYearMonthState)
  public accountingYearMonth$: Observable<AccountingYearMonth>;

  @ViewChild(TabsComponent) tabs: TabsComponent;

  constructor(private dashboardService: DashboardService, private router: Router, private filterWatch: FilterWatchService, private navigate: NavigationService, private reportingService: ReportingService) {}

  get userWithAccountingYearMonth() {
    return {
      UserID: this.user.UserID,
      ...this.accountingYearMonth,
    };
  }

  getRenewalsStatusByAccountingMonth(updatedPayload?) {
    const defaultPayload = {
      ...this.userWithAccountingYearMonth,
      TimeFrame: this.timeFrame,
    };
    const payload = updatedPayload || defaultPayload;

    let methodName = 'getMyRenewalsStatusByAccountingMonth';
    if (this.isMSL) {
      methodName = 'getMSLMyRenewalsStatusByAccountingMonth';
      payload.Branch = [this.selectedBranch];
      payload.SortBy = 'desc';
    } else if (this.isGCE) {
      methodName = 'getGCEMyRenewalsStatusByAccountingMonth';
    }

    this.dashboardService[methodName](payload).subscribe((data) => {
      if (data !== null) {
        this.renewalsInfo = data;
        this.getRenewalsSectionInfo(data);
      }
    });
  }

  getRenewalsSectionInfo(data) {
    this.workingInfo = data.filter((obj) => {
      return obj.Status === 'Submissions';
    });

    this.quotedInfo = data.filter((obj) => {
      return obj.Status === 'Quoted';
    });

    this.boundInfo = data.filter((obj) => {
      return obj.Status === 'Bound';
    });
  }

  getTabMeta(data, filterStatus: string[]): ITabMeta {
    const statusCount = data && data.length ? data[0].StatusCount : '',
      status = data && data.length ? data[0].Status : '',
      statusForecast = data && data.length ? data[0].StatusForecast : '';
    return {
      count: statusCount,
      status: this.user.UserType === 'Market Segment Leader' && status === 'Submissions' ? 'Pending/Working' : status,
      summ: statusForecast,
      component: 'regionalManagerRenew',
      filterStatus: filterStatus,
    };
  }

  getMyRenewalsTable(udatedPayload?) {
    const defaultPayload = {
      ...this.userWithAccountingYearMonth,
      TimeFrame: 'YTD',
      Status: this.status,
      PageNumber: this.isMSL ? 0 : 2,
      PageSize: this.isMSL ? 0 : 4,
      SortBy: 'RenewalsPytd',
      OrderBy: 'asc',
    };

    if (this.isGCE) {
      defaultPayload.SortBy = 'RenewalForecast';
      defaultPayload.OrderBy = 'desc';
      defaultPayload.TimeFrame = 'MTD';
      delete defaultPayload.PageNumber;
      delete defaultPayload.PageSize;
    }

    const payload = udatedPayload || defaultPayload;

    let methodName = 'getRenewalsTableForRegionalManager';
    if (this.isMSL) {
      methodName = 'getMSLRenewalsTableByMonth';
      payload.Branch = [this.selectedBranch];
      payload.SortBy = 'RenewalForecast';
      payload.OrderBy = 'desc';
    } else if (this.isGCE) {
      methodName = 'getGCERenewalsTable';
    }

    this.dashboardService[methodName](payload).subscribe(
      (data) => {
        if (data !== null) {
          this.renewalsByTermDate = data;
          this.branchesUpdated.emit(data);
        } else {
          this.renewalsByTermDate = undefined;
        }
      },
      (err) => {
        this.renewalsByTermDate = undefined;
      }
    );
  }

  dateFilterSelected(data) {
    this.timeFrame = data.frame;
    const updatedPayloadTabs = {
      ...this.userWithAccountingYearMonth,
      TimeFrame: data.frame,
      Status: this.status,
    };
    const updatedPayloadTable = {
      ...this.userWithAccountingYearMonth,
      TimeFrame: data.frame,
      Status: this.status,
      PageNumber: this.user.UserType === 'Market Segment Leader' ? 0 : 2,
      PageSize: this.user.UserType === 'Market Segment Leader' ? 0 : 4,
      SortBy: 'RenewalsPytd',
      OrderBy: 'asc',
    };
    if (this.isGCE) {
      updatedPayloadTable.SortBy = 'Account';
      updatedPayloadTable.OrderBy = 'asc';
      delete updatedPayloadTable.PageNumber;
      delete updatedPayloadTable.PageSize;
    }
    this.getRenewalsStatusByAccountingMonth(updatedPayloadTabs);
    this.getMyRenewalsTable(updatedPayloadTable);
  }

  cellClickHandler(cell) {
    this.currentFilters.Status = this.tabs.getActiveTab().meta.filterStatus;
    if (this.isGCE) {
      if (cell.column && cell.column.colId && cell.column.colId === 'Account') {
        this.navigate.toCustomer(cell.data.ClientID, '', {
          showBrowseBy: true,
          extraFilters: {
            ...this.accountingYearMonth,
            TimeFrame: this.timeFrame,
          },
        });
      }
    } else {
      if (cell.column && cell.column.colId && cell.column.colId === 'Branch') {
        this.updateFilters();
        const serializedFilters = this.filterWatch.serializeFromPayload({
          ...this.currentFilters,
          CreditedBranch: [cell.value],
        });
        this.router.navigate(['/tracking-and-reporting/detail'], {
          queryParams: {
            filters: this.filterWatch.create(serializedFilters),
            showBrowseBy: false,
          },
        });
      }
    }
  }

  seeDetailsClicked() {
    this.updateFilters();
    this.currentFilters.Status = this.tabs.getActiveTab().meta.filterStatus;
    if (this.isGCE) {
      this.renewalsByTermDate.forEach((ele: any) => {
        if (ele.Account.trim() !== 'Total') {
          this.clientIDCollections.push((ele.ClientID + '').trim()), this.clientNameCollections.push(ele.Account.trim());
        }
      });
      this.currentFilters.BrowseByProducer = 'Insured Search';
      console.log(this.renewalsByTermDate);
      this.currentFilters = {
        ...this.currentFilters,
        ClientID: this.clientIDCollections,
        ClientName: this.clientNameCollections,
      };
    }

    const serializedFilters = this.filterWatch.serializeFromPayload({
      ...this.currentFilters,
      CreditedRegion: this.selectedBranch ? [] : this.user.CreditedRegion,
      TransactionType: ['Renewal'],
    });
    this.router.navigate(['/tracking-and-reporting/detail'], {
      queryParams: {
        filters: this.filterWatch.create(serializedFilters),
        showBrowseBy: this.isGCE || this.isMSL ? true : false,
      },
    });
  }

  updateFilters() {
    this.currentFilters = {
      ...this.currentFilters,
      TimeFrame: this.timeFrame,
      CreditedRegion: this.user.CreditedRegion,
      CreditedBranch: this.selectedBranch ? [this.selectedBranch] : this.user.CreditedBranch,
      TransactionType: ['Renewal'],
      //Status: ['Pending', 'Working', 'Quoted', 'Bound'],
    };

    if (this.isMSL) {
      this.currentFilters.CompanyName = ['Major Accounts Division'];
      this.currentFilters.CreditedRegion = [];
    }
  }

  tabSelectionHandler(tab: TabComponent) {
    if (!tab || !tab.meta) {
      return;
    }

    this.currentFilters.Status = tab.meta.filterStatus || this.currentFilters.Status;
  }

  ngOnInit() {
    if (this.user.UserType === 'Regional Manager' || this.isMSL || this.isGCE) {
      this.timeFrame = 'MTD';
      this.currentDateFilterIndex = 0;
    }

    if (this.isGCE) {
      this.tableType = 'renewals-gce';
    }

    if (this.isMSL) {
      this.tableType = 'renewals-msl';
    }

    combineLatest([this.accountingYearMonth$, this.dashboardService.selectedTabAnnounced$.pipe(skip(1))]).subscribe(([accountingYearMonth, tab]) => {
      this.accountingYearMonth = accountingYearMonth;
      this.currentFilters.AccountMonth = accountingYearMonth.AccountingMonth as MonthName;
      this.currentFilters.AccountYear = accountingYearMonth.AccountingYear;
      this.status = tab['status'];
      this.getRenewalsStatusByAccountingMonth();
      const updatedPayloadTable = {
        ...this.userWithAccountingYearMonth,
        TimeFrame: this.timeFrame,
        Status: this.status,
        //PageNumber: (this.isMSL) ? 0 : 2,
        //PageSize: (this.isMSL) ? 0 : 4,
        SortBy: 'RenewalsPytd',
        OrderBy: 'asc',
      };

      if (this.isMSL) {
        this.getBranchList();
      }
      if (this.isGCE) {
        updatedPayloadTable.SortBy = 'Account';
        updatedPayloadTable.OrderBy = 'asc';
        // delete updatedPayloadTable.PageNumber;
        // delete updatedPayloadTable.PageSize;
      }

      this.getMyRenewalsTable(updatedPayloadTable);
    });
  }

  getBranchList() {
    this.branchlist = [{ text: 'Viewing All Branches', value: '' }];

    // this.user.CreditedBranch.sort((b1, b2) => {
    //   if(b1 > b2) return 1;
    //   if(b1 < b2) return -1;
    // });
    for (var i = 0; i < this.user.RegionBranch.length; i++) {
      var branch = this.user.RegionBranch[i].split('-');
      if (i != 0) {
        if (branch[0].trim() != this.user.RegionBranch[i - 1].split('-')[0].trim()) {
          this.branchlist.push({
            text: '----------------------',
            value: '----------------------',
          });
        }
      }
      this.branchlist.push({ text: branch[1], value: branch[1] });
    }

    //this.user.RegionBranch.forEach((ele) => {
    //  this.branchlist.push({ text: ele, value: ele });
    //});

    // this.reportingService.getCreditBranchbyRegion(this.user.CreditedRegion)
    // .subscribe(data => {
    //   let branches: any = data;
    //   this.branchlist = [{text:'Viewing All Branches', value: ''}];
    //   branches.forEach(ele => {
    //     this.branchlist.push(ele);
    //   });

    // })
  }

  branchFilterSelected(data) {
    this.selectedBranch = data.value;
    const updatedPayloadTabs = {
      ...this.userWithAccountingYearMonth,
      TimeFrame: this.timeFrame,
      Status: this.status,
      Branch: this.selectedBranch,
    };
    const updatedPayloadTable = {
      ...this.userWithAccountingYearMonth,
      TimeFrame: this.timeFrame,
      Status: this.status,
      PageNumber: 0,
      PageSize: 0,
      SortBy: 'RenewalsPytd',
      OrderBy: 'asc',
      Branch: this.selectedBranch,
    };

    this.getRenewalsStatusByAccountingMonth(updatedPayloadTabs);
    this.getMyRenewalsTable(updatedPayloadTable);
  }

  get isGCE() {
    return this.user.UserType === 'Global Client Executive';
  }

  get isMSL() {
    return this.user.UserType === 'Market Segment Leader';
  }
}
