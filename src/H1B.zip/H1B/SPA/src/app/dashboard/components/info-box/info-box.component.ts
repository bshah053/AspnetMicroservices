import { Component, Input } from '@angular/core';
import { Select } from '@ngxs/store';
import { AccountingYearMonthState, AccountingYearMonth } from 'store/accounting-month-year.store';
import { Observable } from 'rxjs';

@Component({
  selector: 'cb-info-box',
  templateUrl: './info-box.component.html',
  styleUrls: ['./info-box.component.scss'],
})
export class InfoBoxComponent {
  @Input() user;
  @Select(AccountingYearMonthState)
  public accountingYearMonth$: Observable<AccountingYearMonth>;
}
