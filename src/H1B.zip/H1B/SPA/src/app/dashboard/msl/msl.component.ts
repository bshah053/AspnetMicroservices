import { Component, OnInit, Input } from '@angular/core';
import { NavigationService } from '../../services/navigation.service';

@Component({
  selector: 'msl',
  templateUrl: './msl.component.html',
  styleUrls: ['./msl.component.scss'],
  providers: [],
})
export class MSLComponent implements OnInit {
  @Input() user: Object;

  branches: any[] = [];
  defaultYTD;

  constructor(private navigation: NavigationService) {}

  ngOnInit() {}

  handleBranchesUpdate(data) {
    this.branches = data.filter((b: any) => b.Branch !== 'Total');
  }

  meetingsSeeAllClicked() {
    this.navigation.toMyMeetings();
  }
}
