import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { Select, Store } from '@ngxs/store';
import { combineLatest, Observable } from 'rxjs';
import { Task } from '../shared/tasks/tasks.component';
import { User } from '../user/user.model';
import { UserState } from '../user/user.store';
import { HelpItem } from './help-item';
import { DashboardService } from '../dashboard/dashboard.service';

@Component({
  templateUrl: './help.component.html',
  styleUrls: ['./help.component.scss'],
})
export class HelpComponent implements OnInit {
  @Select(UserState) public user$: Observable<User>;

  user: User;

  // open;
  // isSelected; //

  helpList: any = [];
  // userID: string;
  // category:String;

  // loading = false;

  constructor(private dashboardService: DashboardService) {
    combineLatest([this.user$]).subscribe(([user]) => {
      this.user = user;
    });
  }

  ngOnInit() {
    this.fetchHelpDetails();
    console.log(this.helpList);
  }
  // this.category=this.helpList.map(item => item.Category)
  // .filter((value, index, self) => self.indexOf(value) === index)
  // console.log(this.category);

  fetchHelpDetails() {
    // this.loading = true;
    this.dashboardService.getHelpDetails(this.user['UserID']).subscribe((data) => (this.helpList = data));
  }
}
