import { Injectable } from '@angular/core';
import { Location } from '@angular/common';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class HistoryService {
  private _change: Subject<string> = new Subject();

  constructor(private location: Location) {
    this.location.subscribe(
      (val) => {
        this._change.next(val.url);
      },
      (err) => {
        console.log('onErr:', err);
      }
    );
  }

  public populateHashToUrl(hash: string): string {
    this.clearQueryParams();

    this.push(this.getCurrentUrl(), this.makeFiltersQueryParams(hash));

    return hash;
  }

  public locationChange(): Subject<string> {
    return this._change;
  }

  private push(url: string, query: string = ''): void {
    window.history.pushState({}, '', window.location.href + query);
  }

  private replace(url: string, query: string = ''): void {
    window.history.pushState({}, '', window.location.href + query);
  }

  private getCurrentUrl(): string {
    return this.location.path().split('?')[0];
  }

  private clearQueryParams(): void {
    this.location.replaceState(this.getCurrentUrl(), '');
  }

  private makeFiltersQueryParams(hash): string {
    return `?filters=${hash}`;
  }
}
