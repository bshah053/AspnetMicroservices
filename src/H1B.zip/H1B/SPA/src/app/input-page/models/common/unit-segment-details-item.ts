export interface UnitSegmentDetailsItem {
  SubGroup: string;
  DivisionName: string;
  GroupName: string;
  Unit: string;
  UnitValue: string;
  InputPage: string;
  NewInputPage: string;
}
