export interface AviationDetails {
  AviationID?: number;
  PolicyReference: string;
  PolicyType: string;
  PolicyNumber?: string;
  PortFolioClass?: string;
  ACESharePercentage?: number;
  TotalPremium?: number;
  ACESharePremium?: number;
  TotalLimit?: number;
  ACESharelimit?: number;
  RateChange?: number;
}
