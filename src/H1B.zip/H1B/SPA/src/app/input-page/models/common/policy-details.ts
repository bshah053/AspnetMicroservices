export interface SubmissionPolicyDetails {
  Product?: string;
  PolicyNumber?: string;
  GWP?: number;
  Exposure?: number;
  ExposureType?: string;
  SIRDeductible?: string;
  PerOccurrenceLimit?: string;
}
