import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { combineLatest } from 'rxjs';
import { ReportingService } from '../../../../tracking-reporting/services/reporting.service';

export interface AccountChangeEvent {
  accountTypes: string[];
  accountNames: string[];
  industrypractice: string[];
}

@Component({
  selector: 'cb-activities-account-filters',
  templateUrl: './activities-account-filters.component.html',
  styleUrls: ['./activities-account-filters.component.scss'],
})
export class ActivitiesAccountFiltersComponent implements OnInit, OnChanges {
  @Output()
  selectionChange: EventEmitter<AccountChangeEvent> = new EventEmitter<AccountChangeEvent>();
  @Input() selectedAccountTypes: string[] = [];
  @Input() selectedAccountNames: string[] = [];
  @Input() selectedIndustryPractice: string[] = [];

  name = 'Customer';
  filters = {
    AccountTypes: {
      name: 'Account Type',
      api: 'getInsuredAccountTypeFilters',
      items: [],
    },
    AccountNames: {
      name: 'Account Name',
      api: 'getInsuredAccountNameFilters',
      items: [],
    },
    IndustryPractice: {
      name: 'Industry Practice',
      api: 'getIndustrypractice',
      items: [],
    },
  };

  constructor(private reportingService: ReportingService) {
    this.fetchAccountFilters();
  }

  ngOnInit() {}

  ngOnChanges(changes: SimpleChanges): void {
    this.fetchAccountFilters();
  }

  get countSelected() {
    return [...this.selectedAccountTypes, ...this.selectedAccountNames, ...this.selectedIndustryPractice].length;
  }

  get selected() {
    return !!this.countSelected;
  }

  get label() {
    const selectedCount = this.countSelected;
    if (selectedCount) {
      return `${this.name} (${selectedCount})`;
    }

    return this.name;
  }

  fetchAccountFilters() {
    combineLatest([
      this.reportingService[this.filters.AccountTypes.api](),
      this.reportingService[this.filters.AccountNames.api]({
        AccountType: this.selectedAccountTypes,
      }),
      this.reportingService[this.filters.IndustryPractice.api](),
    ]).subscribe(([types, names, industry]: any) => {
      this.filters.AccountTypes.items = types;
      this.filters.AccountNames.items = names;
      this.filters.IndustryPractice.items = industry;

      const selectedNames = (this.selectedAccountNames || []).filter((n) => names.some((name) => name.value === n));
      if (selectedNames.length !== this.selectedAccountNames.length) {
        this.selectedAccountNames = selectedNames;
        this.handleAccountNamesChange(this.selectedAccountNames);
      }
    });
  }

  handleAccountTypesChange(values: string[]) {
    this.selectionChange.next({
      accountTypes: [...values],
      accountNames: this.selectedAccountNames,
      industrypractice: this.selectedIndustryPractice,
    });
  }

  handleAccountNamesChange(values: string[]) {
    this.selectionChange.next({
      accountTypes: this.selectedAccountTypes,
      accountNames: values,
      industrypractice: this.selectedIndustryPractice,
    });
  }
  handleIndustryPracticeChange(values: string[]) {
    this.selectionChange.next({
      accountTypes: this.selectedAccountTypes,
      accountNames: this.selectedAccountNames,
      industrypractice: values,
    });
  }
}
