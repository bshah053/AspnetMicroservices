export interface ErrorLogDetailsItem {
  UserID: string;
  ErrorSource?: string;
  ErrorMessage?: string;
  ErrorStackTrace?: string;
  ErrorPayload?: string;
}
