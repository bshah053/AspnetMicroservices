import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MsalGuard } from '@azure/msal-angular';

import { DashboardComponent } from './dashboard.component';
import { DashboardLandingComponent } from './landing/landing.component';
import { MyMeetingsPageComponent } from './my-meetings-page/my-meetings-page.component';
import { TrackerQueueComponent } from './tracker-queue/tracker-queue.component';

const routes: Routes = [
	{
		path: '',
		component: DashboardComponent,
		canActivate: [MsalGuard],
		canActivateChild: [MsalGuard],
		children: [
			{
				path: '',
				component: DashboardLandingComponent,
			},
			{
				path: 'tracker-queue',
				component: TrackerQueueComponent,
			},
			{
				path: 'my-meetings',
				component: MyMeetingsPageComponent,
			},
		],
	},
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule],
})
export class DashboardRoutingModule {}
