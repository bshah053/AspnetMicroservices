import { ContactDetails } from '../../../contacts-activities/search/contacts-search/contact-search.service';

export interface SubmissionContactDetails {
  UserId: string;
  ControlName: string;
  ContactDetails: ContactDetails[];
}
