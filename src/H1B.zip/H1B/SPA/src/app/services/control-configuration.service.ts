import { Injectable } from '@angular/core';
import { FormControl, ValidatorFn, Validators } from '@angular/forms';
import { DataElementsDetails } from 'input-page/models/load/data-elements-control-details-item';
import { ControlType } from 'utilities/common-enum-const';
import { Helper } from 'utilities/common-helper';
import {
  DataElements,
  OptionsItems,
} from '../user-admin/model/forms-controls-data-elements';

@Injectable({
  providedIn: 'root',
})
export class ControlConfigurationService {
  constructor() {}

  setControlConfig(element: DataElements): any {
    return element.IsRequired
      ? new FormControl(
          {
            disabled: !element.IsVisible || element.IsReadonly ? true : false,
            value: this.setDefaultValue(element),
          },
          {
            validators: this.getControlValidator(element, true),
            updateOn: this.getUpdateOn(element),
          }
        )
      : new FormControl(
          {
            disabled: !element.IsVisible || element.IsReadonly ? true : false,
            value: this.setDefaultValue(element),
          },
          {
            validators: this.getControlValidator(element),
            updateOn: this.getUpdateOn(element),
          }
        );
  }

  private setDefaultValue(element: DataElements) {
    if (element.ControlType === ControlType.Dropdown) {
      if (
        ['NewTypeNo', 'UserCountry', 'CurrencyPreference'].includes(
          element.ControlName
        ) &&
        (Helper.isStringNotNullAndEmpty(element.DefaultValue) &&
          element.Options !== null)
      ) {
        const defaultOptions: OptionsItems[] = element.Options.filter(
          (item) => item.value === element.DefaultValue
        );
        if (defaultOptions && defaultOptions.length > 0) {
          return defaultOptions[0];
        } else {
          return '';
        }
      } else {
        return element.DefaultValue;
      }
    } else {
      return element.DefaultValue;
    }
  }

  compareWithDDValue(option, selection) {
    if (typeof option === 'object' && typeof selection === 'object') {
      return option === selection
        ? true
        : option.value.toLowerCase() === selection.value.toLowerCase()
          ? true
          : false;
    } else if (
      Helper.isStringNotNullAndEmpty(option) &&
      Helper.isStringNotNullAndEmpty(selection)
    ) {
      return option === selection
        ? true
        : option.toLowerCase() === selection.toLowerCase()
          ? true
          : false;
    } else if (Helper.isStringNotNullAndEmpty(selection)) {
      return false;
    }
  }

  getUpdateOn(
    element: DataElements | DataElementsDetails
  ): 'blur' | 'change' | 'submit' {
    const blurEventControls = ['MirrorControlID'];
    return blurEventControls.some((cntrl) => cntrl === element.ControlName)
      ? 'blur'
      : 'change';
  }

  getControlValidator(
    element: any,
    isRequired: boolean = false
  ): ValidatorFn | ValidatorFn[] {
    switch (element.ControlType.toLowerCase()) {
      case ControlType.InputText:
      case ControlType.InputMultiLine:
      case ControlType.InputTextAlphabets:
      case ControlType.InputTextPattern:
        if (isRequired) {
          if (
            Helper.isNumberNotNullAndEmpty(element.MaxLength) &&
            Helper.isNumberNotNullAndEmpty(element.MinLength)
          ) {
            if (Helper.isStringNotNullAndEmpty(element.ValidCharRegEx)) {
              return [
                Validators.required,
                Validators.pattern(element.ValidCharRegEx),
                Validators.maxLength(element.MaxLength),
                Validators.minLength(element.MinLength),
              ];
            } else {
              return [
                Validators.required,
                Validators.maxLength(element.MaxLength),
                Validators.minLength(element.MinLength),
              ];
            }
          } else if (Helper.isNumberNotNullAndEmpty(element.MaxLength)) {
            if (Helper.isStringNotNullAndEmpty(element.ValidCharRegEx)) {
              return [
                Validators.required,
                Validators.pattern(element.ValidCharRegEx),
                Validators.maxLength(element.MaxLength),
              ];
            } else {
              return [
                Validators.required,
                Validators.maxLength(element.MaxLength),
              ];
            }
          } else if (Helper.isNumberNotNullAndEmpty(element.MinLength)) {
            if (Helper.isStringNotNullAndEmpty(element.ValidCharRegEx)) {
              return [
                Validators.required,
                Validators.pattern(element.ValidCharRegEx),
                Validators.minLength(element.MinLength),
              ];
            } else {
              return [
                Validators.required,
                Validators.minLength(element.MinLength),
              ];
            }
          } else {
            if (Helper.isStringNotNullAndEmpty(element.ValidCharRegEx)) {
              return [
                Validators.required,
                Validators.pattern(element.ValidCharRegEx),
              ];
            } else {
              return [Validators.required];
            }
          }
        } else {
          if (
            Helper.isNumberNotNullAndEmpty(element.MaxLength) &&
            Helper.isNumberNotNullAndEmpty(element.MinLength)
          ) {
            if (Helper.isStringNotNullAndEmpty(element.ValidCharRegEx)) {
              return [
                Validators.pattern(element.ValidCharRegEx),
                Validators.maxLength(element.MaxLength),
                Validators.minLength(element.MinLength),
              ];
            } else {
              return [
                Validators.maxLength(element.MaxLength),
                Validators.minLength(element.MinLength),
              ];
            }
          } else if (Helper.isNumberNotNullAndEmpty(element.MaxLength)) {
            if (Helper.isStringNotNullAndEmpty(element.ValidCharRegEx)) {
              return [
                Validators.pattern(element.ValidCharRegEx),
                Validators.maxLength(element.MaxLength),
              ];
            } else {
              return [Validators.maxLength(element.MaxLength)];
            }
          } else if (Helper.isNumberNotNullAndEmpty(element.MinLength)) {
            if (Helper.isStringNotNullAndEmpty(element.ValidCharRegEx)) {
              return [
                Validators.pattern(element.ValidCharRegEx),
                Validators.minLength(element.MinLength),
              ];
            } else {
              return [Validators.minLength(element.MinLength)];
            }
          } else {
            if (Helper.isStringNotNullAndEmpty(element.ValidCharRegEx)) {
              return [Validators.pattern(element.ValidCharRegEx)];
            } else {
              return [];
            }
          }
        }
        break;
      case ControlType.InputNumber:
      case ControlType.InputabsNumber:
      case ControlType.InputPercentage:
      case ControlType.InputMoney:
      case ControlType.InputMoney2:
      case ControlType.InputabsMoney:
      case ControlType.InputabsMoney2:
        if (isRequired) {
          if (
            Helper.isNumberNotNullAndEmpty(element.MaxValue) &&
            Helper.isNumberNotNullAndEmpty(element.MinValue)
          ) {
            return [
              Validators.required,
              Validators.max(element.MaxValue),
              Validators.min(element.MinValue),
            ];
          } else if (Helper.isNumberNotNullAndEmpty(element.MaxValue)) {
            return [Validators.required, Validators.max(element.MaxValue)];
          } else if (Helper.isNumberNotNullAndEmpty(element.MinValue)) {
            return [Validators.required, Validators.min(element.MinValue)];
          } else {
            return [Validators.required];
          }
        } else {
          if (
            Helper.isNumberNotNullAndEmpty(element.MaxValue) &&
            Helper.isNumberNotNullAndEmpty(element.MinValue)
          ) {
            return [
              Validators.max(element.MaxValue),
              Validators.min(element.MinValue),
            ];
          } else if (Helper.isNumberNotNullAndEmpty(element.MaxValue)) {
            return [Validators.max(element.MaxValue)];
          } else if (Helper.isNumberNotNullAndEmpty(element.MinValue)) {
            return [Validators.min(element.MinValue)];
          } else {
            return [];
          }
        }
        break;
      case ControlType.InputEmail:
        if (isRequired) {
          return [Validators.required, Validators.email];
        } else {
          return [Validators.email];
        }
        break;
      case ControlType.Checkbox:
        if (isRequired) {
          return [Validators.requiredTrue];
        } else {
          return [];
        }
        break;
      case ControlType.InputPhone:
      case ControlType.Radio:
      case ControlType.Dropdown:
      case ControlType.CascadingDropdown:
      case ControlType.GroupDropdown:
      case ControlType.ComboDropdown:
      case ControlType.GroupComboDropdown:
      case ControlType.CascadingGroupComboDropdown:
      case ControlType.InputAutoComplete:
      case ControlType.InputDate:
      case ControlType.InputZip:
      case ControlType.InputHyperLink:
      case ControlType.InputMailLink:
        if (isRequired) {
          return [Validators.required];
        } else {
          return [];
        }
        break;
      default:
        if (isRequired) {
          return [Validators.required];
        } else {
          return [];
        }
        break;
    }
  }
}
