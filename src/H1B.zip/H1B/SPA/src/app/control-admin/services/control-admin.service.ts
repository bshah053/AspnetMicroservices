import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { environment } from 'environments/environment';
import { ApiService } from 'services/api.service';
import { ForecasterControlMaster } from '../model/forecaster-control-master';
import { ControlMappingDetails } from '../model/control-mapping-details';
import { SegmentsOptionsItems } from '../model/segments-items';
import { SegmentsOptionsGroupItems } from '../model/segments-group-items';
import { DataElements } from '../../user-admin/model/forms-controls-data-elements';

export interface Options {
  text: string;
  value: any;
}

interface OptionsResponse {
  Text: string;
  Value: any;
}

@Injectable({
  providedIn: 'root',
})
export class ControlAdminService extends ApiService {
  constructor(httpClient: HttpClient, private http: HttpClient) {
    super(httpClient, environment.apiSubmissions);
  }

  saveControlMasterDetails(
    payload: ForecasterControlMaster
  ): Observable<string> {
    return this.post('/control/admin/controlmaster/save', null, payload).pipe(
      map((data: string) => data)
    );
  }

  getControlMappingDetails(
    userID,
    controlID
  ): Observable<ControlMappingDetails[]> {
    return this.post(
      `/control/admin/controlmapping?UserID=${userID}&ControlID=${controlID}`,
      null,
      null
    ).pipe(map((data: ControlMappingDetails[]) => data));
  }

  getHierarchyDetails(userID): Observable<SegmentsOptionsItems[]> {
    return this.post(
      `/control/admin/hierarchydetails?UserID=${userID}`,
      null,
      null
    ).pipe(map((data: SegmentsOptionsItems[]) => data));
  }

  getHeaderSegmentsByFilter(
    userID,
    division,
    units
  ): Observable<SegmentsOptionsGroupItems[]> {
    return this.post('/control/admin/headersegmentsbyfilter', null, {
      UserID: userID,
      Division: division,
      Units: units,
    }).pipe(map((data: SegmentsOptionsGroupItems[]) => data));
  }

  getControlElementDetailsByName(userID, tableID): Observable<DataElements[]> {
    return this.post(
      `/control/admin/controldetailsbyname?userID=${userID}&tableID=${tableID}`,
      null,
      null
    ).pipe(map((data: DataElements[]) => data));
  }

  getMasterTableDetails(userID: string): Observable<Options[]> {
    return this.post(`/control/admin/mastertabledetails?UserID=${userID}`).pipe(
      map(this.mapOptions)
    );
  }

  getDivision(userID): Observable<Options[]> {
    return this.post(
      `/control/admin/division?userID=${userID}`,
      null,
      null
    ).pipe(map(this.mapOptions));
  }

  getUnitsByDivision(userID, division): Observable<Options[]> {
    return this.post('/control/admin/unitsbydivision', null, {
      UserID: userID,
      Division: division,
    }).pipe(map(this.mapOptions));
  }

  getSegmentsByUnitsAndDivision(
    userID,
    division,
    units
  ): Observable<Options[]> {
    return this.post('/control/admin/segmentsbyunitsdivision', null, {
      UserID: userID,
      Division: division,
      Units: units,
    }).pipe(map(this.mapOptions));
  }

  private mapOptions(data: OptionsResponse[]) {
    return !data
      ? []
      : data.map((filter) => ({ text: filter.Text, value: filter.Value }));
  }
}
