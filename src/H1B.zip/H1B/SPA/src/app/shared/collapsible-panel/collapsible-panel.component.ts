import {
  Component,
  OnInit,
  TemplateRef,
  Input,
  Output,
  EventEmitter,
  OnChanges,
} from '@angular/core';

@Component({
  selector: 'cb-collapsible-panel',
  templateUrl: './collapsible-panel.component.html',
  styleUrls: ['./collapsible-panel.component.scss'],
})
export class CollapsiblePanelComponent implements OnInit {
  @Input() menuTemplate: TemplateRef<any>;
  @Input() contentTemplate: TemplateRef<any>;
  @Input() title: string;
  @Input() linkName: string = 'See Details';
  @Input() enableCollapse = true;

  @Output() linkClicked = new EventEmitter();

  showPanel = true;

  constructor() {}

  ngOnInit() {}

  toggleCollapse() {
    this.showPanel = !this.showPanel;
  }

  linkClickHandler($e) {
    this.linkClicked.emit($e);
  }
}
