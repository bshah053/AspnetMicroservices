import { Component, OnInit, Input, ChangeDetectionStrategy, Output, EventEmitter } from '@angular/core';

import { User } from '../../../user/user.model';
import { IPostMortemUpdate } from 'shared/post-mortem-update/post-mortem-update.model';
import { CopyDeleteRequestModel } from 'model/copydelete-request-model';
import Utilities from '../../../shared/utilities';
import { TrackerQueueRendererComponent } from '../tracker-queue-renderer/tracker-queue-renderer.component';
import { ReportingService } from '../../../tracking-reporting/services/reporting.service';
import { CopyDeleteService } from 'services/copydelete.service';

const statusList = {
  Pending: 'Lost',
  Working: 'Declined',
  Quoted: 'Quoted-Lost',
  Target: 'Target-Closed',
  Declined: 'Declined',
  Lost: 'Lost',
  'Quoted-Lost': 'Quoted-Lost',
  'Target-Closed': 'Target-Closed',
};

function currencyFormatter(params) {
  return '$' + formatNumber(params.value);
}

function formatNumber(number) {
  return Math.floor(number)
    .toString()
    .replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
}

@Component({
  selector: 'cb-tracker-queue-table',
  templateUrl: './tracker-queue-table.component.html',
  styleUrls: ['./tracker-queue-table.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TrackerQueueTableComponent implements OnInit {
  @Output() savePostMortem = new EventEmitter<any>();
  @Output() sortedObjChange = new EventEmitter<any>();
  @Input() user: User;
  @Input() data;
  @Input() sortedObj;
  context;
  frameworkComponents;
  isOpen = false;
  isNextTermOpen = false;
  actionName = '';
  recordNo: number;
  postMertemObj: IPostMortemUpdate = new IPostMortemUpdate();
  postMortemUpdateForm: IPostMortemUpdate = new IPostMortemUpdate();
  selectedLostReasonList: string[] = [];

  columns: any = [
    {
      headerName: 'Details',
      field: 'Details',
      width: 110,
      suppressSizeToFit: true,
      resizable: true,
      sortable: false,
      cellRenderer: 'trackerQueueRenderer',
    },
    {
      headerName: 'Insured Name',
      field: 'Insured',
      tooltipValueGetter: (params) => params.value,
      width: 140,
      comparator: this.SortComparator,
    },
    {
      headerName: 'Forecast',
      field: 'GrossForecast',
      tooltipValueGetter: (params) => params.value,
      valueFormatter: currencyFormatter,
      cellClass: 'numeric currency',
      width: 110,
    },
    {
      headerName: 'Conf.',
      field: 'ConfidenceFactor',
      tooltipValueGetter: (params) => params.value,
      width: 80,
      // comparator: this.SortComparator,
    },
    {
      headerName: 'Effective',
      field: 'EffectiveDate',
      cellClass: 'date',
      valueFormatter: Utilities.dateFormatter,
      tooltipValueGetter: (params) => params.valueFormatted,
      width: 108,
      headerClass: 'multiline',
      suppressSizeToFit: true,
      cellRenderer: Utilities.restrictCellTextRenderer(),
    },
    {
      headerName: 'Product',
      field: 'Product',
      tooltipValueGetter: (params) => params.value,
      width: 122,
      comparator: this.SortComparator,
    },
    {
      headerName: 'Type',
      field: 'Type',
      tooltipValueGetter: (params) => params.value,
      width: 100,
      comparator: this.SortComparator,
    },
    {
      headerName: 'Producer',
      field: 'ProducerName',
      tooltipValueGetter: (params) => params.value,
      width: 145,
      comparator: this.SortComparator,
    },
    {
      headerName: 'Status',
      field: 'Status',
      tooltipValueGetter: (params) => params.value,
      width: 92,
      comparator: this.SortComparator,
    },
    {
      headerName: 'Underwriter',
      field: 'FullName',
      tooltipValueGetter: (params) => params.value,
      width: 142,
      comparator: this.SortComparator,
    },
  ];

  constructor(private reportingService: ReportingService, private copyDeleteService: CopyDeleteService) {
    this.context = { componentParent: this };
    this.frameworkComponents = {
      trackerQueueRenderer: TrackerQueueRendererComponent,
    };
  }

  ngOnInit() {
    let columnIndex = this.getSelectedColumnsSortedValue();
    if (!this.sortedObj.direction) {
      this.columns[columnIndex].sort = 'desc';
    } else this.columns[columnIndex].sort = this.sortedObj.direction;
  }

  trackerQueueDelete(cell) {
    const deleteRequest: CopyDeleteRequestModel = {
      Source: 'TQ',
      UserID: this.user.UserID,
      RecordNumber: cell.data.Details.RecordNo,
    };
    this.copyDeleteService.showConfirmationDelete(deleteRequest);
  }

  trackerQueueCopy(cell) {
    const copyRequest: CopyDeleteRequestModel = {
      Source: 'TQ',
      UserID: this.user.UserID,
      RecordNumber: cell.data.Details.RecordNo,
      Company: cell.data.Details.CompanyName,
      Status: cell.data.Status,
      LinkedRecordNumber: cell.data.Details.LinkedRecordNumber,
    };
    this.copyDeleteService.showConfirmationCopy(copyRequest);
  }

  trackerQueueNextTerm(cell) {
    this.recordNo = cell.data.Details.RecordNo;
    if (statusList[cell.data.Status] !== undefined) {
      this.getPMDByRecordNumber(this.recordNo, cell);
      this.isNextTermOpen = true;
    } else {
      alert('You can create next term when the status is Target, Target-Closed, Pending, Declined, Working, Lost, Quoted & Quoted-Lost only');
    }
  }

  private SortComparator(a, b) {
    if (a === null && b === null) {
      return 0;
    }
    if (a === null) {
      return -1;
    }
    if (b === null) {
      return 1;
    }
    if (a.toUpperCase() > b.toUpperCase()) return 1;
    if (a.toUpperCase() < b.toUpperCase()) return -1;
    return 0;
  }

  private getPMDByRecordNumber(recordNumber, cell) {
    this.reportingService.getPMDByRecordNumber(recordNumber).subscribe((data: IPostMortemUpdate) => {
      if (data !== null) {
        this.postMortemUpdateForm = data[0];
        this.postMortemUpdateForm.PursureNextYear = 'Yes';
        // data[0].PursureNextYear === 'True' ? 'Yes' : '';
        this.selectedLostReasonList = data[0].LostReason.split();
        this.postMortemUpdateForm.OldStatus = cell.data.Status;
        this.postMortemUpdateForm.Status = statusList[cell.data.Status];
        this.postMortemUpdateForm.Units = cell.data.Details.Subgroup;
        this.postMortemUpdateForm.Segments = cell.data.Details.Division;
      } else {
        this.postMortemUpdateForm = new IPostMortemUpdate();
        this.postMortemUpdateForm.PursureNextYear = 'Yes';
        this.postMortemUpdateForm.OldStatus = cell.data.Status;
        this.postMortemUpdateForm.Status = statusList[cell.data.Status];
        this.postMortemUpdateForm.Units = cell.data.Details.Subgroup;
        this.postMortemUpdateForm.Segments = cell.data.Details.Division;
      }
      console.log(this.postMortemUpdateForm);
    });
  }

  handleNextTermClose($event) {
    this.isNextTermOpen = false;
    this.postMertemObj = {
      ...$event,
      RecordNo: this.recordNo,
      // Status: this.status,
      // OldStatus: this.oldStatus,
      LoginName: this.user.UserID,
    };

    if (this.postMertemObj.Action === 'Save') {
      delete this.postMertemObj.Action;
      this.savePostMortem.next(this.postMertemObj);
    } else if (this.postMertemObj.Action === 'Close') {
      // No Action Required
    }
  }

  handleSortedChange($event) {
    this.sortedObjChange.emit($event);
  }

  getSelectedColumnsSortedValue() {
    switch (this.sortedObj.column) {
      case 'Insured': {
        return 1;
      }
      case 'GrossForecast': {
        return 2;
      }
      case 'ConfidenceFactor': {
        return 3;
      }
      case 'EffectiveDate': {
        return 4;
      }
      case 'Product': {
        return 5;
      }
      case 'Type': {
        return 6;
      }
      case 'ProducerName': {
        return 7;
      }
      case 'Status': {
        return 8;
      }
      case 'FullName': {
        return 9;
      }
      default: {
        return 2;
      }
    }
  }
}
