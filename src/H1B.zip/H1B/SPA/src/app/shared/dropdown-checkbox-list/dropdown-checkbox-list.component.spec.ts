import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { DropdownCheckboxListComponent } from './dropdown-checkbox-list.component';

describe('DropdownCheckboxListComponent', () => {
	let component: DropdownCheckboxListComponent;
	let fixture: ComponentFixture<DropdownCheckboxListComponent>;

	beforeEach(
		waitForAsync(() => {
			TestBed.configureTestingModule({
				declarations: [DropdownCheckboxListComponent],
			}).compileComponents();
		})
	);

	beforeEach(() => {
		fixture = TestBed.createComponent(DropdownCheckboxListComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
