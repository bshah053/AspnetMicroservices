import { IContact } from '../models/contact';

export interface IContactSearchFilters {
  Producer?: string[];
  Customer?: string[];
  ProducerRegion?: string[];
  ProducerBranch?: string[];
  ContactType?: string[];
  RelationshipType?: string[];
  ChubbMarketSegment?: string[];
  Status?: string[];
  ContactName?: string;
  AccountName?: string;
  AccountType?: string;
}

export interface IActivitiesSearchFilters {
  StartDate?: string;
  EndDate?: string;
  Producer?: string[];
  Customer?: string[];
  AccountType?: string[];
  ProducerRegion?: string[];
  ProducerBranch?: string[];
  Owner?: string[];
  OwnerContact?: IContact[];
  Attendee?: string[];
  CallType?: string[];
  CompanyOwnerType?: string[];
  Status?: string[];
  ActivityType?: string[];
  SortBy?: string;
  OwnerUnit?: string[];
  IndustryPractice?: string[];
  EventType?: string[];
}

export class ContactsActivitiesModel {
  contactSearch: IContactSearchFilters = {};
  activitiesSearch: IActivitiesSearchFilters = {};
}
