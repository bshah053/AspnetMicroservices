export interface AuditTrailDetailsItem {
  RecordNumber?: number;
  UpdatedBy: string;
  UpdatedDate: Date;
  PriorValue: string;
  ChangeType: string;
  UpdatedByLoginName: string;
  UpdatedByFirstName: string;
  UpdatedByLastName: string;
  UpdatedByEmailId: string;
}
