import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { ContactSearchService } from '../contact-search.service';

type ListItem = {
  text: string;
  value: string;
};

@Component({
  selector: 'cb-relationshiptype-menu',
  templateUrl: './relationshiptype-menu.component.html',
  styleUrls: ['./relationshiptype-menu.component.scss'],
})
export class RelationshiptypeMenuComponent implements OnInit {
  @Output() selectionChange = new EventEmitter<string[]>();
  @Input() name = 'Relationship Type';
  @Input() selectedItems: string[] = [];
  relationshipTypeList: ListItem[] = [];

  constructor(private contactSearch: ContactSearchService) {}

  ngOnInit() {
    this.relationshipTypes();
  }

  relationshipTypes() {
    this.contactSearch
      .relationshipTypes()
      .subscribe(
        (items: ListItem[]) => (this.relationshipTypeList = items),
        (error) => console.error('Error loading relationship types', error)
      );
  }

  handleRelationshipTypeChange(value: string[]) {
    this.selectionChange.next(value);
  }
}
