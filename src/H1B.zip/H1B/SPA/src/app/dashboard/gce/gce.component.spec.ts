import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { GceComponent } from './gce.component';

describe('GceComponent', () => {
	let component: GceComponent;
	let fixture: ComponentFixture<GceComponent>;

	beforeEach(
		waitForAsync(() => {
			TestBed.configureTestingModule({
				declarations: [GceComponent],
			}).compileComponents();
		})
	);

	beforeEach(() => {
		fixture = TestBed.createComponent(GceComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
