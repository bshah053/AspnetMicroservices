import { Component, Inject, Input, OnInit } from '@angular/core';
import { User } from 'user/user.model';
import { UWGeniusQueueDetailedItems } from '../../models/common/uw-genius-queue-detailed-items';
import { InputPageService } from 'input-page/services/input-page.service';

@Component({
  selector: 'cb-uw-genius-queue-view',
  templateUrl: './uw-genius-queue-view.component.html',
  styleUrls: ['./uw-genius-queue-view.component.scss'],
})
export class UwGeniusQueueViewComponent implements OnInit {
  @Input() user: User;
  @Input() pipeID: number;
  uwGeniusItems: UWGeniusQueueDetailedItems;

  constructor(
    @Inject(InputPageService) private inputPageService: InputPageService
  ) {}

  ngOnInit(): void {
    if (this.pipeID && this.pipeID > 0) {
      this.getUWGeniusQueueDetailsByPipeId();
    }
  }

  getUWGeniusQueueDetailsByPipeId() {
    this.inputPageService
      .getUWGeniusQueueDetailsByPipeId(this.user.UserID, this.pipeID)
      .subscribe((data: UWGeniusQueueDetailedItems) => {
        if (data != null) {
          this.uwGeniusItems = data;
        } else {
          this.uwGeniusItems = null;
        }
      });
  }

  getUWGeniusDetails() {
    return this.uwGeniusItems;
  }
}
