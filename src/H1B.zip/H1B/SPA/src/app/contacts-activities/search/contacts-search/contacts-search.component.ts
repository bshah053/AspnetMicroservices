import { Component, OnInit, AfterViewInit, ViewChild, TemplateRef, ChangeDetectorRef } from '@angular/core';
import { Select, Store } from '@ngxs/store';
import { Observable, combineLatest, zip } from 'rxjs';
import { tap } from 'rxjs/operators';
import { UserState } from '../../../user/user.store';
import { User } from '../../../user/user.model';
import { ContactSearchService, ContactSearchPayload, ContactSortBy, ContactDetailsResponse } from './contact-search.service';
import { ColDef } from 'ag-grid-community';
import { AgGridTemplateRendererComponent } from '../../../shared/ag-grid-utils/ag-grid-template-renderer.component';
import { IPaginationState } from '../../../shared/pagination-controls/pagination-controls.component';
import Utilities from '../../../shared/utilities';
import { ContactsActivitiesState } from '../../store/contacts-activities.store';
import { ContactsActivitiesModel, IContactSearchFilters } from '../../store/contacts-activities.models';
import { SetContactSearchFilters } from '../../store/contacts-activities.actions';
import { IReportPayload, PersistenceType } from '../../../services/save-reports.service';
import { ContactsActivitiesService } from '../../contacts-activities.service';
import { ISaveReportAs } from '../../models/saveReports';
import { FilterWatchService } from '../../../services/filter-watch.service';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { ReportFilters } from '../../../tracking-reporting/reports/reports-header/reports-header.component';
import { HttpEvent, HttpEventType } from '@angular/common/http';
import { RelationshipService } from '../../relationship.service';
import { MoreFilters } from '../more-filters/more-filters.component';
import { ReportingService, FilterType, RegionBranchesResponse, InsuredAccountName } from '../../../tracking-reporting/services/reporting.service';
import { ListItem } from 'app/shared/radio-list/radio-list.component';

@Component({
	selector: 'cb-contacts-search',
	templateUrl: './contacts-search.component.html',
	styleUrls: ['./contacts-search.component.scss'],
})
export class ContactsSearchComponent implements OnInit, AfterViewInit {
	@Select(UserState) public user$: Observable<User>;
	@Select(ContactsActivitiesState) private state$: Observable<ContactsActivitiesModel>;
	// @Output() filtersUpdated: EventEmitter<ReportFilters> = new EventEmitter();
	@ViewChild('nameCell') private nameCell: TemplateRef<any>;
	@ViewChild('accountNameCell') private accountNameCell: TemplateRef<any>;
	@ViewChild('phoneNumberCell') private phoneNumberCell: TemplateRef<any>;

	downloadInProgress = false;
	xlData: HttpEvent<Blob>;
	downloadError = null;

	user: User;
	reportName: string = 'Contacts Search';
	contactTypes = [];
	marketSegments = [];
	statusTypes = [];
	searchPayload: ContactSearchPayload = {};
	savedReport = {};
	columns: ColDef[];
	totalcounts: string;
	state = {
		loading: false,
		empty: true,
		initial: true,
		error: '',
		message: '',
		pagination: false,
	};
	pagination: IPaginationState = {
		current: 1,
		size: 10,
		total: 0,
		frame: 6,
	};
	contactDetails: ContactDetailsResponse;
	filterProperties: Array<keyof ContactSearchPayload> = ['Producer', 'Customer', 'ProducerRegion', 'ProducerBranch', 'ContactType', 'RelationshipType', 'ChubbMarketSegment', 'Status', 'ContactName', 'AccountName', 'AccountType', 'OrderBy', 'IndustrySpecialization', 'ProductSpecialization', 'Cornerstone'];
	isMorefilter: boolean;
	moreFiltersContacts?: Partial<MoreFilters> = {
		ProductSpecialization: [],
		IndustrySpecialization: [],
		Cornerstone: [],
	};
	selectedRegions: Array<string> = [];
	selectedBranches: Array<string> = [];
	regionFilters: Array<FilterType> = [];
	branchFilters: Array<ListItem> = [];

	constructor(private store: Store, private router: Router, private activatedRoute: ActivatedRoute, private filterWatch: FilterWatchService, private contactSearchService: ContactSearchService, private contactsActivitiesService: ContactsActivitiesService, private relationshipService: RelationshipService, private reportingService: ReportingService, private cdRef: ChangeDetectorRef) {
		combineLatest([this.user$, this.state$]).subscribe(([user, state]) => {
			this.user = user;
			const storeFilters = { ...state.contactSearch };
			this.initializeReport(this.activatedRoute.snapshot.queryParams, storeFilters);
		});
	}

	get data() {
		return this.contactDetails && this.contactDetails.ContactSearchInfoModels;
	}

	get paging(): {
		PageNumber: number;
		PageSize: number;
		SortBy: ContactSortBy;
	} {
		return {
			PageNumber: this.pagination.current,
			PageSize: this.pagination.size,
			SortBy: this.searchPayload.SortBy || 'FullName',
		};
	}

	get defaultColumns() {
		return {};
	}

	detailsLoaded() {
		return !this.state.loading && !!this.contactDetails && !!this.contactDetails.ContactSearchInfoModels && !!this.contactDetails.ContactSearchInfoModels.length;
	}

	ngOnInit() {
		//this.resetAllRegions();
		this.reportingService.getRegionFilters().subscribe((data: Array<FilterType>) => {
			this.regionFilters = data;
		});
		this.handleRegionsChange();
		zip(this.getContactTypes(), this.getMarketSegments(), this.getStatusTypes()).subscribe(() => {
			if (!Utilities.isEmptyPayload(this.searchPayload)) {
				this.handleApplyFilters();
			}
		});
	}

	ngAfterViewInit(): void {
		this.columns = [
			{
				headerName: 'FullName',
				headerTooltip: 'FullName',
				field: 'FullName',
				tooltipValueGetter: (params) => params.value,
				width: 208,
				suppressSizeToFit: true,
				cellRendererFramework: AgGridTemplateRendererComponent,
				cellRendererParams: { ngTemplate: this.nameCell },
			},
			{
				headerName: 'Account Name',
				headerTooltip: 'Account Name',
				field: 'AccountName',
				tooltipValueGetter: (params) => params.value,
				width: 310,
				suppressSizeToFit: true,
				cellRendererFramework: AgGridTemplateRendererComponent,
				cellRendererParams: { ngTemplate: this.accountNameCell },
			},
			{
				headerName: 'Contact Type',
				field: 'Type',
				headerTooltip: 'Contact Type',
				tooltipValueGetter: (params) => params.value,
				width: 160,
				suppressSizeToFit: true,
				sortable: true,
			},
			{
				headerName: 'Phone',
				field: 'BusinessNumber',
				width: 151,
				suppressSizeToFit: true,
				sortable: false,
				cellRendererFramework: AgGridTemplateRendererComponent,
				cellRendererParams: { ngTemplate: this.phoneNumberCell },
			},

			{
				headerName: 'Email',
				field: 'Email',
				width: 300,
				suppressSizeToFit: true,
			},

			{
				headerName: 'Address',
				field: 'FullAddress',
				tooltipValueGetter: (params) => params.value,
				width: 200,
				suppressSizeToFit: false,
				cellClass: 'address-cell',
			},

			{
				headerName: 'Branch',
				field: 'Branch',
				tooltipValueGetter: (params) => params.value,
				width: 150,
				suppressSizeToFit: true,
			},
		];
	}

	initializeReport(queryParams: Params, defaultFilters: IContactSearchFilters = {}) {
		const queryFitlers = this.readQueryParams(this.filterWatch.getByHash(queryParams.filters));

		if (!Utilities.isEmptyPayload(queryFitlers)) {
			this.searchPayload = queryFitlers;
			if (this.searchPayload.ProducerRegion || this.searchPayload.ProducerRegion != null) this.selectedRegions = this.searchPayload.ProducerRegion;
			if (this.searchPayload.ProducerBranch || this.searchPayload.ProducerBranch != null) this.selectedBranches = this.searchPayload.ProducerBranch;
			if (this.searchPayload.IndustrySpecialization || this.searchPayload.IndustrySpecialization != null) this.moreFiltersContacts.IndustrySpecialization = this.searchPayload.IndustrySpecialization;
			if (this.searchPayload.ProductSpecialization || this.searchPayload.ProductSpecialization != null) this.moreFiltersContacts.ProductSpecialization = this.searchPayload.ProductSpecialization;
			if (this.searchPayload.Cornerstone || this.searchPayload.Cornerstone != null) this.moreFiltersContacts.Cornerstone = this.searchPayload.Cornerstone;
		} else {
			this.searchPayload = defaultFilters;
		}
	}

	resetAllRegions() {
		this.selectedRegions = [];
		this.selectedBranches = [];
		this.getBranches();
	}

	getContactTypes() {
		return this.contactSearchService.contactTypes().pipe(
			tap(
				(data) => {
					this.contactTypes = data;
				},
				(err) => console.error(err)
			)
		);
	}

	getMarketSegments() {
		return this.contactSearchService.marketSegments().pipe(
			tap(
				(data) => {
					this.marketSegments = data;
				},
				(err) => console.error(err)
			)
		);
	}

	getStatusTypes() {
		return this.contactSearchService.statusTypes().pipe(
			tap(
				(data) => {
					this.statusTypes = data;
				},
				(err) => console.error(err)
			)
		);
	}

	handleUpdateProducer(value: string) {
		this.handleUpdatePayload('Producer', [value]);
	}

	handleUpdatePayload(property: keyof ContactSearchPayload, value: string | number | string[]) {
		// @ts-ignore
		this.searchPayload[property] = value;
	}

	handleSortChanged(sort: { column: ContactSortBy; direction: 'asc' | 'desc' }) {
		if (sort) {
			this.searchPayload.SortBy = sort.column;
			this.searchPayload.OrderBy = this.searchPayload.OrderBy === 'asc' ? 'desc' : 'asc';
		} else {
			this.searchPayload.SortBy = undefined;
			this.searchPayload.OrderBy = undefined;
		}

		this.handleApplyFilters(this.pagination.current);
	}

	private createInitialPaginationState(): IPaginationState {
		return {
			current: 1,
			size: 10,
			total: 0,

			frame: 6,
		};
	}

	handleApplyFilters(pageNumber: number = 1) {
		this.state.loading = true;
		this.state.initial = false;
		this.state.empty = false;
		this.state.error = null;
		this.pagination = this.createInitialPaginationState();
		this.pagination.current = pageNumber;
		this.contactDetails = {
			ContactSearchInfoModels: [],
			PaginationModel: {
				TotalCount: 0,
				PageNumber: 1,
				PageSize: 10,
			},
		};
		const payload = { ...this.paging, ...this.searchPayload };
		this.store.dispatch(new SetContactSearchFilters(this.searchPayload));
		this.saveContactsReport({ UserReportName: 'Contact Search' });
		if (this.columns) {
			this.columns.forEach((c) => (c.sort = undefined));
			if (payload.SortBy) {
				const column = this.columns.find((c) => c.field === payload.SortBy);
				column.sort = payload.OrderBy;
			}
		}

		this.contactSearchService.contactDetails(payload).subscribe(
			(results: ContactDetailsResponse) => {
				if (results == null || results == undefined) {
					this.contactDetails = undefined;
					this.state.loading = false;
					this.state.empty = true;
					this.state.error = 'No Records Found';
				} else {
					this.contactDetails = results;
					const { PageNumber, PageSize, TotalCount } = results.PaginationModel;
					this.checkPaginationState(PageNumber, PageSize, TotalCount);
					// this.pagination = {
					//   ...this.pagination,
					//   total: Math.ceil(TotalCount / PageSize),
					// };
					this.totalcounts = 'Count(' + this.contactDetails.PaginationModel.TotalCount + ')';
					this.state.loading = false;
					this.state.initial = false;
					this.state.empty = !this.contactDetails.ContactSearchInfoModels.length;
					this.state.pagination = TotalCount > PageSize;
				}
			},
			(err) => {
				this.contactDetails = null;
				this.state.loading = false;
				this.state.initial = false;
				this.state.empty = err.status === 404;
				this.state.error = !this.state.empty && err.statusText;
			}
		);
	}

	private checkPaginationState(current, size, total) {
		if (current !== this.pagination.current || total !== this.pagination.current) {
			this.pagination = {
				...this.pagination,
				total: Math.ceil(total / size),
				current,
			};
		}
	}

	handleSaveReport(info: ISaveReportAs) {
		const details = {
			UserReportName: info.reportName,
			ReportNotes: info.reportNotes,
			FilterId: info.filterId ? Number.parseInt(info.filterId) : undefined,
		};

		this.saveContactsReport(details, 'Permanent');
	}

	handleLoadReport(info: ISaveReportAs) {
		this.savedReport = info;
	}

	handleLoadSavedReport(data) {
		this.initializeReport(data.queryParams);
		this.handleApplyFilters();
	}

	exportReport($event) {
		this.downloadInProgress = true;
		if ($event.ExportType.format) {
			const payload = {
				...this.paging,
				...this.searchPayload,
			};
			this.relationshipService.getContactReportFile(payload).subscribe(
				(data) => {
					this.xlData = data;
					switch (data.type) {
						case HttpEventType.Response:
							const filename = `contacts.${data.body.type === 'application/pdf' ? 'pdf' : 'xlsx'}`;
							const downloadedFile = new Blob([data.body], {
								type: data.body.type,
							});
							if (navigator.msSaveBlob) {
								navigator.msSaveBlob(downloadedFile, filename);
							} else {
								const a = document.createElement('a');
								a.setAttribute('style', 'display:none;');
								document.body.appendChild(a);
								a.download = filename;
								a.href = URL.createObjectURL(downloadedFile);
								a.target = '_blank';
								a.click();
								document.body.removeChild(a);
							}
							this.downloadInProgress = false;
							break;
					}
				},
				(err) => {
					// console.log('File Report Error:', err);
					this.downloadInProgress = false;
					this.downloadError = 'An Error Occurred while processing your request';
				}
			);
		}
	}

	readQueryParams(params: Partial<ReportFilters> = {}): ContactSearchPayload {
		const filters: ContactSearchPayload = Object.keys(params || {})
			.filter((key: keyof ContactSearchPayload) => this.filterProperties.includes(key))
			.reduce(
				(searchFilters: ContactSearchPayload, key: keyof ContactSearchPayload) => {
					//@ts-ignore
					searchFilters[key] = params[key];
					return searchFilters;
				},
				{} as ContactSearchPayload
			);

		return filters;
	}

	saveContactsReport(details: Partial<IReportPayload>, type: PersistenceType = 'Temporary') {
		const filters = this.searchPayload;
		this.contactsActivitiesService.saveContactSearch(this.user.UserID, filters, details, type).subscribe((data) => {
			this.savedReport = type === 'Permanent' ? data : this.savedReport;
		});
	}

	pageChanged(pageNumber: number) {
		this.state.loading = true;
		this.state.initial = false;
		this.state.empty = false;
		this.state.error = null;
		this.pagination.current = pageNumber;
		this.contactDetails = {
			ContactSearchInfoModels: [],
			PaginationModel: {
				TotalCount: this.pagination.total,
				PageNumber: pageNumber,
				PageSize: 10,
			},
		};
		const payload = { ...this.paging, ...this.searchPayload };
		this.contactSearchService.contactDetails(payload).subscribe(
			(results: ContactDetailsResponse) => {
				const { PageSize, TotalCount } = results.PaginationModel;

				this.pagination = {
					...this.pagination,
					total: Math.ceil(TotalCount / PageSize),
				};

				this.contactDetails = results;
				this.state.loading = false;
				this.state.initial = false;
				this.state.empty = !this.contactDetails.ContactSearchInfoModels.length;
				this.state.pagination = TotalCount > PageSize;
			},
			(err) => {
				this.state.loading = false;
				this.state.initial = false;
				this.state.empty = err.status === 404;
				this.state.error = err;
			}
		);
	}

	handleClearAllMoreFilters() {
		this.moreFiltersContacts = {};
		this.searchPayload = {
			...this.searchPayload,
			Cornerstone: [],
			ProductSpecialization: [],
			IndustrySpecialization: [],
		};
	}

	onApplyFiltersClick(filters) {
		debugger;
		this.isMorefilter = true;
		this.moreFiltersContacts = filters;
		this.searchPayload = {
			...this.searchPayload,
			Cornerstone: this.moreFiltersContacts.Cornerstone,
			ProductSpecialization: this.moreFiltersContacts.ProductSpecialization,
			IndustrySpecialization: this.moreFiltersContacts.IndustrySpecialization,
		};
		this.handleApplyFilters();
	}

	get regionFilterCount() {
		return [...this.selectedRegions, ...this.selectedBranches].filter(Boolean).length;
	}

	topLevelLabel(name: string, count: number) {
		return !!count ? `${name} (${count})` : name;
	}

	handleRegionsChange() {
		if (this.selectedRegions.length == 0) {
			this.selectedBranches = [];
		}
		this.getBranches();
		this.raiseFilterUpdate();
	}

	handleBranchChange() {
		this.cdRef.detectChanges();
		this.raiseFilterUpdate();
	}

	private raiseFilterUpdate(): void {
		this.searchPayload = {
			...this.searchPayload,
			ProducerRegion: this.selectedRegions,
			ProducerBranch: this.selectedBranches,
		};
	}

	getBranches() {
		this.reportingService.getCreditedRegionBranchesFilters().subscribe((data: RegionBranchesResponse[]) => {
			let branchFiltersList;
			if (this.selectedRegions.length === 0 || (this.selectedRegions.length === 1 && this.selectedRegions[0] === '')) {
				branchFiltersList = data;
			} else {
				branchFiltersList = data.filter((filters) => this.selectedRegions.includes(filters.Region));
			}
			this.branchFilters = branchFiltersList.map((branches: { Branch: string }) => {
				return {
					text: branches.Branch,
					value: branches.Branch,
				};
			});

			this.selectedBranches = this.selectedBranches.filter((selected) => this.branchFilters.findIndex((d) => d.value === selected) > -1);
			this.detectChanges();
		});
	}

	private detectChanges() {
		if (!this.cdRef['destroyed']) {
			this.cdRef.detectChanges();
		}
	}
}
