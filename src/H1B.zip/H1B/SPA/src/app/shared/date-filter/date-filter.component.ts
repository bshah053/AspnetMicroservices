import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {
  TimeFrameType,
  MonthName,
} from '../../tracking-reporting/reports/reports-header/store/reports-header.model';
import { DATE_LIST } from './data-filter.constants';

export interface DateFilterItem {
  title: string;
  value: TimeFrameType;
}
export interface DateFilterSelection {
  month: MonthName;
  year: number;
  frame: TimeFrameType;
  isPickDate?: boolean;
}

@Component({
  selector: 'cb-date-filter',
  templateUrl: './date-filter.component.html',
  styleUrls: ['./date-filter.component.scss'],
})
export class DateFilterComponent implements OnInit {
  @Input() name: string = 'Dropdown Menu';
  @Input() open: boolean = false;
  @Input() readonly: boolean = false;
  @Input() datelist: DateFilterItem[] = DATE_LIST;
  @Input() preselected: number;
  @Input() showCurrentDate = true;
  @Input() width: number = 170;
  @Input() confidenceFactor = 'MTD';

  @Output() selected = new EventEmitter();

  isDatePick: boolean = false;
  currentDate: string = '';
  selectedValues = {
    startDate: '',
    endDate: '',
  };

  @Input() month: MonthName;
  @Input() year: number;

  value: string;
  headSelected;

  monthNames: MonthName[] = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
  ];

  constructor() {
    this.month = this.monthNames[new Date().getMonth()];
    this.year = new Date().getFullYear();
  }

  ngOnInit() {}

  get isOpened(): boolean {
    return this.open;
  }

  get isReadonly(): boolean {
    return this.readonly;
  }

  handleToggleOpen(): void {
    this.open = !this.open;
  }

  handleHide(): void {
    if (!this.isDatePick) this.open = false;
  }

  handleSelection(item: DateFilterItem): void {
    this.value = item.title;
    this.selected.emit(this.makeDateFilterSelection(item));
    this.open = false;
  }

  makeDateFilterSelection(
    item: DateFilterItem,
    isPickDate?: boolean
  ): DateFilterSelection {
    return {
      month: this.month,
      year: this.year,
      frame: item.value,
      isPickDate: isPickDate,
    };
  }

  getCurrent(): string {
    if (!this.value) {
      return this.datelist[this.preselected]
        ? this.datelist[this.preselected].title
        : name;
    }

    return this.value;
  }

  dateFieldChange(field: string, e: Event) {
    const target = e.target as HTMLInputElement;
    const seconds = Date.parse(target.value);
    if (seconds) {
      const date = new Date(seconds);
      const utcDate = new Date(
        date.getUTCFullYear(),
        date.getUTCMonth(),
        date.getUTCDate(),
        -date.getTimezoneOffset() / 60,
        0,
        0
      );
      this.selectedValues[field] = utcDate.toISOString();
    } else {
      target.value = '';
      delete this.selectedValues[field];
    }

    if (this.selectedValues.startDate && this.selectedValues.endDate) {
      this.selected.emit({
        isPickDate: true,
        startDate: this.selectedValues.startDate,
        endDate: this.selectedValues.endDate,
      });
      this.open = false;
    }
  }

  formatDateForInput(dateStr?: string) {
    if (!dateStr) {
      return '';
    }
    const seconds = Date.parse(dateStr);
    if (!seconds) {
      return '';
    }
    const date = new Date(seconds);
    const formated = `${addZero(date.getUTCMonth() + 1)}/${addZero(
      date.getUTCDate()
    )}/${date.getUTCFullYear()}`;
    return formated;

    function addZero(number: number) {
      if (number < 10) {
        return `0${number}`;
      }
      return `${number}`;
    }
  }

  showDates() {
    this.isDatePick = !this.isDatePick;
    this.open = true;
  }
}
