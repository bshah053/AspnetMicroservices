const mockResponse = require('../mocks/data.json');
const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const cors = require('cors');
const port = 3000;
const filterRoutes = require('./filters');
const reportRoutes = require('./reports');
const dynamicsRoutes = require('./dynamics');
const insuredRoutes = require('./insured');

app.use(cors());
app.use(bodyParser.json());

app.use('/filters', filterRoutes());
app.use('/reports', reportRoutes());
app.use('/dynamics', dynamicsRoutes());
app.use('/insured', insuredRoutes());

//UW dashboard
app.get('/users/M4ECKL/profile', (req, res) =>
  res.json(mockResponse.underwriter)
);
app.get('/users/B043236/profile', (req, res) =>
  res.json(mockResponse.regionalManager)
);
app.get('/users/B005301/profile', (req, res) =>
  res.json(mockResponse.branchManager)
);
app.get('/users/M4MUL2/profile', (req, res) =>
  res.json(mockResponse.underwriterManager)
);
app.post('/pipelines/forecast', (req, res) => res.json(mockResponse.forecast));
app.post('/pipelines/nbrenewals/overviewbyaccountingmonth', (req, res) =>
  res.json(mockResponse.overviewbyaccountingmonth)
);
app.post('/users/goals/newbusiness', (req, res) =>
  res.json(mockResponse.newBusinessGoals)
);
app.post('/users/goals/travel', (req, res) =>
  res.json(mockResponse.travelGoals)
);
app.post('/pipelines/nbforecastvsplan', (req, res) =>
  res.json(mockResponse.nbForecastVsPlanData)
);
app.post('/pipelines/uwmanager/nbforecastvsplan', (req, res) =>
  res.json(mockResponse.nbForecastVsPlanData)
);
app.post('/pipelines/newbusiness/statusbyaccountingmonth', (req, res) =>
  res.json(mockResponse.newBusiness)
);
app.post('/pipelines/newbusinessbyaccountingmonth', (req, res) =>
  res.json(mockResponse.newBusinessTable)
);
app.post('/pipelines/renewals/statusbyaccountingmonth', (req, res) =>
  res.json(mockResponse.renewalInfo)
);
app.post('/pipelines/renewalsbytermdate', (req, res) =>
  res.json(mockResponse.renewalsTable)
);
app.post('/pipelines/opentargets', (req, res) =>
  res.json(mockResponse.openTargetsTable)
);
app.post('/pipelines/NewBusiness/Ratio', (req, res) =>
  res.json(mockResponse.newbusinessGraphsData)
);
app.post('/pipelines/uwmanagernewbusiness/ratio', (req, res) =>
  res.json(mockResponse.newbusinessGraphsData)
);
app.post('/pipelines/forecastvsplanoverview', (req, res) =>
  res.json(mockResponse.forecastVsPlanData)
);
app.post('/pipelines/uwmanager/forecastvsplanoverview', (req, res) =>
  res.json(mockResponse.uwManagerForecastVsPlanData)
);
app.post('/pipelines/renewals/toplan', (req, res) =>
  res.json(mockResponse.renewalToPlanData)
);

// Regional Manager Dasboard
app.post('/pipelines/regionalmanager/renewalsbyaccountingmonth', (req, res) =>
  res.json(mockResponse.regionalManagerRenewalByMonth)
);
app.post('/pipelines/uwmanager/renewalsbyaccountingmonth', (req, res) =>
  res.json(mockResponse.renewalInfo)
);
app.post('/pipelines/renewalsbyaccountingmonth', (req, res) =>
  res.json(mockResponse.renewalInfo)
);
app.post('/pipelines/renewalratios', (req, res) =>
  res.json(mockResponse.renewalRatios)
);
app.post('/pipelines/topproducertargetsbyaccountingmonth', (req, res) =>
  res.json(mockResponse.topproducertargetsbyaccountingmonth)
);
app.post('/pipelines/topcustomertargetsbyaccountingmonth', (req, res) =>
  res.json(mockResponse.topcustomertargetsbyaccountingmonth)
);

app.post('/pipelines/uwmanager/goals', (req, res) =>
  res.json(mockResponse.uwmanagergoals)
);

app.listen(port, () =>
  console.log(`Mock server is listening on port ${port}!`)
);
