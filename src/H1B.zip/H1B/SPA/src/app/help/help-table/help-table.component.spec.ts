import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { HelpTableComponent } from './help-table.component';

describe('HelpTableComponent', () => {
	let component: HelpTableComponent;
	let fixture: ComponentFixture<HelpTableComponent>;

	beforeEach(
		waitForAsync(() => {
			TestBed.configureTestingModule({
				declarations: [HelpTableComponent],
			}).compileComponents();
		})
	);

	beforeEach(() => {
		fixture = TestBed.createComponent(HelpTableComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
