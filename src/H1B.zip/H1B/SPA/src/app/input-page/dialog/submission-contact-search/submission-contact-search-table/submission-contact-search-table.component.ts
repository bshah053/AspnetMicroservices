import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ContactDetails } from 'contacts-activities/search/contacts-search/contact-search.service';
import Utilities from 'shared/utilities';

@Component({
	selector: 'cb-submission-contact-search-table',
	templateUrl: './submission-contact-search-table.component.html',
	styleUrls: ['./submission-contact-search-table.component.scss'],
})
export class SubmissionContactSearchTableComponent implements OnInit {
	@Input() contactDetails: ContactDetails[];
	@Output() contachSearchSelectedDetails: EventEmitter<any> = new EventEmitter();

	columns = [
		{
			headerName: 'FullName',
			field: 'FullName',
			tooltipValueGetter: (params) => params.value,
			width: 208,
			cellClass: 'multiline',
			suppressSizeToFit: true,
			cellRenderer: Utilities.restrictCellTextRenderer(),
		},
		{
			headerName: 'Account Name',
			headerTooltip: 'Account Name',
			field: 'AccountName',
			tooltipValueGetter: (params) => params.value,
			width: 310,
			cellClass: 'multiline',
			suppressSizeToFit: true,
			cellRenderer: Utilities.restrictCellTextRenderer(),
		},
		{
			headerName: 'Role',
			field: 'Type',
			headerTooltip: 'Role',
			tooltipValueGetter: (params) => params.value,
			width: 160,
			suppressSizeToFit: true,
			sortable: true,
		},
		{
			headerName: 'Phone',
			headerTooltip: 'Phone',
			field: 'BusinessNumber',
			tooltipValueGetter: (params) => params.value,
			width: 151,
			cellClass: 'multiline',
			suppressSizeToFit: true,
			cellRenderer: Utilities.restrictCellTextRenderer(),
		},
		{
			headerName: 'Email',
			field: 'Email',
			width: 300,
			suppressSizeToFit: true,
		},
		{
			headerName: 'Address',
			field: 'FullAddress',
			tooltipValueGetter: (params) => params.value,
			width: 200,
			suppressSizeToFit: false,
			cellClass: 'address-cell',
		},
		{
			headerName: 'Region',
			field: 'Region',
			tooltipValueGetter: (params) => params.value,
			width: 150,
			suppressSizeToFit: true,
		},
		{
			headerName: 'Branch',
			field: 'Branch',
			tooltipValueGetter: (params) => params.value,
			width: 150,
			suppressSizeToFit: true,
		},
		{
			headerName: 'Chubb Business Unit',
			field: 'ChubbMarketSegment',
			tooltipValueGetter: (params) => params.value,
			width: 150,
			suppressSizeToFit: true,
		},
		{
			headerName: 'Product Specialization',
			field: 'ProductSpecialization',
			tooltipValueGetter: (params) => params.value,
			width: 150,
			suppressSizeToFit: true,
		},
		{
			headerName: 'Industry Specialization',
			field: 'IndustrySpecialization',
			tooltipValueGetter: (params) => params.value,
			width: 150,
			suppressSizeToFit: true,
		},
		{
			headerName: 'Cornerstone',
			field: 'Cornerstone',
			tooltipValueGetter: (params) => params.value,
			width: 150,
			suppressSizeToFit: true,
		},
	];

	constructor() {}

	ngOnInit(): void {
		console.log(this.contactDetails);
	}

	handleSelectedRow(rows) {
		if (rows) {
			this.contachSearchSelectedDetails.next(rows);
		}
	}
}
