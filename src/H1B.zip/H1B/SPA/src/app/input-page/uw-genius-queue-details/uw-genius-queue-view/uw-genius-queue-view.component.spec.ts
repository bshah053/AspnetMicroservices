import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UwGeniusQueueViewComponent } from './uw-genius-queue-view.component';

describe('UwGeniusQueueViewComponent', () => {
  let component: UwGeniusQueueViewComponent;
  let fixture: ComponentFixture<UwGeniusQueueViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [UwGeniusQueueViewComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UwGeniusQueueViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
