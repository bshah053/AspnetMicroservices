import { Directive, ElementRef, HostListener, Input } from '@angular/core';
import { NgControl } from '@angular/forms';

@Directive({
  selector: 'input[allowNumbersOnly]',
})
export class NumbersOnlyDirective {
  @Input() isNumbersOnly = 'Y';
  constructor(private _el: ElementRef) {}

  @HostListener('keyup', ['$event'])
  onkeyup(event) {
    if (
      !(
        (event.keyCode >= 48 && event.keyCode <= 57) ||
        (event.keyCode >= 96 && event.keyCode <= 105) ||
        event.keyCode === 8 ||
        event.keyCode === 9 ||
        event.keyCode === 37 ||
        event.keyCode === 39 ||
        event.keyCode === 46
      ) &&
      this.isNumbersOnly === 'Y'
    ) {
      event.preventDefault();
    }
  }

  @HostListener('keydown', ['$event'])
  onkeydown(event) {
    if (
      !(
        (event.keyCode >= 48 && event.keyCode <= 57) ||
        (event.keyCode >= 96 && event.keyCode <= 105) ||
        event.keyCode === 8 ||
        event.keyCode === 9 ||
        event.keyCode === 37 ||
        event.keyCode === 39 ||
        event.keyCode === 46
      ) &&
      this.isNumbersOnly === 'Y'
    ) {
      event.preventDefault();
    }
  }
}
