import { Component, Input, OnInit } from '@angular/core';
import { Select, Store } from '@ngxs/store';
import { CellClickedEvent, ColDef, ICellRendererParams } from 'ag-grid-community';
import { combineLatest, Observable } from 'rxjs';
import { AccountingYearMonth, AccountingYearMonthState } from 'store/accounting-month-year.store';
import { NavigationService } from '../../../services/navigation.service';
import { MonthName, ReportsHeaderModel } from '../../../tracking-reporting/reports/reports-header/store/reports-header.model';
import { ReportsHeaderState } from '../../../tracking-reporting/reports/reports-header/store/reports-header.store';
import { User } from '../../../user/user.model';
import { DashboardService } from '../../dashboard.service';

@Component({
  selector: 'cb-my-accounts',
  templateUrl: './my-accounts.component.html',
  styleUrls: ['./my-accounts.component.scss'],
})
export class MyAccountsComponent implements OnInit {
  @Input() user: User;

  defaultColDef: any = { sortable: true, resizable: true, unSortIcon: true };
  gceMyAccounts: any;

  myAccountsColumns: ColDef[] = [
    {
      headerName: 'Account',
      headerTooltip: 'Account',
      field: 'Account',
      width: 350,
      suppressMovable: true,
      suppressSizeToFit: true,
      tooltipField: 'Account',
      cellClass: 'cell-wrap-text',
      cellRenderer: (cell: ICellRendererParams) => {
        if (cell.data.ClientID) {
          return `<a href="javascript:void(0);" rel="noopener">${cell.value}</a>`;
        } else {
          return cell.value;
        }
      },
      autoHeight: true,
    },
    {
      headerName: 'In-Force Forecast',
      headerTooltip: 'In-Force Forecast',
      field: 'CurrentInforceRelationship',
      valueFormatter: currencyFormatter,
      tooltipValueGetter: (params) => params.valueFormatted,
      width: 200,
      cellClass: 'numeric currency',
      suppressMovable: true,
      suppressSizeToFit: true,
    },
    {
      headerName: 'Line Count',
      headerTooltip: 'Bound Line Count',
      field: 'BoundLineCount',
      width: 200,
      headerClass: 'multiline',
      cellClass: 'numeric',
      suppressMovable: true,
      suppressSizeToFit: true,
      tooltipField: 'BoundLineCount',
    },
    {
      headerName: 'Policy Count',
      headerTooltip: 'Policy Count',
      field: 'PolicyCount',
      width: 200,
      headerClass: 'multiline',
      cellClass: 'numeric',
      suppressMovable: true,
      suppressSizeToFit: true,
      tooltipField: 'PolicyCount',
    },
    {
      headerName: 'Target Forecast',
      headerTooltip: 'Target Forecast',
      field: 'Forecast',
      valueFormatter: currencyFormatter,
      tooltipValueGetter: (params) => params.valueFormatted,
      width: 200,
      cellClass: 'numeric currency',
      suppressMovable: true,
      suppressSizeToFit: true,
    },
  ];

  myAccountsLoading = false;

  @Select(ReportsHeaderState) public reportFilters$: Observable<ReportsHeaderModel>;
  currentFilters: ReportsHeaderModel;

  @Select(AccountingYearMonthState) public accountingYearMonth$: Observable<AccountingYearMonth>;
  accountingYearMonth: AccountingYearMonth;

  constructor(private dashboardService: DashboardService, private navigate: NavigationService) {}

  ngOnInit() {
    combineLatest([this.reportFilters$, this.accountingYearMonth$]).subscribe(([filters, accountingYearMonth]) => {
      this.currentFilters = filters;
      this.accountingYearMonth = accountingYearMonth;
      const payload = {
        TimeFrame: 'YTD',
        UserID: this.user.UserID,
        AccountingMonth: accountingYearMonth.AccountingMonth as MonthName,
        AccountingYear: accountingYearMonth.AccountingYear,
      };
      this.dashboardService.getGCEMyAccounts(payload);
      this.fetchMyAccounts();
    });
  }

  handleMyAccountsCellClick(e) {
    if (e.data.ClientID) {
      this.navigate.toCustomer(e.data.ClientID, '', {
        extraFilters: this.currentFilters,
        showBrowseBy: true,
      });
    }
  }

  fetchMyAccounts() {
    this.myAccountsLoading = true;
    this.dashboardService.gceMyAccounts.subscribe(
      (data) => {
        if (data !== null) {
          this.gceMyAccounts = data;
        } else {
          this.gceMyAccounts = undefined;
        }
        this.myAccountsLoading = false;
      },
      (err) => {
        this.gceMyAccounts = undefined;
        this.myAccountsLoading = false;
      }
    );
  }
}

function currencyFormatter(params) {
  return '$' + formatNumber(params.value);
}

function formatNumber(number) {
  return Math.floor(number)
    .toString()
    .replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
}
