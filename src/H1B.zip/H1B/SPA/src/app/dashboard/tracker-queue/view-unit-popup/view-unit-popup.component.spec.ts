import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { ViewUnitPopupComponent } from './view-unit-popup.component';

describe('ViewUnitPopupComponent', () => {
	let component: ViewUnitPopupComponent;
	let fixture: ComponentFixture<ViewUnitPopupComponent>;

	beforeEach(
		waitForAsync(() => {
			TestBed.configureTestingModule({
				declarations: [ViewUnitPopupComponent],
			}).compileComponents();
		})
	);

	beforeEach(() => {
		fixture = TestBed.createComponent(ViewUnitPopupComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
