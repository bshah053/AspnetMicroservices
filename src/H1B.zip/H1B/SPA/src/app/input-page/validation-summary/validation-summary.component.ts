import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { FormGroup } from '@angular/forms';

import { DataElementsDetails } from 'input-page/models/load/data-elements-control-details-item';

@Component({
  selector: 'cb-validation-summary',
  templateUrl: './validation-summary.component.html',
  styleUrls: ['./validation-summary.component.scss'],
})
export class ValidationSummaryComponent implements OnInit, OnChanges {
  @Input() form: FormGroup;
  @Input() data: DataElementsDetails[] = [];
  errors: string[] = [];

  constructor() {}

  ngOnInit(): void {
    console.log('ngOnInit');
    this.resetErrorMessages();
    this.generateErrorMessages(this.form);
  }

  ngOnChanges(changes: SimpleChanges): void {
    console.log('ngOnChanges', changes);
    // if (this.form instanceof FormGroup === false) {
    //   throw new Error('You must supply the validation summary with an NgForm.');
    // }
    this.form.statusChanges.subscribe((status) => {
      this.resetErrorMessages();
      this.generateErrorMessages(this.form);
    });
  }

  resetErrorMessages() {
    this.errors.length = 0;
  }

  generateErrorMessages(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach((controlName) => {
      let control = formGroup.controls[controlName];
      let errors = control.errors;
      if (errors === null || errors.count === 0) {
        return;
      }
      const ctrl = this.data.filter((element) => {
        return element.ControlName === controlName;
      });

      if (ctrl && ctrl.length > 0) {
        const ctrlElements: DataElementsDetails = ctrl[0];

        if (errors.required) {
          this.errors.push(`${ctrlElements.DataLabel} is required`);
        }

        if (errors.email) {
          this.errors.push(`${ctrlElements.DataLabel}  must be a valid email address.`);
        }

        if (errors.minlength) {
          this.errors.push(`${ctrlElements.DataLabel} minimum length is ${errors.minlength.requiredLength}.`);
        }

        if (errors.maxlength) {
          this.errors.push(`${ctrlElements.DataLabel} maximum allowed characters is limited to ${errors.maxlength.requiredLength}.`);
        }

        if (errors.min) {
          this.errors.push(`${ctrlElements.DataLabel} min value is ${errors.min.min}.`);
        }

        if (errors.max) {
          this.errors.push(`${ctrlElements.DataLabel} maximum permissible value is ${errors.max.max}.`);
        }

        if (errors.isInValid) {
          this.errors.push(`${ctrlElements.DataLabel} ${errors.customMessage}`);
        }

        if (errors.pattern) {
          this.errors.push(`${ctrlElements.DataLabel} must be a valid value`);
        }

        if (errors.message) {
          this.errors.push(`${ctrlElements.DataLabel} ${errors.message}`);
        }
      } else {
        return;
      }
    });
  }
}
