import { Directive, HostListener, ElementRef } from '@angular/core';

@Directive({
  selector: '[focusInvalidControl]',
})
export class FocusInvalidControlDirective {
  constructor(private el: ElementRef) {}

  @HostListener('submit')
  onFormSubmit() {
    const invalidControl = this.el.nativeElement.querySelector('.is-invalid');

    if (invalidControl) {
      invalidControl.focus();
    }
  }
}
