import { Injectable } from '@angular/core';
import { ValidatorFn, AbstractControl } from '@angular/forms';
import { FormGroup } from '@angular/forms';

@Injectable({
  providedIn: 'root',
})
export class CustomvalidationService {
  constructor() {}

  setReadOnly(formControl: AbstractControl, isReadonly: boolean) {
    (<any>formControl).nativeElement.readOnly = isReadonly;
  }

  patternValidator(controlName): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } => {
      // console.log('Test-controlName');
      // console.log(controlName);
      if (!control.value) {
        return null;
      }
      const valid = false;
      return valid ? null : { isValid: true };
    };
  }

  rangeValidator(control: AbstractControl): { [key: string]: boolean } | null {
    if (
      control.value !== null &&
      (isNaN(control.value) || control.value < 20 || control.value > 70)
    ) {
      return { isValid: true };
    }
    return null;
  }
}
