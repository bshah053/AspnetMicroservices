export interface USDForecastConvertor {
  UserID?: string;
  Currency?: string;
  Forecast?: number;
  AccountingYear?: string;
  AccountingMonth?: string;
  IsNetforecastYN?: string;
  Unit?: string;
  Segment?: string;
  PortFolioClass?: string;
}
