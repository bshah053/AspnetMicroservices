export interface ISaveReportAs {
  reportName: string;
  reportNotes: string;
  filterId: string;
}
