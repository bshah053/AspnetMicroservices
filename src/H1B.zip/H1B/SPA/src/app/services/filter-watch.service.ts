import { ReportFilters } from './../tracking-reporting/reports/reports-header/reports-header.component';
import { HistoryService } from './history.service';
import { LocalStorageService } from './local-storage.service';
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { ReportsHeaderModel } from '../tracking-reporting/reports/reports-header/store/reports-header.model';

@Injectable({
  providedIn: 'root',
})
export class FilterWatchService {
  private storageKey = 'filters';
  private current: string; // current filter hash
  private _change: Subject<ReportFilters> = new Subject(); // event for filter changes

  constructor(private history: HistoryService, private localStorage: LocalStorageService) {
    if (!this.store()) {
      this.resetStore();
    }

    // this.history
    //   .locationChange()
    //   .subscribe((url: string) => this.locationChangeHandler(url));
  }

  change(): Subject<ReportFilters> {
    return this._change;
  }

  getByHash(hash: string): ReportFilters | undefined {
    const store = this.store();
    return store ? store[hash] : undefined;
  }

  create(filters: ReportFilters): string {
    const hash = this.makeHash();

    this.persistData(hash, filters);

    return hash;
  }

  setCurrentHash(hash: string = this.makeHash()): void {
    this.current = hash;
  }

  getCurrentHash(): string {
    return this.current;
  }

  clearCurrentHash(): void {
    this.current = undefined;
  }

  locationChangeHandler(url: string): void {
    const hash = this.getHashFromUrl(url);

    if (!hash) {
      this.clearCurrentHash();
    } else {
      this.setCurrentHash(hash);
    }
    const filtersState = this.getByHash(hash);
    this._change.next(filtersState);
  }

  serializeFromPayload(
    payload: ReportsHeaderModel,
    ui = {
      browseByProducer: payload.BrowseByProducer ? payload.BrowseByProducer : 'CHUBB Regions',
      browseByValue: payload.BrowseByProducer ? 'none' : undefined,
    }
  ): ReportFilters {
    return {
      AccountMonth: payload.AccountMonth,
      AccountYear: payload.AccountYear,
      TimeFrame: payload.TimeFrame as string,
      CreditedRegion: payload.CreditedRegion,
      CreditedBranch: payload.CreditedBranch,
      CompanyName: payload.CompanyName,
      Division: payload.Division,
      Unit: payload.Unit,
      Segment: payload.Segment,
      Subsegment: payload.Subsegment,
      MCCCode: payload.MCCCode,
      UnderwriterName: payload.UnderwriterName,
      // UWBranch: payload.UWBranch
      //UnderwriterAssistantName: payload.UWAssistant,
      ProducerName: payload.ProducerName,
      ProducerBranch: payload.ProducerBranch,
      ProducerRegion: payload.ProducerRegion,
      ProducerBranchName: payload.ProducerBranchName,
      PASCode: payload.PASCode,

      TransactionType: payload.TransactionType,
      Status: payload.Status,
      Product: payload.Product,
      Program: payload.Program,

      AccountType: payload.AccountType,
      ClientID: payload.ClientID,
      ClientName: payload.ClientName,
      TimeFrameReadonly: payload.TimeFrameReadonly,
      browseByProducer: ui.browseByProducer,
      browseByValue: ui.browseByValue,
      isDashBoard: payload.isDashBoard,
      DateFilterFlag: payload.DateFilterFlag,
      EffectiveDateEnd: payload.EffectiveDateEnd,
      EffectiveDateStart: payload.EffectiveDateStart,
      BulkUpdateReportName: payload.BulkUpdateReportName,
      Range: payload.Range,
      Forecast: payload.Forecast,
      ConfidenceFactor: payload.ConfidenceFactor,
      UserID: payload.UserID,
      isProfileSummaryDashboard: payload.isProfileSummaryDashboard,
      RecordNo: payload.RecordNo,
      GeniusPipeID: payload.GeniusPipeID,
      IsGenius: payload.IsGenius,
      DYN: payload.DYN,
      IYN: payload.IYN,
      LYNE: payload.LYNE,
      ForecastStartDate: payload.ForecastStartDate,
      ForecastEndDate: payload.ForecastEndDate,
      ExchangeCurrency: payload.ExchangeCurrency,
      ForecastDivision: payload.ForecastDivision,
      ControlNumber: payload.ControlNumber,
      PolicyType: payload.PolicyType,
      TargetConfidence: payload.TargetConfidence,
      Confidence: payload.Confidence,
    };
  }

  private getHashFromUrl(url: string): string {
    const [host, queryString] = url.split('?');

    return this.getQueryParam(queryString).filters;
  }

  private resetStore(storage = {}): void {
    this.localStorage.set(this.storageKey, storage);
  }

  private getQueryParam(q: string): { filters?: string } {
    return decodeURI(q)
      .replace('?', '')
      .split('&')
      .map((param) => param.split('='))
      .reduce((values, [key, value]) => {
        values[key] = value;
        return values;
      }, {});
  }

  private persistData(hash: string, filters: ReportFilters): void {
    if (!hash) {
      return;
    }

    try {
      const store = this.store();
      store[hash] = filters;
      this.localStorage.set('filters', store);
    } catch (exception) {
      this.deleteOldestHashFromStore();
      this.persistData(hash, filters);
    }
  }

  private deleteOldestHashFromStore() {
    const store = this.store();

    if (store) {
      delete store[this.getOldestHash()];
      this.resetStore(store);
    } else {
      this.resetStore();
    }
  }

  private getOldestHash(): string {
    const byOldest = this.getHashCollection().sort((a, b) => parseInt(a, 10) - parseInt(b, 10));

    return byOldest.length ? byOldest[0] : undefined;
  }

  private getHashCollection(): string[] {
    return Object.keys(this.store());
  }

  private store() {
    return this.localStorage.get('filters');
  }

  private pushToHistory(hash: string): void {
    if (hash) {
      this.history.populateHashToUrl(hash);
    }
  }

  private makeHash(): string {
    return new Date().getTime() + '';
  }
}
