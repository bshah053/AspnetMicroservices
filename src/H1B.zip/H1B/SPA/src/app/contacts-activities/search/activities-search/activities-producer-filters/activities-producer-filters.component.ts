import { Component, OnInit, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { combineLatest } from 'rxjs';
import { ReportingService } from '../../../../tracking-reporting/services/reporting.service';

export interface ProducerChangeEvent {
  national: string[];
  region: string[];
  branch: string[];
  pasCodes: string[];
}

@Component({
  selector: 'cb-activities-producer-filters',
  templateUrl: './activities-producer-filters.component.html',
  styleUrls: ['./activities-producer-filters.component.scss'],
})
export class ActivitiesProducerFiltersComponent implements OnInit, OnChanges {
  @Output() selectionChange = new EventEmitter<ProducerChangeEvent>();
  @Input() selectedNational: string[] = [];
  @Input() selectedRegion: string[] = [];
  @Input() selectedBranch: string[] = [];
  @Input() selectedPASCodes: string[] = [];

  name = 'Producer';
  filters = {
    National: {
      name: 'National',
      api: 'getProducerNationalFilters',
      items: [],
    },
    Region: {
      name: 'Region',
      api: 'getProducerRegionFilters',
      items: [],
    },
    Branch: {
      name: 'Branch',
      api: 'getProducerBranchFilters',
      items: [],
    },
    PAScodes: {
      name: 'PAS codes',
      api: 'getProducerCodes',
      items: [],
    },
  };

  constructor(private reportingService: ReportingService) {
    this.fetchTopProducerFilters();
  }

  ngOnInit() {}

  ngOnChanges(changes: SimpleChanges): void {
    this.fetchTopProducerFilters();
  }

  get countSelected() {
    return [...this.selectedNational, ...this.selectedRegion, ...this.selectedBranch, ...this.selectedPASCodes].length;
  }

  get selected() {
    return !!this.countSelected;
  }

  get label() {
    const selectedCount = this.countSelected;
    if (selectedCount) {
      return `${this.name} (${selectedCount})`;
    }

    return this.name;
  }

  fetchTopProducerFilters() {
    combineLatest([
      this.reportingService[this.filters.National.api](this.selectedRegion, this.selectedBranch, this.selectedPASCodes),
      this.reportingService[this.filters.Region.api](this.selectedNational, this.selectedPASCodes),
      this.reportingService[this.filters.Branch.api](this.selectedNational, this.selectedRegion),
      this.reportingService[this.filters.PAScodes.api](this.selectedNational, this.selectedRegion, this.selectedBranch),
    ]).subscribe(([national, region, branch, codes]: any) => {
      this.filters.National.items = national;
      this.filters.Region.items = region;
      this.filters.Branch.items = branch;
      this.filters.PAScodes.items = codes;
    });
  }

  handleNationalChange(values: string[]) {
    this.selectionChange.next(this.generateChangeEvent(values));
  }

  handleRegionChange(values: string[]) {
    this.selectionChange.next(this.generateChangeEvent(this.selectedNational, values));
  }

  handleBranchChange(values: string[]) {
    this.selectionChange.next(this.generateChangeEvent(this.selectedNational, this.selectedRegion, values));
  }

  handlePASCodeChange(values: string[]) {
    this.selectionChange.next(this.generateChangeEvent(this.selectedNational, this.selectedRegion, this.selectedBranch, values));
  }

  generateChangeEvent(national: string[] = [], region: string[] = [], branch: string[] = [], pasCodes: string[] = []): ProducerChangeEvent {
    return {
      national,
      region,
      branch,
      pasCodes,
    };
  }
}
