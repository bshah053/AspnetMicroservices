import { Directive, Input, TemplateRef } from '@angular/core';

@Directive({
  selector: '[cbCtrlTemplate]',
})
export class CtrlTemplateDirective {
  @Input('cbCtrlTemplate') templateName: string;

  constructor(public template: TemplateRef<any>) {}
}
