import { Component, HostListener, Inject, OnInit } from '@angular/core';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import {
  Validators,
  FormGroup,
  FormControl,
  ValidatorFn,
} from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Select } from '@ngxs/store';
import { combineLatest, Observable } from 'rxjs';

import { User } from 'user/user.model';
import { UserState } from 'user/user.store';
import { InputPageService } from 'input-page/services/input-page.service';
import {
  LayerDetailsDataElements,
  LayerDetailsItem,
} from './model/layer-details-item';
import { Helper } from 'utilities/common-helper';
import {
  CanadaLDControlsDetail,
  CanadaLDValueChangedControls,
} from 'utilities/common-enum-const';

@Component({
  selector: 'layer-details',
  templateUrl: './layer-details.component.html',
  styleUrls: ['./layer-details.component.scss'],
})
export class LayerDetailsComponent implements OnInit {
  constructor(
    @Inject(InputPageService) private inputPageService: InputPageService,
    public dialogRef: MatDialogRef<LayerDetailsComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    combineLatest([this.user$]).subscribe(([user]) => {
      this.user = user;
    });
  }

  @HostListener('window:keyup.esc')
  onKeyUp() {
    this.dialogRef.close();
  }

  @Select(UserState) public user$: Observable<User>;
  user: User;
  layerDetails: LayerDetailsItem;
  recordNumber = 0;
  submitted = false;
  layerDetailsFormGroup: FormGroup;
  LayerNumber: number[] = [1, 2, 3, 4, 5, 6, 7];
  validationErrorSummary = '';
  layerLabelControls: string[] = [];

  ngOnInit(): void {
    if (this.data) {
      this.getLayerDetails();
      this.recordNumber = this.data.RecordNumber;
    }
    this.layerLabelControls = [
      'Layer Number',
      'ACE Share Percentage',
      'Total Layer Premium',
      'Total Layer Limit',
      'Total Layer Attachment',
      'Total Layer Benchmark Premium',
      'Total Layer AdjustedExpiring Premium',
      'Total Layer TIV',
      'Expiring TIV',
      'Current Rate',
      'Expiring Rate',
      'ACE Share Expiring Premium',
      'ACE Participation',
      'ACE Layer Premium',
      'ACE Layer Benchmark Premium',
      'ACE Layer Adjusted Expiring Premium',
    ];
  }

  get layerDetailsFields() {
    return this.layerDetailsFormGroup.controls;
  }

  private generateLayerDetailsFormGroup() {
    const group = {
      ACELayerPremium: new FormControl(''),
      ACELayerBenchmarkPremium: new FormControl(''),
      ACELayerAdjustedExpiringPremium: new FormControl(''),
    };
    this.layerDetails.DataDetailsElements.forEach((element) => {
      element.LayerDataElementsDetails.forEach((cntrl) => {
        group[cntrl.ControlName] = this.setControlConfig(cntrl);
      });
    });
    this.layerDetailsFormGroup = new FormGroup(group);
    // console.log('this.layerDetailsFormGroup');
    // console.log(this.layerDetailsFormGroup);
    this.formControlValueChanged();
    this.validationOnLoad();
  }

  private setControlConfig(cntrl: LayerDetailsDataElements): any {
    return cntrl.MandatoryYN === 'Y'
      ? new FormControl(
          {
            disabled: cntrl.EditableYN === 'N' ? true : false,
            value: cntrl.ControlName.includes('LayerNumber')
              ? Number(cntrl.SelectedValues)
              : cntrl.SelectedValues,
          },
          {
            validators: Helper.getControlValidator(cntrl, true),
          }
        )
      : new FormControl(
          {
            disabled: cntrl.EditableYN === 'N' ? true : false,
            value: cntrl.ControlName.includes('LayerNumber')
              ? Number(cntrl.SelectedValues)
              : cntrl.SelectedValues,
          },
          {
            validators: Helper.getControlValidator(cntrl),
          }
        );
  }

  formControlValueChanged() {
    for (let controlIndex = 1; controlIndex <= 7; controlIndex++) {
      CanadaLDValueChangedControls.forEach((element) => {
        const controlName = element + controlIndex;
        this.layerDetailsFormGroup
          .get(controlName)
          .valueChanges.pipe(
            debounceTime(100),
            distinctUntilChanged()
          )
          .subscribe((controlValue) => {
            this.handleValueChange(controlName + ' : ' + controlValue);
            this.customValidtion(controlName, controlValue);
          });
      });
    }
  }

  private customValidtion(controlName: any, controlValue: any) {
    console.warn(controlValue);
    if (controlName.includes('LayerNumber')) {
      this.setMandatory(controlName);
    } else if (controlName.includes('ACESharePercentage')) {
    } else if (controlName.includes('ACELayerPremium')) {
      this.sumACEPremium('ACELayerPremium');
    } else if (controlName.includes('ACELayerBenchmarkPremium')) {
      this.sumACEPremium('ACELayerBenchmarkPremium');
    } else if (controlName.includes('ACELayerAdjustedExpiringPremium')) {
      this.sumACEPremium('ACELayerAdjustedExpiringPremium');
    } else if (controlName.includes('TotalLayerLimit')) {
      this.calculateACEPremium(controlName, 'ACEParticipation');
    } else if (controlName.includes('TotalLayerPremium')) {
      this.calculateACEPremium(controlName, 'ACELayerPremium');
    } else if (controlName.includes('TotalLayerBenchmarkPremium')) {
      this.calculateACEPremium(controlName, 'ACELayerBenchmarkPremium');
    } else if (controlName.includes('TotalLayerAdjustedExpiringPremium')) {
      this.calculateACEPremium(controlName, 'ACELayerAdjustedExpiringPremium');
    }
  }

  private sumACEPremium(controlName) {
    const aceTotalPremium =
      this.getNumValueByName(controlName + 1) +
      this.getNumValueByName(controlName + 2) +
      this.getNumValueByName(controlName + 3) +
      this.getNumValueByName(controlName + 4) +
      this.getNumValueByName(controlName + 5) +
      this.getNumValueByName(controlName + 6) +
      this.getNumValueByName(controlName + 7);
    this.setValueByName(controlName, aceTotalPremium);
  }

  private calculateACEPremium(controlName, targetControlName) {
    const index = controlName.substring(
      controlName.length,
      controlName.length - 1
    );
    const acePremium =
      (this.getNumValueByName('ACESharePercentage' + index) *
        this.getNumValueByName(controlName)) /
      100;
    this.setValueByName(targetControlName + index, acePremium);
  }

  private validationOnLoad() {
    this.LayerNumber.forEach((lNumber) => {
      this.setMandatory('LayerNumber' + lNumber);
    });
    this.sumACEPremium('ACELayerPremium');
    this.sumACEPremium('ACELayerBenchmarkPremium');
    this.sumACEPremium('ACELayerAdjustedExpiringPremium');
  }

  handleValueChange(controlValue) {
    console.log(controlValue);
    console.log('Triggered handle Value Change Method: ' + controlValue);
  }

  setMandatory(controlName: string) {
    const isRequired =
      this.layerDetailsFields[controlName].value > 0 ? true : false;
    const elementsDetails = CanadaLDControlsDetail.filter((element) => {
      return element.KeyName === controlName;
    });

    if (elementsDetails) {
      if (isRequired) {
        this.addValidators(elementsDetails[0].ControlName);
      } else {
        this.removeValidators(elementsDetails[0].ControlName);
      }
    }
  }

  private setValueByName(controlName, controlValue) {
    if (this.layerDetailsFields[controlName]) {
      this.layerDetailsFields[controlName].setValue(controlValue);
    }
  }

  private getNumValueByName(controlName): number {
    if (this.layerDetailsFields[controlName]) {
      return Helper.isNumberNotNullAndEmpty(
        this.layerDetailsFields[controlName].value
      )
        ? Number.parseInt(this.layerDetailsFields[controlName].value)
        : 0;
    } else {
      return 0;
    }
  }

  private addValidators(controlList: any[]) {
    controlList.forEach((element) => {
      if (
        !element.includes('LayerNumber') &&
        this.layerDetailsFields[element]
      ) {
        this.layerDetailsFields[element].setValidators([Validators.required]);
        this.layerDetailsFields[element].updateValueAndValidity({
          onlySelf: true,
          emitEvent: false,
        });
      }
    });
  }

  private removeValidators(controlList: any[]) {
    controlList.forEach((element) => {
      if (
        !element.includes('LayerNumber') &&
        this.layerDetailsFields[element]
      ) {
        this.layerDetailsFields[element].clearValidators();
        this.layerDetailsFields[element].updateValueAndValidity({
          onlySelf: true,
          emitEvent: false,
        });
      }
    });
  }

  handleSave(action) {
    if (action === 'save') {
      this.submitted = true;
      // stop here if form is invalid
      if (this.layerDetailsFormGroup.invalid) {
        return;
      }
      this.submitted = false;
      this.dialogRef.close(this.layerDetailsFormGroup.value);
    }
  }

  handleCancel() {
    this.dialogRef.close();
  }

  handleReset(action) {
    if (action === 'reset') {
      this.layerDetailsFormGroup.markAsPristine();
      this.layerDetailsFormGroup.markAsUntouched();
      this.layerDetailsFormGroup.reset();
    }
  }

  getLayerDetails() {
    this.inputPageService
      .getLayerDetails(this.data.UserID, this.data.RecordNumber)
      .subscribe(async (data: LayerDetailsItem) => {
        if (data != null) {
          this.layerDetails = data;
        } else {
          this.layerDetails = null;
        }
        await this.generateLayerDetailsFormGroup();
      });
  }
}
