import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { GenericsFormsMasterComponent } from './generics-forms-master.component';

describe('GenericsFormsMasterComponent', () => {
	let component: GenericsFormsMasterComponent;
	let fixture: ComponentFixture<GenericsFormsMasterComponent>;

	beforeEach(
		waitForAsync(() => {
			TestBed.configureTestingModule({
				declarations: [GenericsFormsMasterComponent],
			}).compileComponents();
		})
	);

	beforeEach(() => {
		fixture = TestBed.createComponent(GenericsFormsMasterComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
