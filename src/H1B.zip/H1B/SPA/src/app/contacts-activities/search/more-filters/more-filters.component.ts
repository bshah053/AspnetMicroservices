import {
  Component,
  EventEmitter,
  Output,
  ChangeDetectorRef,
  Input,
  OnChanges,
} from '@angular/core';
import { ALL_MORE_FILTERS, FilterGroup } from './all-more-filters.const';
import { User } from '../../../user/user.model';
import { ReportingService } from '../../../tracking-reporting/services/reporting.service';
import { isTemplateSpan } from 'typescript';
import { ReportName } from 'app/tracking-reporting/reports/reports-page/reports-page.component';

export interface MoreFilters {
  Ownerunit: string[];
  Currency: string[];
  EventType: string[];
  ProductSpecialization: string[];
  IndustrySpecialization: string[];
  Cornerstone: string[];
}

@Component({
  selector: 'cb-activities-more-filters',
  templateUrl: './more-filters.component.html',
  styleUrls: ['./more-filters.component.scss'],
})
export class MoreFiltersComponent implements OnChanges {
  @Input() user: User;
  @Input() reportName: 'Activities Search';
  @Input() selectedValues: Partial<MoreFilters> = {};

  loadedFilterData: any = null;
  loadedFilterDataError: any = null;
  moreFilters: FilterGroup[];
  searchQuery = '';
  expandedIndex = -1;
  expandedChildIndex = -1;

  @Output() whenClose: EventEmitter<boolean> = new EventEmitter();
  @Output()
  moreFiltersApplied: EventEmitter<Partial<MoreFilters>> = new EventEmitter();
  @Output() clearAllApplied: EventEmitter<boolean> = new EventEmitter();

  constructor(
    private reportingService: ReportingService,
    private cdRef: ChangeDetectorRef
  ) {}
  ngOnChanges() {
    this.moreFilters = [].concat(this.allMoreFilters);
    // this.selectedValues  = { Currency: ['USD'] };
    console.log(this.moreFilters);
  }

  get allMoreFilters(): FilterGroup[] {
    return ALL_MORE_FILTERS.map((group) => {
      return {
        ...group,
        options: group.options.filter((option) => {
          return option.reportsAvailability.indexOf(this.reportName) > -1;
        }),
      };
    }).filter((group) => group.options.length > 0);
  }

  getSelectedCountForGroup(group) {
    return group.options.filter(
      (option) =>
        !!this.selectedValues[option.id] &&
        this.selectedValues[option.id].length
    ).length;
  }

  close() {
    this.whenClose.emit(true);
  }
  searchBy(query: string) {
    this.searchQuery = query;
    this.moreFilters = this.allMoreFilters
      .map((group) => ({
        ...group,
        options: group.options.filter((o) =>
          new RegExp(this.searchQuery, 'i').test(o.title)
        ),
      }))
      .filter((group) => group.options.length);
    if (query && this.moreFilters.length) {
      this.expandedIndex = 0;
    } else {
      this.expandedIndex = -1;
    }
  }
  toggleGroup(index: number) {
    if (this.expandedIndex === index) {
      this.expandedIndex = -1;
    } else {
      this.expandedIndex = index;
    }
    this.clearLoadedFilter();
    this.expandedChildIndex = -1;
  }
  toggleChild(index: number) {
    if (this.expandedChildIndex === index) {
      this.expandedChildIndex = -1;
      this.clearLoadedFilter();
    } else {
      this.expandedChildIndex = index;
      this.loadDataForFilter(
        this.moreFilters[this.expandedIndex].options[this.expandedChildIndex].id
      );
    }
  }

  applyMoreFilters() {
    debugger;
    this.moreFiltersApplied.emit(this.selectedValues);
  }

  clearAll() {
    this.selectedValues = {};
    this.clearAllApplied.emit(true);
  }

  clearLoadedFilter() {
    this.loadedFilterData = null;
    this.loadedFilterDataError = null;
  }
  loadDataForFilter(id: string) {
    this.clearLoadedFilter();
    let path;
    let method = 'getFilters';
    let payload: any = {};
    switch (id) {
      case 'Ownerunit':
        (path = 'companies/ownerunits'), (method = 'getOwnerUnits');
        break;
      case 'EventType':
        (path = 'dynamics/eventtype'), (method = 'getEventType');
        break;
      case 'ProductSpecialization':
        (path = ''), (method = 'getProductSpecializationType');
        break;
      case 'IndustrySpecialization':
        (path = ''), (method = 'getIndustrySpecializationType');
        break;
      case 'Cornerstone':
        (path = ''), (method = 'getCornerstorneType');
        break;
    }
    this.reportingService[method](path, this.user.UserID, null).subscribe(
      (data) => {
        this.loadedFilterData = data;
        this.cdRef.detectChanges();
      },
      (e) => {
        this.loadedFilterDataError = e.message;
        this.cdRef.detectChanges();
      }
    );
  }
  get selectedOptionsCount() {
    return Object.keys(this.selectedValues)
      .filter(
        (key) =>
          [
            'EffectiveDateStart',
            'EffectiveDateEnd',
            'ExpirationDateStart',
            'ExpirationDateEnd',
            'CreateDateStart',
            'CreateDateEnd',
            'BoundDateStart',
            'BoundDateEnd',
            'Currency',
          ].indexOf(key) === -1
      )
      .filter(
        (key) => !!this.selectedValues[key] && this.selectedValues[key].length
      ).length;
  }

  checkboxFieldChange(field: string, e: Event) {
    const target = e.target as HTMLInputElement;
    this.selectedValues[field] = target.checked ? 'Yes' : '';
  }
  inputFieldChange(field: string, e: Event) {
    const target = e.target as HTMLInputElement;
    this.selectedValues[field] = target.value;
  }
  dropdownFieldChange(field: string, e: Event) {
    const target = e.target as HTMLSelectElement;
    this.selectedValues[field] = target.value;
  }
}
