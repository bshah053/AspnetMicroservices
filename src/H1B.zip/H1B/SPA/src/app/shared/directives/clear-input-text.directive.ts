import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: 'input[clearInputText]',
})
export class ClearInputTextDirective {
  constructor(private elementRef: ElementRef) {}

  @HostListener('focus', ['$event'])
  public onInputFocus(event) {
    debugger;
    this.elementRef.nativeElement.value = '';
  }
}
