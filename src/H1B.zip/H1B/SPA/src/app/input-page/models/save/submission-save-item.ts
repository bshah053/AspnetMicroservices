import { SubmissionPolicyDetails } from 'input-page/models/common/policy-details';
import { BuildOutScheduleItems } from 'input-page/dialog/build-out-schedule/model/build-out-schedule-items';
import { ISubmissionChildItem } from './submission-child-item';
import { ISubmissionParentItem } from './submission-parent-item';

export class SubmissionSaveItem {
  ParentItem: ISubmissionParentItem = {
    NonRenewable: 0,
    Services: 0,
    TargetType: 0,
  };
  ChildItem: ISubmissionChildItem[] = [];
  ConstructionPolicyDetails?: SubmissionPolicyDetails[] = [];
  BuildOutScheduleItems?: BuildOutScheduleItems[] = [];
  CommonDetails?: CommonDetails = {
    SubmissionPageType: '',
    BaseRecordFlag: 0,
  };
}

export interface CommonDetails {
  SubmissionPageType?: string;
  BaseRecordFlag?: number;
}
