import { Component, Input, Output, EventEmitter } from '@angular/core';
import * as moment from 'moment';
import { chunk } from 'lodash-es';
import { CalendarMeetingModel } from '../calendar-view/calendar-view.component';
@Component({
  selector: 'cb-month-view',
  templateUrl: './month-view.component.html',
  styleUrls: ['./month-view.component.scss'],
})
export class MonthViewComponent {
  @Input() selectedDate: moment.Moment;
  @Input() selectedWeekStart: moment.Moment;
  @Input() selectedMonth: moment.Moment;
  @Input() meetings: CalendarMeetingModel[];
  @Output() selectedDateChange = new EventEmitter<moment.Moment>();
  @Output() selectedMonthChanged = new EventEmitter<moment.Moment>();

  get monthDates() {
    const days = [];
    const firstDayOfMonth = moment(this.selectedMonth).date(1);
    const firstDayOfWeekOfMonth = moment(firstDayOfMonth).day(0);
    const lastDayOfMonth = moment(firstDayOfMonth)
      .add(1, 'month')
      .subtract(1, 'day');
    const nextDayAfterLastDayOfWeekOfMonth = moment(lastDayOfMonth)
      .day(6)
      .add(1, 'day');
    for (
      let i = 0;
      moment(firstDayOfWeekOfMonth)
        .add(i, 'days')
        .isBefore(nextDayAfterLastDayOfWeekOfMonth);
      i++
    ) {
      days.push(moment(firstDayOfWeekOfMonth).add(i, 'days'));
    }
    return chunk(days, 7);
  }

  isToday(date: moment.Moment) {
    return date.isSame(Date.now(), 'day');
  }
  haveMeetings(day: moment.Moment) {
    const startOfTheDay = moment(day).startOf('day');
    const endOfTheDay = moment(day).endOf('day');
    const dayMetings = this.meetings.filter((m) => {
      if (
        moment(m.from).isAfter(startOfTheDay) &&
        moment(m.from).isBefore(endOfTheDay)
      ) {
        return true;
      }
      if (
        moment(m.from).isBefore(startOfTheDay) &&
        moment(m.to).isAfter(startOfTheDay)
      ) {
        return true;
      }
      return false;
    });
    return dayMetings.length > 0;
  }

  prevMonth() {
    this.selectedMonthChanged.emit(
      moment(this.selectedMonth).subtract(1, 'month')
    );
  }
  nextMonth() {
    this.selectedMonthChanged.emit(moment(this.selectedMonth).add(1, 'month'));
  }
  selectDate(day) {
    this.selectedDateChange.emit(day);
  }
}
