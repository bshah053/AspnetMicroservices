import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { BuildOutScheduleComponent } from './build-out-schedule.component';

describe('BuildOutScheduleComponent', () => {
	let component: BuildOutScheduleComponent;
	let fixture: ComponentFixture<BuildOutScheduleComponent>;

	beforeEach(
		waitForAsync(() => {
			TestBed.configureTestingModule({
				declarations: [BuildOutScheduleComponent],
			}).compileComponents();
		})
	);

	beforeEach(() => {
		fixture = TestBed.createComponent(BuildOutScheduleComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
