import { Component } from '@angular/core';

import { SharedService } from 'services/shared.service';

@Component({
  selector: 'cb-error',
  templateUrl: './error.component.html',
  styleUrls: ['./error.component.scss'],
})
export class ErrorComponent {
  constructor(private sharedService: SharedService) {
    this.sharedService.sendHeaderVisibilityStatus(true);
  }

  openEmail() {
    let emailTo = 'TrackerSupport@Chubb.com';
    let emailSub = 'User Access';
    let emailBody =
      'Hi \r\n\r\nPlease provide the following information to request Tracker access.' +
      '\r\n\r\n' +
      'Legacy Chubb ID or Legacy ACE LAN ID:' +
      '\r\n\r\n' +
      'Role:  Pick one and include the correspoinding additional information.' +
      '\r\n\r\n' +
      'Branch Manager, Branch: ' +
      '\r\n\r\n' +
      'Regional Manager, Region' +
      '\r\n\r\n' +
      'Underwriter Manager, Underwriters who report to you' +
      '\r\n\r\n' +
      'GCE';
    '\r\n\r\n';
    emailBody =
      emailBody + '\r\n\r\n' + 'MSL, Credited Region (s), Credited Branch(es)' + '\r\n\r\n' + 'Underwriter ' + '\r\n\r\n' + 'Manager’s Name' + '\r\n\r\n' + 'Genius ID (optional):' + '\r\n\r\n' + 'Edit Access (requires Manager approval): Y/N' + '\r\n\r\n' + 'If yes, please provide the Unit/Segments need.' + '\r\n\r\n' + '\r\n\r\n' + '\r\n\r\n' + 'Regards' + '\r\n\r\n' + 'Tracker Support.';
    location.href = 'mailto:' + emailTo + '?subject=' + emailSub + '&body=' + encodeURI(emailBody);
  }
}
