import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { SubmissionContactSearchComponent } from './submission-contact-search.component';

describe('SubmissionContactSearchComponent', () => {
	let component: SubmissionContactSearchComponent;
	let fixture: ComponentFixture<SubmissionContactSearchComponent>;

	beforeEach(
		waitForAsync(() => {
			TestBed.configureTestingModule({
				declarations: [SubmissionContactSearchComponent],
			}).compileComponents();
		})
	);

	beforeEach(() => {
		fixture = TestBed.createComponent(SubmissionContactSearchComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
