import {
  Component,
  OnInit,
  Input,
  ViewEncapsulation,
  HostListener,
  ElementRef,
} from '@angular/core';

@Component({
  selector: 'cb-dropdown-menu',
  templateUrl: './dropdown-menu.component.html',
  styleUrls: ['./dropdown-menu.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class DropdownMenuComponent implements OnInit {
  @Input() name = 'Dropdown Menu';
  @Input() open = false;
  @Input() headSelected = false;
  @Input() className = 'cb-dropdown-menu';
  @Input() isReportHeaderBar = false;
  constructor() {}

  ngOnInit() {}

  get isOpened() {
    return this.open;
  }

  handleToggleOpen() {
    this.open = !this.open;
  }

  handleHide() {
    this.open = false;
  }
}
