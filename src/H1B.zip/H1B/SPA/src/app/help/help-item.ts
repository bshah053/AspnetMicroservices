export interface HelpItem {
  CategoryName: string;
  FileName: string;
  FilePath: string;
  Category: {
    Category: string;
  };
}
