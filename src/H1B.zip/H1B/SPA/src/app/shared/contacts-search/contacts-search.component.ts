import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import { Subscription } from 'rxjs';
import { distinctUntilChanged, debounceTime, switchMap } from 'rxjs/operators';
import { InputTextComponent } from '../input-text/input-text.component';
import { RelationshipService } from '../../contacts-activities/relationship.service';
import { IContact } from '../../contacts-activities/models/contact';

@Component({
  selector: 'cb-contacts-search-list',
  templateUrl: './contacts-search.component.html',
  styleUrls: ['./contacts-search.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class ContactsSearchListComponent implements OnInit {
  @Input() preselected: IContact[];
  @Output() selectedEvent = new EventEmitter();

  @ViewChild('inputSearch', { static: true })
  private inputFilter: InputTextComponent;

  private debounceSearchTime = 500;
  private searchSubscription: Subscription;

  selections: IContact[] = [];
  results: IContact[];

  searchPlaceholder = 'Type to search';
  searchMaxLength = 100;

  state = { loading: false, error: '' };
  trackByItem;
  firstUncheckedItem;

  constructor(private relationsipService: RelationshipService) {}

  ngOnInit(): void {
    this.subscribeSearch();

    if (this.preselected && this.preselected.length) {
      this.selections = this.preselected;
    }
  }

  deselectContact(checkbox, index) {
    this.onCheckboxStateChange(checkbox, index, 'selections');
  }

  selectContact(checkbox, index) {
    this.onCheckboxStateChange(checkbox, index, 'results');
  }

  private resetSearchSubscription() {
    this.searchSubscription.unsubscribe();
    this.subscribeSearch();
  }

  private onCheckboxStateChange(
    checkbox,
    index,
    sourceList: 'selections' | 'results'
  ) {
    const targetList = sourceList === 'selections' ? 'results' : 'selections';

    if (this[targetList]) {
      this[targetList].push(checkbox.value);
    }
    delete this[sourceList][index];

    this[sourceList] = this[sourceList].filter(Boolean);

    this.selectedEvent.emit(this.selections);
  }

  private subscribeSearch() {
    this.searchSubscription = this.inputFilter.change
      .pipe(
        debounceTime(this.debounceSearchTime),
        distinctUntilChanged(),
        switchMap((value) => {
          this.state.loading = true;
          return this.relationsipService.searchChubbContacts(value);
        })
      )
      .subscribe(
        (data) => {
          this.results = data;
          this.state.loading = false;
          this.state.error = '';
        },
        (err) => {
          this.state.loading = false;
          this.state.error = 'no results were found';

          this.resetSearchSubscription();
        }
      );
  }
}
