export class SegmentsOptionsItems {
  Division: string;
  Units?: string;
  Text: string;
  Value: any;
  DisplayOrder?: number;
}
