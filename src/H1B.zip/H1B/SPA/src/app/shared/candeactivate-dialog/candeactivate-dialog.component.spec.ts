import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CandeactivateDialogComponent } from './candeactivate-dialog.component';

describe('CandeactivateDialogComponent', () => {
  let component: CandeactivateDialogComponent;
  let fixture: ComponentFixture<CandeactivateDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CandeactivateDialogComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CandeactivateDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
