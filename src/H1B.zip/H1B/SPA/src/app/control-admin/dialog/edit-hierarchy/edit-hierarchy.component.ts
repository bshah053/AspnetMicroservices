import {
  Component,
  HostListener,
  Inject,
  Injector,
  OnInit,
} from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

import { NotificationService } from 'services/notification.service';
import {
  EditHierarchyDetails,
  HierarchyItems,
} from '../../model/edit-hierarchy-details';
import {
  Options,
  ControlAdminService,
} from 'app/control-admin/services/control-admin.service';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';

@Component({
  selector: 'cb-edit-hierarchy',
  templateUrl: './edit-hierarchy.component.html',
  styleUrls: ['./edit-hierarchy.component.scss'],
})
export class EditHierarchyComponent implements OnInit {
  isShowContent = true;
  ehdFormGroup: FormGroup;
  submitted = false;
  divisionSearchValue = '';
  unitsSearchValue = '';
  segmentsSearchValue = '';
  divisionOptions: Options[] = [];
  unitsOptions: Options[] = [];
  segmentsOptions: Options[] = [];
  notifier;

  constructor(
    public dialogRef: MatDialogRef<EditHierarchyComponent>,
    @Inject(MAT_DIALOG_DATA) public editHierarchyDetails: EditHierarchyDetails,
    private injector: Injector,
    private controlAdminService: ControlAdminService
  ) {
    this.notifier = this.injector.get(NotificationService);
  }

  @HostListener('window:keyup.esc')
  onKeyUp() {
    this.dialogRef.close();
  }

  ngOnInit(): void {
    try {
      this.createFormGroup();
      this.enableControlValueChange();
      this.getDivision();
      this.getUnitsByDivision();
      this.getSegmentsByUnitsAndDivision();
    } catch (error) {
      console.log({ error });
    }
  }

  get hierarchyFields() {
    return this.ehdFormGroup.controls;
  }

  private createFormGroup() {
    this.ehdFormGroup = new FormGroup({
      Division: new FormControl(
        {
          disabled: false,
          value: this.editHierarchyDetails.SelectedHierarchyDetails.Division,
        },
        { validators: [Validators.required] }
      ),
      Units: new FormControl(
        {
          disabled: false,
          value: this.editHierarchyDetails.SelectedHierarchyDetails.Units,
        },
        { validators: [Validators.required] }
      ),
      Segments: new FormControl(
        {
          disabled: false,
          value: this.editHierarchyDetails.SelectedHierarchyDetails.Segments,
        },
        { validators: [Validators.required] }
      ),
    });
  }

  enableControlValueChange() {
    const valueChangedControls = ['Division', 'Units', 'Segments'];
    valueChangedControls.forEach((controlName) => {
      this.ehdFormGroup
        .get(controlName)
        .valueChanges.pipe(
          debounceTime(100),
          distinctUntilChanged()
        )
        .subscribe((controlValue) => {
          console.log({ controlValue });
          if (controlName === 'Division') {
            if (this.isDuplicateHierarchyExists()) {
              this.hierarchyFields['Division'].setValue('', {
                emitEvent: false,
              });
              this.notifier.showWarning(
                'Same hierarchy details already exist!!!',
                10
              );
            } else {
              this.hierarchyFields['Units'].setValue('', { emitEvent: false });
              this.hierarchyFields['Segments'].setValue('', {
                emitEvent: false,
              });
              this.getUnitsByDivision();
              this.getSegmentsByUnitsAndDivision();
            }
          } else if (controlName === 'Units') {
            if (this.isDuplicateHierarchyExists()) {
              this.hierarchyFields['Units'].setValue('', { emitEvent: false });
              this.notifier.showWarning(
                'Same hierarchy details already exist!!!',
                10
              );
            } else {
              this.hierarchyFields['Segments'].setValue('', {
                emitEvent: false,
              });
              this.getSegmentsByUnitsAndDivision();
            }
          } else if (controlName === 'Segments') {
            if (this.isDuplicateHierarchyExists()) {
              this.hierarchyFields['Segments'].setValue('', {
                emitEvent: false,
              });
              this.notifier.showWarning(
                'Same hierarchy details already exist!!!',
                10
              );
            }
          }
        });
    });
  }

  resetSearchValue(controlName) {
    if (controlName === 'Division') {
      this.divisionSearchValue = '';
    } else if (controlName === 'Units') {
      this.unitsSearchValue = '';
    } else if (controlName === 'Segments') {
      this.segmentsSearchValue = '';
    }
  }

  handleCancel() {
    this.dialogRef.close();
  }

  resetHierarchyDetails() {
    this.ehdFormGroup.markAsPristine();
    this.ehdFormGroup.markAsUntouched();
    this.ehdFormGroup.patchValue(
      {
        Division: this.editHierarchyDetails.SelectedHierarchyDetails.Division,
        Units: this.editHierarchyDetails.SelectedHierarchyDetails.Units,
        Segments: this.editHierarchyDetails.SelectedHierarchyDetails.Segments,
      },
      { emitEvent: false }
    );
  }

  updateEditHierarchyDetails(action) {
    try {
      if (action === 'save') {
        this.submitted = true;
        if (this.ehdFormGroup.invalid) {
          return;
        }
        this.submitted = false;
        const updatedHierarchyItems: HierarchyItems = {
          Division: this.hierarchyFields['Division'].value,
          Units: this.hierarchyFields['Units'].value,
          Segments: this.hierarchyFields['Segments'].value,
        };
        this.dialogRef.close(updatedHierarchyItems);
      }
    } catch (error) {
      throw error;
    }
  }

  isDuplicateHierarchyExists(): Boolean {
    if (
      this.editHierarchyDetails &&
      this.editHierarchyDetails.HierarchyDetails
    ) {
      const filteredHierarchyDetails = this.editHierarchyDetails.HierarchyDetails.filter(
        (items) => {
          return (
            items.Division === this.hierarchyFields['Division'].value &&
            items.Units === this.hierarchyFields['Units'].value &&
            items.Segments === this.hierarchyFields['Segments'].value
          );
        }
      );
      if (filteredHierarchyDetails && filteredHierarchyDetails.length > 0) {
        return true;
      } else {
        return false;
      }
    }
  }

  getDivision() {
    this.controlAdminService
      .getDivision(this.editHierarchyDetails.SelectedHierarchyDetails.UserID)
      .pipe()
      .subscribe((data: Options[]) => {
        if (data != null) {
          this.divisionOptions = data;
        } else {
          this.divisionOptions = [];
        }
      });
  }

  getUnitsByDivision() {
    this.controlAdminService
      .getUnitsByDivision(
        this.editHierarchyDetails.SelectedHierarchyDetails.UserID,
        this.hierarchyFields['Division'].value
      )
      .pipe()
      .subscribe((data: Options[]) => {
        if (data != null) {
          this.unitsOptions = data;
        } else {
          this.unitsOptions = [];
        }
      });
  }

  getSegmentsByUnitsAndDivision() {
    this.controlAdminService
      .getSegmentsByUnitsAndDivision(
        this.editHierarchyDetails.SelectedHierarchyDetails.UserID,
        this.hierarchyFields['Division'].value,
        this.hierarchyFields['Units'].value
      )
      .pipe()
      .subscribe((data: Options[]) => {
        if (data != null) {
          this.segmentsOptions = data;
        } else {
          this.segmentsOptions = [];
        }
      });
  }
}
