export interface DNBCompanyDetailsItem {
  CompanyName: string;
  LegalName: string;
  Address: string;
  City: string;
  State: string;
  Zip: string;
  PrimaryDUNS: string;
  DomesticUltimateDUNS: string;
  GlobalUltimateDUNS: string;
  SICCode: string;
  LocationType: string;
  Source: string;
  ShellAccountNo: string;
  CCS: string;
  NAICSCode: string;
  NAICSCodeDescription: string;
  PaydexScore: string;
  ConfidenceCode: string;
}
