import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UwGeniusQueueDetailsComponent } from './uw-genius-queue-details.component';

describe('UwGeniusQueueDetailsComponent', () => {
  let component: UwGeniusQueueDetailsComponent;
  let fixture: ComponentFixture<UwGeniusQueueDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [UwGeniusQueueDetailsComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UwGeniusQueueDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
