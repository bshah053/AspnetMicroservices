import { ChangeDetectorRef, Component, Injector, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Select } from '@ngxs/store';
import { combineLatest, Observable, Subscription } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';

import { UserAdminService } from '../user-admin/services/user-admin.service';
import { ControlConfigurationService } from 'services/control-configuration.service';
import { NotificationService } from 'services/notification.service';
import { SharedService } from 'services/shared.service';
import { ConfirmationDialogComponent } from 'shared/confirmation-dialog/confirmation-dialog.component';
import { CtrlTemplateComponent } from 'shared/templates/ctrl-template/ctrl-template.component';
import { User } from 'user/user.model';
import { UserState } from 'user/user.store';
import { Helper } from 'utilities/common-helper';
import { DataElements, DataElementsSectionWise, FormsControlsDataElements } from '../user-admin/model/forms-controls-data-elements';
import { ControlMappingDetails } from './model/control-mapping-details';
import { ControlAdminService } from './services/control-admin.service';
import { InputFormPopupComponent } from 'input-page/dialog/input-form-popup/input-form-popup.component';
import { SegmentsOptionsItems } from './model/segments-items';
import { SegmentsOptionsGroupItems } from './model/segments-group-items';
import { EditHierarchyComponent } from './dialog/edit-hierarchy/edit-hierarchy.component';
import { EditHierarchyDetails, HierarchyItems } from './model/edit-hierarchy-details';
import { NavigationService } from 'services/navigation.service';

@Component({
  selector: 'cb-control-admin',
  templateUrl: './control-admin.component.html',
  styleUrls: ['./control-admin.component.scss'],
})
export class ControlAdminComponent implements OnInit {
  @Select(UserState) public user$: Observable<User>;
  user: User;
  @ViewChild('ctrlTemplate') ctrlTemplate: CtrlTemplateComponent;
  controlsTemplate: TemplateRef<any>;
  isShowContent = false;
  isShowMappingContent = false;
  isLoading = false;
  caFormGroup: FormGroup;
  mappingFormGroup: FormGroup;
  submitted = false;
  currencyType = 'USD';
  notifier;
  sharedService$: Subscription;
  collectionDetails$: Subscription;
  mappingPrefix = '';
  masterPrefix = '';
  scriptHeader = '';

  private _formsControlsDataElements: FormsControlsDataElements;
  public get formsControlsDataElements(): FormsControlsDataElements {
    return this._formsControlsDataElements;
  }
  public set formsControlsDataElements(value: FormsControlsDataElements) {
    this._formsControlsDataElements = value;
  }
  private _dataElements: DataElements[];
  public get dataElements(): DataElements[] {
    return this._dataElements;
  }
  public set dataElements(value: DataElements[]) {
    this._dataElements = value;
  }
  private _dataElementsSectionWise: DataElementsSectionWise[];
  public get dataElementsSectionWise(): DataElementsSectionWise[] {
    return this._dataElementsSectionWise;
  }
  public set dataElementsSectionWise(value: DataElementsSectionWise[]) {
    this._dataElementsSectionWise = value;
  }
  headerDataElements: DataElements[] = [];
  segmentsOptionsItems: SegmentsOptionsItems[] = [];
  segmentsOptionsGroupItems: SegmentsOptionsGroupItems[] = [];

  constructor(private sharedService: SharedService, private configurationService: ControlConfigurationService, private navigation: NavigationService, private userAdminService: UserAdminService, private controlAdminService: ControlAdminService, private injector: Injector, public dialog: MatDialog, private caFormBuilder: FormBuilder, private cdRef: ChangeDetectorRef) {
    try {
      combineLatest([this.user$]).subscribe(([user]) => {
        this.user = user;
        if (this.user && Helper.isStringNotNullAndEmpty(this.user.UserID)) {
          if (this.isControlAdmin) {
            this.notifier = this.injector.get(NotificationService);
            this.setInitialPayloadValue();
            this.ctrlsTemplateChanges();
            this.getHeaderSegmentsByFilter();
            this.getControlsElements();
          } else {
            this.navigation.toErrorPage();
          }
        }
      });
    } catch (error) {
      console.log({ error });
    }
  }

  ngOnInit(): void {
    try {
      this.scriptHeader = 'BEGIN \n' + 'DECLARE @CONTROLID BIGINT=0; \n' + 'SELECT @CONTROLID = (MAX(Control_id)+1) FROM FORECASTER_CONTROL_MASTER(nolock) \n' + 'IF(@CONTROLID > 0) \n' + '	BEGIN \n';
      this.mappingPrefix = '		INSERT INTO FORECASTER_CONTROL_MAPPING(' + 'control_id,Group_name,Sub_group,Division,IsVisible,IsRequired,CondShowHide,Control_Label,Comments,' + 'DefaultValue,IsUpd,SectionID,SectionDisplayOrder,ControlDisplayOrder,LockEdit,LockEditDescription)\n		VALUES\n';
      this.masterPrefix =
        '		INSERT INTO FORECASTER_CONTROL_MASTER(' +
        'Control_id,Control_Desc,Table_name,Column_name,column_type,ControlName,ControlType,' +
        'ControlMaxLength,ControlMinLength,ControlMaxValue,ControlMinValue,ControlTooltip,ControlHint,ValidCharRegEx,ValidationMessage,' +
        'HyperLinkYN,HyperLinkIconType,HyperLinkTooltip,DependencyFlag,ControlGroupVisibleYN,ControlGroupIndicator,ControlGroupHeaderName,' +
        'GroupName,LookupTableName,LookupTableTextValue,LookupTableDataValue,LookupDependant_GroupName,LookupDependant_SubGroup,LookupDependant_Division,' +
        'Comments,Active)\n		VALUES';
      // this.getHeaderSegmentsByFilter();
      // this.getControlsElements();
    } catch (error) {
      console.log({ error });
    }
  }

  ngOnDestroy() {
    try {
    } catch (error) {
      console.log({ error });
    }
  }

  getTemplate() {
    if (this.ctrlTemplate) {
      this.controlsTemplate = this.ctrlTemplate.getTemplate('ctrlsTemplate');
    }
  }

  public controlById(index, control) {
    if (!control) return null;
    return control.ControlId;
  }

  ctrlsTemplateChanges() {
    this.sharedService$ = this.sharedService.setCTRLSChanges().subscribe((ctrlsDetails: DataElements) => {});
  }

  get isControlAdmin(): boolean {
    let userRole = this.user['MenuMapDetails'].filter((element) => element.MenuDescription == 'Control Admin')[0];
    return userRole && userRole.IsUserPermissible == 'Y' ? true : false;
  }

  get userAdminFields() {
    return this.caFormGroup.controls;
  }

  get mappingDetails() {
    return this.mappingFormGroup.get('Mapping') as FormArray;
  }

  get headerDivision() {
    if (this.isCTRLExists('DivisionHeader')) {
      const selectedDivision = this.userAdminFields['DivisionHeader'].value;
      return selectedDivision && selectedDivision.length > 0 ? selectedDivision : [];
    } else {
      return [];
    }
  }

  get headerUnits() {
    if (this.isCTRLExists('UnitsHeader')) {
      const selectedUnits = this.userAdminFields['UnitsHeader'].value;
      return selectedUnits && selectedUnits.length > 0 ? selectedUnits : [];
    } else {
      return [];
    }
  }

  get isMirrorRequired() {
    return Boolean(this.caFormGroup.get('IsMirrorRequired').value);
  }

  private async createFormGroup() {
    const formGroup = {};
    if (this.dataElementsSectionWise) {
      this.dataElementsSectionWise.forEach((sectionWiseElement) => {
        if (sectionWiseElement.SectionKey === 'FCMASTER') {
          sectionWiseElement.DataElements.forEach((element) => {
            if (Helper.isStringNotNullAndEmpty(element.ControlName)) {
              formGroup[element.ControlName] = this.configurationService.setControlConfig(element);
            } else {
              console.log('Control Name is Blank for ' + element);
            }
          });
        }
      });
    }

    if (this.headerDataElements) {
      this.headerDataElements.forEach((element) => {
        if (Helper.isStringNotNullAndEmpty(element.ControlName)) {
          formGroup[element.ControlName] = this.configurationService.setControlConfig(element);
        } else {
          console.log('Control Name is Blank for ' + element);
        }
      });
    }

    this.caFormGroup = new FormGroup(formGroup);
    this.addDefaultMappingControls();

    setTimeout(() => {
      // To Validation on Load
      this.validationOnLoad();
      // To Enable Validation on Control Value changes
      this.enableControlValueChange();
      this.cdRef.detectChanges();
    }, 10);
  }

  private addDefaultMappingControls() {
    this.mappingFormGroup = this.caFormBuilder.group({
      Mapping: this.caFormBuilder.array([this.getFormsGroup(this.getMappingSection())]),
    });
  }

  getMappingSection(): DataElementsSectionWise {
    const sectionWiseElement: DataElementsSectionWise[] = this.dataElementsSectionWise.filter((dataElement) => {
      return dataElement.SectionKey === 'FCMAPPPING';
    });
    if (sectionWiseElement && sectionWiseElement.length > 0) {
      return sectionWiseElement[0];
    }
  }

  addNewMappingControls() {
    const sectionWiseElement: DataElementsSectionWise[] = this.getMappingSectionDataElements();
    if (sectionWiseElement && sectionWiseElement.length > 0) {
      this.mappingDetails.push(this.getFormsGroup(sectionWiseElement[0]));
    }
  }

  removeMappingControls(rowIndex: number) {
    if (this.mappingDetails.length > 1) {
      const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
        width: '510px',
        data: { Action: 'Delete' },
        hasBackdrop: true,
        backdropClass: 'backdropBackground',
      });

      dialogRef.afterClosed().subscribe((result) => {
        if (result && Helper.isStringNotNullAndEmpty(result.Action)) {
          if (result.Action === 'Delete confirm') {
            this.mappingDetails.removeAt(rowIndex);
          }
        }
      });
    } else {
      const message = 'One row should be retained!!!';
      this.notifier.showError(message);
    }
  }

  getFormsGroup(sectionWiseElement: DataElementsSectionWise): FormGroup {
    const formGroup = this.caFormBuilder.group({});
    sectionWiseElement.DataElements.forEach((element) => {
      if (Helper.isStringNotNullAndEmpty(element.ControlName)) {
        formGroup.addControl(element.ControlName, this.configurationService.setControlConfig(element));
      }
    });
    return formGroup;
  }

  enableControlValueChange() {
    const valueChangedControls = ['IsMirrorRequired', 'DivisionHeader', 'UnitsHeader', 'ControlDescription'];
    valueChangedControls.forEach((controlName) => {
      if (this.isCTRLExists(controlName)) {
        this.caFormGroup
          .get(controlName)
          .valueChanges.pipe(debounceTime(100), distinctUntilChanged())
          .subscribe((controlValue) => {
            if (controlName === 'IsMirrorRequired') {
              this.setHierarchyVisibility();
            } else if (controlName === 'DivisionHeader' || controlName === 'UnitsHeader') {
              this.getHeaderSegmentsByFilter();
            } else if (controlName === 'ControlDescription') {
              this.setDefaultValidationMessage();
            }
          });
      }
    });
  }

  private setDefaultValidationMessage() {
    const controlLabel = this.caFormGroup.get('ControlDescription').value;
    this.caFormGroup.get('ValidationMessage').setValue('Please Provide Value For ' + controlLabel);
  }

  private setHierarchyVisibility() {
    this.headerDataElements.forEach((element) => {
      if (element.ControlName === 'DivisionHeader' || element.ControlName === 'UnitsHeader' || element.ControlName === 'SegmentsHeader') {
        element.IsVisible = !this.isMirrorRequired;
        if (this.isMirrorRequired) {
          this.userAdminFields[element.ControlName].disable({
            emitEvent: false,
          });
          this.userAdminFields[element.ControlName].setValue([], {
            emitEvent: false,
          });
        } else {
          this.userAdminFields[element.ControlName].enable({
            emitEvent: false,
          });
        }
      } else if (element.ControlName === 'MirrorControlID') {
        element.IsVisible = this.isMirrorRequired;
        if (this.isMirrorRequired) {
          this.userAdminFields[element.ControlName].enable({
            emitEvent: false,
          });
        } else {
          this.userAdminFields[element.ControlName].disable({
            emitEvent: false,
          });
          this.userAdminFields[element.ControlName].setValue('', {
            emitEvent: false,
          });
        }
      }
    });
  }

  sendControlsChanges() {}

  validationOnLoad() {
    this.setHierarchyVisibility();
  }

  isCTRLExists(controlName: string) {
    if (this.caFormGroup && this.caFormGroup.controls[controlName]) {
      return true;
    } else {
      return false;
    }
  }

  isMappingCTRLExists(controlName: string, rowIndex: number) {
    if (this.mappingDetails && this.mappingDetails.controls[rowIndex].get(controlName)) {
      return true;
    } else {
      return false;
    }
  }

  setInitialPayloadValue() {}

  saveControlDetails(action) {
    try {
      if (action === 'save') {
        this.submitted = true;
        if (this.caFormGroup.invalid) {
          return;
        }
        this.submitted = false;
        // console.log(this.caFormGroup.getRawValue());
        this.downloadSQLScript();
      }
    } catch (error) {
      throw error;
    }
  }

  resetControlDetails() {
    this.submitted = false;
    this.caFormGroup.markAsPristine();
    this.caFormGroup.markAsUntouched();
    this.caFormGroup.reset();
    this.resetGeneratedMappingControls();
  }

  closeControlAdminPage() {
    window.history.back();
  }

  getControlsElements() {
    try {
      this.isLoading = true;
      this.isShowContent = false;
      this.userAdminService
        .getFormsControlsElements(this.user.UserID, 'CONTROLMASTER')
        .pipe()
        .subscribe(
          (data: FormsControlsDataElements[]) => {
            if (data != null) {
              this._dataElements = data[0].DataElements.filter((filter) => filter.ControlType !== null).sort((a: any, b: any) => {
                return a.ControlDisplayOrder - b.ControlDisplayOrder;
              });
              // this._dataElementsSectionWise = data[0].DataElementsSectionWise;
              this._dataElementsSectionWise = data[0].DataElementsSectionWise.filter((element) => {
                return element.SectionKey === 'FCMASTER' || element.SectionKey === 'FCMAPPPING';
              });
              // console.log(this.dataElementsSectionWise);
              this.headerDataElements = data[0].DataElementsSectionWise.filter((element) => {
                return element.SectionKey === 'FCMHEADER';
              })[0].DataElements.sort((a: any, b: any) => {
                return a.ControlDisplayOrder - b.ControlDisplayOrder;
              });
              // console.log(this.headerDataElements);
              this.getHierarchyDetails();
              this.getTemplate();
              this.createFormGroup();
              setTimeout(() => {
                this.isShowContent = true;
                this.isLoading = false;
              }, 0);
            }
          },
          (err) => {
            this.isLoading = false;
            console.error(err);
          }
        );
    } catch (error) {
      this.isLoading = false;
      this.isShowContent = false;
      console.error(error);
    }
  }

  private addOptionInDropDown(optionsItems: SegmentsOptionsItems[]) {
    const sectionWiseElement: DataElementsSectionWise[] = this.getMappingSectionDataElements();
    if (sectionWiseElement && sectionWiseElement.length > 0 && optionsItems && optionsItems.length > 0) {
      const cntrlList: DataElements[] = sectionWiseElement[0].DataElements.filter((element) => {
        return element.ControlName === 'Segments';
      });
      if (cntrlList && cntrlList.length > 0) {
        cntrlList[0].CustomOptions = optionsItems;
      }
    }
  }

  getHierarchyDetails() {
    try {
      this.controlAdminService
        .getHierarchyDetails(this.user.UserID)
        .pipe()
        .subscribe((data: SegmentsOptionsItems[]) => {
          if (data != null) {
            this.segmentsOptionsItems = data;
            this.addOptionInDropDown(this.segmentsOptionsItems);
          } else {
            this.segmentsOptionsItems = [];
          }
        });
    } catch (error) {
      this.segmentsOptionsItems = [];
      console.error(error);
    }
  }

  getHeaderSegmentsByFilter() {
    try {
      if ((this.headerDivision.length === 0 && this.headerUnits.length === 0) || (this.headerDivision.length > 0 && this.headerUnits.length > 0)) {
        this.controlAdminService
          .getHeaderSegmentsByFilter(this.user.UserID, this.headerDivision, this.headerUnits)
          .pipe()
          .subscribe((data: SegmentsOptionsGroupItems[]) => {
            if (data != null) {
              this.segmentsOptionsGroupItems = data;
            } else {
              this.segmentsOptionsGroupItems = [];
            }
          });
      }
    } catch (error) {
      this.segmentsOptionsGroupItems = [];
      console.error(error);
    }
  }

  resetGeneratedMappingControls() {
    this.isShowMappingContent = false;
    this.userAdminFields['DivisionHeader'].setValue([], {
      emitEvent: false,
    });
    this.userAdminFields['UnitsHeader'].setValue([], {
      emitEvent: false,
    });
    this.userAdminFields['SegmentsHeader'].setValue([], {
      emitEvent: false,
    });
    this.mappingFormGroup.markAsPristine();
    this.mappingFormGroup.markAsUntouched();
    this.addDefaultMappingControls();
  }

  mirrorMappingControlFirstRowValue() {
    if (this.mappingFormGroup && this.mappingDetails && this.mappingDetails.length > 0) {
      const firstRowValue = this.mappingDetails.controls[0].value;
      // console.log(firstRowValue);
      const totalRows = this.mappingDetails.length;
      for (let rowIndex = 1; rowIndex < totalRows; rowIndex++) {
        this.mappingDetails.controls[rowIndex].patchValue(
          {
            IsVisible: firstRowValue['IsVisible'],
            IsRequired: firstRowValue['IsRequired'],
            CondShowHide: firstRowValue['CondShowHide'],
            ControlLabel: firstRowValue['ControlLabel'],
            Comments: firstRowValue['Comments'],
            DefaultValue: firstRowValue['DefaultValue'],
            IsReadonly: firstRowValue['IsReadonly'],
            SectionName: firstRowValue['SectionName'],
            SectionDisplayOrder: firstRowValue['SectionDisplayOrder'],
            ControlDisplayOrder: firstRowValue['ControlDisplayOrder'],
            LockEdit: firstRowValue['LockEdit'],
            LockEditDescription: firstRowValue['LockEditDescription'],
          },
          {
            emitEvent: false,
          }
        );
      }
    }
  }

  generateMappingControl() {
    try {
      this.isShowMappingContent = false;
      const isMirrorRequired: boolean = this.caFormGroup.get('IsMirrorRequired').value;
      if (isMirrorRequired && this.caFormGroup.get('MirrorControlID').valid) {
        this.generateControlsRowByControlID();
      } else {
        this.generateControlsRowBySegments();
      }
    } catch (error) {
      console.error(error);
    }
  }

  private generateControlsRowBySegments() {
    const selectedSegments = this.caFormGroup.get('SegmentsHeader').value;
    if (selectedSegments && selectedSegments.length > 0) {
      let dialogRef = this.dialog.open(InputFormPopupComponent, {
        data: {
          loader: true,
        },
      });

      this.addDefaultMappingControls();
      const totalRecords = selectedSegments.length;
      this.showRowTotalNotification(totalRecords);
      this.addNewMappingControlRows(totalRecords);
      selectedSegments.forEach((item, rowIndex) => {
        this.setMappingControlValue(rowIndex, item);
        if (rowIndex === totalRecords - 1) {
          this.cdRef.detectChanges();
          dialogRef.close();
          this.isShowMappingContent = true;
        }
      });
    }
  }

  private setMappingControlValue(rowIndex: number, item: SegmentsOptionsItems) {
    this.mappingDetails.controls[rowIndex].patchValue(
      {
        Division: item.Division,
        Units: item.Units,
        Segments: item.Value,
        IsVisible: true,
        IsRequired: false,
        CondShowHide: false,
        ControlLabel: '',
        Comments: '',
        DefaultValue: '',
        IsReadonly: false,
        SectionName: '',
        SectionDisplayOrder: '',
        ControlDisplayOrder: '',
        LockEdit: '',
        LockEditDescription: '',
      },
      {
        emitEvent: false,
      }
    );
  }

  private showRowTotalNotification(totalRecords: number) {
    this.notifier.showSuccess('Total no of mapping record is ' + totalRecords, 10);
  }

  private addNewMappingControlRows(totalRecords: number) {
    const sectionWiseElement: DataElementsSectionWise[] = this.getMappingSectionDataElements();
    if (sectionWiseElement && sectionWiseElement.length > 0) {
      for (let rowIndex = 1; rowIndex < totalRecords; rowIndex++) {
        this.mappingDetails.push(this.getFormsGroup(sectionWiseElement[0]));
      }
    }
  }

  private updateHierarchy(rowIndex: number) {
    this.showHierarchyDetails(rowIndex);
  }

  showHierarchyDetails(rowIndex: number): void {
    const editHierarchyDetails: EditHierarchyDetails = {
      HierarchyDetails: this.mappingFormGroup.getRawValue().Mapping.map((items) => ({
        Division: items.Division,
        Units: items.Units,
        Segments: items.Segments,
      })),
      SelectedHierarchyDetails: {
        UserID: this.user.UserID,
        Division: this.mappingDetails.controls[rowIndex].get('Division').value,
        Units: this.mappingDetails.controls[rowIndex].get('Units').value,
        Segments: this.mappingDetails.controls[rowIndex].get('Segments').value,
      },
    };

    const dialogRef = this.dialog.open(EditHierarchyComponent, {
      width: '510px',
      data: editHierarchyDetails,
      hasBackdrop: true,
      backdropClass: 'backdropBackground',
    });

    dialogRef.afterClosed().subscribe((updatedHierarchyItems: HierarchyItems) => {
      if (updatedHierarchyItems) {
        this.mappingDetails.controls[rowIndex].get('Division').setValue(updatedHierarchyItems.Division);
        this.mappingDetails.controls[rowIndex].get('Units').setValue(updatedHierarchyItems.Units);
        this.mappingDetails.controls[rowIndex].get('Segments').setValue(updatedHierarchyItems.Segments);
      }
    });
  }

  generateControlsRowByControlID() {
    let dialogRef = this.dialog.open(InputFormPopupComponent, {
      data: {
        loader: true,
      },
    });
    const controlId = this.caFormGroup.get('MirrorControlID').value;
    this.collectionDetails$ = this.controlAdminService
      .getControlMappingDetails(this.user.UserID, controlId)
      .pipe()
      .subscribe((controlMappingdetails: ControlMappingDetails[]) => {
        if (controlMappingdetails != null) {
          this.addDefaultMappingControls();
          const totalRecords = controlMappingdetails.length;
          this.showRowTotalNotification(totalRecords);
          this.addNewMappingControlRows(totalRecords);

          controlMappingdetails.forEach((item, rowIndex) => {
            this.mappingDetails.controls[rowIndex].patchValue(
              {
                Division: item.Division,
                Units: item.Units,
                Segments: item.Segments,
                IsVisible: item.IsVisible,
                IsRequired: item.IsRequired,
                CondShowHide: item.CondShowHide,
                ControlLabel: item.ControlLabel,
                Comments: item.Comments,
                DefaultValue: item.DefaultValue,
                IsReadonly: item.IsUpd === 'Y' ? true : false,
                SectionName: String(item.SectionID),
                SectionDisplayOrder: item.SectionDisplayOrder,
                ControlDisplayOrder: item.ControlDisplayOrder,
                LockEdit: item.LockEdit,
                LockEditDescription: item.LockEditDescription,
              },
              {
                emitEvent: false,
              }
            );
            if (rowIndex === totalRecords - 1) {
              this.isShowMappingContent = true;
              this.cdRef.detectChanges();
              dialogRef.close();
            }
          });
        }
      });
  }

  private getMappingSectionDataElements(): DataElementsSectionWise[] {
    return this.dataElementsSectionWise.filter((dataElement) => {
      return dataElement.SectionKey === 'FCMAPPPING';
    });
  }

  private setMappingValueByName(controlName: string, controlValue: any, rowIndex: number, isEmitEvent: boolean = false) {
    if (this.mappingDetails.controls[rowIndex] && Helper.isStringNotNullAndEmpty(this.mappingDetails.controls[rowIndex].get(controlName))) {
      this.mappingDetails.controls[rowIndex].get(controlName).setValue(controlValue, { emitEvent: isEmitEvent });
    }
  }

  private downloadSQLScript() {
    // const masterFilename = 'Master Script New.sql';
    // const mappingFilename = 'Mapping Script New.sql';
    // this.generateSQLScriptFile(this.generateMasterScript(), masterFilename);
    // this.generateSQLScriptFile(this.generateMappingScript(), mappingFilename);
    const filename = 'InsertScriptFor' + this.userAdminFields['ControlName'].value + '.sql';
    const finalScript = this.scriptHeader + this.generateMasterScript() + '\n \n' + this.generateMappingScript() + '\n	END\n END';
    this.generateSQLScriptFile(finalScript, filename);
  }

  get controlMaxLength() {
    return Helper.isNumberNotNullAndEmpty(this.userAdminFields['ControlMaxLength'].value) ? this.userAdminFields['ControlMaxLength'].value : null;
  }

  get controlMinLength() {
    return Helper.isNumberNotNullAndEmpty(this.userAdminFields['ControlMinLength'].value) ? this.userAdminFields['ControlMinLength'].value : null;
  }

  get controlMaxValue() {
    return Helper.isNumberNotNullAndEmpty(this.userAdminFields['ControlMaxValue'].value) ? this.userAdminFields['ControlMaxValue'].value : null;
  }

  get controlMinValue() {
    return Helper.isNumberNotNullAndEmpty(this.userAdminFields['ControlMinValue'].value) ? this.userAdminFields['ControlMinValue'].value : null;
  }

  get controlGroupIndicator() {
    return Helper.isNumberNotNullAndEmpty(this.userAdminFields['ControlGroupIndicator'].value) ? this.userAdminFields['ControlGroupIndicator'].value : null;
  }

  private generateMasterScript() {
    let masterFieldValue = '';
    masterFieldValue = `(@CONTROLID,'${this.userAdminFields['ControlDescription'].value}','${this.userAdminFields['TableName'].value}','${this.userAdminFields['ColumnName'].value}','${this.userAdminFields['ColumnType'].value}','${this.userAdminFields['ControlName'].value}','${this.userAdminFields['ControlType'].value}',${this.controlMaxLength},${this.controlMinLength},${this.controlMaxValue},${
      this.controlMinValue
    },'${this.userAdminFields['ControlToolTip'].value}','${this.userAdminFields['ControlHint'].value}','${this.userAdminFields['ValidCharRegEx'].value}','${this.userAdminFields['ValidationMessage'].value}','${Boolean(this.userAdminFields['IsHyperLink'].value) === true ? 'Y' : ''}','${this.userAdminFields['HyperLinkIconType'].value}','${this.userAdminFields['HyperLinkToolTip'].value}','${
      this.userAdminFields['DependencyFlag'].value
    }','${Boolean(this.userAdminFields['IsControlGroupVisible'].value) === true ? 'Y' : ''}',${this.controlGroupIndicator},'${this.userAdminFields['ControlGroupHeaderName'].value}','${this.userAdminFields['GroupName'].value}','${this.userAdminFields['LookupTableName'].value}','${this.userAdminFields['LookupTableTextValue'].value}','${this.userAdminFields['LookupTableDataValue'].value}','${
      this.userAdminFields['LookupDependantGroupName'].value
    }','${this.userAdminFields['LookupDependantSubGroup'].value}','${this.userAdminFields['LookupDependantDivision'].value}','${this.userAdminFields['Comments'].value}','Y')`;
    return this.masterPrefix + masterFieldValue;
  }

  private generateMappingScript() {
    let masterFieldValue = '';
    const saveMappingValueDetails: any[] = this.mappingFormGroup.getRawValue().Mapping;
    const totalCount = saveMappingValueDetails.length - 1;
    saveMappingValueDetails.forEach((mappingValue, rowIndex) => {
      const fieldValue = `		(@CONTROLID,'${mappingValue['Division']}','${mappingValue['Units']}','${mappingValue['Segments']}',${Boolean(mappingValue['IsVisible']) === true ? 1 : 0},${Boolean(mappingValue['IsRequired']) === true ? 1 : 0},${Boolean(mappingValue['CondShowHide']) === true ? 1 : 0},'${mappingValue['ControlLabel']}','${mappingValue['Comments']}','${mappingValue['DefaultValue']}','${
        Boolean(mappingValue['IsReadonly']) === true ? 'N' : 'Y'
      }','${mappingValue['SectionName']}','${mappingValue['SectionDisplayOrder']}','${mappingValue['ControlDisplayOrder']}','${mappingValue['LockEdit']}','${mappingValue['LockEditDescription']}')`;

      if (rowIndex < totalCount) {
        masterFieldValue += fieldValue + ',\n';
      } else {
        masterFieldValue += fieldValue;
      }
    });
    return this.mappingPrefix + masterFieldValue;
  }

  private generateSQLScriptFile(text, filename: string) {
    const downloadedFile = new Blob([text], { type: 'text/plain' });
    this.navigation.toFileDownload(filename, downloadedFile);
    // let textFile = null;
    // if (textFile !== null) {
    //   window.URL.revokeObjectURL(textFile);
    // }
    // textFile = window.URL.createObjectURL(data);

    // const a = document.createElement('a');
    // a.setAttribute('style', 'display:none;');
    // document.body.appendChild(a);
    // a.download = filename;
    // a.href = textFile;
    // a.target = '_blank';
    // a.click();
    // document.body.removeChild(a);
  }
}
