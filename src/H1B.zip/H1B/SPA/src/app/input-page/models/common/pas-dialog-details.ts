export class PASDialogDetails {
  Title: string;
  ActionType: string;
  Message: string;
}
