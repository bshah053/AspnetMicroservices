import { Component, OnInit, Inject, ChangeDetectorRef, HostListener } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { SubmissionContactDetails } from 'input-page/models/common/submission-contact-details';
import Utilities from 'shared/utilities';
import { ContactDetails } from '../../../contacts-activities/search/contacts-search/contact-search.service';

@Component({
	selector: 'submission-contact-search-mini',
	templateUrl: './submission-contact-search-mini.component.html',
	styleUrls: ['./submission-contact-search-mini.component.scss'],
})
export class SubmissionContactSearchMiniComponent implements OnInit {
	columns = [
		{
			headerName: 'FullName',
			field: 'FullName',
			tooltipValueGetter: (params) => params.value,
			width: 150,
			cellClass: 'multiline',
			suppressSizeToFit: true,
			cellRenderer: Utilities.restrictCellTextRenderer(),
		},
		{
			headerName: 'FirstName',
			headerTooltip: 'FirstName',
			field: 'FirstName',
			tooltipValueGetter: (params) => params.value,
			width: 150,
			cellClass: 'multiline',
			suppressSizeToFit: true,
			cellRenderer: Utilities.restrictCellTextRenderer(),
		},
		{
			headerName: 'LastName',
			headerTooltip: 'LastName',
			field: 'LastName',
			tooltipValueGetter: (params) => params.value,
			width: 150,
			cellClass: 'multiline',
			suppressSizeToFit: true,
			cellRenderer: Utilities.restrictCellTextRenderer(),
		},
		{
			headerName: 'Email',
			headerTooltip: 'Email',
			field: 'Email',
			tooltipValueGetter: (params) => params.value,
			width: 150,
			cellClass: 'multiline',
			suppressSizeToFit: true,
			cellRenderer: Utilities.restrictCellTextRenderer(),
		},
	];

	constructor(public dialogRef: MatDialogRef<SubmissionContactSearchMiniComponent>, @Inject(MAT_DIALOG_DATA) public submissionContactDetails: SubmissionContactDetails) {}

	@HostListener('window:keyup.esc')
	onKeyUp() {
		this.dialogRef.close();
	}

	contactDetails: ContactDetails[];
	selectedContactDetails: SubmissionContactDetails = {
		ContactDetails: null,
		ControlName: '',
		UserId: '',
	};
	selectedFullName = '';
	headerName = '';

	ngOnInit(): void {
		if (this.submissionContactDetails) {
			this.contactDetails = this.submissionContactDetails.ContactDetails;
			if (['ContactFirst', 'ContactLast', 'BrokerEmail'].includes(this.submissionContactDetails.ControlName)) {
				this.headerName = 'Matching Contact Details';
			} else if (['LoginName', 'UWEmail'].includes(this.submissionContactDetails.ControlName)) {
				this.headerName = 'Matching UW Details';
			} else if (['UnderwriterAssistant', 'UAEmail'].includes(this.submissionContactDetails.ControlName)) {
				this.headerName = 'Matching UA Details';
			}
		}
	}

	rowSelected(selectedRow) {
		this.selectedFullName = '';
		console.warn(selectedRow);
		if (selectedRow) {
			this.selectedFullName = selectedRow[0].FullName;
			this.selectedContactDetails.ContactDetails = selectedRow;
			this.selectedContactDetails.ControlName = this.submissionContactDetails.ControlName;
		}
	}

	handleCancel(): void {
		this.dialogRef.close(null);
	}

	handleSelectedRow() {
		if (this.selectedContactDetails) {
			this.dialogRef.close(this.selectedContactDetails);
		}
	}
	//test commit//test
}
