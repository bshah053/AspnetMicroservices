import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {
  TimeFrameType,
  MonthName,
} from '../../tracking-reporting/reports/reports-header/store/reports-header.model';

export interface BranchFilterItem {
  text: string;
  value: string;
}

@Component({
  selector: 'cb-branch-filter',
  templateUrl: './branch-filter.component.html',
  styleUrls: ['./branch-filter.component.scss'],
})
export class BranchFilterComponent implements OnInit {
  @Input() name: string = 'Dropdown Menu';
  @Input() open: boolean = false;
  @Input() readonly: boolean = false;
  @Input() branchlist: BranchFilterItem[];
  @Input() preselected: string;
  @Input() showCurrentDate = true;
  @Input() width: number = 170;
  @Input() filterType: string = 'branch';
  @Input() isConfiden: boolean = false;
  @Output() selected = new EventEmitter();
  headSelected;
  value: string;
  branches = [];

  get _preselected() {
    if (!this.value && !this.preselected && this.branchlist.length > 0) {
      return this.branchlist[0] &&
        this.branchlist[0].text === 'Viewing All Branches'
        ? 'Viewing All Branches'
        : this.filterType == 'range'
          ? '>='
          : this.branchlist[0].value;
    }

    if (this.preselected) {
      return this.preselected;
    }

    return this.value;
  }

  constructor() {}

  ngOnInit() {}

  get isOpened(): boolean {
    return this.open;
  }

  get isReadonly(): boolean {
    return this.readonly;
  }

  handleToggleOpen(): void {
    this.open = !this.open;
  }

  handleHide(): void {
    this.open = false;
  }

  handleSelection(item: BranchFilterItem): void {
    if (item.text === '----------------------') return;
    this.value = item.text;
    this.selected.emit(item);
    this.open = false;
  }

  getCurrent(): string {
    if (!this.value) {
      return this.branchlist[0] &&
        this.branchlist[0].text === 'Viewing All Branches'
        ? 'Viewing All Branches'
        : this.branchlist[0].value;
    }

    return this.value;
  }
}
