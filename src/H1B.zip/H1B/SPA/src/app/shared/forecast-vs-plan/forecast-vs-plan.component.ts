import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Select, Store } from '@ngxs/store';
import { combineLatest, Observable } from 'rxjs';
import { AccountingYearMonth, AccountingYearMonthState } from 'store/accounting-month-year.store';
import { DashboardService } from '../../dashboard/dashboard.service';
import { FilterWatchService } from '../../services/filter-watch.service';
import Utilities from '../../shared/utilities';
import { MonthName, ReportsHeaderModel, TimeFrameType } from '../../tracking-reporting/reports/reports-header/store/reports-header.model';
import { ReportsHeaderState } from '../../tracking-reporting/reports/reports-header/store/reports-header.store';
import { User } from '../../user/user.model';
import { DateFilterItem, DateFilterSelection } from '../date-filter/date-filter.component';
import { ListItem } from '../radio-list/radio-list.component';

export interface IForecastVsPayload {
  UserID: string;
  AccountingMonth: MonthName;
  AccountingYear: number;
  TimeFrame: TimeFrameType;
  Confidence: number;
  Range: string;
}

export interface IForecastVsPlanItems {
  TitleInfo: string;
  Forecast: number;
  PlanValue: number;
  ForecastVsPlan: number;
  ForecastVsPlanPercentage: number;
  DetailsGroupedBy: string;
  Details: {
    Forecast: number;
    PlanValue: number;
    Branch: string;
    Company: string;
    Segment: string;
  };
}

@Component({
  selector: 'cb-forecast-vs-plan',
  templateUrl: './forecast-vs-plan.component.html',
  styleUrls: ['./forecast-vs-plan.component.scss'],
})
export class ForecastVsPlanComponent implements OnInit {
  @Input() user: User;
  @Input() underwriters = [];

  rangeList = [
    { text: '=', value: '=' },
    { text: '>', value: '>' },
    { text: '<', value: '<' },
    { text: '<=', value: '<=' },
    { text: '>=', value: '>=' },
  ];
  confidenceFactorList = [
    { text: '', value: '' },
    { text: '1', value: '1' },
    { text: '2', value: '2' },
    { text: '3', value: '3' },
    { text: '4', value: '4' },
    { text: '5', value: '5' },
    { text: '6', value: '6' },
    { text: '7', value: '7' },
    { text: '8', value: '8' },
    { text: '9', value: '9' },
    { text: '10', value: '10' },
  ];

  @Select(ReportsHeaderState)
  public reportFilters$: Observable<ReportsHeaderModel>;
  currentFilters: ReportsHeaderModel;

  @Select(AccountingYearMonthState)
  public accountingYearMonth$: Observable<AccountingYearMonth>;
  accountingYearMonth: AccountingYearMonth;

  addCommaToNumber = Utilities.addCommasToNumber;
  forecastVsPlan: IForecastVsPlanItems;
  forecastVsPlanYTD: IForecastVsPlanItems;
  forecastVsPlanYTDdDetailsbyNullSeg: Array<any>;
  brchMgrNewBusiness: Object;
  forecastVsPlanBarConfig: Object;

  forecastVsPlanSubscription: any;
  brchMgrNewBusinessSubscription: any;

  dateList: DateFilterItem[] = [
    { title: 'MTD', value: 'MTD' },
    { title: '3 Months', value: 'R3' },
    { title: 'YTD', value: 'YTD' },
    { title: 'R12', value: 'R12' },
  ];

  currentDateFilterIndex = 0;
  selectedTimeFrame: TimeFrameType = 'MTD';
  range: string = '>=';
  confidenceFactor: number;
  constructor(private dashboardService: DashboardService, private filterWatch: FilterWatchService, private router: Router, private store: Store) {
    combineLatest([this.reportFilters$, this.accountingYearMonth$]).subscribe(([filters, accountingYearMonth]) => {
      this.currentFilters = filters;
      this.accountingYearMonth = accountingYearMonth;
    });
  }

  get routerLink() {
    const isBranchManager = this.user.UserType === 'Branch Manager';
    return [`/tracking-and-reporting/${isBranchManager ? 'forecast-detail' : 'forecast-region'}`];
  }

  get BranchOrRegion() {
    if (this.user.UserType === 'Branch Manager') {
      return this.user.CreditedBranch;
    }

    return this.user.CreditedRegion;
  }

  getForecastVsPlan(payload): void {
    let method = 'getForecastVsPlan';
    if (this.isUWM) {
      method = 'getUWMForecastVsPlan';
    }
    this.dashboardService[method](payload).subscribe((data: IForecastVsPlanItems) => {
      if (data !== null) {
        this.forecastVsPlan = data;
        this.setForecastVsPlanBarGraph(data);
        if (this.isUWM) {
          payload.TimeFrame = 'YTD';
          this.dashboardService[method](payload).subscribe((dataUWM: IForecastVsPlanItems) => {
            this.getForecastVsPlanYTD(dataUWM);
          });
        } else {
          this.getForecastVsPlanYTD(data);
        }
      }
    });
  }

  getForecastVsPlanYTD(data) {
    // let method = 'getForecastVsPlan';
    // if (this.isUWM) {
    //   method = 'getUWMForecastVsPlan';
    // }
    // this.dashboardService[method](payload).subscribe((data) => {
    this.forecastVsPlanYTD = data;
    this.forecastVsPlanYTDdDetailsbyNullSeg = data.Details.filter((obj) => {
      return 'Segment' in obj ? obj.Segment === null : true;
    });

    if (this.isUWM) {
      this.forecastVsPlanYTDdDetailsbyNullSeg.sort(function(a, b) {
        if (a.Underwriter < b.Underwriter) {
          return -1;
        }
        if (a.Underwriter > b.Underwriter) {
          return 1;
        }
        return 0;
      });
    }
    // });
  }

  getBrchMgrNewBusiness(): void {
    this.brchMgrNewBusinessSubscription = this.dashboardService.brchMgrNewBusiness.subscribe((data: IForecastVsPlanItems) => {
      if (data !== null) {
        this.forecastVsPlan = data;
      }
    });
  }

  setForecastVsPlanBarGraph(data?: any): void {
    const color = '#150fc5';
    this.forecastVsPlanBarConfig = {
      showIndicator1: false,
      barWrapper: {
        width: 710,
        height: 26,
      },
      barContainer: {
        background: color,
        height: 100,
        opacity: 0.2,
      },
      barStyle: {
        width: (data.Forecast / data.PlanValue) * 100,
        height: 100,
        background: color,
        top: 0,
      },
      indicator2Style: {
        color: '#8ff4ff',
        height: 40,
        top: -7,
        left: (data.PlanValue / data.Forecast) * 100,
      },
    };
  }

  rangeFilterSelected(data): void {
    const payload = { range: data.text };
    this.range = data.text;
    if (this.confidenceFactor) this.getForecastVsPlan(this.makePayload(payload));
  }

  confidenceFilterSelected(data): void {
    const payload = { confidence: data.text };
    this.confidenceFactor = data.text;
    this.getForecastVsPlan(this.makePayload(payload));
  }

  dateFilterSelected(data: DateFilterSelection): void {
    const payload = { TimeFrame: data.frame };
    this.selectedTimeFrame = data.frame;

    this.getForecastVsPlan(this.makePayload(payload));
  }

  makePayload(data): IForecastVsPayload {
    return {
      UserID: this.user['UserID'],
      AccountingMonth: data.month || this.accountingYearMonth.AccountingMonth,
      AccountingYear: data.year || this.accountingYearMonth.AccountingYear,
      TimeFrame: data.TimeFrame || this.selectedTimeFrame,
      Confidence: data.confidence || data.confidenceFactor,
      Range: data.range || this.range,
    };
  }

  navigateTitle(allDetails: boolean) {
    const commonFilters = {
      ...this.currentFilters,
      AccountMonth: this.accountingYearMonth.AccountingMonth as MonthName,
      AccountYear: this.accountingYearMonth.AccountingYear,
      UserID: this.user.UserID,
      TimeFrame: this.selectedTimeFrame,
      Confidence: this.confidenceFactor ? this.confidenceFactor : 0,
      CreditedRegion: [],
      CompanyName: [],
      CreditedBranch: [],
      Range: this.range,
    };
    switch (this.user.UserType) {
      case 'Underwriter Manager':
        commonFilters.TransactionType = ['New', 'Renewal', 'Other'];
        commonFilters.UnderwriterName = this.underwriters.map((u) => u.value);
        break;
      case 'Regional Manager':
        commonFilters.CreditedRegion = this.user.CreditedRegion;
        commonFilters.CreditedBranch = this.forecastVsPlanYTDdDetailsbyNullSeg.map((item) => {
          return item.Branch;
        });
        if (!allDetails) {
          commonFilters.TimeFrame = 'YTD';
          // commonFilters.TimeFrameReadonly = true;
        }
        break;
      default:
        if (!allDetails && this.isBM) {
          commonFilters.TimeFrame = 'YTD';
        }
        commonFilters.CreditedBranch = this.user.CreditedBranch;
        break;
    }
    const serializedFilters = this.filterWatch.serializeFromPayload(commonFilters, {
      browseByProducer: 'CHUBB Regions',
      browseByValue: this.isUWM ? 'underwriters' : 'regions',
    });
    this.router.navigate(this.routerLink, {
      queryParams: {
        filters: this.filterWatch.create(serializedFilters),
        showBrowseBy: false,
      },
    });
  }

  navigateItem(item) {
    const commonFilters = {
      ...this.currentFilters,
      AccountMonth: this.accountingYearMonth.AccountingMonth as MonthName,
      AccountYear: this.accountingYearMonth.AccountingYear,
      UserID: this.user.UserID,
      TimeFrame: this.isUWM || this.isBM || this.isRM ? 'YTD' : this.selectedTimeFrame,
      TimeFrameReadonly: false,
      CreditedBranch: [],
      CompanyName: [],
      CreditedRegion: [],
    };
    switch (this.user.UserType) {
      case 'Underwriter Manager':
        commonFilters.UnderwriterName = [item.UnderwriterLanID];
        commonFilters.TransactionType = ['New', 'Renewal', 'Other'];
        commonFilters.Status = ['Pending', 'Working', 'Quoted', 'Bound'];
        break;
      case 'Regional Manager':
        commonFilters.CreditedBranch = [item.Branch];
        commonFilters.TimeFrame = 'YTD';
        // commonFilters.TimeFrameReadonly = true;
        break;
      default:
        commonFilters.CreditedBranch = this.user.CreditedBranch;
        commonFilters.CompanyName = [item.Company];
        break;
    }
    const serializedFilters = this.filterWatch.serializeFromPayload(commonFilters, {
      browseByProducer: 'CHUBB Regions',
      browseByValue: this.isUWM ? 'underwriters' : 'regions',
    });
    this.router.navigate(this.routerLink, {
      queryParams: {
        filters: this.filterWatch.create(serializedFilters),
        showBrowseBy: false,
      },
    });
  }

  ngOnInit() {
    this.getForecastVsPlan(this.makePayload({}));
    // this.getForecastVsPlanYTD(this.makePayload({ TimeFrame: 'YTD' }));
  }

  get isUWM() {
    return this.user.UserType === 'Underwriter Manager';
  }
  get isBM() {
    return this.user.UserType === 'Branch Manager';
  }
  get isRM() {
    return this.user.UserType === 'Regional Manager';
  }
}
