import { Select } from '@ngxs/store';
import { Observable } from 'rxjs';
import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { UrlHelper } from '../../../utilities/url.helper';
import { User } from '../../../user/user.model';
import { UserState } from '../../../user/user.store';
import { RoutedFrom } from 'shared/utilities';
import { NavigationService } from 'services/navigation.service';
import { SharedService } from 'services/shared.service';

@Component({
  selector: 'cb-tracker-queue-renderer',
  templateUrl: './tracker-queue-renderer.component.html',
  styleUrls: ['./tracker-queue-renderer.component.scss'],
})
export class TrackerQueueRendererComponent implements ICellRendererAngularComp {
  public params: any;
  public url: string;
  @Select(UserState) public user$: Observable<User>;
  user;
  open;
  data;
  isSelected;
  isOpen = false;
  isWriteAccess = true;
  isNextTermAccess = true;

  constructor(
    private navigation: NavigationService,
    private sharedService: SharedService
  ) {}

  agInit(params: any): void {
    this.params = params;
    this.user$.subscribe((user) => {
      this.user = user;
    });
    this.url = UrlHelper.inputPageLink(this.params.data.Details, this.user);
    this.isWriteAccess =
      this.params.data.Details.EditFlag === 'Y' ? true : false;
    this.isNextTermAccess =
      this.params.data.Details.NextTermFlag === 'Y' ? true : false;
  }

  public inputPageUrl(): string {
    return this.url;
  }

  public invokeParentMethod(action) {
    this.isOpen = true;
    let methodName = '';

    switch (action) {
      case 'Delete': {
        methodName = 'trackerQueueDelete';
        break;
      }
      case 'Copy': {
        methodName = 'trackerQueueCopy';
        break;
      }
      case 'Next Term': {
        methodName = 'trackerQueueNextTerm';
        break;
      }
      case 'View': {
        methodName = '';
        this.onSelectionChanges(this.params.data);
        break;
      }
      default: {
        methodName = '';
        break;
      }
    }
    if (methodName !== '') {
      this.params.context.componentParent[methodName](this.params);
    }
  }

  refresh(): boolean {
    return false;
  }

  get isOpened(): boolean {
    return this.open;
  }

  handleToggleOpen(): void {
    this.open = !this.open;
    if (this.open) {
      this.isSelected = true;
    } else {
      this.isSelected = false;
    }
  }

  handleHide(): void {
    this.open = this.isSelected;
  }

  handleCancel($event) {
    this.handleToggleOpen();
  }

  onSelectionChanges(rowData) {
    if (this.user) {
      if (
        rowData.Details.blnCheckNavigation !== undefined &&
        rowData.Details.blnCheckNavigation === 1
      ) {
        // this.sharedService.sendShowLoading();
        this.navigation.toSubmission(
          rowData.Details.RecordNo,
          this.user,
          RoutedFrom.TrackerQueue,
          true
        );
      } else {
        const url = UrlHelper.inputPageLink(rowData.Details, this.user);
        window.open(url, '_blank');
        return;
      }
    }
  }
}
