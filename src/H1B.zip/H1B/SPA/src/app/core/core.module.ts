import { NgModule, Optional, SkipSelf } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { CopyDeleteService } from './../services/copydelete.service';
import { UrlService } from './../services/url.service';
import { LoginComponent } from './components/login/login.component';
import { GrowlerModule } from './components/growler/growler.module';
import { EnsureModuleLoadedOnceGuard } from './components/ensure-module-loaded-once.guard';

const components: any[] = [LoginComponent];

@NgModule({
  declarations: [...components],
  exports: [...components, GrowlerModule],
  imports: [CommonModule, FormsModule, ReactiveFormsModule, GrowlerModule],
  providers: [UrlService, CopyDeleteService, { provide: 'Window', useFactory: () => window }], // these should be singleton
})
export class CoreModule extends EnsureModuleLoadedOnceGuard {
  // Ensure that CoreModule is only loaded into AppModule

  // Looks for the module in the parent injector to see if it's already been loaded (only want it loaded once)
  constructor(@Optional() @SkipSelf() parentModule: CoreModule) {
    super(parentModule);
  }
}
