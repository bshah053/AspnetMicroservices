import {
  Component,
  Input,
  EventEmitter,
  ElementRef,
  ViewChild,
  AfterViewInit,
  Output,
} from '@angular/core';
import { User } from '../../../user/user.model';
import * as moment from 'moment';

export interface CalendarMeetingModel {
  id: string;
  from: Date | string;
  to: Date | string;
  subject: string;
  location: string;
  attendees: {
    required: string[];
    optional: string[];
  };
}

@Component({
  selector: 'cb-calendar-view',
  templateUrl: './calendar-view.component.html',
  styleUrls: ['./calendar-view.component.scss'],
})
export class CalendarViewComponent implements AfterViewInit {
  @ViewChild('grid', { static: true })
  private grid: ElementRef<HTMLElement>;
  @Input() user: User; // TODO: remove if not used
  @Input() selectedDate: moment.Moment;
  @Input() selectedWeekStart: moment.Moment;
  @Output() weekStartDateChange = new EventEmitter<moment.Moment>();
  @Output() selectedDateChange = new EventEmitter<moment.Moment>();
  @Output() meetingOpened = new EventEmitter<string>();
  @Output() meetingCreate = new EventEmitter();

  meetingHeight = 50;

  @Input() meetings: CalendarMeetingModel[];

  get currentMonthYear() {
    const weekEnd = moment(this.selectedWeekStart).day(6);
    if (weekEnd.month() !== this.selectedWeekStart.month()) {
      if (weekEnd.year() !== this.selectedWeekStart.year()) {
        return `${moment(this.selectedWeekStart).format(
          'MMMM YYYY'
        )} / ${moment(weekEnd).format('MMMM YYYY')}`;
      } else {
        return `${moment(this.selectedWeekStart).format('MMMM')} / ${moment(
          weekEnd
        ).format('MMMM YYYY')}`;
      }
    } else {
      return moment(this.selectedWeekStart).format('MMMM YYYY');
    }
  }

  get weekDays() {
    const weekDays = [];
    for (let d = 0; d < 7; d++) {
      weekDays.push(moment(this.selectedWeekStart).day(d));
    }
    return weekDays;
  }

  get dayHours() {
    const hours = [];
    for (let h = 0; h < 24; h++) {
      hours.push(h);
    }
    return hours;
  }

  ngAfterViewInit() {
    this.grid.nativeElement.scrollTop = 6 * this.meetingHeight;
  }

  dayMeetings(day) {
    const meetings = this.meetings
      .filter((m) => {
        return (
          moment(day).isSame(moment(m.from), 'day') ||
          moment(day).isSame(moment(m.to), 'day') ||
          moment(day).isBetween(moment(m.from), moment(m.to))
        );
      })
      .map((m) => {
        const meetingModel = {
          height: 0,
          top: 0,
          startSameDay: true,
          endSameDay: true,
        };
        if (moment(day).isSame(moment(m.from), 'day')) {
          meetingModel.top = this.hoursLength(m.from);
          if (moment(day).isSame(moment(m.to), 'day')) {
            meetingModel.endSameDay = true;
            meetingModel.height =
              this.hoursLength(m.to) - this.hoursLength(m.from);
          } else {
            meetingModel.endSameDay = false;
            meetingModel.height = 24 - this.hoursLength(m.from);
          }
        } else {
          meetingModel.startSameDay = false;
          if (moment(day).isSame(moment(m.to), 'day')) {
            meetingModel.endSameDay = true;
            meetingModel.height = this.hoursLength(m.to);
          } else {
            meetingModel.endSameDay = false;
            meetingModel.height = 24;
          }
        }
        meetingModel.height = meetingModel.height * this.meetingHeight;
        meetingModel.top = meetingModel.top * this.meetingHeight;

        return {
          model: meetingModel,
          meeting: m,
        };
      });
    return meetings;
  }

  private hoursLength(m) {
    return moment(m).hours() + moment(m).minutes() / 60;
  }

  selectDate(day) {
    this.selectedDateChange.emit(day);
  }

  isToday(date: moment.Moment) {
    return date.isSame(Date.now(), 'day');
  }

  setPrevWeek() {
    this.selectedWeekStart = moment(this.selectedWeekStart).subtract(1, 'week');
    this.weekStartDateChange.emit(this.selectedWeekStart);
  }
  setNextWeek() {
    this.selectedWeekStart = moment(this.selectedWeekStart).add(1, 'week');
    this.weekStartDateChange.emit(this.selectedWeekStart);
  }

  showHour(hour) {
    if (hour === 0) {
      return '12 AM';
    }
    return `${hour !== 12 ? hour % 12 : hour} ${hour < 12 ? 'AM' : 'PM'}`;
  }

  formatTime(time) {
    return moment(time).format('h:mm a');
  }

  handleScroll($e) {
    const target = $e.target;
    target.querySelector('.grid-header').style.top = `${target.scrollTop}px`;
    target.querySelector('.grid-content .time').style.left = `${
      target.scrollLeft
    }px`;
    target.querySelector('.timezone').style.left = `${target.scrollLeft}px`;
    target.querySelector('.timezone').style.top = `${target.scrollTop}px`;
  }
  openMeeting(meetingGUID) {
    this.meetingOpened.emit(meetingGUID);
  }
  addMeeting() {
    this.meetingCreate.emit();
  }
}
