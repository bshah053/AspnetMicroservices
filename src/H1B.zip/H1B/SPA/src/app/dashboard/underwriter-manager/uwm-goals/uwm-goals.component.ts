import { Component, Input, OnInit } from '@angular/core';
import { Select } from '@ngxs/store';
import { combineLatest, Observable, Subscription } from 'rxjs';
import { AccountingYearMonth, AccountingYearMonthState } from 'store/accounting-month-year.store';
import Utilities from '../../../shared/utilities';
import { User } from '../../../user/user.model';
import { DashboardService } from '../../dashboard.service';
import { UnderwriterManagerGoal } from '../../models/underwriter-manager-goal';
import { SharedService } from '../../../services/shared.service';

@Component({
  selector: 'cb-uwm-goals',
  templateUrl: './uwm-goals.component.html',
  styleUrls: ['./uwm-goals.component.scss'],
})
export class UwmGoalsComponent implements OnInit {
  @Input() user: User;
  columns = [
    {
      headerName: 'Underwriter',
      field: 'Underwriter',
      tooltipValueGetter: (params) => params.value,
      width: 170,
      cellRenderer: Utilities.restrictCellTextRenderer(),
      cellClass: 'multiline',
      suppressSizeToFit: true,
    },
    {
      headerName: 'New Business Bound',
      children: [
        {
          headerName: 'YTD',
          headerTooltip: 'New Business Bound YTD',
          field: 'NBBoundGoalAchievedPercentage',
          headerClass: 'sub-heading',
          valueFormatter: Utilities.currencyCommaFormatter,
          width: 100,
          cellClass: 'numeric percentage multiline',
          tooltipValueGetter: (params) => params.valueFormatted,
          cellRenderer: Utilities.restrictCellTextRenderer(),
          suppressSizeToFit: true,
        },
        {
          headerValueGetter: () => this.getCurrentYear() + ' Goals',
          headerTooltip: {
            toString: () => 'New Business Bound ' + this.getCurrentYear(),
          },
          field: 'NBYearlyGoal',
          headerClass: 'sub-heading',
          valueFormatter: Utilities.currencyCommaFormatter,
          width: 100,
          cellClass: 'numeric percentage multiline',
          tooltipValueGetter: (params) => params.valueFormatted,
          cellRenderer: Utilities.restrictCellTextRenderer(),
          suppressSizeToFit: true,
        },
      ],
    },
    {
      headerName: 'Travel',
      children: [
        {
          headerName: 'YTD',
          headerTooltip: 'Travel YTD',
          field: 'TravelGoalVisitAchievedPercentage',
          headerClass: 'sub-heading',
          valueFormatter: Utilities.addCommasToNumber,
          width: 100,
          cellClass: 'numeric percentage multiline',
          tooltipValueGetter: (params) => params.valueFormatted,
          cellRenderer: Utilities.restrictCellTextRenderer(),
          suppressSizeToFit: true,
        },
        {
          headerValueGetter: () => this.getCurrentYear() + ' Goals',
          headerTooltip: { toString: () => 'Travel ' + this.getCurrentYear() },
          field: 'TravelYearlyGoal',
          headerClass: 'sub-heading',
          valueFormatter: Utilities.addCommasToNumber,
          width: 100,
          cellClass: 'numeric percentage multiline',
          tooltipValueGetter: (params) => params.valueFormatted,
          cellRenderer: Utilities.restrictCellTextRenderer(),
          suppressSizeToFit: true,
        },
      ],
    },
  ];
  goals: UnderwriterManagerGoal[] = [];
  loading = false;

  @Select(AccountingYearMonthState) private accountingYearMonth$: Observable<AccountingYearMonth>;
  accountingYearMonth: AccountingYearMonth;
  _subscription: Subscription;

  constructor(private dashboardService: DashboardService, private sharedService: SharedService) {
    this._subscription = this.sharedService.refreshFetchGoals().subscribe(() => {
      this.fetchGoals();
    });
  }

  ngOnInit(): void {
    combineLatest([this.accountingYearMonth$]).subscribe(([accountingYearMonth]) => {
      this.accountingYearMonth = accountingYearMonth;
      this.fetchGoals();
    });
  }

  private fetchGoals() {
    this.loading = true;

    const params = {
      UserID: this.user.UserID,
      AccountingYear: this.accountingYearMonth.AccountingYear,
      AccountingMonth: this.accountingYearMonth.AccountingMonth,
      TimeFrame: 'YTD',
    };

    this.dashboardService.getUWMGoals(params).subscribe((goals) => {
      if (goals !== null) {
        this.goals = goals;
      }
      this.loading = false;
    });
  }

  private getCurrentYear() {
    return (this.accountingYearMonth && this.accountingYearMonth.AccountingYear) || new Date().getFullYear();
  }
}
