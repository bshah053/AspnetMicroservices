import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { TopTargetsComponent } from './top-targets.component';

describe('TopTargetsComponent', () => {
	let component: TopTargetsComponent;
	let fixture: ComponentFixture<TopTargetsComponent>;

	beforeEach(
		waitForAsync(() => {
			TestBed.configureTestingModule({
				declarations: [TopTargetsComponent],
			}).compileComponents();
		})
	);

	beforeEach(() => {
		fixture = TestBed.createComponent(TopTargetsComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
