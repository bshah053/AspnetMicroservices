import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { ContactSearchService } from '../contact-search.service';

type ListItem = {
  text: string;
  value: string;
};

@Component({
  selector: 'cb-top-level-menu',
  templateUrl: './top-level-menu.component.html',
  styleUrls: ['./top-level-menu.component.scss'],
})
export class TopLevelMenuComponent {
  @Output() selectionChange = new EventEmitter<string[]>();
  @Input() name = 'Items';
  @Input() items: ListItem[] = [];
  @Input() selectedItems: string[] = [];

  get label() {
    if (this.selectedItems && this.selectedItems.length) {
      return `${this.name} (${this.selectedItems.length})`;
    }

    return this.name;
  }

  get selected() {
    return !!this.selectedItems && !!this.selectedItems.length;
  }

  handleSelectionChange(value: string[]) {
    this.selectionChange.next(value);
  }
}
