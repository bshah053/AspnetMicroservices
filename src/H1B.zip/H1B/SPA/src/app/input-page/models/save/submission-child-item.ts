export interface ISubmissionChildItem {
  ControlName: string;
  SelectedValue: string;
  TableIndicator: string;
  RowIndicator: string;
}
