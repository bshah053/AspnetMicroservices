import { DateFilterItem } from './date-filter.component';

export const DATE_LIST: DateFilterItem[] = [
  { title: 'MTD', value: 'MTD' },
  { title: '3 Months', value: 'R3' },
  { title: 'YTD', value: 'YTD' },
  { title: 'R12', value: 'R12' },
];
