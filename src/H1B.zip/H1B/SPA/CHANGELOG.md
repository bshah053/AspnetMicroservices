# Change Log

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

<a name="2.0.1"></a>
## [2.0.1](https://nausp-aapp0001.aceins.com/Digital-CRUX/crux-frontend/compare/v1.0.0...v2.0.1) (2019-01-04)


### Bug Fixes

* **Dependencies:** Point dependencies to exact version instead of caret in package.json (DCRUX-479) ([c952e4b](https://nausp-aapp0001.aceins.com/Digital-CRUX/crux-frontend/commits/c952e4b))
* **Dependencies:** Update Prettier Ignore (DCRUX-479) ([8cf7323](https://nausp-aapp0001.aceins.com/Digital-CRUX/crux-frontend/commits/8cf7323))
* **Dependencies:** Update Prettier Ignore (DCRUX-479) ([58443aa](https://nausp-aapp0001.aceins.com/Digital-CRUX/crux-frontend/commits/58443aa))


### Features

* **CRUX v2:** Upgrade CRUX Frontend to Angular 6 ([#15](https://nausp-aapp0001.aceins.com/Digital-CRUX/crux-frontend/issues/15)) ([7bd5443](https://nausp-aapp0001.aceins.com/Digital-CRUX/crux-frontend/commits/7bd5443))
* **DCRUX-499:** Add Chubb fonts, remove Google fonts, update crux-themes ([#16](https://nausp-aapp0001.aceins.com/Digital-CRUX/crux-frontend/issues/16)) ([36770be](https://nausp-aapp0001.aceins.com/Digital-CRUX/crux-frontend/commits/36770be))
* **Version:** Add ability to generate version from package.json and use it within the app (DCRUX-555) ([3b8911b](https://nausp-aapp0001.aceins.com/Digital-CRUX/crux-frontend/commits/3b8911b))



<a name="2.0.0"></a>
# [2.0.0](https://nausp-aapp0001.aceins.com/Digital-CRUX/crux-frontend/compare/v2.0.0-rc.0...v2.0.0) (2018-11-19)


<a name="2.0.0-rc.0"></a>
# [2.0.0-rc.0](https://nausp-aapp0001.aceins.com/na-digital-apps/crux-frontend/compare/v0.2.5...v2.0.0-rc.0) (2018-11-08)


### Features

* **DCRUX-482:** Upgrade CRUX-Frontend to Angular 6 ([b28e5b0](https://nausp-aapp0001.aceins.com/na-digital-apps/crux-frontend/commits/b28e5b0))
* **Dependencies:** Point to exact version of dependencies instead of caret ([96a43dd](https://nausp-aapp0001.aceins.com/na-digital-apps/crux-frontend/commits/96a43dd))


<a name="1.0.0"></a>
# [1.0.0](https://nausp-aapp0001.aceins.com/na-digital-apps/crux-frontend/compare/v0.2.5...v1.0.0) (2018-10-29)


### Features

* **Repo Manager:** Add Nexus registry and point CRUX Artifacts from Nexus ([ed30a3e](https://nausp-aapp0001.aceins.com/na-digital-apps/crux-frontend/commits/ed30a3e))



<a name="0.2.5"></a>
## [0.2.5](https://nausp-aapp0001.aceins.com/na-digital-apps/crux-frontend/compare/v0.2.4...v0.2.5) (2018-10-17)



<a name="0.2.4"></a>
## [0.2.4](https://nausp-aapp0001.aceins.com/na-digital-apps/crux-frontend/compare/v0.2.3...v0.2.4) (2018-09-26)


### Bug Fixes

* **Bundling Issues:** Fix bundle issues due to TypeScript version incompatibility ([0970e2d](https://nausp-aapp0001.aceins.com/na-digital-apps/crux-frontend/commits/0970e2d))



<a name="0.2.3"></a>
## [0.2.3](https://nausp-aapp0001.aceins.com/na-digital-apps/crux-frontend/compare/v0.2.2...v0.2.3) (2018-08-07)


### Features

* **Analytics:** Add GA & GTM script as part of Frontend ([b39355f](https://nausp-aapp0001.aceins.com/na-digital-apps/crux-frontend/commits/b39355f))



<a name="0.2.2"></a>
## [0.2.2](https://nausp-aapp0001.aceins.com/na-digital-apps/crux-frontend/compare/v0.2.0...v0.2.2) (2018-07-20)


### Features

* **Mock Server:** Add ability to run mock server alongside webpack dev server (using Concurrently) ([bc45697](https://nausp-aapp0001.aceins.com/na-digital-apps/crux-frontend/commits/bc45697))



<a name="0.2.1"></a>
## [0.2.1](https://nausp-aapp0001.aceins.com/na-digital-apps/crux-frontend/compare/v0.2.0...v0.2.1) (2018-06-12)


### Features

* **Mock Server:** Add ability to run mock server alongside webpack dev server (using Concurrently) ([c762575](https://nausp-aapp0001.aceins.com/na-digital-apps/crux-frontend/commits/c762575))



<a name="0.2.0"></a>
# [0.2.0](https://nausp-aapp0001.aceins.com/na-digital-apps/crux-frontend/compare/v0.1.6...v0.2.0) (2018-05-21)


### Features

* Add script to remove CRUX dependencies from package.json as pre-commit hook ([133238d](https://nausp-aapp0001.aceins.com/na-digital-apps/crux-frontend/commits/133238d))



<a name="0.1.6"></a>
## [0.1.6](https://nausp-aapp0001.aceins.com/na-digital-apps/crux-frontend/compare/v0.1.4...v0.1.6) (2018-05-08)


### Bug Fixes

* Add links to Material Icons & Roboto Font ([20f3fbf](https://nausp-aapp0001.aceins.com/na-digital-apps/crux-frontend/commits/20f3fbf))



<a name="0.1.5"></a>
## [0.1.5](https://nausp-aapp0001.aceins.com/na-digital-apps/crux-frontend/compare/v0.1.4...v0.1.5) (2018-05-08)


### Bug Fixes

* Add links to Material Icons & Roboto Font ([20f3fbf](https://nausp-aapp0001.aceins.com/na-digital-apps/crux-frontend/commits/20f3fbf))



<a name="0.1.4"></a>
## [0.1.4](https://nausp-aapp0001.aceins.com/na-digital-apps/crux-frontend/compare/v0.1.3...v0.1.4) (2018-05-01)



<a name="0.1.3"></a>
## [0.1.3](https://nausp-aapp0001.aceins.com/na-digital-apps/crux-frontend/compare/v0.1.2...v0.1.3) (2018-04-23)


### Bug Fixes

* Update docs to manually add dependencies to CRUX ([d090294](https://nausp-aapp0001.aceins.com/na-digital-apps/crux-frontend/commits/d090294))


### Features

* Remove CRUX dependencies ([da031a0](https://nausp-aapp0001.aceins.com/na-digital-apps/crux-frontend/commits/da031a0))



<a name="0.1.2"></a>
## [0.1.2](https://nausp-aapp0001.aceins.com/na-digital-apps/crux-frontend/compare/v0.1.1...v0.1.2) (2018-04-17)


### Features

* Add Jest for unit testing ([e444f9b](https://nausp-aapp0001.aceins.com/na-digital-apps/crux-frontend/commits/e444f9b))
* Add sample test for AppComponent using Jest ([ffaecac](https://nausp-aapp0001.aceins.com/na-digital-apps/crux-frontend/commits/ffaecac))



<a name="0.1.1"></a>
## 0.1.1 (2018-04-17)


### Features

* Add a Card and Footer as part of base project ([eeded26](https://nausp-aapp0001.aceins.com/na-digital-apps/crux-frontend/commits/eeded26))
* Update README ([5c714f5](https://nausp-aapp0001.aceins.com/na-digital-apps/crux-frontend/commits/5c714f5))


<a name="0.0.1"></a>
## 0.0.1 (2018-04-17)
