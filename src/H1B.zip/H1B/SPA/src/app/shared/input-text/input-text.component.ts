import {
  AfterViewInit,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  ElementRef,
  EventEmitter,
  Input,
  NgZone,
  Output,
  ViewChild,
} from '@angular/core';
import { fromEvent } from 'rxjs';
import Utilities from '../utilities';

@Component({
  selector: 'cb-input-text',
  templateUrl: './input-text.component.html',
  styleUrls: ['./input-text.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class InputTextComponent implements AfterViewInit {
  @Input() className: string;
  @Input() value = '';
  @Input() maxLength: number;
  @Input() name = 'defaultText';
  @Input() placeholder = '';
  @Input() onlyNumbers = false;
  @Output() change = new EventEmitter<string>();
  @Input() leftIcon: string;
  @Input() rightIcon: string;
  @Input() placeholderPrefix: string;

  @ViewChild('input') private input: ElementRef<HTMLInputElement>;

  constructor(private zone: NgZone, private cdRef: ChangeDetectorRef) {}

  ngAfterViewInit() {
    this.handleEdgeClearIcon();
    this.cdRef.markForCheck();
  }

  handleChange(value: string) {
    this.value = value;
    this.change.next(value);
    return false;
  }

  keyPressHandler(event) {
    this.handleChange(event.target.value);
  }

  focusInput() {
    this.input.nativeElement.focus();
  }

  hasValue() {
    return (
      !!this.value &&
      this.value.length > 0 &&
      Array.from(this.value).filter((v) => !!v).length > 0
    );
  }

  private handleEdgeClearIcon() {
    if (!Utilities.isEdge) {
      return;
    }

    // in IE11 clear icon fires 'input' event, but not in Edge, so handle 'mouseup' and check if value became empty
    this.zone.runOutsideAngular(() => {
      fromEvent(this.input.nativeElement, 'mouseup').subscribe((e: any) => {
        if (!this.input.nativeElement.value) {
          return;
        }

        setTimeout(() => {
          if (!this.input.nativeElement.value) {
            this.handleChange('');
            this.cdRef.detectChanges();
          }
        });
      });
    });
  }
}
