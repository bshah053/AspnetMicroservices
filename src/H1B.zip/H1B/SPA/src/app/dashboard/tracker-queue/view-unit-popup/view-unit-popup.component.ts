import { Component, OnInit, Inject, HostListener } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { User } from 'user/user.model';
import { ReportingService } from '../../../tracking-reporting/services/reporting.service';

@Component({
  selector: 'cb-view-unit-popup',
  templateUrl: './view-unit-popup.component.html',
  styleUrls: ['./view-unit-popup.component.scss'],
})
export class ViewUnitPopupComponent implements OnInit {
  selectedCompanies: Array<string> = [];
  selectedDivisions: Array<string> = [];
  name = 'View Unit';
  ViewUnitLiastList: any = [];
  userID: string;

  constructor(
    private reportingService: ReportingService,
    public dialogRef: MatDialogRef<ViewUnitPopupComponent>,
    @Inject(MAT_DIALOG_DATA) public user: User
  ) {}

  @HostListener('window:keyup.esc')
  onKeyUp() {
    this.dialogRef.close();
  }

  ngOnInit() {
    if (this.user && this.user.UserID) {
      this.fetchUnitData();
    }
  }

  handleCancel() {
    this.dialogRef.close();
  }

  fetchUnitData() {
    this.reportingService
      .getDivisionUnits(
        this.selectedCompanies,
        this.selectedDivisions,
        this.user.UserID
      )
      .subscribe((data) => (this.ViewUnitLiastList = data));
  }
}
