import { Component, OnInit } from '@angular/core';
import { Select } from '@ngxs/store';
import { combineLatest, Observable, Subscription } from 'rxjs';
import { finalize, tap } from 'rxjs/operators';
import { AccountingYearMonth, AccountingYearMonthState } from 'store/accounting-month-year.store';
import { ListItem } from '../../shared/radio-list/radio-list.component';
import { MonthName, ReportsHeaderModel } from '../../tracking-reporting/reports/reports-header/store/reports-header.model';
import { User } from '../../user/user.model';
import { UserState } from '../../user/user.store';
import { UrlHelper } from '../../utilities/url.helper';
import { DashboardService } from '../dashboard.service';
import Utilities, { RoutedFrom } from '../../shared/utilities';
import { Router, ActivatedRoute } from '@angular/router';
import { FilterWatchService } from '../../services/filter-watch.service';
import { ReportingService } from '../../tracking-reporting/services/reporting.service';
import { SharedService } from '../../services/shared.service';
import { FilterType, InputPageService } from '../../input-page/services/input-page.service';
import { UWGeniusQueueDetails } from '../../input-page/models/common/uw-genius-queue-details';
import { UnitSegmentDetailsItem } from '../../input-page/models/common/unit-segment-details-item';
import { MatDialog } from '@angular/material/dialog';
import { ViewUnitPopupComponent } from './view-unit-popup/view-unit-popup.component';

@Component({
  selector: 'cb-tracker-queue',
  templateUrl: './tracker-queue.component.html',
  styleUrls: ['./tracker-queue.component.scss'],
})
export class TrackerQueueComponent implements OnInit {
  @Select(UserState) public user$: Observable<User>;
  @Select(AccountingYearMonthState)
  public accountingYearMonth$: Observable<AccountingYearMonth>;

  user: User;
  accountingYearMonth: AccountingYearMonth;
  currentFilters: ReportsHeaderModel;
  trackerQueue: any;
  trackerQueueSubscription: any;
  currentDate = '';
  timeframe = 'MTD';
  value: string;
  openMonth = false;
  openYear = false;
  preselected: number;
  showCurrentDate = true;
  selected;
  years = [];
  forecast: any = '';
  orderBy = '';
  sortBy = '';

  loading = true;
  error = null;
  confidence: Array<ListItem> = [];
  selectConfidence = [];
  totalForecast = 0;
  totalCount = '';
  geniusCount: number = 0;
  ShowGeniusCount: boolean = false;
  addCommaToNumber = Utilities.addCommasToNumber;
  isExpanded = false;
  selectUnitURL: string;
  geniusURL: string;
  monthNames: MonthName[] = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

  range = ['=', '>', '<', '>=', '<='];
  selectRange = '=';
  sortedObjValue = {};
  unitSegmentList: FilterType[];
  submissionvisibility = 'T1';
  sharedService$: Subscription;

  constructor(private router: Router, private filterWatch: FilterWatchService, private dashboardService: DashboardService, private reportingService: ReportingService, private route: ActivatedRoute, private sharedService: SharedService, private inputPageService: InputPageService, public dialog: MatDialog) {
    combineLatest([this.user$, this.accountingYearMonth$]).subscribe(([user, accountingYearMonth]) => {
      this.user = user;
      this.accountingYearMonth = { ...accountingYearMonth };

      // generate list of years
      const min = accountingYearMonth.AccountingYear - 10;
      const max = accountingYearMonth.AccountingYear + 5;
      for (let i = min; i >= min && i <= max; i++) {
        this.years.push(i);
      }

      const filter = this.route.snapshot.queryParams.filters;

      if (filter) {
        const storedFilters = this.filterWatch.getByHash(filter);
        this.getTrackerQueue(storedFilters, false);
      } else {
        this.getTrackerQueue(null, false);
      }
      this.confidence = [
        { value: '0', text: '0' },
        { value: '1', text: '1' },
        { value: '2', text: '2' },
        { value: '3', text: '3' },
        { value: '4', text: '4' },
        { value: '5', text: '5' },
        { value: '6', text: '6' },
        { value: '7', text: '7' },
        { value: '8', text: '8' },
        { value: '9', text: '9' },
        { value: '10', text: '10' },
      ];
    });
  }

  ngOnInit() {
    // this.sharedService.showLoading$.subscribe();
    this.getGeniusSubmissionCount(this.user.UserID);
    this.getSubmissionVisibilityByUserID();
    // this.getUnitSegmentDetailsByUserID();
    this.selectUnitURL = UrlHelper.selectUnitURL();
    this.sharedService$ = this.sharedService.setTQReloadRequest().subscribe((result) => {
      this.submitClickHandler(true);
    });
  }

  serializeData(data: string[] = []): ListItem[] {
    return data.map((i) => ({ text: i, value: i }));
  }

  toggleChild() {
    this.isExpanded = !this.isExpanded;
  }

  get allMonth() {
    return this.serializeData(this.monthNames);
  }

  get allRange() {
    return this.serializeData(this.range);
  }

  get allYears() {
    return this.serializeData(this.years);
  }

  get isNotDynamicUser() {
    return this.user['DynamicUser'] === 'No';
  }

  get isUserTypeU() {
    return this.user['UserType'] === 'Underwriter';
  }

  handleRangeSelection(item) {
    this.selectRange = item.value;
  }

  getGeniusSubmissionCount(UserID) {
    console.log(UserID);
    this.dashboardService.getGeniusSubmissionsCount(UserID).subscribe((data: any) => {
      if (data != null) {
        this.geniusCount = data;
        if (this.geniusCount > 0) {
          this.ShowGeniusCount = true;
          this.geniusSubmissions();
        }
      }
    });
  }

  getTrackerQueue(hashFilter, isReload) {
    const payload = hashFilter ? this.generatePayloadFormFilter(hashFilter) : this.generatePayload();
    this.loading = true;
    this.trackerQueue = null;
    this.error = null;
    if (isReload && this.orderBy && this.sortBy) {
      payload.OrderBy = this.sortBy;
      payload.SortBy = this.orderBy;
    } else {
      payload.OrderBy = '';
      payload.SortBy = '';
    }

    this.dashboardService
      .getTrackerQueue(payload)
      .pipe(
        tap((data) => {
          if (data !== null) {
            this.trackerQueue = data;

            if (this.trackerQueue.length === 1) {
              this.totalForecast = this.trackerQueue[0].GrossForecast;
              this.totalCount = this.trackerQueue[0].Details.RecordNo;
              this.trackerQueue = [];
              this.error = true;
            } else {
              this.totalForecast = this.trackerQueue[this.trackerQueue.length - 1].GrossForecast;
              this.totalCount = 'Count(' + this.trackerQueue[this.trackerQueue.length - 1].Details.RecordNo + ')';
            }

            if (this.trackerQueue.length > 1) {
              this.trackerQueue.splice(-1, 1);
            }
          }
        }),
        finalize(() => (this.loading = false))
      )
      .subscribe(
        () => {},
        (err) => {
          this.error = err;
        }
      );
  }

  private generatePayloadFormFilter(filters) {
    filters.Confidence = filters.ConfidenceFactor;
    this.selectConfidence = filters.Confidence;
    this.selectRange = filters.Range;
    this.accountingYearMonth.AccountingMonth = filters.AccountMonth;
    this.accountingYearMonth.AccountingYear = filters.AccountYear;
    this.timeframe = filters.TimeFrame;
    this.forecast = filters.Forecast;
    return filters;
  }

  private generatePayload() {
    return {
      UserID: this.user.UserID,
      AccountMonth: this.accountingYearMonth.AccountingMonth,
      AccountYear: this.accountingYearMonth.AccountingYear,
      TimeFrame: this.timeframe,
      CreditedRegion: [''],
      CreditedBranch: [''],
      UnderwriterName: [''],
      UnderwriterLANID: '',
      CompanyName: [''],
      Division: [''],
      Unit: [''],
      Range: this.forecast === undefined || this.forecast === '' ? '' : this.selectRange,
      Segment: [''],
      Confidence: this.selectConfidence,
      ConfidenceFactor: this.selectConfidence,
      Forecast: this.forecast === undefined || this.forecast === '' ? 0 : this.forecast,
      ProducerName: [''],
      ProducerRegion: [''],
      ProducerBranch: [''],
      ProducerCode: [''],
      UWBranch: [''],
      UWRegion: [''],
      PolicyNumber: [''],
      RecordNo: 0,
      PageNumber: 1,
      PageSize: 0,
      SortBy: '',
      OrderBy: '',
    };
  }

  get isOpenedYear(): boolean {
    return this.openYear;
  }

  get isOpenedMonth(): boolean {
    return this.openMonth;
  }

  handleToggleOpenMonth(): void {
    this.openMonth = !this.openMonth;
  }

  handleToggleOpenYear(): void {
    this.openYear = !this.openYear;
  }

  handleHide(): void {
    // this.open = false;
  }

  onSelectedValuesChange(event) {
    this.selectConfidence = event;
    // this.getTrackerQueue();
  }

  handleSelection(item, type): void {
    this[type] = item.frame || item.value;
  }

  handleMonthYearSelection(item, type) {
    this.accountingYearMonth[type] = item.value;
  }

  makeDateFilterSelection(item) {
    return {
      month: this.accountingYearMonth.AccountingMonth,
      year: this.accountingYearMonth.AccountingYear,
      frame: item.value,
    };
  }

  setSelectedValues(selectedValues) {}

  onForecastInputChange(value) {
    this.forecast = '';
    if (value !== '') {
      this.forecast = parseInt(value.replace(/,/g, '').trim() || 0, 10);
    }
  }

  outsideClick() {
    if (this.isExpanded) {
      this.isExpanded = false;
    }
  }

  submitClickHandler(isReload) {
    this.getTrackerQueue(null, isReload);
    this.isExpanded = false;
  }

  addNewRecord() {
    this.ToAviationSubmissionPage();
    // if (this.unitSegmentList && this.unitSegmentList.length === 1) {
    //   this.handleNavigation();
    // } else {
    //   this.router.navigate(['/submission/select-unit-segment']);
    // }
  }

  viewUnitDetails() {
    const dialogRef = this.dialog.open(ViewUnitPopupComponent, {
      width: '330px',
      data: this.user,
      hasBackdrop: true,
      backdropClass: 'backdropBackground',
    });

    dialogRef.afterClosed().subscribe((data) => {
      if (data) {
      }
    });
  }

  private ToAviationSubmissionPage() {
    const payload = <ReportsHeaderModel>{
      Division: ['CGM'],
      Unit: ['Aviation'],
      Segment: ['Aviation'],
      UserID: this.user.UserID,
      UnderwriterName: [this.user.UserID],
      GeniusPipeID: 0,
      IsGenius: 'N',
      DYN: 'Y',
      IYN: 'N',
      LYNE: 'N',
    };

    const serializedFilters = this.filterWatch.serializeFromPayload(payload);
    this.router.navigate(['/submission/input-page'], {
      queryParams: {
        filters: this.filterWatch.create(serializedFilters),
        routedFrom: RoutedFrom.SelectUnit,
      },
    });
  }

  get isAddNewVisible() {
    return this.submissionvisibility === 'T1' || this.submissionvisibility === 'T1T2';
  }

  get isAviationAddNewVisible() {
    return this.submissionvisibility === 'T2' || this.submissionvisibility === 'T1T2';
  }

  geniusSubmissions() {
    this.geniusURL = UrlHelper.geniusURL();
  }

  accountBulkUpdateHandler() {
    let payload: any;
    payload = {
      ...this.generatePayload(),
      BulkUpdateReportName: 'Tracker Queue',
    };

    const serializedFilters = this.filterWatch.serializeFromPayload(<ReportsHeaderModel>{
      ...payload,
    });

    this.router.navigate(['/tracking-and-reporting/account-bulk-update'], {
      queryParams: {
        filters: this.filterWatch.create(serializedFilters),
      },
    });
  }

  // handleDelete(recordNo) {
  //   this.sharedService.sendShowLoading();
  //   this.reportingService.deleteTransactionByRecordNo(recordNo, this.user.UserID).subscribe((data: any) => {
  //     if (data != null) {
  //       this.submitClickHandler(true);
  //     } else {
  //       console.log('There is an issue while deleting the record!!!');
  //     }
  //     this.sharedService.sendHideLoading();
  //   });
  // }

  // handleCopy(recordNo) {
  //   this.sharedService.sendShowLoading();
  //   this.reportingService.copySubmission(recordNo, this.user.UserID).subscribe((data: any) => {
  //     if (data != null) {
  //       this.submitClickHandler(true);
  //     } else {
  //       console.log('There is an issue while copying the record!!!');
  //     }
  //     this.sharedService.sendHideLoading();
  //   });
  // }

  handleSavePostMortem(postMertemObj) {
    this.sharedService.sendShowLoading();
    this.reportingService.savePostMortemByRecordNo(postMertemObj).subscribe((data: any) => {
      if (data != null) {
        this.submitClickHandler(true);
      } else {
        console.log('There is an issue while updating post mortem details the record!!!');
      }
      this.sharedService.sendHideLoading();
    });
  }

  handleSortedObj($event) {
    this.orderBy = $event && $event.column ? $event.column : '';
    this.sortBy = $event && $event.direction ? $event.direction : '';
    this.sortedObjValue = $event;
  }

  getUnitSegmentDetailsByUserID() {
    this.unitSegmentList = null;
    this.inputPageService.getUnitSegmentDetailsByUserID(this.user.UserID).subscribe((data: UnitSegmentDetailsItem[]) => {
      if (data !== null) {
        this.unitSegmentList = data.map((filter: { Unit: string; UnitValue: string }) => {
          return {
            text: filter.Unit,
            value: filter.UnitValue,
          };
        });
      } else {
        this.unitSegmentList = null;
      }
    });
  }

  getSubmissionVisibilityByUserID() {
    this.inputPageService.getSubmissionVisibilityByUserID(this.user.UserID).subscribe(
      (data: string) => {
        if (data !== null) {
          this.submissionvisibility = data;
        } else {
          this.submissionvisibility = 'T1';
        }
      },
      (err) => {
        console.error(err);
        this.submissionvisibility = 'T1';
      }
    );
  }

  handleNavigation() {
    const queryParams = this.unitSegmentList[0].value.split('*');
    if (queryParams != null && queryParams.length > 0) {
      if (queryParams && queryParams.length === 9 && queryParams[8].trim() === 'T1') {
        this.navigateToInputPage(queryParams);
      } else {
        this.navigateToSubmissionPage(queryParams);
      }
    }
  }

  private navigateToSubmissionPage(queryParams: string[]) {
    const payload = <ReportsHeaderModel>{
      Division: [queryParams[0] ? queryParams[0].trim() : ''],
      Unit: [queryParams[1] ? queryParams[1].trim() : ''],
      Segment: [queryParams[2] ? queryParams[2].trim() : ''],
      UnderwriterName: [this.user.UserID],
      GeniusPipeID: 0,
      IsGenius: 'N',
      DYN: queryParams[4] ? queryParams[4].trim() : '',
      IYN: queryParams[5] ? queryParams[5].trim() : '',
      LYNE: queryParams[6] ? queryParams[6].trim() : '',
    };
    // console.log(payload);
    const serializedFilters = this.filterWatch.serializeFromPayload(payload);
    this.router.navigate(['/submission/input-page'], {
      queryParams: {
        filters: this.filterWatch.create(serializedFilters),
        routedFrom: RoutedFrom.TrackerQueue,
      },
    });
  }

  private navigateToInputPage(queryParams: string[]) {
    const redirectUrlQueryParams = UrlHelper.generateInputPageQueryParams(queryParams);

    if (redirectUrlQueryParams !== '') {
      const redirectUrl = UrlHelper.getInputPageLink(redirectUrlQueryParams);
      console.log(redirectUrl);
      window.open(redirectUrl, '_blank');
    }
  }
}
