import { Component, Input, TemplateRef, ViewChild, OnChanges, AfterViewInit, Output, EventEmitter, SimpleChange } from '@angular/core';
import { ColDef } from 'ag-grid-community';
import { UrlHelper } from '../../../../utilities/url.helper';
import { ContactsActivitiesHelper } from '../../../../utilities/contacts-activities.helper';
import { AgGridTemplateRendererComponent } from '../../../../shared/ag-grid-utils/ag-grid-template-renderer.component';
import Utilities from '../../../../shared/utilities';
import { ModalService } from '../../../../shared/modal/modal.service';
import { NavigationService } from '../../../../services/navigation.service';
import { User } from '../../../../user/user.model';
import { ContactDetails } from '../contact-search.service';
import { ISaveReportAs } from '../../../../contacts-activities/models/saveReports';

@Component({
	selector: 'cb-contacts-search-table',
	templateUrl: './contacts-search-table.component.html',
	styleUrls: ['./contacts-search-table.component.scss'],
})
export class ContactsSearchTableComponent implements AfterViewInit {
	@Input() contacts: ContactDetails[];
	@Input() error: string;
	@Input() user: User;
	@Input() savedReportId: number;
	@Input() totalcounts: number;
	@Output() resort = new EventEmitter();
	@Output() saveReport = new EventEmitter<ISaveReportAs>();
	@Output() loadedReport = new EventEmitter<ISaveReportAs>();
	@Output() exportReport: EventEmitter<any> = new EventEmitter();

	@ViewChild('nameCell', { static: true })
	private nameCell: TemplateRef<any>;
	@ViewChild('accountNameCell', { static: true })
	private accountNameCell: TemplateRef<any>;
	@ViewChild('phoneNumberCell', { static: true })
	private phoneNumberCell: TemplateRef<any>;

	name = 'Contact Search';

	columns: ColDef[];

	ngAfterViewInit(): void {
		this.columns = [
			{
				headerName: 'FullName',
				headerTooltip: 'FullName',
				field: 'FullName',
				tooltipValueGetter: (params) => params.value,
				width: 208,
				suppressSizeToFit: true,
				cellRendererFramework: AgGridTemplateRendererComponent,
				cellRendererParams: { ngTemplate: this.nameCell },
			},
			{
				headerName: 'Account Name',
				headerTooltip: 'Account Name',
				field: 'AccountName',
				tooltipValueGetter: (params) => params.value,
				width: 310,
				suppressSizeToFit: true,
				cellRendererFramework: AgGridTemplateRendererComponent,
				cellRendererParams: { ngTemplate: this.accountNameCell },
			},
			{
				headerName: 'Role',
				field: 'Type',
				headerTooltip: 'Role',
				tooltipValueGetter: (params) => params.value,
				width: 160,
				suppressSizeToFit: true,
				sortable: true,
			},
			{
				headerName: 'Phone',
				field: 'BusinessNumber',
				width: 151,
				suppressSizeToFit: true,
				sortable: false,
				cellRendererFramework: AgGridTemplateRendererComponent,
				cellRendererParams: { ngTemplate: this.phoneNumberCell },
			},

			{
				headerName: 'Email',
				field: 'Email',
				width: 300,
				suppressSizeToFit: true,
			},

			{
				headerName: 'Address',
				field: 'FullAddress',
				tooltipValueGetter: (params) => params.value,
				width: 200,
				suppressSizeToFit: false,
				cellClass: 'address-cell',
			},
			{
				headerName: 'Region',
				field: 'Region',
				tooltipValueGetter: (params) => params.value,
				width: 150,
				suppressSizeToFit: true,
			},
			{
				headerName: 'Branch',
				field: 'Branch',
				tooltipValueGetter: (params) => params.value,
				width: 150,
				suppressSizeToFit: true,
			},

			{
				headerName: 'Chubb Business Unit',
				field: 'ChubbMarketSegment',
				tooltipValueGetter: (params) => params.value,
				width: 150,
				suppressSizeToFit: true,
			},
			{
				headerName: 'Product Specialization',
				field: 'ProductSpecialization',
				tooltipValueGetter: (params) => params.value,
				width: 150,
				suppressSizeToFit: true,
			},
			{
				headerName: 'Industry Specialization',
				field: 'IndustrySpecialization',
				tooltipValueGetter: (params) => params.value,
				width: 150,
				suppressSizeToFit: true,
			},
			{
				headerName: 'Cornerstone',
				field: 'Cornerstone',
				tooltipValueGetter: (params) => params.value,
				width: 150,
				suppressSizeToFit: true,
			},
		];
	}

	constructor(private modalService: ModalService, private navigation: NavigationService) {}

	openByName(row) {
		const url = UrlHelper.dynamicsEditContactUrl(row.ContactGUID);
		this.openPopup(url);
	}

	openByAccountName(row) {
		debugger;
		ContactsActivitiesHelper.openRelatedTo(row, this.navigation);
	}

	addNewContact() {
		const url = UrlHelper.dynamicsContactUrl();
		this.openPopup(url);
	}

	openPopup(url) {
		this.modalService.openBrowserWindow(url);
	}

	formatPhoneNumber(phoneNumber: string) {
		return Utilities.formatPhoneNumber(phoneNumber);
	}

	handleSortChanged(sort: { column: string; direction: 'asc' | 'desc' }) {
		this.resort.next(sort);
	}

	handleSaveReport(data: ISaveReportAs) {
		this.saveReport.next(data);
	}

	exportReportHandler($event) {
		this.exportReport.emit({
			ExportType: $event,
			ScreenName: 'Contact-Search',
		});
	}

	handleLoadReport(data: ISaveReportAs) {
		this.loadedReport.next(data);
	}
}
