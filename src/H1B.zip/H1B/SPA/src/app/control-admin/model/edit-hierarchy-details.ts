export interface EditHierarchyDetails {
  HierarchyDetails: HierarchyItems[];
  SelectedHierarchyDetails: HierarchyItems;
}

export interface HierarchyItems {
  UserID?: string;
  Division?: string;
  Units?: string;
  Segments?: string;
}
