import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { FilteredCheckboxListComponent } from './filtered-checkbox-list.component';

describe('FilteredCheckboxListComponent', () => {
	let component: FilteredCheckboxListComponent;
	let fixture: ComponentFixture<FilteredCheckboxListComponent>;

	beforeEach(
		waitForAsync(() => {
			TestBed.configureTestingModule({
				declarations: [FilteredCheckboxListComponent],
			}).compileComponents();
		})
	);

	beforeEach(() => {
		fixture = TestBed.createComponent(FilteredCheckboxListComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
