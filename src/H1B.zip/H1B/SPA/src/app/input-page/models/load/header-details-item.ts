export interface HeaderDetailsItem {
  UserInsuredName: string;
  RecordNumberYN: string;
  RecordNumber?: number;
  ScheduleNumberYN: string;
  ScheduleNumber?: number;
  SubmissionIDYN: string;
  SubmissionID: string;
  EscalateYN: string;
  AuditTrailYN: string;
}
