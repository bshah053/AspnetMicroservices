import { Component, OnInit, OnDestroy, Inject } from '@angular/core';
import { Event, NavigationCancel, NavigationEnd, NavigationError, NavigationStart, Router } from '@angular/router';
import { MsalService, MsalBroadcastService, MSAL_GUARD_CONFIG, MsalGuardConfiguration } from '@azure/msal-angular';
import { AuthenticationResult, InteractionStatus, PopupRequest, RedirectRequest } from '@azure/msal-browser';
import { combineLatest, Observable, Subject, Subscription } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';

import { VERSION } from './version';
import { User } from './user/user.model';
import { Store, Select } from '@ngxs/store';
import { SetUser } from './user/user.actions';
import { UserState } from './user/user.store';
import { AccountingYearMonth, AccountingYearMonthState, SetAccountingYearMonth } from './store/accounting-month-year.store';
import { UserService } from './user/user.service';
import { SharedService } from 'services/shared.service';
import { Helper } from 'utilities/common-helper';
import { NavigationService } from 'services/navigation.service';
import { UrlService } from 'services/url.service';
import { ReportBtnEntitiesState } from 'shared/report-tabs/store/report-entity.store';
import { IReportBtn } from 'shared/report-tabs/store/report-entity.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'Tracker 2';
  isIframe = false;
  loginDisplay = false;
  version = VERSION;
  private readonly _destroying$ = new Subject<void>();
  userID: string;
  user: User;
  email = '';
  routeParams: Object;
  previousUrl: string = null;
  currentUrl: string = null;
  @Select(UserState) public user$: Observable<User>;
  @Select(AccountingYearMonthState) public accountingYearMonth$: Observable<AccountingYearMonth>;
  @Select(ReportBtnEntitiesState.getAll) public allReports$: Observable<IReportBtn[]>;
  @Select(ReportBtnEntitiesState.getKeyReports) public keyReports$: Observable<IReportBtn[]>;
  subscriptionUser$: Subscription;
  subscriptionAccountingYearMonth$: Subscription;
  allReportsRoutes: IReportBtn[] = [];
  keyReportsRoutes: IReportBtn[] = [];
  queryParams = {};
  isHeaderVisibile: boolean = true;

  constructor(@Inject(MSAL_GUARD_CONFIG) private msalGuardConfig: MsalGuardConfiguration, private authService: MsalService, private msalBroadcastService: MsalBroadcastService, private navigation: NavigationService, private userService: UserService, private store: Store, private router: Router, private sharedService: SharedService, private urlService: UrlService) {
    combineLatest([this.user$]).subscribe(([user]) => {
      this.user = user;
    });
    this.navigationInterceptor();
    this.sharedService.setHeaderVisibilityStatus().subscribe((result) => {
      if (result) {
        this.isHeaderVisibile = false;
      } else {
        this.isHeaderVisibile = true;
      }
    });
  }

  ngOnInit(): void {
    Promise.resolve().then(() => {
      this.isIframe = window !== window.parent && !window.opener;
      this.msalBroadcastService.inProgress$
        .pipe(
          // Filtering for all interactions to be completed
          filter((status: InteractionStatus) => status === InteractionStatus.None),
          takeUntil(this._destroying$)
        )
        .subscribe(() => {
          setTimeout(() => {
            if (!this.user || !this.user.Email) {
              this.getUserProfile();
              // this.getAllReports();
              // this.getKeyReports();
            }
            this.checkAndSetActiveAccount();
          }, 1);
        });
    });
    this.getAccountingYearMonth();
  }

  ngOnDestroy(): void {
    Promise.resolve().then(() => {
      this._destroying$.next(undefined);
      this._destroying$.complete();
    });
    if (this.subscriptionUser$) {
      this.subscriptionUser$.unsubscribe();
    }
    if (this.subscriptionAccountingYearMonth$) {
      this.subscriptionAccountingYearMonth$.unsubscribe();
    }
  }

  get userEmail() {
    if (this.authService.instance.getAllAccounts() && this.authService.instance.getAllAccounts().length > 0) {
      return this.authService.instance.getAllAccounts()[0].username;
    } else {
      return '';
    }
  }

  getAllReports(): void {
    this.allReports$.subscribe((reportList) => {
      this.allReportsRoutes = reportList;
      this.queryParams = this.makeQueryParams();
    });
  }

  getKeyReports(): void {
    this.keyReports$.subscribe((reportList) => {
      this.keyReportsRoutes = reportList;
      this.queryParams = this.makeQueryParams();
    });
  }

  makeQueryParams() {
    return { showBrowseBy: false, isReportLandingpage: true };
  }

  private navigationInterceptor(): void {
    this.setPreviousUrl();
    // this.setLodingProgress();
  }

  // private setLodingProgress() {
  //   this.router.events.subscribe((event: Event) => {
  //     switch (true) {
  //       case event instanceof NavigationStart: {
  //         this.sharedService.sendLoading(true);
  //         break;
  //       }
  //       case event instanceof NavigationEnd:
  //       case event instanceof NavigationCancel:
  //       case event instanceof NavigationError: {
  //         this.sharedService.sendLoading(false);
  //         break;
  //       }
  //       default: {
  //         this.sharedService.sendLoading(false);
  //         break;
  //       }
  //     }
  //   });
  // }

  private setPreviousUrl() {
    this.router.events.pipe(filter((event) => event instanceof NavigationEnd)).subscribe((event: NavigationEnd) => {
      this.previousUrl = this.currentUrl;
      this.currentUrl = event.url;
      this.urlService.setPreviousUrl(this.previousUrl);
    });
  }

  private getUserProfile() {
    if (Helper.isStringNotNullAndEmpty(this.userEmail)) {
      this.subscriptionUser$ = this.userService.getUserProfile(this.userEmail).subscribe(
        (data: User) => {
          if (data !== null) {
            this.user = data;
            this.store.dispatch(new SetUser(this.user));
          } else {
            this.navigation.toUnAuthorized();
          }
        },
        (err) => {
          console.error(err.error);
          this.navigation.toServerFailure();
        }
      );
    }
  }

  private getAccountingYearMonth() {
    this.subscriptionAccountingYearMonth$ = this.userService.getCurrentAccountingYearMonth().subscribe(
      (data) => {
        if (data !== null) {
          this.store.dispatch(new SetAccountingYearMonth(data as AccountingYearMonth));
        }
      },
      (err) => {
        console.error(err.error);
      }
    );
  }

  checkAndSetActiveAccount() {
    let activeAccount = this.authService.instance.getActiveAccount();
    if (!activeAccount && this.authService.instance.getAllAccounts().length > 0) {
      let accounts = this.authService.instance.getAllAccounts();
      this.authService.instance.setActiveAccount(accounts[0]);
    }
  }

  loginRedirect() {
    if (this.msalGuardConfig.authRequest) {
      this.authService.loginRedirect({
        ...this.msalGuardConfig.authRequest,
      } as RedirectRequest);
    } else {
      this.authService.loginRedirect();
    }
  }

  loginPopup() {
    if (this.msalGuardConfig.authRequest) {
      this.authService.loginPopup({ ...this.msalGuardConfig.authRequest } as PopupRequest).subscribe((response: AuthenticationResult) => {
        this.authService.instance.setActiveAccount(response.account);
      });
    } else {
      this.authService.loginPopup().subscribe((response: AuthenticationResult) => {
        this.authService.instance.setActiveAccount(response.account);
      });
    }
  }

  logout(popup?: boolean) {
    if (popup) {
      this.authService.logoutPopup({
        mainWindowRedirectUri: '/',
      });
    } else {
      this.authService.logoutRedirect();
    }
  }
}
