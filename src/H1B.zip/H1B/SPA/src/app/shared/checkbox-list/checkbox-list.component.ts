import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, Input, NgZone, OnChanges, OnInit, Output, SimpleChange } from '@angular/core';
import { ListItem } from '../radio-list/radio-list.component';
import Utilities from '../utilities';

@Component({
  selector: 'cb-checkbox-list',
  templateUrl: './checkbox-list.component.html',
  styleUrls: ['./checkbox-list.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CheckboxListComponent implements OnInit, OnChanges {
  @Input() className = 'checkbox-list';
  @Input() items: Array<ListItem>;
  @Input() selectedValues: Array<any> = [];
  @Input() disabledValues: Array<any> = [];
  @Output() selectedValuesChange = new EventEmitter<Array<any>>();
  @Input() segregated = false;
  @Input() singleSelect = false;

  viewItems: Array<ListItem>;
  firstUncheckedItem: ListItem;
  prefix = Utilities.shortId();
  selectedValuesMap = {}; // object lookup is faster than Map.has in IE

  constructor(private cdRef: ChangeDetectorRef, private zone: NgZone) {}

  ngOnInit() {}

  ngOnChanges(changes: { [key in keyof CheckboxListComponent]: SimpleChange }) {
    if (changes.selectedValues) {
      this.setSelectedValues(this.selectedValues);
    }
    if (changes.items || changes.selectedValues) {
      this.updateViewItems();
    }
  }

  handleSelectChange(ev: any) {
    const item = ev.value;

    if (ev.selected) {
      if (this.singleSelect) {
        this.selectedValuesMap = {};
        this.selectedValues.length = 0;
      }

      this.selectedValuesMap[item.value] = true;
      this.selectedValues.push(item.value);
    } else {
      delete this.selectedValuesMap[item.value];
      const index = this.selectedValues.indexOf(item.value);
      if (index !== -1) {
        this.selectedValues.splice(index, 1);
      }
    }
    this.selectedValuesChange.emit(this.selectedValues);

    this.updateViewItems();

    this.zone.runOutsideAngular(() => {
      setTimeout(() => this.cdRef.detectChanges());
    });
  }

  private updateViewItems() {
    this.items = this.items || [];

    if (this.segregated) {
      this.viewItems = [];
      const uncheckedItems = [];

      for (let i = 0, len = this.items.length; i < len; i++) {
        const item = this.items[i];
        if (this.selectedValuesMap[item.value]) {
          this.viewItems.push(item);
        } else {
          uncheckedItems.push(item);
        }
      }

      this.firstUncheckedItem = uncheckedItems[0];
      uncheckedItems.forEach((item) => this.viewItems.push(item));
    } else {
      this.viewItems = this.items;
      this.firstUncheckedItem = undefined;
    }
  }

  isSelected(item: ListItem): boolean {
    return this.selectedValuesMap[item.value];
  }

  setSelectedValues(selectedValues: Array<any>) {
    if (this.singleSelect && selectedValues && selectedValues.length > 1) {
      selectedValues = [selectedValues[0]];
    }

    this.selectedValues = selectedValues || [];
    this.selectedValuesMap = {};

    for (let i = 0, len = this.selectedValues.length; i < len; i++) {
      this.selectedValuesMap[this.selectedValues[i]] = true;
    }
  }

  trackByItem(index, item: ListItem): any {
    return item.value;
  }

  valueDisabled(value: string): boolean {
    return this.disabledValues && this.disabledValues.indexOf(value) > -1;
  }
}
