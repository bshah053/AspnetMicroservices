import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, Input, NgZone, OnChanges, OnDestroy, OnInit, Output, SimpleChange, ViewChild, ViewEncapsulation } from '@angular/core';
import { Subscription, timer } from 'rxjs';
import { debounce } from 'rxjs/operators';
import { CheckboxListComponent } from '../checkbox-list/checkbox-list.component';
import { InputTextComponent } from '../input-text/input-text.component';
import { ListItem } from '../radio-list/radio-list.component';
import Utilities from '../utilities';

@Component({
  selector: 'cb-filtered-checkbox-list',
  templateUrl: './filtered-checkbox-list.component.html',
  styleUrls: ['./filtered-checkbox-list.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FilteredCheckboxListComponent implements OnInit, OnDestroy, OnChanges {
  @Input() className: string;
  @Input() title: string;
  @Input() placeholder = 'Type name';
  @Input() items: Array<ListItem>;
  @Input() selectedValues: Array<any> = [];
  @Input() disabledValues: Array<any> = [];
  @Output() selectedValuesChange = new EventEmitter<Array<any>>();
  @Input() segregated = true;
  @Input() filterDebounce = 300;
  @Input() showFilter = true;
  @Input() showCheckAll = true;
  @Input() maxLength = 20;
  @Input() singleSelect = false;

  @ViewChild('inputFilter', { static: true })
  private inputFilter: InputTextComponent;
  @ViewChild(CheckboxListComponent, { static: true })
  private checkboxList: CheckboxListComponent;

  filterValue = '';
  filteredItems: Array<ListItem>;
  prefix = Utilities.shortId();

  private inputFilterSubscription: Subscription;

  constructor(private cdRef: ChangeDetectorRef, private zone: NgZone) {}

  ngOnInit() {
    this.subscribeFilter();
  }

  ngOnDestroy() {
    if (this.inputFilterSubscription) {
      this.inputFilterSubscription.unsubscribe();
    }
  }

  ngOnChanges(changes: { [key in keyof FilteredCheckboxListComponent]: SimpleChange }) {
    if (changes.items) {
      this.updateFilteredItems();
    }
  }

  private subscribeFilter() {
    this.inputFilterSubscription = this.inputFilter.change.pipe(debounce(() => timer(this.filterDebounce))).subscribe((filterValue) => {
      this.filterValue = filterValue;
      this.updateFilteredItems();
      this.cdRef.detectChanges();
    });
  }

  private updateFilteredItems() {
    if (this.filterValue && this.filterValue.length > 0) {
      const filterValue = this.filterValue.toLowerCase();

      this.filteredItems = this.items.filter((item) => this.checkboxList.isSelected(item) || item.text.toLowerCase().includes(filterValue));
    } else {
      this.filteredItems = this.items;
    }
  }

  get componentClass() {
    return ['filtered-checkbox-list', this.className].filter((s) => !!s).join(' ');
  }

  private setSelectedValues(selectedValues) {
    this.selectedValues = selectedValues;
    this.selectedValuesChange.emit(this.selectedValues);
  }

  handleSelectAll(selected = true) {
    const newSelectedValues = selected ? this.items.map((i) => i.value) : [];
    this.checkboxList.setSelectedValues(newSelectedValues);
    this.setSelectedValues(this.checkboxList.selectedValues);

    if (selected) {
      this.filteredItems = this.items;
    } else {
      // when ClearAll then we need update filteredItems according to user input
      this.updateFilteredItems();
    }
  }

  onSelectedValuesChange(selectedValues) {
    this.setSelectedValues(selectedValues);
    this.updateFilteredItems();

    this.zone.runOutsideAngular(() => {
      setTimeout(() => this.cdRef.detectChanges());
    });
  }

  isSelected(item: ListItem): boolean {
    return this.checkboxList.isSelected(item);
  }
}
