import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'cb-confirmation-dialog-box',
  templateUrl: './confirmation-dialog-box.component.html',
  styleUrls: ['./confirmation-dialog-box.component.scss'],
})
export class ConfirmationDialogBoxComponent implements OnInit {
  @Input() action: string;
  @Input() open;
  @Output() close = new EventEmitter<any>();
  isSelected;
  selectedAction: string;
  name = 'Confirmation Dialog Box';

  constructor() {}

  ngOnInit() {}

  get isOpened(): boolean {
    return this.open;
  }

  handleToggleOpen(): void {
    this.open = !this.open;
    if (this.open) {
      this.isSelected = true;
    } else {
      this.isSelected = false;
    }
  }

  handleHide(): void {
    if (this.isSelected !== undefined) {
      this.open = this.isSelected;
    }
  }

  handleCancel() {
    this.handleToggleOpen();
    this.close.emit('Cancel');
  }

  handleSave() {
    this.handleToggleOpen();
    this.selectedAction = `${this.action} confirm`;
    this.close.emit(this.selectedAction);
  }
}
