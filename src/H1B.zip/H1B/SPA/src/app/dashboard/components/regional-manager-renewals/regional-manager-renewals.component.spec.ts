import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { RegionalManagerRenewalsComponent } from './regional-manager-renewals.component';

describe('RegionalManagerRenewalsComponent', () => {
	let component: RegionalManagerRenewalsComponent;
	let fixture: ComponentFixture<RegionalManagerRenewalsComponent>;

	beforeEach(
		waitForAsync(() => {
			TestBed.configureTestingModule({
				declarations: [RegionalManagerRenewalsComponent],
			}).compileComponents();
		})
	);

	beforeEach(() => {
		fixture = TestBed.createComponent(RegionalManagerRenewalsComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
