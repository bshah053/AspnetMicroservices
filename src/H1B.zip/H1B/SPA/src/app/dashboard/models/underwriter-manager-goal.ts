export interface UnderwriterManagerGoal {
  Underwriter: string;
  NBBoundGoalAchievedPercentage: number;
  NBYearlyGoal: number;
  TravelGoalVisitAchievedPercentage: number;
  TravelYearlyGoal: number;
  UnderwriterLANID: string;
  EmailID: string;
}
