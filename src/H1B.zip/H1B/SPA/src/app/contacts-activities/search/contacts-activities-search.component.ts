import { Component, OnInit } from '@angular/core';
import { Select } from '@ngxs/store';

import { Observable, combineLatest } from 'rxjs';
import { UserState } from '../../user/user.store';
import { User } from '../../user/user.model';
import { ListItem } from '../../shared/radio-list/radio-list.component';
import { ReportingService } from '../../tracking-reporting/services/reporting.service';
import { ContactsActivitiesSearchService } from './contacts-activities-search.service';
import { IActivitySearch } from './contacts-activities-search-table/contacts-activities-search-table.component';
import { RelationshipService } from '../relationship.service';
import { IPaginationState } from '../../shared/pagination-controls/pagination-controls.component';

export interface IContactsActivitiesSearchPayload {
  StartDate?: string;
  EndDate?: string;

  Producer?: string[];
  Customer?: string[];
  ProducerRegion?: string[];
  ProducerBranch?: string[];
  Owner?: string[];
  Attendee?: string[];
  CallType?: string[];
  CompanyOwnerType?: string[];
  Status?: string[];
  ActivityType?: string[];

  PageNumber?: number;
  PageSize?: number;
  SortBy?: string;
  OrderBy?: string;
}

export interface IContactsActivitiesSearchResponse {
  MeetingDetailsInfoOutputModels: IActivitySearch[];
  PaginationModel: { PageNumber: number; PageSize: number; TotalCount: number };
}

@Component({
  templateUrl: './contacts-activities-search.component.html',
  styleUrls: ['./contacts-activities-search.component.scss'],
})
export class ContactsActivitiesSearchComponent implements OnInit {
  @Select(UserState) public user$: Observable<User>;

  user: User;
  selectedAccountTypes: string[] = [];
  selectedAccountNames: string[] = [];
  accountTypes: ListItem[];
  accountNames: ListItem[];

  contactsActivities: IActivitySearch[];

  state = { loading: false, empty: true, initial: true, error: '' };

  producerFilterCount = 0;

  StartDate: string;
  EndDate: string;

  pagination: IPaginationState = {
    current: 1,
    size: 10,
    total: 0,

    frame: 6,
  };

  payload = {
    applied: <IContactsActivitiesSearchPayload>{},
    current: <IContactsActivitiesSearchPayload>{},
  };

  bottomFilters = {
    Date: {
      name: 'Date',
      value: 'Date',
      StartDate: '',
      EndDate: '',
    },
    Type: {
      name: 'Type',
      value: 'Type',
      items: [],
      selected: [],
    },
    CallType: {
      name: 'Call Type',
      value: 'CallType',
      items: [],
      selected: [],
    },
    OwnerCompany: {
      name: 'Owner Company',
      value: 'OwnerCompany',
      items: [],
      selected: [],
    },
    AttendeeOwner: {
      name: 'Attendee/Owner',
      value: 'AttendeeOwner',
      items: [],
      selected: [],
    },
  };

  producer = {
    filters: {
      National: {
        name: 'National',
        value: 'National',
        api: 'getProducerNationalFilters',
        items: [],
        selected: [],
        dependsOn: [],
        affects: 'Region',
      },
      Region: {
        name: 'Region',
        value: 'Region',
        api: 'getProducerRegionFilters',
        items: [],
        selected: [],
        dependsOn: ['National'],
        affects: 'Branch',
      },
      Branch: {
        name: 'Branch',
        value: 'Branch',
        api: 'getProducerBranchFilters',
        items: [],
        selected: [],
        dependsOn: ['National', 'Region'],
        affects: 'PAScodes',
      },
      PAScodes: {
        name: 'PAS codes',
        value: 'PAScodes',
        api: 'getProducerCodes',
        items: [],
        selected: [],
        dependsOn: ['National', 'Regional', 'Branch'],
        affects: '',
      },
    },
  };

  constructor(private reportingService: ReportingService, private relationshipService: RelationshipService, private activitiesService: ContactsActivitiesSearchService) {
    combineLatest([this.user$, reportingService.getInsuredAccountTypeFilters(), reportingService.getInsuredAccountNameFilters()]).subscribe(([user, accountTypes, accountNames]) => {
      this.user = user;
      this.accountTypes = accountTypes;
      this.accountNames = accountNames;
    });

    this.fetchTopProducerFilters();
    this.fetchBottomFilters();
  }

  ngOnInit() {}

  fetchTopProducerFilters() {
    combineLatest([this.reportingService[this.producer.filters.National.api](), this.reportingService[this.producer.filters.Region.api](), this.reportingService[this.producer.filters.Branch.api](), this.reportingService[this.producer.filters.PAScodes.api]()]).subscribe(([national, region, branch, codes]: any) => {
      this.producer.filters.National.items = national;
      this.producer.filters.Region.items = region;
      this.producer.filters.Branch.items = branch;
      this.producer.filters.PAScodes.items = codes;
    });
  }

  fetchBottomFilters() {
    this.reportingService.getActivityTypeFilters().subscribe(
      (data: any) => (this.bottomFilters.Type.items = data),
      (err) => (this.bottomFilters.Type.items = [])
    );
    this.reportingService.getCallTypeFilters().subscribe(
      (data: any) => (this.bottomFilters.CallType.items = data),
      (err) => (this.bottomFilters.CallType.items = [])
    );
    this.reportingService.getOwnerCompanyFilters().subscribe(
      (data: any) => (this.bottomFilters.OwnerCompany.items = data),
      (err) => (this.bottomFilters.OwnerCompany.items = [])
    );
  }

  handleAccountTypesChange() {
    this.accountNames = [];
    this.selectedAccountNames = [];
    this.reportingService.getInsuredAccountNameFilters({ AccountType: this.selectedAccountTypes }).subscribe((accountNames) => (this.accountNames = accountNames));
  }

  handleProducerTypeChange(type: string) {
    if (!type) {
      return console.error('handleProducerTypeChange: no producer type provided!');
    }

    this.reviseProducerFilters(this.producer.filters[type]);
  }

  get filterCount() {
    const { filters } = this.producer;

    return filters.National.selected.length + filters.Region.selected.length + filters.Branch.selected.length + filters.PAScodes.selected.length;
  }

  topLevelLabel(name: string, ...selectedItems: string[][]) {
    const total = selectedItems.reduce((t, s) => t + s.length, 0);
    return total ? `${name} (${total})` : name;
  }

  handleApplyFilters($e) {
    this.payload.applied = this.createInitialPayloadObject();
    this.payload.applied.PageNumber = 1;

    this.contactsActivities = [];

    this.state.loading = true;
    this.state.initial = false;
    this.state.empty = false;
    this.state.error = '';

    this.activitiesService.fetchContactsActivitiesSearch(this.payload.applied).subscribe(
      (data: IContactsActivitiesSearchResponse) => this.handleResponseSuccessForContactActivitiesSearch(data),
      (err) => this.handleResponseErrorForContactsActivitiesSearch(err)
    );
  }

  resortTableData($event) {
    this.payload.applied.SortBy = $event.value;
    this.contactsActivities = [];

    this.activitiesService.fetchContactsActivitiesSearch(this.payload.applied).subscribe(
      (data: IContactsActivitiesSearchResponse) => this.handleResponseSuccessForContactActivitiesSearch(data),
      (err) => this.handleResponseErrorForContactsActivitiesSearch(err)
    );
  }

  get dateFilterLabel() {
    const label = this.bottomFilters.Date.name;
    const count = [this.bottomFilters.Date.StartDate, this.bottomFilters.Date.EndDate].filter((v) => !!v).length;
    return count ? `${label} (${count})` : label;
  }

  dateFieldChange(field: string, e: Event) {
    const target = e.target as HTMLInputElement;
    const seconds = Date.parse(target.value);
    if (seconds) {
      const date = new Date(seconds);
      const utcDate = new Date(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), -date.getTimezoneOffset() / 60, 0, 0);
      this.bottomFilters.Date[field] = utcDate.toISOString();
    } else {
      target.value = '';
      delete this.bottomFilters.Date[field];
    }
  }

  formatDateForInput(dateStr?: string) {
    if (!dateStr) {
      return '';
    }
    const seconds = Date.parse(dateStr);
    if (!seconds) {
      return '';
    }
    const date = new Date(seconds);
    const formated = `${addZero(date.getUTCMonth() + 1)}/${addZero(date.getUTCDate())}/${date.getUTCFullYear()}`;
    return formated;

    function addZero(number: number) {
      if (number < 10) {
        return `0${number}`;
      }
      return `${number}`;
    }
  }

  pageChanged($event) {
    this.payload.applied.PageNumber = $event;
    this.contactsActivities = [];

    this.activitiesService.fetchContactsActivitiesSearch(this.payload.applied).subscribe(
      (data: IContactsActivitiesSearchResponse) => this.handleResponseSuccessForContactActivitiesSearch(data),
      (err) => this.handleResponseErrorForContactsActivitiesSearch(err)
    );
  }

  ownerAttendeeChanged(contacts) {
    this.bottomFilters.AttendeeOwner.items = contacts;
    this.bottomFilters.AttendeeOwner.selected = contacts.map((i) => i.Email);
  }

  private createInitialPayloadObject(): IContactsActivitiesSearchPayload {
    return {
      StartDate: this.bottomFilters.Date.StartDate,
      EndDate: this.bottomFilters.Date.EndDate,

      Producer: this.producer.filters.National.selected,
      ProducerRegion: this.producer.filters.Region.selected,
      ProducerBranch: this.producer.filters.Branch.selected,

      Customer: this.selectedAccountNames,

      CallType: this.bottomFilters.CallType.selected,
      CompanyOwnerType: this.bottomFilters.OwnerCompany.selected,
      ActivityType: this.bottomFilters.Type.selected,

      Owner: this.bottomFilters.AttendeeOwner.selected,

      PageNumber: 1,
      PageSize: 10,
    };
  }

  private reviseProducerFilters(filter) {
    if (!filter.affects || !filter.affects.length) {
      return;
    }

    const { filters } = this.producer;
    const affectedFilter = filters[filter.affects];

    const args = affectedFilter.dependsOn.map((valueName) => (filters[valueName] ? filters[valueName].selected : null)).filter(Boolean);

    this.reportingService[affectedFilter.api](...args).subscribe(
      (data) => this.setFilterData(affectedFilter, data),
      (err) => this.setFilterData(affectedFilter, [])
    );
  }

  private setFilterData(filter, data) {
    filter.items = data;
    filter.selected = this.checkSelected(filter.selected, data);

    if (filter.affects && filter.affects.length) {
      return this.reviseProducerFilters(filter);
    }
  }

  private checkSelected(selection: any[], collection: any[]): string[] {
    return selection.filter((i) => {
      return collection.filter((s) => s.value === i).length;
    });
  }

  private remapTextValueWithLowerCase(data) {
    return data.map((i) => ({ text: i.Text, value: i.Value }));
  }

  private remapToTextValueFromFirstLastName(data) {
    return data.map((i) => ({ text: i.FullName, value: i.Email }));
  }

  private handleResponseSuccessForContactActivitiesSearch(data: IContactsActivitiesSearchResponse) {
    if (data !== null) {
      this.contactsActivities = data.MeetingDetailsInfoOutputModels;
      const { PageNumber, PageSize, TotalCount } = data.PaginationModel;
      this.checkPaginationState(PageNumber, PageSize, TotalCount);
      this.state.loading = false;
      this.state.empty = false;
    } else {
      this.handleResponseErrorForContactsActivitiesSearch(null);
    }
  }

  private checkPaginationState(current, size, total) {
    if (current !== this.pagination.current || total !== this.pagination.current) {
      this.pagination = {
        ...this.pagination,
        total: Math.ceil(total / size),
        current,
      };
    }
  }

  private handleResponseErrorForContactsActivitiesSearch(err) {
    this.contactsActivities = undefined;
    this.state.loading = false;
    this.state.empty = true;
  }
}
