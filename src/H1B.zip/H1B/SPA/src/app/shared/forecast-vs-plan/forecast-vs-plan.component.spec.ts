import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { ForecastVsPlanComponent } from './forecast-vs-plan.component';

describe('ForecastVsPlanComponent', () => {
	let component: ForecastVsPlanComponent;
	let fixture: ComponentFixture<ForecastVsPlanComponent>;

	beforeEach(
		waitForAsync(() => {
			TestBed.configureTestingModule({
				declarations: [ForecastVsPlanComponent],
			}).compileComponents();
		})
	);

	beforeEach(() => {
		fixture = TestBed.createComponent(ForecastVsPlanComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
