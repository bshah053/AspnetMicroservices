export interface LookupDataElementItem {
  ControlName: string;
  ControlType: string;
  DataText: string;
  DataValue: string;
  DisplayOrder?: number;
  ErrorOutput: string;
}
