import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { ApiService } from '../../../services/api.service';
import {
  ReportingService,
  FilterType,
} from '../../../tracking-reporting/services/reporting.service';
import { map, publishReplay, refCount } from 'rxjs/operators';
import { MoreFilters } from '../more-filters/more-filters.component';

export type ContactSortBy =
  | 'FullName'
  | 'AccountName'
  | 'Type'
  | 'BusinessNumber'
  | 'Email'
  | 'Address'
  | 'Branch';

export type ContactSearchPayload = {
  Producer?: string[];
  Customer?: string[];
  ProducerRegion?: string[];
  ProducerBranch?: string[];
  ContactType?: string[];
  RelationshipType?: string[];
  ChubbMarketSegment?: string[];
  Status?: string[];
  ContactName?: string;
  AccountName?: string;
  AccountType?: string;
  PageNumber?: number;
  PageSize?: number;
  SortBy?: ContactSortBy;
  OrderBy?: string;
  FirstName?: string;
  LastName?: string;
  FullName?: string;
  Email?: string;
  SubmissionSearchType?: string;
  IndustrySpecialization?: string[];
  ProductSpecialization?: string[];
  Cornerstone?: string[];
  //MoreFilters?: Partial<MoreFilters>
};

export type ContactDetails = {
  FirstName: string;
  LastName: string;
  FullName: string;
  Email: string;
  MobileNumber: string;
  BusinessNumber: string;
  Address1: string;
  City: string;
  StateCode: string;
  RegionCode: string;
  ZipCode: string;
  JobTitle: string;
  JobRole: string;
  FullAddress: string;
  ContactGUID: string;
  AccountGUID: string;
  AccountName: string;
  Type: string;
  Region: string;
  Branch: string;
  AccountType: string;
  ProducerRegion: string;
  ProducerBranch: string;
  ClientID: string;
  ProducerName: string;
  ChubbMarketSegment: string;
  ProductSpecialization: string;
  IndustrySpecialization: string;
  Cornerstone: string;
};

export type ContactDetailsResponse = {
  ContactSearchInfoModels: ContactDetails[];
  PaginationModel: {
    TotalCount: number;
    PageNumber: number;
    PageSize: number;
  };
};

@Injectable({ providedIn: 'root' })
export class ContactSearchService extends ApiService {
  contactStatusTypesCAFilters: Observable<FilterType[]>;

  constructor(
    httpClient: HttpClient,
    private reportingService: ReportingService
  ) {
    super(httpClient, environment.apiRelationship);
  }

  relationshipTypes() {
    return this.reportingService.getRelationshipTypes();
  }

  producerBranches() {
    return this.reportingService.getProducerBranchFilters();
  }

  contactTypes() {
    return this.reportingService.getContactTypeFilters();
  }

  marketSegments() {
    return this.reportingService.getChubbMarketSegmentFilters();
  }

  statusTypes(): Observable<FilterType[]> {
    if (!this.contactStatusTypesCAFilters) {
      this.contactStatusTypesCAFilters = this.get(
        '/dynamics/filters/contactstatus'
      ).pipe(
        map(this.toFilters),
        publishReplay(1),
        refCount()
      );
    }
    return this.contactStatusTypesCAFilters;
  }

  contactDetails(
    payload: ContactSearchPayload
  ): Observable<ContactDetailsResponse> {
    return this.post('/dynamics/search/contactdetails', null, payload).pipe(
      map((data: ContactDetailsResponse) => data)
    );
  }

  toFilters(data: { Text: string; Value: string }[]) {
    return !data
      ? []
      : data.map((filter) => ({ text: filter.Text, value: filter.Value }));
  }
}
