import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'cb-flex-link',
  templateUrl: './flex-link.component.html',
  styleUrls: ['./flex-link.component.scss'],
})
export class FlexLinkComponent implements OnInit {
  @Input() url: string;
  @Input() label: string;
  @Input() queryParams = {};
  @Input() iconClass = 'far fa-file-alt';

  constructor() {}

  ngOnInit() {}

  get isExternal() {
    return (
      !!this.url &&
      ['http', '//'].some((segment: string) => this.url.startsWith(segment))
    );
  }
}
