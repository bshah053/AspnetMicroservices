export interface UWGeniusQueueDetails {
  PipeID?: number;
  EffectiveDate: Date;
  Type: string;
  BrokerName: string;
  UnderwriterName: string;
  InsuredName: string;
  SubmissionID: string;
}
