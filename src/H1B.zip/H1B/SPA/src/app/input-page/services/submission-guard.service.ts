import { CanDeactivate } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { MatDialog } from '@angular/material/dialog';
import { InputPageComponent } from '../input-page.component';
import { CandeactivateDialogComponent } from '../../shared/candeactivate-dialog/candeactivate-dialog.component';
import { LoadingService } from 'shared/loading-spinner/loading.service';

@Injectable({
  providedIn: 'root',
})
export class SubmissionGuardService implements CanDeactivate<InputPageComponent> {
  constructor(public dialog: MatDialog, public loadingService: LoadingService) {}

  canDeactivate(component: InputPageComponent): Observable<boolean> | Promise<boolean> | boolean {
    if (component.submissionFormGroup.dirty) {
      this.loadingService.loadingOff();
      const dialogRef = this.dialog.open(CandeactivateDialogComponent);
      return dialogRef.afterClosed().pipe(
        map((result) => {
          if (result === 'confirm') {
            this.loadingService.loadingOn();
            return true;
          } else {
            return false;
          }
        })
      );
    } else {
      this.loadingService.loadingOn();
      return true;
    }
  }
}
