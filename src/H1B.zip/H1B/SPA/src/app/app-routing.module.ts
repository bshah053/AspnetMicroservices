import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MsalGuard } from '@azure/msal-angular';

import { LoginComponent } from './core/components/login/login.component';
import { ErrorComponent } from 'shared/error/error.component';
import { AppPreloadingStrategy } from './app-routing/app-preloading-strategy';
import { HelpComponent } from './help/help.component';
import { PageNotFoundComponent } from './pagenotfound/pagenotfound.component';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { LoginFailedComponent } from 'shared/login-failed/login-failed.component';
import { UnauthorizedComponent } from 'shared/unauthorized/unauthorized.component';
import { InvalidParamsComponent } from 'shared/invalid-params/invalid-params.component';
import { ServerFailureComponent } from 'shared/server-failure/server-failure.component';

const routes: Routes = [
  // {
  //   path: 'id_token',
  //   redirectTo: 'dashboard',
  //   pathMatch: 'full',
  //   canActivate: [MsalGuard],
  // },
  // {
  //   path: '',
  //   redirectTo: 'dashboard',
  //   pathMatch: 'full',
  //   canActivate: [MsalGuard],
  // },
  {
    // Needed for hash routing
    path: 'code',
    component: LandingPageComponent,
  },
  {
    path: '',
    component: LandingPageComponent,
  },
  {
    path: 'dashboard',
    loadChildren: () => import('./dashboard/dashboard.module').then((m) => m.DashboardModule),
    data: { preload: true, delay: 0 },
    canActivate: [MsalGuard],
  },
  {
    path: 'tracking-and-reporting',
    loadChildren: () => import('./tracking-reporting/tracking-reporting.module').then((m) => m.TrackingReportingModule),
    data: { preload: true, delay: 2000 },
    canActivate: [MsalGuard],
  },
  {
    path: 'contacts-and-activities',
    canActivate: [MsalGuard],
    loadChildren: () => import('./contacts-activities/contacts-activities.module').then((m) => m.ContactsActivitiesModule),
    data: { preload: true, delay: 5000 },
  },
  // {
  //   path: 'submission',
  //   canActivate: [MsalGuard],
  //   loadChildren: () => import('./submission/submission.module').then(m => m.SubmissionModule),
  //   data: { preload: true, delay: 5000 },
  // },
  {
    path: 'submission',
    canActivate: [MsalGuard],
    loadChildren: () => import('./input-page/input-page.module').then((m) => m.InputPageModule),
    data: { preload: true, delay: 5000 },
  },
  {
    path: 'admin',
    canActivate: [MsalGuard],
    loadChildren: () => import('./user-admin/user-admin.module').then((m) => m.UserAdminModule),
    data: { preload: true, delay: 5000 },
  },
  {
    path: 'controladmin',
    canActivate: [MsalGuard],
    loadChildren: () => import('./control-admin/control-admin.module').then((m) => m.ControlAdminModule),
    data: { preload: true, delay: 5000 },
  },
  {
    path: 'help',
    canActivate: [MsalGuard],
    component: HelpComponent,
    data: { preload: true, delay: 5000 },
  },
  {
    path: 'login',
    component: LoginComponent,
    data: { preload: true, delay: 5000 },
  },
  {
    path: 'login-failed',
    component: LoginFailedComponent,
  },
  {
    path: 'unauthorized',
    component: UnauthorizedComponent,
  },
  {
    path: 'server-failure',
    component: ServerFailureComponent,
  },
  {
    path: 'error',
    component: ErrorComponent,
  },
  {
    path: 'invalid-params',
    component: InvalidParamsComponent,
  },
  {
    path: '404',
    component: PageNotFoundComponent,
  },

  {
    path: '**',
    redirectTo: '/404',
  },
];

const isIframe = window !== window.parent && !window.opener;

@NgModule({
  // imports: [RouterModule.forRoot(routes, { useHash: true, preloadingStrategy: PreloadAllModules })],
  imports: [
    RouterModule.forRoot(routes, {
      useHash: true,
      initialNavigation: !isIframe ? 'enabled' : 'disabled',
      preloadingStrategy: AppPreloadingStrategy,
      relativeLinkResolution: 'legacy',
      scrollPositionRestoration: 'enabled',
    }),
  ],
  exports: [RouterModule],
  declarations: [],
})
export class AppRoutingModule {}
