import {
  Component,
  OnInit,
  Inject,
  ChangeDetectorRef,
  HostListener,
} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { SubmissionContactDetails } from 'input-page/models/common/submission-contact-details';
import { finalize } from 'rxjs/operators';
import { ListItem } from 'shared/radio-list/radio-list.component';
import {
  FilterType,
  RegionBranchesResponse,
  ReportingService,
} from 'tracking-reporting/services/reporting.service';
import { Helper } from 'utilities/common-helper';
import {
  ContactDetails,
  ContactDetailsResponse,
  ContactSearchPayload,
  ContactSearchService,
} from '../../../contacts-activities/search/contacts-search/contact-search.service';

@Component({
  selector: 'submission-contact-search',
  templateUrl: './submission-contact-search.component.html',
  styleUrls: ['./submission-contact-search.component.scss'],
})
export class SubmissionContactSearchComponent implements OnInit {
  constructor(
    public dialogRef: MatDialogRef<SubmissionContactSearchComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private contactSearchService: ContactSearchService,
    private reportingService: ReportingService,
    private cdRef: ChangeDetectorRef
  ) {}

  @HostListener('window:keyup.esc')
  onKeyUp() {
    this.dialogRef.close();
  }

  relationshipTypeList: ListItem[] = [];
  contactTypes = [];
  marketSegments = [];
  statusTypes = [];
  regionFilters: Array<FilterType> = [];
  branchFilters: Array<ListItem> = [];
  productSpecializationList: FilterType[];
  industrySpecializationList: FilterType[];
  cornerstoneList: FilterType[];
  selectedFullName = '';
  headerName = '';
  errorMessage = '';
  loading = false;
  isEmpty = false;
  initial = false;
  contactDetails: ContactDetails[];
  selectedContactDetails: SubmissionContactDetails = {
    ContactDetails: null,
    ControlName: '',
    UserId: '',
  };
  contactSearchFilter: ContactSearchPayload = {};

  ngOnInit(): void {
    this.resetFilterControl();
    this.setHeaderNameAndSearchType();
    if (this.data.ContactSearchFilter) {
      this.contactSearchFilter = {
        ...this.data.ContactSearchFilter,
      };
      if (
        Helper.isStringNotNullAndEmpty(
          this.contactSearchFilter.FirstName.trim()
        ) ||
        Helper.isStringNotNullAndEmpty(
          this.contactSearchFilter.LastName.trim()
        ) ||
        Helper.isStringNotNullAndEmpty(
          this.contactSearchFilter.FullName.trim()
        ) ||
        Helper.isStringNotNullAndEmpty(this.contactSearchFilter.Email.trim())
      ) {
        this.getContactsDetails();
      }
    }
    this.loadAllLookUpData();
  }

  private setHeaderNameAndSearchType() {
    if (this.data.ControlName === 'BrokerEmail') {
      this.headerName = 'Submission Contact Search';
      this.contactSearchFilter.SubmissionSearchType = 'PRODUCER';
    } else if (this.data.ControlName === 'UWEmail') {
      this.headerName = 'Submission Underwriter Search';
      this.contactSearchFilter.SubmissionSearchType = 'UW';
    } else if (this.data.ControlName === 'UAEmail') {
      this.headerName = 'Submission Underwriter Assistant Search';
      this.contactSearchFilter.SubmissionSearchType = 'UA';
    }
  }

  loadAllLookUpData() {
    this.relationshipTypes();
    this.getRegionFilters();
    this.handleRegionsChange();
    this.getContactTypes();
    this.getMarketSegments();
    this.getStatusTypes();
    this.getProductSpecializationType();
    this.getIndustrySpecializationType();
    this.getCornerstorneType();
  }

  resetFilterControl() {
    this.selectedFullName = '';
    this.contactDetails = null;
    this.selectedContactDetails.ContactDetails = null;
    this.contactSearchFilter = {
      ProducerRegion: [],
      ProducerBranch: [],
      ContactType: [],
      RelationshipType: [],
      ChubbMarketSegment: [],
      Status: [],
      ContactName: '',
      AccountName: '',
      AccountType: '',
      Email: '',
      FirstName: '',
      LastName: '',
      FullName: '',
      // SubmissionSearchType: '',
      PageNumber: 1,
      PageSize: 0,
      SortBy: 'FullName',
      OrderBy: '',
      IndustrySpecialization: [],
      ProductSpecialization: [],
      Cornerstone: [],
    };
    this.errorMessage = '';
    this.isEmpty = false;
    this.loading = false;
  }

  rowSelected(selectedRow) {
    this.selectedFullName = '';
    console.warn(selectedRow);
    if (selectedRow) {
      this.selectedFullName = selectedRow[0].FullName;
      this.selectedContactDetails.ContactDetails = selectedRow;
      this.selectedContactDetails.ControlName = this.data.ControlName;
    }
  }

  handleSearch() {
    this.contactDetails = null;
    this.errorMessage = '';
    if (
      Helper.isStringArrayNotNullAndEmpty(
        this.contactSearchFilter.RelationshipType
      ) ||
      Helper.isStringArrayNotNullAndEmpty(
        this.contactSearchFilter.ProducerRegion
      ) ||
      Helper.isStringArrayNotNullAndEmpty(
        this.contactSearchFilter.ProducerBranch
      ) ||
      Helper.isStringArrayNotNullAndEmpty(
        this.contactSearchFilter.ContactType
      ) ||
      Helper.isStringArrayNotNullAndEmpty(
        this.contactSearchFilter.ChubbMarketSegment
      ) ||
      Helper.isStringArrayNotNullAndEmpty(this.contactSearchFilter.Status) ||
      Helper.isStringNotNullAndEmpty(
        this.contactSearchFilter.ContactName.trim()
      ) ||
      Helper.isStringNotNullAndEmpty(
        this.contactSearchFilter.AccountName.trim()
      ) ||
      Helper.isStringArrayNotNullAndEmpty(
        this.contactSearchFilter.ProductSpecialization
      ) ||
      Helper.isStringArrayNotNullAndEmpty(
        this.contactSearchFilter.IndustrySpecialization
      ) ||
      Helper.isStringArrayNotNullAndEmpty(
        this.contactSearchFilter.Cornerstone
      ) ||
      Helper.isStringNotNullAndEmpty(
        this.contactSearchFilter.FirstName.trim()
      ) ||
      Helper.isStringNotNullAndEmpty(
        this.contactSearchFilter.LastName.trim()
      ) ||
      Helper.isStringNotNullAndEmpty(
        this.contactSearchFilter.FullName.trim()
      ) ||
      Helper.isStringNotNullAndEmpty(this.contactSearchFilter.Email.trim())
    ) {
      this.getContactsDetails();
    } else {
      this.errorMessage = 'Please select/enter atleast one filter condtion...';
    }
  }

  handleCancel(): void {
    this.dialogRef.close(null);
  }

  handleSelectedRow() {
    if (this.selectedContactDetails) {
      this.dialogRef.close(this.selectedContactDetails);
    }
  }

  getContactsDetails() {
    this.loading = true;
    this.isEmpty = false;
    this.contactSearchService
      .contactDetails(this.contactSearchFilter)
      .pipe(
        finalize(() => {
          this.loading = false;
        })
      )
      .subscribe(
        (data: ContactDetailsResponse) => {
          if (data !== null) {
            console.log({ data });
            this.contactDetails = data.ContactSearchInfoModels;
          } else {
            this.isEmpty = true;
            this.contactDetails = null;
          }
        },
        (err) => {
          this.contactDetails = null;
        }
      );
  }

  relationshipTypes() {
    this.contactSearchService
      .relationshipTypes()
      .subscribe(
        (items: ListItem[]) => (this.relationshipTypeList = items),
        (error) => console.error('Error loading relationship types', error)
      );
  }

  handleRegionsChange() {
    this.getBranches();
  }

  handleBranchChange(branch: string[]) {
    this.contactSearchFilter.ProducerBranch = branch;
    console.log({ branch });
  }

  getRegionFilters() {
    this.reportingService
      .getRegionFilters()
      .subscribe((data: Array<FilterType>) => {
        this.regionFilters = data;
      });
  }

  getBranches() {
    this.reportingService
      .getCreditedRegionBranchesFilters()
      .subscribe((data: RegionBranchesResponse[]) => {
        let branchFiltersList;
        if (
          this.contactSearchFilter.ProducerRegion.length === 0 ||
          (this.contactSearchFilter.ProducerRegion.length === 1 &&
            this.contactSearchFilter.ProducerRegion[0] === '')
        ) {
          branchFiltersList = data;
        } else {
          branchFiltersList = data.filter((filters) =>
            this.contactSearchFilter.ProducerRegion.includes(filters.Region)
          );
        }
        this.branchFilters = branchFiltersList.map(
          (branches: { Branch: string }) => {
            return {
              text: branches.Branch,
              value: branches.Branch,
            };
          }
        );

        this.contactSearchFilter.ProducerBranch = this.contactSearchFilter.ProducerBranch.filter(
          (selected) =>
            this.branchFilters.findIndex((d) => d.value === selected) > -1
        );
        this.detectChanges();
      });
  }

  private detectChanges() {
    if (!this.cdRef['destroyed']) {
      this.cdRef.detectChanges();
    }
  }

  resetAllRegions() {
    this.contactSearchFilter.ProducerRegion = [];
    this.contactSearchFilter.ProducerBranch = [];
    this.getBranches();
  }

  getContactTypes() {
    this.contactSearchService.contactTypes().subscribe(
      (data) => {
        this.contactTypes = data;
      },
      (e) => {
        this.contactTypes = null;
      }
    );
  }

  getMarketSegments() {
    this.contactSearchService.marketSegments().subscribe(
      (data) => {
        this.marketSegments = data;
      },
      (e) => {
        this.marketSegments = null;
      }
    );
  }

  getStatusTypes() {
    this.contactSearchService.statusTypes().subscribe(
      (data) => {
        this.statusTypes = data;
      },
      (e) => {
        this.statusTypes = null;
      }
    );
  }

  getProductSpecializationType() {
    this.reportingService
      .getProductSpecializationType(null, this.data.UserId)
      .subscribe(
        (data) => {
          console.log({ data });
          this.productSpecializationList = data;
        },
        (e) => {
          this.productSpecializationList = null;
        }
      );
  }

  getIndustrySpecializationType() {
    this.reportingService
      .getIndustrySpecializationType(null, this.data.UserId)
      .subscribe(
        (data) => {
          console.log({ data });
          this.industrySpecializationList = data;
        },
        (e) => {
          this.industrySpecializationList = null;
        }
      );
  }

  getCornerstorneType() {
    this.reportingService.getCornerstorneType(null, this.data.UserId).subscribe(
      (data) => {
        console.log({ data });
        this.cornerstoneList = data;
      },
      (e) => {
        this.cornerstoneList = null;
      }
    );
  }
}
