import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UwGeniusQueueComponent } from './uw-genius-queue.component';

describe('UwGeniusQueueComponent', () => {
  let component: UwGeniusQueueComponent;
  let fixture: ComponentFixture<UwGeniusQueueComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [UwGeniusQueueComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UwGeniusQueueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
