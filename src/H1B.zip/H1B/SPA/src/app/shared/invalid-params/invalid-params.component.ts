import { Component, OnInit } from '@angular/core';

import { SharedService } from 'services/shared.service';

@Component({
  selector: 'invalid-params',
  templateUrl: './invalid-params.component.html',
  styleUrls: ['./invalid-params.component.scss'],
})
export class InvalidParamsComponent implements OnInit {
  constructor(private sharedService: SharedService) {
    this.sharedService.sendHeaderVisibilityStatus(true);
  }

  ngOnInit(): void {}
}
