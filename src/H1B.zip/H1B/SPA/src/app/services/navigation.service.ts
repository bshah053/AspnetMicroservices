import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { RoutedFrom } from 'shared/utilities';
import { User } from 'user/user.model';
import { UrlHelper, Record } from 'utilities/url.helper';
import { ReportsHeaderModel } from '../tracking-reporting/reports/reports-header/store/reports-header.model';
import { FilterWatchService } from './filter-watch.service';
import { SharedService } from './shared.service';

export interface ProducerProfileOptions {
  ProducerBranch?: string[];
  ProducerRegion?: string[];
  extraFilters?: any;
  showBrowseBy?: boolean;
}

@Injectable({
  providedIn: 'root',
})
export class NavigationService {
  constructor(private router: Router, private filterWatch: FilterWatchService, private sharedService: SharedService) {}

  toProducerProfile(producerName: string, options: ProducerProfileOptions = {}) {
    const filters = this.filterWatch.serializeFromPayload(
      <ReportsHeaderModel>{
        ...options.extraFilters,
        ProducerName: [producerName !== null ? producerName.trim() : producerName],
        ProducerBranch: (options.ProducerBranch || []).filter((b) => !!b),
        ProducerRegion: (options.ProducerRegion || []).filter((r) => !!r),
      },
      { browseByProducer: 'Producers', browseByValue: 'producerName' }
    );

    this.router
      .navigate(['tracking-and-reporting/producer-profile'], {
        queryParams: {
          filters: this.filterWatch.create(filters),
          showBrowseBy: options.showBrowseBy,
        },
      })
      .then(() => {});
  }

  toCustomer(clientId: string, clientName: string = '', options: { extraFilters?: any; showBrowseBy?: boolean } = {}) {
    const filters = this.filterWatch.serializeFromPayload(
      <ReportsHeaderModel>{
        ...options.extraFilters,
        ClientID: [(clientId + '').trim()],
        ...(clientName ? { ClientName: [clientName.trim()] } : {}),
      },
      {
        browseByProducer: 'Insured Search',
        browseByValue: 'none',
      }
    );

    this.router
      .navigate(['tracking-and-reporting/customer'], {
        queryParams: {
          filters: this.filterWatch.create(filters),
          showBrowseBy: !!options.showBrowseBy,
        },
      })
      .then(() => {});
  }

  toMyMeetings() {
    this.router.navigate(['/dashboard/my-meetings']);
  }

  toSubmission(recordNo, user: User, routedFrom, isCheckNavigation: boolean = false) {
    let IS_REQUIRE_NAVIGATE_TO_SUBMISSION = isCheckNavigation;
    if (IS_REQUIRE_NAVIGATE_TO_SUBMISSION) {
      const payload = <ReportsHeaderModel>{
        Division: [],
        Unit: [],
        Segment: [],
        UserID: user.UserID,
        UnderwriterName: [user.UserID],
        RecordNo: recordNo,
        GeniusPipeID: 0,
      };
      const serializedFilters = this.filterWatch.serializeFromPayload(payload);
      const filters = this.filterWatch.create(serializedFilters);
      const url = UrlHelper.submissionPageLink(filters, routedFrom);
      window.open(url, '_blank');
      return;
    } else {
      const payload: Record = {
        RecordNo: recordNo,
        Subgroup: '',
      };
      const url = UrlHelper.inputPageLink(payload, user);
      window.open(url, '_blank');
      return;
    }
  }

  toUnAuthorized() {
    this.router.navigate(['/unauthorized']);
  }

  toErrorPage() {
    this.router.navigate(['/error']);
  }

  toServerFailure() {
    this.router.navigate(['/server-failure']);
  }

  toFileDownload(filename: string, downloadedFile: Blob) {
    const a = document.createElement('a');
    a.setAttribute('style', 'display:none;');
    document.body.appendChild(a);
    a.download = filename;
    a.href = URL.createObjectURL(downloadedFile);
    a.target = '_blank';
    a.click();
    document.body.removeChild(a);
  }
}
