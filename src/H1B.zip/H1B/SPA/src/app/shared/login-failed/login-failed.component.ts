import { Component, OnInit } from '@angular/core';

import { SharedService } from 'services/shared.service';

@Component({
  selector: 'cb-login-failed',
  templateUrl: './login-failed.component.html',
  styleUrls: ['./login-failed.component.scss'],
})
export class LoginFailedComponent implements OnInit {
  constructor(private sharedService: SharedService) {
    this.sharedService.sendHeaderVisibilityStatus(true);
  }

  ngOnInit(): void {}
}
