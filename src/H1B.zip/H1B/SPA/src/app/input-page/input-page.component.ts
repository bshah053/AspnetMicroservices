import { Component, Inject, OnDestroy, OnInit, AfterViewInit, ViewChild, Injector, ChangeDetectorRef } from '@angular/core';
import { MatAccordion } from '@angular/material/expansion';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { AbstractControl } from '@angular/forms';
import * as moment from 'moment';
import { Select } from '@ngxs/store';
import { combineLatest, Observable, Subscription } from 'rxjs';
import { debounceTime, distinctUntilChanged, filter, finalize, switchMap, tap } from 'rxjs/operators';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { DatePipe } from '@angular/common';

import { NotificationService } from 'services/notification.service';
import { CopyDeleteService } from 'services/copydelete.service';
import { FilterType, InputPageService } from './services/input-page.service';
import { ReportingService } from 'tracking-reporting/services/reporting.service';
import { ContactDetails, ContactDetailsResponse, ContactSearchPayload, ContactSearchService } from 'contacts-activities/search/contacts-search/contact-search.service';
import { ModalService } from 'shared/modal/modal.service';
import { SharedService } from 'services/shared.service';

import { User } from 'user/user.model';
import { UserState } from 'user/user.store';
import { DataElementsControlDetailsItem, DataElementsDetails, OptionsUWItems } from './models/load/data-elements-control-details-item';
import { SubmissionLoadItem } from './models/load/submission-load-item';
import { LookupDataElementItem } from './models/lookup/lookup-data-element-item';
import { SubmissionSaveItem } from './models/save/submission-save-item';
import { SubmissionSaveOutputModel } from './models/save/submission-save-output-model';
import { DnBInsuredStateItem } from './models/common/dnb-insured-state-item';
import { SubmissionHelperResponseItem } from './models/common/submission-helper-response-item';
import { SubmissionHelperFilterItem } from './models/common/submission-helper-filter-item';
import { FilterWatchService } from 'services/filter-watch.service';
import { EscalationDetailItem } from './models/common/escalation-details-item';
import { ReportsHeaderModel } from 'tracking-reporting/reports/reports-header/store/reports-header.model';
import { SubmissionContactDetails } from './models/common/submission-contact-details';
import { BuildOutScheduleItems } from './dialog/build-out-schedule/model/build-out-schedule-items';
import { USDForecastConvertor } from './models/common/usd-forecast-convertor';
import { UWGeniusQueueDetailedItems } from './models/common/uw-genius-queue-detailed-items';
import { CollectionDeletedItems } from 'input-page/models/common/collection-deleted-items';
import { ResolvedSubmissionLoad } from './models/load/resolved-submissionload.model';
import { MetadataDetailsItem } from './models/load/metadata-details-item';
import { ControlDetails } from 'utilities/submission-json';
import { PASDialogDetails } from './models/common/pas-dialog-details';
import { ReportFilters } from 'tracking-reporting/reports/reports-header/reports-header.component';
import { HeaderDetailsItem } from './models/load/header-details-item';
import { FooterDetailsItem } from './models/load/footer-details-item';
import { CopyDeleteRequestModel } from 'model/copydelete-request-model';

import { SubmissionAuditTrailDetailsComponent } from 'shared/submission-audit-trail-details/submission-audit-trail-details.component';
import { SubmissionEscalationDetailComponent } from 'shared/submission-escalation-detail/submission-escalation-detail.component';
import { InputFormPopupComponent } from './dialog/input-form-popup/input-form-popup.component';
import { PasvalidationDialogComponent } from 'shared/pasvalidation-dialog/pasvalidation-dialog.component';
import { ConfirmationDialogComponent } from 'shared/confirmation-dialog/confirmation-dialog.component';
import { LayerDetailsComponent } from './dialog/layer-details/layer-details.component';
import { SubmissionMessageDialogComponent } from 'shared/submission-message-dialog/submission-message-dialog.component';
import { SubmissionProducerLookupComponent } from 'shared/submission-producer-lookup/submission-producer-lookup.component';
import { SubmissionDnBLookupComponent } from 'shared/submission-dnb-lookup/submission-dnb-lookup.component';
import { SubmissionContactSearchComponent } from './dialog/submission-contact-search/submission-contact-search.component';
import { SubmissionContactSearchMiniComponent } from './dialog/submission-contact-search-mini/submission-contact-search-mini.component';
import { BuildOutScheduleComponent } from './dialog/build-out-schedule/build-out-schedule.component';
import { UwGeniusQueueViewComponent } from './uw-genius-queue-details/uw-genius-queue-view/uw-genius-queue-view.component';

import { HelperMethodName, RoutedFrom } from 'shared/utilities';
import { Helper } from 'utilities/common-helper';
import { UrlHelper } from 'utilities/url.helper';
import {
  CheckboxTransPattern,
  CheckControls,
  Constants,
  GetDiffDaysInputPageName,
  InputPageName,
  IsCIGroup,
  PMLCloudControls,
  PolicyTypeValSegment,
  PolicyTypeValUnit,
  SectionType,
  Status,
  Type,
  UserIdDateControls,
  DisplayCtrlPortfolio,
  PMLControls,
  TTCNUnitSegment,
  ResetMandatoryControlList,
  ValueChangedControls,
  HelperControls,
  DateValueValidationControls,
  BlurEventControls,
  ControlType,
  CanadaLayerControls,
  TransferSegment,
  TransferFCGSegment,
  PostMortemPageName,
  SubmissionPageType,
  DBLookupControlList,
  TransferSegmentCI,
} from 'utilities/common-enum-const';

@Component({
  selector: 'cb-input-page',
  templateUrl: './input-page.component.html',
  styleUrls: ['./input-page.component.scss'],
})
export class InputPageComponent implements OnInit, AfterViewInit, OnDestroy {
  constructor(
    private cdRef: ChangeDetectorRef,
    @Inject(ReportingService) private reportingService: ReportingService,
    private contactSearchService: ContactSearchService,
    private inputPageService: InputPageService,
    private copyDeleteService: CopyDeleteService,
    private sharedService: SharedService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    @Inject(FilterWatchService) private filterWatch: FilterWatchService,
    public dialog: MatDialog,
    private modalService: ModalService,
    public datepipe: DatePipe,
    private injector: Injector,
    private submissionFB: FormBuilder
  ) {
    try {
      this.setQueryParams();
      combineLatest([this.user$]).subscribe(([user]) => {
        this.user = user;
        if (this.user && Helper.isStringNotNullAndEmpty(this.user.UserID)) {
          if (this.user.UserID) {
            this.userID = this.user.UserID;
          }
          this.submissionFormGroup = new FormGroup({
            InsuredName: new FormControl(''),
          });
          this.getInputPageControlsDetails();
          this.fetchLoadData();
        }
      });
      this.notifier = this.injector.get(NotificationService);
    } catch (error) {
      console.log({ error });
    }
  }
  @Select(UserState) public user$: Observable<User>;
  user: User;
  @ViewChild(MatAccordion) accordion: MatAccordion;
  @ViewChild(UwGeniusQueueViewComponent) uwGeniusQueueDetails: UwGeniusQueueViewComponent;
  collectionDeletedItems: CollectionDeletedItems[] = [];
  filters: ReportFilters = {} as ReportFilters;
  dataElementsControlDetailsItem: DataElementsControlDetailsItem[] = [];
  dataElementsControlDetailsItemPanel: DataElementsControlDetailsItem[] = [];
  private _dataElementsAllDetails: DataElementsDetails[] = [];

  private setQueryParams() {
    // this.routedFrom = this.activatedRoute.snapshot.queryParams.routedFrom;
    this.activatedRoute.queryParams.subscribe((params) => {
      if (params.routedFrom) {
        this.routedFrom = params.routedFrom;
        if (this.routedFrom !== 'SU') {
          this.sharedService.sendHeaderVisibilityStatus(true);
        }
      }
      if (params.filters) {
        this.storedFilters = this.filterWatch.getByHash(params.filters);
        this.recordNumber = this.storedFilters.RecordNo ? this.storedFilters.RecordNo : 0;
      }

      if (params.recordNumber) {
        this.recordNumber = params.recordNumber !== 0 ? params.recordNumber : 0;
        this.userID = params.userID !== '' ? params.userID : this.user.UserID;
      }
    });
  }

  public get DataElementsAllDetails(): DataElementsDetails[] {
    return this._dataElementsAllDetails;
  }
  public set DataElementsAllDetails(value: DataElementsDetails[]) {
    this._dataElementsAllDetails = value;
  }
  private _routedFrom: string;
  public get routedFrom(): string {
    return this._routedFrom;
  }
  public set routedFrom(value: string) {
    this._routedFrom = value;
  }
  public get saveButtonLabel() {
    return this.isRecordExists ? 'Update' : 'Save';
  }
  queryParams: Array<string> = [];
  inputPageHeader: HeaderDetailsItem;
  inputPageFooter: FooterDetailsItem;
  lookup: LookupDataElementItem[];
  confidanceFactorlookup: FilterType[];
  statusLookup: FilterType[];
  submissionSaveItem: SubmissionSaveItem = new SubmissionSaveItem();
  submissionSaveOutputModel: SubmissionSaveOutputModel;
  buildOutScheduleItems: BuildOutScheduleItems[] = [];
  messageHandler: string;
  responseMessage: string;
  isErrorSummary: boolean;
  notifier;
  private _metadataDetails: MetadataDetailsItem;
  public get MetadataDetails(): MetadataDetailsItem {
    return this._metadataDetails;
  }
  public set MetadataDetails(value: MetadataDetailsItem) {
    this._metadataDetails = value;
  }
  sectionName: string[];
  sectionNameForList: string[];
  sectionKeyItems: string[];
  sectionKeyItemsForList: string[];
  escalationDetailItem: EscalationDetailItem;
  contactSearchFilter: ContactSearchPayload = {};
  submissionContactDetails: SubmissionContactDetails;
  contactSearchDetails: ContactDetails[];
  dnbInsuredStateItem: DnBInsuredStateItem = new DnBInsuredStateItem();
  pasDialogDetails: PASDialogDetails = new PASDialogDetails();
  recordNumber = 0;
  userID: string;
  actionName = '';
  isSubmittedData = false;
  storedFilters;
  hideNetForecast = true;
  hideExpiringNetForecast = true;
  currencyType = 'USD';
  dialogLoading;
  lostReasonList: FilterType[];
  outOfMarket = true;
  postMortremReason = true;
  searchdropdown: string;

  submissionFormGroup: FormGroup;
  submitted = false;
  submissionFormGroupSubs: Subscription;
  subscriptionLoad$: Subscription;
  subscriptionLookup$: Subscription;
  buildOutSchedule$: Subscription;
  helperDetails$: Subscription;
  escalationDetails$: Subscription;
  portfolioClassDetails$: Subscription;
  sharedServiceSub$: Subscription;
  collectionDetails$: Subscription;
  subscriptionAviationDetails$: Subscription;
  underWriterNameSearch$: Subscription;
  sharedService$: Subscription;
  isLookupLoading = false;
  linkedRecordNoTitle = '';
  headerLink20 = false;
  headerLink25 = false;
  headerLink33 = false;
  step = 0;
  totalSection = 0;
  public get isShowPolicyDetails() {
    return this.isValidConstruction();
  }
  isShowContent = false;
  isLoading = false;
  error: string;
  // quickSubmission = new FormControl(false);
  private _forecastConvertor: USDForecastConvertor = {
    IsNetforecastYN: 'N',
  };
  public get forecastConvertor(): USDForecastConvertor {
    return this._forecastConvertor;
  }
  public set forecastConvertor(value: USDForecastConvertor) {
    this._forecastConvertor = value;
  }

  ngOnInit() {
    try {
      // this.submissionFormGroup = new FormGroup({
      //   InsuredName: new FormControl(''),
      // });
      // this.getInputPageControlsDetails();
      this.sharedService$ = this.sharedService.setSubmissionCopyDeleteStatus().subscribe((result) => {
        this.copySuccessAction(result);
      });
    } catch (error) {
      console.log({ error });
    }
  }

  ngAfterViewInit() {}

  ngOnDestroy() {
    try {
      if (this.subscriptionLoad$) {
        this.subscriptionLoad$.unsubscribe();
      }
      if (this.subscriptionLookup$) {
        this.subscriptionLookup$.unsubscribe();
      }
      if (this.buildOutSchedule$) {
        this.buildOutSchedule$.unsubscribe();
      }
      if (this.helperDetails$) {
        this.helperDetails$.unsubscribe();
      }
      if (this.escalationDetails$) {
        this.escalationDetails$.unsubscribe();
      }
      if (this.portfolioClassDetails$) {
        this.portfolioClassDetails$.unsubscribe();
      }
      if (this.collectionDetails$) {
        this.collectionDetails$.unsubscribe();
      }
      if (this.subscriptionAviationDetails$) {
        this.subscriptionAviationDetails$.unsubscribe();
      }
      if (this.underWriterNameSearch$) {
        this.underWriterNameSearch$.unsubscribe();
      }
      if (this.sharedService$) {
        this.sharedService$.unsubscribe();
      }
    } catch (error) {
      console.log({ error });
    }
  }

  public controlById(index, control) {
    if (!control) return null;
    return control.ControlId;
  }

  compareWithDDValue(option, selection) {
    if (Helper.isStringNotNullAndEmpty(option) && Helper.isStringNotNullAndEmpty(selection)) {
      return option === selection ? true : option.toLowerCase() === selection.toLowerCase() ? true : false;
    } else if (Helper.isStringNotNullAndEmpty(selection)) {
      return false;
    }
  }

  get isSubmissionFGInValid() {
    if (this.submissionFormGroup) {
      return this.submitted && this.submissionFormGroup.invalid;
    }
  }

  get isGeniusExist() {
    return this.storedFilters && this.storedFilters.GeniusPipeID > 0;
  }

  private async generateSubmissionFormGroup() {
    const formGroup = {};
    if (this.dataElementsControlDetailsItemPanel) {
      this.dataElementsControlDetailsItemPanel.forEach((sectionWiseElement) => {
        if (sectionWiseElement.SectionType === SectionType.Collections) {
          formGroup[sectionWiseElement.SectionKey] = this.addNewSectionGroup(sectionWiseElement);
        } else {
          this.addFormsControls(sectionWiseElement.DataElementsDetails, formGroup);
          if (sectionWiseElement.DataElementsGroupDetails && sectionWiseElement.DataElementsGroupDetails.length > 0) {
            sectionWiseElement.DataElementsGroupDetails.forEach((groupWiseElement) => {
              this.addFormsControls(groupWiseElement.DataElementsDetails, formGroup);
            });
          }
        }
      });
    }

    this.submissionFormGroup = new FormGroup(formGroup);
    // console.log(this.submissionFormGroup);
    setTimeout(() => {
      // To Validation on Load
      this.validationOnLoad();
      // To Enable Validation on Control Value changes
      this.enableControlValueChange();
      if (this.isCollectionExists) {
        this.enableCollectionControlValueChange();
      }
      this.updateErrorWarning();
      this.cdRef.detectChanges();
    }, 1000);
  }

  addNewSectionGroup(sectionWiseElement: DataElementsControlDetailsItem): FormGroup {
    if (sectionWiseElement.SectionType === SectionType.Collections) {
      return this.submissionFB.group({
        [sectionWiseElement.SectionKey]: this.submissionFB.array([this.getFormsGroup(sectionWiseElement)]),
      });
    } else {
      return this.getFormsGroup(sectionWiseElement);
    }
  }

  getFormsGroup(sectionWiseElement: DataElementsControlDetailsItem): FormGroup {
    const formGroup = this.submissionFB.group({});
    sectionWiseElement.DataElementsDetails.forEach((element) => {
      if (Helper.isStringNotNullAndEmpty(element.ControlName)) {
        formGroup.addControl(element.ControlName, this.setControlConfig(element));
      }
    });

    // if (
    //   sectionWiseElement.DataElementsGroupDetails &&
    //   sectionWiseElement.DataElementsGroupDetails.length > 0
    // ) {
    //   sectionWiseElement.DataElementsGroupDetails.forEach(
    //     (groupWiseElement) => {
    //       groupWiseElement.DataElementsDetails
    //         .forEach((element) => {
    //           if (Helper.isStringNotNullAndEmpty(element.ControlName)) {
    //             formGroup.addControl(element.ControlName, this.setControlConfig(element));
    //           }
    //         });
    //     }
    //   );
    // }
    return formGroup;
  }

  private addFormsControls(dataElementsDetails: DataElementsDetails[], group: {}) {
    dataElementsDetails.forEach((element) => {
      if (Helper.isStringNotNullAndEmpty(element.ControlName)) {
        group[element.ControlName] = this.setControlConfig(element);
      } else {
        console.log('Control Name is Blank for ' + element);
      }
    });
  }

  collectionsControls(sectionKey: string): FormArray {
    if (this.submissionFormGroup.get(sectionKey)) {
      return this.submissionFormGroup.get(sectionKey).get(sectionKey) as FormArray;
    } else {
      return null;
    }
  }

  addNewCollectionControls(sectionKey: string) {
    const sectionWiseElement: DataElementsControlDetailsItem[] = this.dataElementsControlDetailsItemPanel.filter((dataElement) => {
      return dataElement.SectionKey === sectionKey;
    });
    if (sectionWiseElement && sectionWiseElement.length > 0) {
      this.collectionsControls(sectionKey).push(this.getFormsGroup(sectionWiseElement[0]));
      this.enableCollectionControlValueChange();
      if (sectionKey === 'AviationDetails') {
        this.setValidatorsByStatus();
      }
    }
  }

  removeCollectionControls(sectionKey: string, rowIndex: number) {
    if (this.collectionsControls(sectionKey).length > 1) {
      const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
        width: '510px',
        data: { Action: 'Delete', label: 'Delete' },
        hasBackdrop: true,
        backdropClass: 'backdropBackground',
      });

      dialogRef.afterClosed().subscribe((result) => {
        if (result && Helper.isStringNotNullAndEmpty(result.Action)) {
          if (result.Action === 'Delete confirm') {
            this.addCollectionDeletedIdsBySectionkey(sectionKey, rowIndex);
            this.collectionsControls(sectionKey).removeAt(rowIndex);
          }
        }
      });
    } else {
      const message = 'One row should be retained!!!';
      this.notifier.showError(message);
    }
  }

  private addCollectionDeletedIdsBySectionkey(sectionKey: string, rowIndex: number) {
    let id;
    if (this.isAviationExists) {
      id = this.collectionsControls(sectionKey).controls[rowIndex].get('AVNAviationID').value;
    }
    if (id && id > 0) {
      this.collectionDeletedItems.push({
        sectionKey: sectionKey,
        id: id,
      });
    }
  }

  private setControlConfig(element: DataElementsDetails): any {
    // const isDisabled = (!element.IsVisible || element.IsReadonly) ? true : false;
    const isDisabled = !element.IsVisible ? true : false;
    return element.IsRequired
      ? new FormControl(
          {
            disabled: isDisabled,
            value: this.translateValues(element),
          },
          {
            validators: Helper.getControlValidator(element, true),
            updateOn: this.getUpdateOn(element),
          }
        )
      : new FormControl(
          {
            disabled: isDisabled,
            value: this.translateValues(element),
          },
          {
            validators: Helper.getControlValidator(element),
            updateOn: this.getUpdateOn(element),
          }
        );
  }

  private getUpdateOn(element: any): 'blur' | 'change' | 'submit' {
    return BlurEventControls.some((cnt) => cnt === element.ControlName) ? 'blur' : 'change';
  }

  translateValues(field: DataElementsDetails) {
    try {
      const target = field.SelectedValues;
      if (Helper.isStringNotNullAndEmpty(target) && field.SectionType !== SectionType.Collections) {
        if (field.ControlType.toLowerCase() === 'radio') {
          return this.reverseRadioValue({ field, target });
        } else if (field.ControlType.toLowerCase() === 'inputabsnumber' || field.ControlType.toLowerCase() === 'inputnumber') {
          return Helper.toRoundNumber(target);
        } else if (field.ControlType.toLowerCase() === 'checkbox') {
          return this.reverseCheckboxValue({ field, target });
        } else if (field.ControlType.toLowerCase() === 'inputdate') {
          return this.setFormattedDateValue(target);
        } else if (field.ControlType.toLowerCase() === 'combodropdown') {
          if (Helper.isStringNotNullAndEmpty(field.PatternTypeName)) {
            return target.split(field.PatternTypeName);
          } else {
            return target.split(',');
          }
        } else if (field.ControlType.toLowerCase() === 'dropdown') {
          return this.setDropdownSelectedValue(field);
        } else {
          return target;
        }
      } else {
        return '';
      }
    } catch (error) {
      console.log({ error });
    }
  }

  private setFormattedDateValue(target: string) {
    return Helper.isStringNotNullAndEmpty(target) ? this.toDate(target, 'yyyy-MM-dd') : '';
  }

  private setDropdownSelectedValue(field: DataElementsDetails) {
    const target = field.SelectedValues;
    if (field.ControlName === 'Privacy') {
      return this.setPrivacySelectedValue(target);
    } else {
      return target;
    }
  }

  private setPrivacySelectedValue(target: string) {
    return target === '2' ? '' : target === '0' ? '2' : target === '1' ? '1' : '';
  }

  reverseRadioValue({ field, target }: { field: any; target: any }) {
    if (Helper.isStringNotNullAndEmpty(target)) {
      return target.trim();
    } else {
      return target;
    }
  }

  reverseCheckboxValue({ field, target }: { field: any; target: any }) {
    if (field.PatternTypeName === CheckboxTransPattern.YesNo) {
      return target === 'Yes' ? true : false;
    } else if (field.PatternTypeName === CheckboxTransPattern.YN) {
      return target === 'Y' ? true : false;
    } else if (field.PatternTypeName === CheckboxTransPattern.RegisteredNo) {
      return target === 'Registered' ? true : false;
    } else {
      return target === 1 || target === '1' ? true : false;
    }
  }

  async enableControlValueChange() {
    try {
      ValueChangedControls.forEach((controlName) => {
        if (this.isControlExists(controlName)) {
          this.submissionFormGroup
            .get(controlName)
            .valueChanges.pipe(debounceTime(1000), distinctUntilChanged())
            .subscribe((controlValue) => {
              this.handleValueChange(controlName + ' : ' + controlValue);
              if (CheckControls.some((cn) => cn === controlName)) {
                this.setUserIdAndCurrentDate(controlName);
                if (controlName === 'canadaPCQuotedCheck' || controlName === 'CanadaPCQuoteAcceptanceCheck') {
                  this.validateMetricsStatus();
                }
              } else if (DateValueValidationControls.some((cn) => cn === controlName)) {
                this.setDateValueValidation();
                this.datesValidationAH();
                this.validateBoundQuotedSubDateAH();
              } else if (HelperControls.some((cn) => cn === controlName)) {
                this.getSubmissionHelper(controlName);
                this.customValidation(controlName, controlValue);
              } else {
                this.customValidation(controlName, controlValue);
              }
            });
        }
      });

      this.setUnderwriterDetails();
    } catch (error) {
      console.error(error);
    }
  }

  async enableCollectionControlValueChange() {
    if (this.isAviationExists) {
      this.enableAviationValueChange();
    }
  }

  private enableAviationValueChange() {
    const valueChangedCollsControls = ['AVNACESharePercentage', 'AVNTotalPremium', 'AVNTotalLimit', 'AVNPortFolioClass', 'AVNPremiumCurrency', 'AVNProduct'];
    try {
      valueChangedCollsControls.forEach((controlName) => {
        const sectionKey = 'AviationDetails';
        const collectionDetails = this.collectionsControls(sectionKey);
        if (collectionDetails) {
          for (let rowIndex = 0; rowIndex < collectionDetails.length; rowIndex++) {
            if (this.isCollsCTRLExistsForChangeEvent(collectionDetails, controlName, rowIndex)) {
              collectionDetails.controls[rowIndex]
                .get(controlName)
                .valueChanges.pipe(debounceTime(1000), distinctUntilChanged())
                .subscribe((controlValue) => {
                  if (['AVNTotalPremium', 'AVNPortFolioClass'].includes(controlName)) {
                    Promise.resolve().then(() => {
                      if (Helper.isStringNotNullAndEmpty(this.getCollectionValueByName('AVNACESharePercentage', rowIndex))) {
                        this.setACESharePremium(rowIndex);
                        if (Helper.isStringNotNullAndEmpty(this.getCollectionValueByName('AVNPremiumCurrency', rowIndex))) {
                          this.setTotalPremiumUSD(rowIndex);
                          this.setACESharePremiumUSD(rowIndex);
                          this.setNetForecastUSD(rowIndex);
                        }
                      }
                    });
                  } else if (controlName === 'AVNACESharePercentage') {
                    Promise.resolve().then(() => {
                      if (Helper.isStringNotNullAndEmpty(this.getCollectionValueByName('AVNTotalPremium', rowIndex))) {
                        this.setACESharePremium(rowIndex);
                        this.setACESharelimit(rowIndex);
                        if (Helper.isStringNotNullAndEmpty(this.getCollectionValueByName('AVNPremiumCurrency', rowIndex))) {
                          this.setTotalPremiumUSD(rowIndex);
                          this.setACESharePremiumUSD(rowIndex);
                          this.setNetForecastUSD(rowIndex);
                        }
                      }
                    });
                  } else if (controlName === 'AVNTotalLimit') {
                    if (Helper.isStringNotNullAndEmpty(this.getCollectionValueByName('AVNACESharePercentage', rowIndex))) {
                      this.setACESharelimit(rowIndex);
                    }
                  } else if (controlName === 'AVNPremiumCurrency') {
                    Promise.resolve().then(() => {
                      this.setLimitCurrency(rowIndex);
                      if (Helper.isStringNotNullAndEmpty(this.getCollectionValueByName('AVNACESharePercentage', rowIndex)) && Helper.isStringNotNullAndEmpty(this.getCollectionValueByName('AVNTotalPremium', rowIndex))) {
                        this.setTotalPremiumUSD(rowIndex);
                        this.setACESharePremiumUSD(rowIndex);
                        this.setNetForecastUSD(rowIndex);
                      }
                    });
                  } else if (controlName === 'AVNProduct') {
                    this.setPortFolioClass(rowIndex);
                  }
                });
            }
          }
        }
      });
    } catch (error) {
      console.error(error);
    }
  }

  setLimitCurrency(rowIndex: number) {
    const premiumCurrency = this.getCollectionValueByName('AVNPremiumCurrency', rowIndex);
    this.setCollectionValueByName('AVNLimitCurrency', premiumCurrency, rowIndex);
  }

  setACESharePremium(rowIndex) {
    const totalPremium = this.getCollectionNumValueByName('AVNTotalPremium', rowIndex);
    console.log({ totalPremium });
    const aceSharePremium = totalPremium * this.getACESharePercentage(rowIndex);
    this.setCollectionValueByName('AVNACESharePremium', aceSharePremium, rowIndex);
  }

  setACESharelimit(rowIndex) {
    const totalLimit = this.getCollectionNumValueByName('AVNTotalLimit', rowIndex);

    const aceSharelimit = totalLimit * this.getACESharePercentage(rowIndex);
    this.setCollectionValueByName('AVNACESharelimit', aceSharelimit, rowIndex);
  }

  setTotalPremiumUSD(rowIndex) {
    const totalPremium = this.getCollectionNumValueByName('AVNTotalPremium', rowIndex);
    console.log({ totalPremium });
    this.forecastConvertor = {
      ...this.forecastConvertor,
      Forecast: totalPremium,
      IsNetforecastYN: 'N',
      Currency: this.getCollectionValueByName('AVNPremiumCurrency', rowIndex),
      PortFolioClass: '',
    };
    if (Helper.isStringNotNullAndEmpty(this.forecastConvertor.UserID)) {
      let totalPremiumUSD: number = 0;
      this.subscriptionAviationDetails$ = this.inputPageService.getUSDConvertedForecast(this.forecastConvertor).subscribe(async (data: number) => {
        Promise.resolve().then(() => {
          if (data != null) {
            totalPremiumUSD = Number(data);
          }
          this.setCollectionValueByName('AVNTotalPremiumUSD', totalPremiumUSD, rowIndex);
          const totalProgramPremium = this.getTotalProgramPremium();
          this.setValueByName('TotalProgramPremium', totalProgramPremium);
          this.setReadOnlyByName('TotalProgramPremium', true);
        });
      });
    }
  }

  setACESharePremiumUSD(rowIndex) {
    const aceSharePremium = this.getCollectionNumValueByName('AVNACESharePremium', rowIndex);
    console.log({ aceSharePremium });
    this.forecastConvertor = {
      ...this.forecastConvertor,
      Forecast: aceSharePremium,
      IsNetforecastYN: 'N',
      Currency: this.getCollectionValueByName('AVNPremiumCurrency', rowIndex),
      PortFolioClass: '',
    };
    if (Helper.isStringNotNullAndEmpty(this.forecastConvertor.UserID)) {
      let aceSharePremiumUSD: number = 0;
      this.subscriptionAviationDetails$ = this.inputPageService.getUSDConvertedForecast(this.forecastConvertor).subscribe(async (data: number) => {
        Promise.resolve().then(() => {
          if (data != null) {
            aceSharePremiumUSD = Number(data);
          }
          this.setCollectionValueByName('AVNACESharePremiumUSD', aceSharePremiumUSD, rowIndex);
          const totalForecast = this.getGrossForecast();
          this.setValueByName('Forecast', totalForecast);
          this.setReadOnlyByName('Forecast', true);
        });
      });
    }
  }

  setNetForecastUSD(rowIndex) {
    const aceSharePremium = this.getCollectionNumValueByName('AVNACESharePremium', rowIndex);
    console.log({ aceSharePremium });
    this.forecastConvertor = {
      ...this.forecastConvertor,
      Forecast: aceSharePremium,
      IsNetforecastYN: 'Y',
      PortFolioClass: this.getCollectionValueByName('AVNPortFolioClass', rowIndex),
      Currency: this.getCollectionValueByName('AVNPremiumCurrency', rowIndex),
    };
    if (Helper.isStringNotNullAndEmpty(this.forecastConvertor.UserID)) {
      let netForecastUSD: number = aceSharePremium;
      this.subscriptionAviationDetails$ = this.inputPageService.getUSDConvertedForecast(this.forecastConvertor).subscribe(async (data: number) => {
        Promise.resolve().then(() => {
          if (data != null) {
            netForecastUSD = Number(data);
          }
          this.setCollectionValueByName('AVNNetForecastUSD', netForecastUSD, rowIndex);
          const netForecast = this.getNetForecast();
          this.setValueByName('NetForecast', netForecast);
          this.setReadOnlyByName('NetForecast', true);
        });
      });
    }
  }

  setPortFolioClass(rowIndex: number) {
    const product = this.getCollectionValueByName('AVNProduct', rowIndex);
    if (Helper.isStringNotNullAndEmpty(product)) {
      let helperFilterItem: SubmissionHelperFilterItem;
      helperFilterItem = {
        UserID: this.forecastConvertor.UserID,
        Unit: this.forecastConvertor.Unit,
        Segment: this.forecastConvertor.Segment,
        HelperMethodName: HelperMethodName.PortfolioByLOB,
        Product: product,
      };
      this.helperDetails$ = this.inputPageService.getSubmissionHelperDetails(helperFilterItem).subscribe((data: SubmissionHelperResponseItem) => {
        if (data && data !== null) {
          this.setCollectionValueByName('AVNPortFolioClass', data.PortFolioClass, rowIndex);
        }
      });
    } else {
      this.setCollectionValueByName('AVNPortFolioClass', '', rowIndex);
    }
  }

  private getACESharePercentage(rowIndex: number): number {
    const aceSharePercentage: number = this.getCollectionNumValueByName('AVNACESharePercentage', rowIndex);
    console.log({ aceSharePercentage });
    const percentage = aceSharePercentage / 100;
    return percentage;
  }

  getCollectionItems(sectionKey: string): any[] {
    const collections = this.submissionFormGroup.getRawValue()[sectionKey];
    if (collections && collections[sectionKey]) {
      return collections[sectionKey];
    } else {
      return [];
    }
  }

  getTotalProgramPremium(): number {
    const sectionKey = 'AviationDetails';
    let totalProgramPremium = this.getCollectionItems(sectionKey).reduce((accumulator, current) => accumulator + Number(current.AVNTotalPremiumUSD ? current.AVNTotalPremiumUSD : 0), 0);
    return totalProgramPremium;
  }

  getGrossForecast(): number {
    const sectionKey = 'AviationDetails';
    let sumGrossForecastUSD = this.getCollectionItems(sectionKey).reduce((accumulator, current) => accumulator + Number(current.AVNACESharePremiumUSD ? current.AVNACESharePremiumUSD : 0), 0);
    return sumGrossForecastUSD;
  }

  getNetForecast(): number {
    const sectionKey = 'AviationDetails';
    let sumNetForecastUSD = this.getCollectionItems(sectionKey).reduce((accumulator, current) => accumulator + Number(current.AVNNetForecastUSD ? current.AVNNetForecastUSD : 0), 0);
    return sumNetForecastUSD;
  }

  calculateUSDByMonthYear(accountingMonth: string = '', accountingYear: string = '') {
    if (Helper.isStringNotNullAndEmpty(accountingMonth) && Helper.isStringNotNullAndEmpty(accountingYear)) {
      const sectionKey = this.getSectionKeyByName('NetForecast');
      const collectionDetails = this.getCollectionItems(sectionKey);
      this.forecastConvertor.AccountingMonth = accountingMonth;
      this.forecastConvertor.AccountingYear = accountingYear;
      if (collectionDetails && collectionDetails.length > 0) {
        const totalRows = collectionDetails.length;
        for (let rowIndex = 0; rowIndex < totalRows; rowIndex++) {
          if (Helper.isStringNotNullAndEmpty(this.getCollectionValueByName('AVNACESharePercentage', rowIndex)) && Helper.isStringNotNullAndEmpty(this.getCollectionValueByName('AVNPremiumCurrency', rowIndex)) && Helper.isStringNotNullAndEmpty(this.getCollectionValueByName('AVNTotalPremium', rowIndex))) {
            this.setTotalPremiumUSD(rowIndex);
            this.setACESharePremiumUSD(rowIndex);
            if (Helper.isStringNotNullAndEmpty(this.getCollectionValueByName('AVNPortFolioClass', rowIndex))) {
              this.setNetForecastUSD(rowIndex);
            }
          }
        }
      }
    }
  }

  isCollsCTRLExistsForChangeEvent(collectionDetails: any, controlName: string, rowIndex: number): boolean {
    if (collectionDetails.controls[rowIndex].get(controlName)) {
      return true;
    } else {
      console.log(controlName + 'is not available');
      return false;
    }
  }

  setValidatorsByStatus() {
    setTimeout(() => {
      if (this.StatusValue === Status.Bound) {
        this.setValidators(true);
      } else {
        this.setValidators();
      }
      this.cdRef.detectChanges();
    }, 0);
  }

  private setValidators(isRequired: boolean = false) {
    if (this.DataElementsAllDetails) {
      const sectionKey = 'AviationDetails';
      let totalRows = this.collectionsControls(sectionKey).length;
      for (let rowIndex = 0; rowIndex < totalRows; rowIndex++) {
        this.DataElementsAllDetails.filter((ele) => ele.IsRequired && ele.SectionKey === sectionKey).forEach((cnt) => {
          if (isRequired) {
            this.addCollectionValidators(sectionKey, cnt.ControlName, rowIndex);
          } else {
            this.removeCollectionValidators(sectionKey, cnt.ControlName, rowIndex);
          }
        });
      }
    }
  }

  private removeCollectionValidators(sectionKey: string, controlName: string, rowIndex: number) {
    const collectionDetails = this.collectionsControls(sectionKey);
    if (collectionDetails.controls[rowIndex].get(controlName)) {
      collectionDetails.controls[rowIndex].get(controlName).clearValidators();
      collectionDetails.controls[rowIndex].get(controlName).updateValueAndValidity({
        emitEvent: false,
      });
    }
  }

  private addCollectionValidators(sectionKey: string, controlName: string, rowIndex: number) {
    const collectionDetails = this.collectionsControls(sectionKey);
    if (collectionDetails.controls[rowIndex].get(controlName)) {
      collectionDetails.controls[rowIndex].get(controlName).setValidators([Validators.required]);
      collectionDetails.controls[rowIndex].get(controlName).updateValueAndValidity({
        emitEvent: false,
      });
    }
  }

  private setUnderwriterDetails() {
    const autoCompleteCTRL = ['LoginName', 'UnderwriterAssistant'];
    try {
      autoCompleteCTRL.forEach((ctrlName) => {
        if (this.isControlExists(ctrlName)) {
          const CTRL = this.getElementsByName(ctrlName);
          this.submissionFormGroup
            .get(ctrlName)!
            .valueChanges.pipe(
              debounceTime(300),
              tap(() => (this.isLookupLoading = true)),
              filter((underWriterName) => !!underWriterName),
              switchMap((underWriterName) => this.inputPageService.getUnderWriterNameSearch(typeof underWriterName === 'string' ? underWriterName : underWriterName.text).pipe(finalize(() => (this.isLookupLoading = false))))
            )
            .subscribe((data) => {
              CTRL[0].OptionsUWItems = data;
            });

          this.submissionFormGroup
            .get(ctrlName)!
            .valueChanges.pipe(debounceTime(300), distinctUntilChanged())
            .subscribe((item: OptionsUWItems) => {
              console.log({ item });
              if (ctrlName === 'LoginName') {
                if (typeof item === 'string') {
                  if (!Helper.isStringNotNullAndEmpty(this.loginName)) {
                    this.setValueByNameNoEvent('UWEmail', '');
                  }
                } else if (typeof item === 'object') {
                  this.setValueByNameNoEvent('UWEmail', item.email);
                  this.setValueByName('UWBranch', item.uwBranch);
                  this.contactSearchFilter.FullName = item.text;
                  this.contactSearchFilter.Email = item.email;
                  this.contactSearchFilter.SubmissionSearchType = 'UW';
                  // this.submissionSaveItem.ParentItem.LoginName = item.value;
                  this.getContactsDetails('LoginName', true);
                }
              } else if (ctrlName === 'UnderwriterAssistant') {
                if (typeof item === 'string') {
                  if (!Helper.isStringNotNullAndEmpty(this.submissionFormGroup.get('UnderwriterAssistant').value)) {
                    this.setValueByNameNoEvent('UAEmail', '');
                  }
                } else if (typeof item === 'object') {
                  this.setValueByNameNoEvent('UAEmail', item.email);
                  this.contactSearchFilter.FullName = item.text;
                  this.contactSearchFilter.Email = item.email;
                  this.contactSearchFilter.SubmissionSearchType = 'UA';
                  // this.submissionSaveItem.ParentItem.UnderwriterAssistant =
                  //   item.value;
                  this.getContactsDetails('UnderwriterAssistant', true);
                }
              }
            });
        }
      });
    } catch (error) {
      console.error(error);
    }
  }

  displayFn(uwOptionsItems: OptionsUWItems): string {
    return uwOptionsItems && uwOptionsItems.text ? uwOptionsItems.text : '';
  }

  setUnderwriterLogin(fullName: string, onLoad: boolean, onSearch: boolean = false) {
    if (Helper.isStringNotNullAndEmpty(fullName)) {
      this.underWriterNameSearch$ = this.inputPageService.getUnderWriterNameSearch(fullName).subscribe((uwItems: OptionsUWItems[]) => {
        if (uwItems !== null && uwItems.length > 0) {
          this.submissionFormGroup.get('LoginName').setValue(uwItems[0], {
            emitEvent: false,
          });
          this.setValueByNameNoEvent('UWEmail', uwItems[0].email);
          if ((!Helper.isStringNotNullAndEmpty(this.getValueByName('UWBranch')) || onSearch) && Helper.isStringNotNullAndEmpty(uwItems[0].uwBranch)) {
            this.setValueByName('UWBranch', uwItems[0].uwBranch);
          }
          if (onLoad) {
            this.setUWCRMGUID();
          }
        }
      });
    }
  }

  setUnderwriterAssistant(fullName: string, onLoad: boolean = false) {
    if (Helper.isStringNotNullAndEmpty(fullName)) {
      this.underWriterNameSearch$ = this.inputPageService.getUnderWriterNameSearch(fullName).subscribe((uwItems: OptionsUWItems[]) => {
        if (uwItems !== null) {
          this.submissionFormGroup.get('UnderwriterAssistant').setValue(uwItems[0], {
            emitEvent: false,
          });
          this.setValueByNameNoEvent('UAEmail', uwItems[0].email);
          if (onLoad) {
            this.setUACRMGUID();
          }
        }
      });
    }
  }

  get uaFullName() {
    const uaItem = this.submissionFormGroup.get('UnderwriterAssistant').value;
    if (uaItem && typeof uaItem === 'object') {
      return uaItem.text;
    } else {
      return '';
    }
  }

  get uaEmail() {
    const uaItem = this.submissionFormGroup.get('UnderwriterAssistant').value;
    if (uaItem && typeof uaItem === 'object') {
      return uaItem.email;
    } else {
      return '';
    }
  }

  get underwriterAssistant() {
    const loginNameItem = this.submissionFormGroup.get('UnderwriterAssistant').value;
    if (loginNameItem && typeof loginNameItem === 'object') {
      return loginNameItem.value;
    } else {
      return '';
    }
  }

  get loginName() {
    const loginNameItem = this.submissionFormGroup.get('LoginName').value;
    if (loginNameItem && typeof loginNameItem === 'object') {
      return loginNameItem.value;
    } else {
      return '';
    }
  }

  get uwFullName() {
    const loginNameItem = this.submissionFormGroup.get('LoginName').value;
    if (loginNameItem && typeof loginNameItem === 'object') {
      return loginNameItem.text;
    } else {
      return '';
    }
  }

  get uwEmail() {
    const loginNameItem = this.submissionFormGroup.get('LoginName').value;
    if (loginNameItem && typeof loginNameItem === 'object') {
      return loginNameItem.email;
    } else {
      return '';
    }
  }

  get uwBranch() {
    const loginNameItem = this.submissionFormGroup.get('LoginName').value;
    if (loginNameItem && typeof loginNameItem === 'object') {
      return loginNameItem.uwBranch;
    } else {
      return '';
    }
  }

  get loginUserID() {
    return this.user.UserID || this.userID;
  }

  customValidation(controlName: string, controlValue: any) {
    switch (controlName) {
      case 'AccountingYear':
      case 'AccountingMonth':
        this.calculateUSDByMonthYear(this.getValueByName('AccountingMonth'), this.getValueByName('AccountingYear'));
        break;
      case 'Status':
        this.onStatusChange();
        break;
      case 'LayerStatus':
        this.capitalRiskValidation();
        break;
      case 'Type':
        this.onTypeChange();
        break;
      case 'MergersAndAcquisitionsYN':
        this.maHideVisible();
        break;
      case 'FirmType':
        this.maRetroDateHideVisible();
        break;
      case 'PortFolioClass':
        this.publicEntityValidation();
        this.validateMedRisk();
        this.displayCtrlPortfolio();
        break;
      case 'Product':
        this.validateMedRisk();
        this.pmlValidationByProduct();
        this.capitalRiskValidation();
        this.getPortFolioClassByProducts();
        this.setSymbol();
        this.displayCtrlProduct();
        this.displayCloud();
        this.disp();
        this.productChangeAH();
        // this.populateStatusByType();
        break;
      case 'Forecast':
        this.setNetForecast();
        this.setUISDIC();
        this.getAnnualPremium();
        this.validateControlValueByName(controlName);
        this.mfgCustomValidation();
        break;
      case 'FrontingFee':
        this.frontFeeValid();
        this.setNetForecast();
        break;
      case 'GrossFACPremium':
        this.setNetForecast();
        break;
      case 'BandMFacility':
        this.sumGrossFACPremium();
        break;
      case 'USBOrLADGWP':
        this.setUISDIC();
        break;
      case 'Brokerage':
      case 'BasePremium':
      case 'Limit':
      case 'RiskSICCode':
        this.validateControlValueByName(controlName);
        this.fillPostmortemDefault();
        break;
      case 'PrimaryExcess':
        this.disp();
        this.setSymbolByPrimaryExcess();
        break;
      case 'PolicyNo':
        this.setSymbol();
        this.policyTypeValidation(controlName);
        this.setType();
        this.validatePolicyNoAH();
        break;
      case 'ExpiringPolicyNumber':
        this.policyTypeValidation(controlName);
        break;
      case 'PolicyType':
      case 'ExpiringPolicyType':
        this.policyNumberValidation(controlName);
        break;
      case 'ConfidentialityAgreement':
        this.confidentialityAgreement();
        break;
      case 'EffectiveDate':
        this.targetEffectiveDtValidation();
        this.aogDateValidation();
        this.getAnnualPremium();
        this.setDefaultExpirationDate();
        break;
      case 'ExpirationDate':
        this.aogDateValidation();
        this.getAnnualPremium();
        break;
      case 'ChubbIssuedForeignPolicies':
        this.foreignPolValidation();
        break;
      case 'PolicyTerm':
        this.policyTermTypeVisible();
        break;
      case 'SurplusShare':
      case 'AffiliatedFacility':
      case 'NonAffiliatedFacility':
        this.sumGrossFACPremium();
        break;
      case 'LowerDeductibleWording':
        this.amountSubjectVisibleOrHide();
        break;
      case 'AggregateDeductible':
        this.aggDeductibleVisibleOrHide();
        break;
      case 'SelfAuditCheck':
        this.setSelfAuditValue();
        break;
      case 'Privacy':
        this.pmlValidationByPrivacy();
        this.getPortFolioClassByProducts();
        this.displayCloud();
        break;
      case 'DBTOption':
        this.pmlValidationByPrivacy();
        break;
      case 'Segment':
        if (this.isValidUnit('Regional Target')) {
          // this.capitalRiskValidation();
          // this.validationRiskNAIC();
          // this.validateMandatoryNAICCode();
          // this.setMandatoryByUnitSegment();
          // this.setNetForecast();
          // this.getPortFolioClassByProducts();
          // this.outToMarketIndicator();
          // this.validateSixdigit();
          // this.setPolicyRISCNAICValues();
          // this.setMandatoryByStatus();
          // this.displayCtrlPortfolio();
          // this.mfgMandatoryValidation();
          // this.mfgCustomValidation();
          // this.pmlDisplay();
          // this.productChangeAH();
        } else {
          this.reloadSubmissionPage();
        }
        break;
      case 'SubSegment':
        this.disp();
        this.setSymbol();
        // this.populateStatusByType();
        break;
      case 'PrimaryIndustry':
        this.getPortFolioClassByProducts();
        break;
      case 'RiskNAIC':
        this.validateSixdigit();
        break;
      case 'NAICSCode':
        this.validateSixdigitNAICCode();
        this.setPolicyRISCNAICValues();
        break;
      case 'ProducerCode':
        this.validateBrokerCode();
        break;
      case 'DBSIC':
        this.setPolicyRISCNAICValues();
        break;
      case 'OutToMarketIndicator':
        this.outToMarketIndicator();
        break;
      case 'DataBreachFundInsideTheLimit':
        this.displayDataLimit();
        break;
      case 'PackagePremium':
      case 'AutoPremium':
      case 'MarinePremium':
      case 'BuildersRiskPremium':
      case 'OtherPremium':
      case 'MGLRiskPremium':
      case 'BoatClubPremium':
        this.mfgCustomValidation();
        break;
      case 'InsuredName':
        this.inputPageHeader.UserInsuredName = controlValue;
        break;
      case 'MNCode':
        this.mnCodeValidation();
        break;
      case 'MarketingProgramCode':
        this.mpCodeValidation();
        break;
      case 'AccountInMarket':
        this.fillReasons();
        break;
      case 'Incumbent':
        this.fillPostmortemDefault();
        break;
      case 'Auditable':
      case 'AuditableFrequency':
        this.auditFreqOtherEnable();
        this.setAuditableFrequencyMandatory();
        break;
      case 'Services':
        this.setAuditableFrequencyMandatory();
        break;
      case 'PolicyExtended':
        this.setPolicyNoOfMonthsExtended();
        break;
      case 'ConfidenceFactor':
        this.disp1();
        break;
      case 'WrapupType':
        this.constructionDisplay();
        this.validateCompetition();
        break;
      case 'ContactFirst':
      case 'ContactLast':
      case 'BrokerEmail':
      case 'UWEmail':
      case 'UAEmail':
        this.handleContactSearch(controlName);
        break;
      case 'ForecastType':
        this.handleBuildOutSchedule();
        this.setTotalProjectPremiumVisibility();
        break;
      case 'MailingStatus':
        this.setMailedDate();
        break;
      case 'TRIAPurchased':
        this.setTRIAPremiumMandatoryByTRIA();
        break;
      case 'IndustryPractice':
        this.setIndustryPracticeDescription();
        break;
      case 'Comments':
        this.setCommentsSaveIconVisibility();
        break;
      case 'OutToMarketCarrier':
        if (controlValue) {
          if (controlValue.length === 0) {
            const outOfCarrier = this.getOutToMarketCarrier();
            if (outOfCarrier) {
              outOfCarrier[0].isOpen = false;
            }
          }
        }
        break;
      default:
        this.handleValueChange('default :' + controlName + ' : ' + controlValue);
        break;
    }
  }

  setDefaultExpirationDate() {
    if (!this.isRecordExists && Helper.isStringNotNullAndEmpty(this.getValueByName('EffectiveDate'))) {
      const effectiveDate: Date = this.getDateValueByName('EffectiveDate');
      const currentYear = new Date().getFullYear();
      if (Helper.isLeapYear(currentYear)) {
        effectiveDate.setDate(effectiveDate.getDate() + 366);
      } else {
        effectiveDate.setDate(effectiveDate.getDate() + 365);
      }
      const expirationDate = this.datepipe.transform(new Date(effectiveDate), 'yyyy-MM-dd');
      this.setValueByName('ExpirationDate', expirationDate);
    }
  }

  private setIndustryPracticeDescription() {
    const industryPractice = this.getValueByName('IndustryPractice');
    if (Helper.isStringNotNullAndEmpty(industryPractice)) {
      const cascadingPayload = {
        UserID: this.loginUserID,
        ParentControlName: 'IndustryPractice',
        ChildControlName: 'IndustryPracticeDescription',
        ParentControlValues: [industryPractice],
      };
      this.loadCascadingDropdownLookup(cascadingPayload);
    } else {
      if (this.lookup) {
        const ipdLookup: FilterType[] = this.lookup
          .filter((ele) => ele.ControlName === 'IndustryPracticeDescription')
          .map((items) => ({
            text: items.DataText,
            value: items.DataValue,
            displayOrder: items.DisplayOrder,
          }));
        this.loadLookupByName(ipdLookup, 'IndustryPracticeDescription');
      }
      if (Helper.isStringNotNullAndEmpty(this.getValueByName('IndustryPracticeDescription'))) {
        this.setValueByName('IndustryPracticeDescription', '');
      }
    }
  }

  setMailedDate() {
    if (this.getValueByName('MailingStatus') === 'Mailed') {
      this.setValueByName('MailedDate', Helper.setDateNow());
    } else {
      this.setValueByName('MailedDate', '');
    }
  }

  async validationOnLoad() {
    this.initialSaveItemControlsData();
    this.setCollectionCTRLSValue();
    this.setMandatoryByInputPageName();
    this.setMandatoryByUnitSegment();
    this.transferChangeUnitVisibility();
    // Save Submission Validation
    if (this.isValidInputPageName(InputPageName.InputChubb)) {
      this.cuwValidation();
    }
    // set Control Visibility On Load
    if (this.isValidInputPageName(InputPageName.InputCapitalRisk)) {
      this.capitalRiskDisplay();
      this.disp();
      // this.changeCaption(); called inside this.disp();
    }
    // Page_PreRender
    this.setByInputPageName();
    this.setDefaultValueByGeniusPipeId();
    this.setStatusandPostMortem();
    this.triggerValidationForNewOrExistingSub();
    this.triggerValidationForExistingSub();
    this.amountSubjectVisibleOrHide(true);
    this.aggDeductibleVisibleOrHide(true);
  }

  setCollectionCTRLSValue() {
    if (this.isRecordExists && this.sectionKeyItemsForList) {
      this.sectionKeyItemsForList.forEach((sectionKey) => {
        this.setCollectionsValueBySectionkey(sectionKey);
      });
    }
  }

  private setCollectionsValueBySectionkey(sectionKey: string) {
    const methodName = 'get' + sectionKey;
    this.collectionDetails$ = this.inputPageService[methodName](this.userID, this.recordNumber).subscribe(async (collectionsItems: any[]) => {
      setTimeout(() => {
        if (collectionsItems != null) {
          console.log({ collectionsItems });
          collectionsItems.forEach((items, rowIndex) => {
            if (rowIndex > 0) {
              this.addNewCollectionControls(sectionKey);
            }
            if (this.DataElementsAllDetails) {
              const filteredDataElements = this.DataElementsAllDetails.filter((element) => {
                return (element.SectionKey = sectionKey);
              });
              filteredDataElements.forEach((cnt) => {
                this.setCollectionValueByName(cnt.ControlName, items[cnt.ControlName] === undefined ? '' : items[cnt.ControlName], rowIndex);
              });
            }
          });
        }
        this.enableCollectionControlValueChange();
      }, 0);
    });
  }

  private isCollectionControlExists(controlName: string): Boolean {
    const sectionKey = this.getSectionKeyByName(controlName);
    if (this.submissionCollectionFields(sectionKey) && this.submissionCollectionFields(sectionKey).get(controlName)) {
      return true;
    } else {
      return false;
    }
  }

  private getSectionKeyByName(controlName: string) {
    const filteredSectionDetails = this.DataElementsAllDetails.filter((element) => {
      return element.ControlName === controlName;
    });
    if (filteredSectionDetails && filteredSectionDetails.length > 0) {
      return filteredSectionDetails[0].SectionKey;
    } else {
      return '';
    }
  }

  private setDDLDefaultValue() {
    const dropdownDataElements = this.DataElementsAllDetails.filter((element) => element.ControlType === 'dropdown' && element.SelectedValues !== '' && element.SelectedValues !== null);
    console.log({ dropdownDataElements });
    if (dropdownDataElements && dropdownDataElements.length > 0) {
      dropdownDataElements.forEach((item) => {
        const filteredOrgLookup = this.lookup.filter((element) => {
          return element.ControlName.toLowerCase() === item.ControlName.toLowerCase() && element.DataValue === item.SelectedValues;
        });
        if (filteredOrgLookup && filteredOrgLookup.length === 0) {
          const filteredLookup = this.lookup.filter((element) => {
            return element.ControlName.toLowerCase() === item.ControlName.toLowerCase() && [element.DataValue.toLowerCase(), element.DataText.toLowerCase()].includes(item.SelectedValues.toLowerCase());
          });
          if (filteredLookup && filteredLookup.length === 0) {
            this.reloadLoadDDLByName(item.ControlName, item.SelectedValues);
          }
          // if (filteredLookup && filteredLookup.length > 0) {
          //   this.setValueByNameNoEvent(
          //     item.ControlName,
          //     filteredLookup[0].DataValue
          //   );
          // } else {
          //   this.reloadLoadDDLByName(item.ControlName, item.SelectedValues);
          // }
        }
      });
    }
  }

  reloadLoadDDLByName(controlName, defaultValue) {
    if (Helper.isStringNotNullAndEmpty(controlName) && Helper.isStringNotNullAndEmpty(defaultValue)) {
      const cntl = this.getElementsByName(controlName);
      try {
        if (cntl && cntl.length > 0) {
          let optionList: any = cntl[0].Options;
          if (optionList) {
            optionList.push({
              text: defaultValue,
              value: defaultValue,
            });
          } else {
            optionList = {
              text: defaultValue,
              value: defaultValue,
            };
          }
          cntl[0].Options = optionList;
        }
      } catch (error) {
        console.log({ error });
      }
    }
  }

  private setPolicyNoOfMonthsExtended() {
    if (Boolean(this.getValueByName('PolicyExtended')) === true) {
      this.setEnableOrDisable('NumberOfMonthsExtended', true);
    } else {
      this.setEnableOrDisable('NumberOfMonthsExtended', false);
    }
  }

  callPolicyExtended() {
    if (this.isValidStatus(Status.Bound)) {
      this.setEnableOrDisable('PolicyExtended', true);
      if (Boolean(this.getValueByName('PolicyExtended')) === true) {
        this.setEnableOrDisable('NumberOfMonthsExtended', true);
      } else {
        this.setEnableOrDisable('NumberOfMonthsExtended', false);
      }
    } else {
      this.setEnableOrDisable('PolicyExtended', false);
      this.setEnableOrDisable('NumberOfMonthsExtended', false);
    }
  }

  private triggerValidationForNewOrExistingSub() {
    this.setCRMGUID();
    if (Helper.isStringNotNullAndEmpty(this.StatusValue)) {
      this.onStatusChange(true);
    }
    if (Helper.isStringNotNullAndEmpty(this.TypeValue)) {
      this.onTypeChange(true);
    }
    if (Helper.isStringNotNullAndEmpty(this.StatusValue) && Helper.isStringNotNullAndEmpty(this.TypeValue)) {
      this.setMandatoryByStatusAndType();
    }
    this.validationRiskNAIC();
    this.validateMandatoryNAICCode();
    this.setNetForecast();
    if (Helper.isStringNotNullAndEmpty(this.getValueByName('Product'))) {
      this.getPortFolioClassByProducts();
    }
    this.outToMarketIndicator();
    this.validateSixdigit();
    this.setPolicyRISCNAICValues();
    this.setSymbol();
    this.validateMedRisk();
    this.validateMetricsStatus();
    this.policyTermTypeVisible();

    this.displayCtrlProduct();
    this.displayCtrlPortfolio();
    this.mfgMandatoryValidation();
    this.maHideVisibleOnLoad();
    this.constructionDisplay();
    this.setTRIAPremiumMandatoryByTRIA();
    if (this.isAviationExists) {
      this.setValidatorsByStatus();
    }
    this.setTotalProjectPremiumVisibility();
  }

  private triggerValidationForExistingSub() {
    if (this.isRecordExists) {
      this.setUnderwriterLogin(this.getControlValueByName('LoginName'), true);
      this.setUnderwriterAssistant(this.getControlValueByName('UnderwriterAssistant'), true);
      const outToMarketCarrier: any = this.getValueByName('OutToMarketCarrier');
      if (outToMarketCarrier && outToMarketCarrier.length > 0) {
        this.showOutToMarketCarrier();
      }
      this.validateOccurance();
      this.pmlValidationByProduct();
      this.setUISDIC();
      this.getAnnualPremium();
      this.validateControlValueByName('Brokerage');
      this.validateControlValueByName('BasePremium');
      this.validateControlValueByName('Forecast');
      this.validateControlValueByName('Limit');
      this.validateControlValueByName('RiskSICCode');
      this.mfgCustomValidation();
      this.frontFeeValid();
      this.sumGrossFACPremium();
      this.setSymbolByPrimaryExcess();
      this.policyTypeValidation('PolicyNo');
      this.policyTypeValidation('ExpiringPolicyNumber');
      this.policyNumberValidation('PolicyType');
      this.policyNumberValidation('ExpiringPolicyType');
      this.confidentialityAgreement();
      this.aogDateValidation();
      this.setSelfAuditValue();
      this.pmlValidationByPrivacy();
      this.validateSixdigitNAICCode();
      this.validateBrokerCode();
      this.displayDataLimit();
      this.customValidationAH();
      this.setDBLookupMandatory();
      this.setLinkedRecordNumberTitle();
    }
  }

  setLinkedRecordNumberTitle() {
    this.linkedRecordNoTitle = '';
    if (this.MetadataDetails && ['Major Accounts Division', 'Commercial Insurance Division', 'Small Retail Division'].includes(this.companyValue)) {
      if ([Status.Target, Status.TargetClosed].includes(this.StatusValue)) {
        this.linkedRecordNoTitle = this.MetadataDetails.LinkedRecordNumber > 0 ? 'Submission Record Received' : 'Submission Not Received';
      } else {
        this.linkedRecordNoTitle = this.MetadataDetails.LinkedRecordNumber > 0 ? 'Linked Target Record' : '';
      }
    }
  }

  private transferChangeUnitVisibility() {
    const cntlUnit = this.getElementsByName('Unit');
    if (cntlUnit) {
      cntlUnit[0].IsHyperLink = false;
      if (this.isRecordExists && Helper.isStringNotNullAndEmpty(this.getValueByName('Segment'))) {
        if (TransferSegment.includes(this.getValueByName('Segment'))) {
          cntlUnit[0].IsHyperLink = true;
        }
        if (this.isValidStatus(Status.Target) && this.isValidDivision('Foreign Casualty Group')) {
          if (TransferFCGSegment.includes(this.getValueByName('Segment'))) {
            cntlUnit[0].IsHyperLink = true;
          }
        }
        if (this.isValidStatus(Status.Target) && this.getValueByName('Company') === 'Commercial Insurance Division') {
          if (TransferSegmentCI.includes(this.getValueByName('Segment'))) {
            cntlUnit[0].IsHyperLink = true;
          }
        }
      }
    }
  }

  private setDefaultValueByGeniusPipeId() {
    if (this.isGeniusExist) {
      if (!this.isRecordExists) {
        this.validateControlValueByName('Forecast');
        this.validateControlValueByName('RiskSICCode');
        this.policyTypeValidation('PolicyNo');
        this.policyNumberValidation('PolicyType');
      }
      this.getSubmissionHelper('InsuredName');
      this.getSubmissionHelper('RiskSICCode');
      this.getSubmissionHelper('PrimaryIndustry');
      this.getSubmissionHelper('Forecast');
      this.getSubmissionHelper('Type');
      this.getSubmissionHelper('BrokerBranch');
      this.getSubmissionHelper('CreditedBranch');
      this.getSubmissionHelper('PortFolioClass');
      this.getSubmissionHelper('DBSIC');
      if (this.isValidSegment('Property - National Accounts')) {
        // SetPortfolioClassBasedOnNAIC()
        this.getSubmissionHelper('RiskNAIC');
      }

      this.inputPageHeader.UserInsuredName = this.getValueByName('InsuredName');
      if (this.inputPageFooter) {
        this.inputPageFooter.ResetYN = 'N';
      }
      this.getPortfolioClassLookupDetails();
    }
  }

  private loadPortFolioClassByFilter(portFolioClassList: FilterType[]) {
    if (this.isValidSegment('Global Accident & Sickness') && portFolioClassList) {
      // Fill Portfolio By Genius
      const cntl = this.getElementsByName('PortFolioClass');
      if (cntl) {
        cntl[0].Options = portFolioClassList.sort((a: any, b: any) => {
          return a.text - b.text;
        });
      }
    }
  }

  private getPortfolioClassLookupDetails() {
    const payload = this.generatePayload();
    const PortfolioClassPayload = {
      ...payload,
      UserID: payload.UserID,
      Division: payload.Division,
      Unit: payload.Unit,
      Segment: payload.Segment,
      SubSegment: '',
      Product: '',
      Industry: '',
      PrimaryExcess: '',
    };
    this.portfolioClassDetails$ = this.inputPageService.getPortfolioClassLookupDetails(PortfolioClassPayload).subscribe((data: FilterType[]) => {
      if (data != null) {
        this.loadPortFolioClassByFilter(data);
      }
    });
  }

  private loadCascadingDropdownLookup(cascadingPayload) {
    this.portfolioClassDetails$ = this.inputPageService.getCascadingDropdownLookup(cascadingPayload).subscribe((data: FilterType[]) => {
      if (data != null) {
        this.loadLookupByName(data, cascadingPayload.ChildControlName);
      }
    });
  }

  private loadLookupByName(lookupDetails: FilterType[], controlName: string) {
    const cntl = this.getElementsByName(controlName);
    if (cntl) {
      cntl[0].Options = lookupDetails.sort((a: any, b: any) => {
        return a.DisplayOrder - b.DisplayOrder;
      });
    }
  }

  private setByInputPageName() {
    // Page_PreRender
    if (this.isValidInputPageName(InputPageName.Inputpml)) {
      if (!this.isValidSegment('Private Company/NFP')) {
        PMLCloudControls.forEach((element) => {
          this.setControlVisibility(element, true);
        });
      }
      if (!this.isValidSegment('Professional Liability')) {
        this.setControlVisibility('FinlinesRiskManagerFirstName', true);
        this.setControlVisibility('FinlinesRiskManagerLastName', true);
        this.setControlVisibility('RiskManagerEmailAddress', true);
        this.setControlVisibility('RiskManagerPhoneNumber', true);
      }
      this.setControlVisibility('Privacy', true);
      if (this.getValueByName('Privacy') === '1' && (this.getValueByName('Privacy').IndexOf('Privacy Protect') > -1 || this.getValueByName('Privacy').IndexOf('Digitech') > -1 || this.getValueByName('Privacy').IndexOf('Digital DNA') > -1 || this.getValueByName('Privacy').IndexOf('Technology') > -1)) {
        this.viewCloud('1');
      } else {
        if (this.getValueByName('Privacy') === '1') {
          this.viewCloud('2');
        } else {
          this.viewCloud('');
        }
      }
      this.pmlDisplay();
      this.showSections();
      this.showPCP();
      this.showFISections();
    }
  }

  get submissionFields() {
    return this.submissionFormGroup.controls;
  }

  submissionCollectionFields(sectionKey: string) {
    return this.submissionFormGroup.controls[sectionKey];
  }

  fetchLoadData() {
    if (this.isRecordExists) {
      this.getEscalationDetails();
      if (['M', 'C'].includes(this.getValueByName('ForecastType'))) {
        this.getBuildOutScheduleDetails();
      }
    }
  }

  initialSaveItemControlsData() {
    this.submissionSaveItem.CommonDetails.SubmissionPageType = this.isValidAandH() ? SubmissionPageType.AH : this.isValidConstruction() ? SubmissionPageType.Construction : this.isValidCanada() ? SubmissionPageType.Canada : SubmissionPageType.Input;
    const payload = this.generatePayload();
    this.submissionSaveItem.ParentItem.RecordNumber = payload.RecordNumber;
    this.submissionSaveItem.ParentItem.BuildOutSchduleNumber = this.inputPageHeader.ScheduleNumber;
    this.submissionSaveItem.ParentItem.UserID = payload.UserID;
    this.submissionSaveItem.ParentItem.Unit = payload.Unit;
    this.submissionSaveItem.ParentItem.Division = payload.Division;
    this.submissionSaveItem.ParentItem.Segment = payload.Segment;
    this.submissionSaveItem.ParentItem.GeniusPipeID = payload.GeniusPipeID;

    if (this.isRecordExists) {
      if (this.routedFrom === RoutedFrom.Transfer) {
        this.setUnderwriterLogin(this.storedFilters.UnderwriterName, true);
      }
    } else if (this.isGeniusExist && this.uwGeniusQueueDetails) {
      const uwGeniusItems: UWGeniusQueueDetailedItems = this.uwGeniusQueueDetails.getUWGeniusDetails();
      if (uwGeniusItems) {
        if (Helper.isStringNotNullAndEmpty(uwGeniusItems.UWLastName) || Helper.isStringNotNullAndEmpty(uwGeniusItems.UWLastName)) {
          const uwFullName = uwGeniusItems.UWFirstName + ' ' + uwGeniusItems.UWLastName;
          this.setUnderwriterLogin(uwFullName, true);
        }
        if (Helper.isStringNotNullAndEmpty(uwGeniusItems.UAFirstName) || Helper.isStringNotNullAndEmpty(uwGeniusItems.UALastName)) {
          const uaFullName = uwGeniusItems.UAFirstName + ' ' + uwGeniusItems.UALastName;
          this.setUnderwriterAssistant(uaFullName, true);
        }
      }
    } else {
      this.setUnderwriterLogin(this.user.UserID, true);
      this.setValueByNameNoEvent('UWEmail', this.user.Email);
    }
    // To Open PAS Validation dialog if aplicable.
    this.openDialog('ProducerCode');
    this.setDefaultValueOnLoad();
    this._forecastConvertor.UserID = payload.UserID;
    this._forecastConvertor.Segment = this.SegmentValue;
    this._forecastConvertor.Unit = this.UnitValue;
    this._forecastConvertor.AccountingYear = this.getValueByName('AccountingYear');
    this._forecastConvertor.AccountingMonth = this.getValueByName('AccountingMonth');
  }

  setDefaultValueOnLoad() {
    this.setReadOnlyByName('WSGRegion', true);
    // this.setEnableOrDisable('WSGRegion', false);
    if (this.isValidUnit('Political Risk and Credit')) {
      this.setValueByName('EffectiveDate', Helper.setDateNow());
    }
    if (this.isValidInputPageName(InputPageName.InputSurety)) {
      this.setEnableOrDisable('SubSegment', false);
    }
    if (this.isValidInputPageName(InputPageName.InputCapitalRisk)) {
      this.setDataLabelByName('Forecast', 'Coded Premium');
      this.setDataLabelByName('BasePremium', 'Base Premium');
    }
    if (['CRS Environmental', 'Wholesale-Environmental'].includes(this.UnitValue) && this.isValidSegment('Environmental')) {
      this.setDataLabelByName('AdjustedExpiring', 'Adjusted Expiring');
    }
    if (['Advantage', 'DBA'].includes(this.UnitValue)) {
      this.setDataLabelByName('PrimaryIndustry', 'Primary Industry');
    }

    if (this.isRecordExists) {
      if (this.isValidSegment('Property - National Accounts')) {
        if (Helper.isStringNotNullAndEmpty(this.getValueByName('PortFolioClass'))) {
          this.setReadOnlyByName('PortFolioClass', false);
        } else {
          this.setReadOnlyByName('PortFolioClass', true);
        }
      }
      if (Helper.isStringNotNullAndEmpty(this.getValueByName('CriticalRec'))) {
        this.setReadOnlyByName('CriticalRec', false);
      } else {
        this.setReadOnlyByName('CriticalRec', true);
      }
      // Handled in setValueByPolicyStatus method
      // if ([Status.Target, Status.TargetClosed].includes(this.StatusValue)) {
      //   this.setReadOnlyByName('AccountingYear', false);
      //   // this.setEnableOrDisable('AccountingYear', false);
      // }
      if (Helper.isStringNotNullAndEmpty(this.getValueByName('RelationshipManager'))) {
        this.setReadOnlyByName('RelationshipManager', true);
        this.setEnableOrDisable('RelationshipManager', false);
      } else {
        this.setControlVisibility('RelationshipManager', false);
      }
    } else {
      this.setControlVisibility('RelationshipManager', false);
    }
    if ([Type.New, Type.Other].includes(this.getValueByName('Type'))) {
      this.setEnableOrDisable('BasePremium', false);
    }
    this.setValueByName('CanadaPCSubmissionReceivedLoginId', this.submissionSaveItem.ParentItem.UserID);
    this.setValueByName('CanadaPCSubmissionReceivedDate', Helper.setDateNow());
    this.setValueByName('CanadaProfSubmissionReceivedLoginId', this.submissionSaveItem.ParentItem.UserID);
    this.setValueByName('CanadaProfSubmissionReceivedDate', Helper.setDateNow());
    // if (this.isValidUnit('Penn Millers') && ['Package', 'Comp'].includes(this.getSegmentValue())) {
    //   if(Helper.isStringArrayNotNullAndEmpty(this.getValueByName('PolicyIssuedLoginId'))){
    //   this.setValueByName('PolicyIssuedCheck', true);
    //   }
    // }
    // if (this.isValidUnit('Canada Casualty') && this.isValidSegment('Environmental')) {
    //   if(Helper.isStringArrayNotNullAndEmpty(this.getValueByName('PolicyIssuedLoginId'))){
    //   this.setValueByName('SelfAudit', true);
    //   }
    // }
    if (['International Advantage', 'Casualty'].includes(this.SegmentValue)) {
      this.setDataLabelByName('BrokerState', 'Broker State/Province');
      if (this.isValidSegment('International Advantage')) {
        this.setDataLabelByName('HazardCode', 'Hazard Casualty Code');
      }
    }

    if (this.getValueByName('ProgramDesignation') === 'A&H Key Targets') {
      this.setControlVisibility('Uwriter', true);
    } else {
      this.setControlVisibility('Uwriter', false);
    }

    if (this.MetadataDetails && this.MetadataDetails.SourceSystem === 'Tracker Copy' && this.isValidUnit('High Net Worth')) {
      if (Helper.isStringNotNullAndEmpty(this.getValueByName('SubmissionReceived'))) {
        this.setReadOnlyByName('SubmissionReceived', true);
        this.setEnableOrDisable('SubmissionReceived', false);
      } else {
        this.setValueByName('SubmissionReceived', Helper.setDateNow());
        // this.setUserIdAndCurrentDate('SubmissionReceived');
      }
    }

    if (this.isValidAandH()) {
      this.setDataLabelByName('Auditable', 'Subject To Premium Audit?');
    } else {
      this.setDataLabelByName('Auditable', 'Auditable');
    }
    // this.setAuditableFrequencyMandatory();
    this.setAssistanceProviderMandatory();
    if (this.UnitValue.includes('Canada') || this.SegmentValue.includes('Canada') || this.DivisionValue.includes('Canada')) {
      this.setControlVisibility('PolicyType', false);
      this.setControlVisibility('ExpiringPolicyType', false);
    }
    // if (this.getValueByName('DBNumber') === 'NM' || Helper.isStringNotNullAndEmpty(this.getValueByName('DBNumber'))) {
    //   this.setReadOnlyByName('DBSIC', false);
    // } else {
    //   this.setReadOnlyByName('DBSIC', true);
    // }
    this.setForecastTooltip();
    this.setUWRegionTooltip();
    if (!this.isRecordExists) {
      // pageDefault()
      if (this.isValidInputPageName(InputPageName.InputMedRisk)) {
        this.setDataLabelByName('ExpiringRevenueAmount', 'Exp Revenue');
      } else if (this.isValidInputPageName(InputPageName.InputGlobalSolution)) {
        this.setDataLabelByName('OtherAceCapacity', 'Other Ace Capacity');
      } else if (this.isValidInputPageName(InputPageName.InputCapitalRisk)) {
        this.setDataLabelByName('BrokerState', 'Broker Province');
      } else if (this.isValidInputPageName(InputPageName.Inputpml)) {
        this.setValueByName('Commission', '');
      }
      if (this.isValidUnit('Mexico') && this.isValidSegment('Mexico')) {
        this.setValueByName('Commission', '');
        // lblRI.Visible = true;
      }
      if (this.isValidSegment('Franchise')) {
        this.setReadOnlyByName('PrimaryIndustry', true);
      }
    }
    // if (
    //   [
    //     'Wholesale Inland Marine',
    //     'Wholesale Excess',
    //     'Wholesale Property',
    //     'Wholesale Primary',
    //   ].includes(this.UnitValue)
    // ) {
    //   this.setReadOnlyByName('Revenue', true);
    //   this.setReadOnlyByName('SubSegment', true);
    //   if (this.isValidUnit('Wholesale Property')) {
    //     this.setReadOnlyByName('SubSegment', false);
    //   }
    // }

    if (['Contractors', 'Maintenance Wrap Up'].includes(this.SegmentValue)) {
      this.setReadOnlyByName('WrapupType', true);
      this.setReadOnlyByName('ProductLimit', true);
      this.setReadOnlyByName('ExpiringProductLimit', true);
      this.setReadOnlyByName('OpsExtention', true);
    } else if (this.isValidSegment('Wrap Up')) {
      this.setReadOnlyByName('WrapupType', false);
    }
  }

  // populateStatusByType() {
  //   if (!this.isValidConstruction() && !this.isValidAandH()) {
  //     if (
  //       this.storedFilters &&
  //       this.storedFilters.IsGenius !== 'Y' &&
  //       this.storedFilters.LYNE !== 'N'
  //     ) {
  //       if ([Type.New, Type.Renewal].includes(this.getValueByName('Type'))) {
  //         if (this.storedFilters.LYNE === 'Y') {
  //           if (
  //             ['Abacus', 'Hartford Bordereaux', 'Brotherhood Mutual'].includes(
  //               this.getValueByName('SubSegment')
  //             )
  //           ) {
  //             this.loadStatusByType('ALL');
  //           } else {
  //             if (
  //               ![Status.Target, Status.TargetClosed].includes(
  //                 this.getStatusValue()
  //               )
  //             ) {
  //               this.setValueByName('Status', '');
  //             }
  //             this.loadStatusByType('TARGET');
  //           }
  //         } else if (this.storedFilters.LYNE === 'E') {
  //           if (
  //             ![Status.Target, Status.Declined].includes(this.getStatusValue())
  //           ) {
  //             this.setValueByName('Status', '');
  //           }
  //           this.loadStatusByType('TARGET_AND_DECLINED');
  //           if (
  //             ['PRV - K&R', 'NFP - K&R', 'NFP - K&R'].includes(
  //               this.getValueByName('SubSegment')
  //             )
  //           ) {
  //             this.loadStatusByType('ALL');
  //           }
  //         } else {
  //           this.loadStatusByType('ALL');
  //         }
  //       } else {
  //         this.loadStatusByType('ALL');
  //       }
  //     }
  //   }
  // }

  // loadStatusByType(lockStatus: string = 'ALL') {
  //   if (this.statusLookup) {
  //     let lookupOptions: FilterType[];
  //     if (lockStatus === 'ALL') {
  //       lookupOptions = this.statusLookup;
  //     } else if (lockStatus === 'TARGET') {
  //       lookupOptions = this.statusLookup.filter((status) => {
  //         return (
  //           status.value === Status.Target ||
  //           status.value === Status.TargetClosed
  //         );
  //       });
  //     } else if (lockStatus === 'TARGET_AND_DECLINED') {
  //       lookupOptions = this.statusLookup.filter((status) => {
  //         return (
  //           status.value === Status.Target || status.value === Status.Declined
  //         );
  //       });
  //     }
  //     const cntlStatus = this.getElementsByName('Status');
  //     if (cntlStatus && cntlStatus.length > 0) {
  //       cntlStatus[0].Options = lookupOptions;
  //       // cntlStatus[0].Options = lookupOptions.sort(
  //       //   (a: any, b: any) => {
  //       //     return a.DisplayOrder - b.DisplayOrder;
  //       //   }
  //       // );
  //     }
  //   }
  // }

  loadStatusByTypeForROTR(onLoad: boolean = false) {
    if (this.statusLookup) {
      let lookupOptions: FilterType[];
      if (this.TypeValue === Type.New) {
        if (this.storedFilters && this.storedFilters.LYNE === 'Y') {
          lookupOptions = this.filteredStatusForLookup(true);
        } else {
          lookupOptions = this.statusLookup;
        }
      } else {
        lookupOptions = this.filteredStatusForLookup();
      }
      const cntlStatus = this.getElementsByName('Status');
      if (cntlStatus && lookupOptions && cntlStatus.length > 0) {
        cntlStatus[0].Options = lookupOptions.sort((a: any, b: any) => {
          return a.DisplayOrder - b.DisplayOrder;
        });
      }

      if (onLoad) {
        this.setStatusByCompany();
      }
    }
  }

  private setStatusByCompany() {
    let lookupOptions: FilterType[];
    if (['Major Accounts Division', 'Commercial Insurance Division', 'Small Retail Division'].includes(this.companyValue) && this.isRecordExists) {
      if ([Status.Target, Status.TargetClosed].includes(this.StatusValue)) {
        lookupOptions = this.filteredStatusForLookup(true);
      } else {
        lookupOptions = this.filteredStatusForLookup();
      }
      const cntlStatus = this.getElementsByName('Status');
      if (cntlStatus && lookupOptions && cntlStatus.length > 0) {
        cntlStatus[0].Options = lookupOptions.sort((a: any, b: any) => {
          return a.DisplayOrder - b.DisplayOrder;
        });
      }
    }
  }

  private filteredStatusForLookup(isTarget: Boolean = false): FilterType[] {
    let lookupOptions: FilterType[];
    if (isTarget) {
      lookupOptions = this.statusLookup.filter((status) => {
        return status.value === Status.Target || status.value === Status.TargetClosed;
      });
      if (![Status.Target, Status.TargetClosed].includes(this.StatusValue)) {
        this.setValueByName('Status', '');
      }
    } else {
      lookupOptions = this.statusLookup.filter((status) => {
        return status.value !== Status.Target && status.value !== Status.TargetClosed;
      });
      if ([Status.Target, Status.TargetClosed].includes(this.StatusValue)) {
        this.setValueByName('Status', '');
      }
    }
    return lookupOptions;
  }

  async getInputPageControlsDetails() {
    try {
      this.isLoading = true;
      this.isShowContent = false;
      // const submissionLoad: SubmissionLoadItem[] = await this.activatedRoute.snapshot.data['submissionLoad'];
      const resolvedSubmissionLoad: ResolvedSubmissionLoad = await this.activatedRoute.snapshot.data['submissionLoad'];
      if (resolvedSubmissionLoad.error === null) {
        const submissionLoad: SubmissionLoadItem = resolvedSubmissionLoad.submissionLoadItem;
        if (submissionLoad) {
          await this.extractDataByModel(submissionLoad);
          // set default values for ddl
          this.setDDLDefaultValue();
          // load confidence Factor based on status for exisitg record
          this.loadCFAndStatus();
          this.setHeaderLinkStyle();
          // this.fetchLoadData();
        }
      } else {
        this.isLoading = false;
        this.isShowContent = false;
        this.error = resolvedSubmissionLoad.error;
      }
    } catch (error) {
      console.warn({ error });
      this.errorRedirectToPrevious();
    }
  }

  private errorRedirectToPrevious() {
    this.isShowContent = false;
    this.dialogLoading && this.dialogLoading.close();
    this.dialogLoading = this.dialog.open(InputFormPopupComponent, {
      data: {
        Message: 'Error occured while loading input page control!!!',
        IsSuccess: false,
        loader: false,
        RecordNumber: 0,
        OkLabel: 'Ok',
      },
    });

    this.dialogLoading.afterClosed().subscribe(() => {
      this.closeInputPage();
    });
  }

  private setHeaderLinkStyle() {
    this.headerLink33 = false;
    this.headerLink25 = false;
    this.headerLink20 = false;
    if (this.inputPageHeader) {
      if (this.inputPageHeader.SubmissionIDYN === 'N' && this.inputPageHeader.ScheduleNumberYN === 'N') {
        this.headerLink33 = true;
      } else if (this.inputPageHeader.SubmissionIDYN === 'Y' || this.inputPageHeader.ScheduleNumberYN === 'Y') {
        this.headerLink25 = true;
      } else {
        this.headerLink20 = true;
      }
    }
  }

  private async extractDataByModel(data: SubmissionLoadItem) {
    this.inputPageHeader = data.HeaderDetailsItem;
    this.inputPageFooter = data.FooterDetailsItem;
    this._metadataDetails = data.MetadataDetailsItem;
    this._dataElementsAllDetails = data.ControlsElementsDetails;
    this.lookup = data.LookupDetailsItem;

    Promise.resolve().then(() => {
      this.dataElementsControlDetailsItemPanel = data.DataElementsControlDetailsItem.filter((e) => {
        e.isOpen = false;
        return e.SectionType === SectionType.Secondary || e.SectionType === SectionType.Collections;
      });
      // this.totalSection = this.dataElementsControlDetailsItemPanel && this.dataElementsControlDetailsItemPanel.length;
      this.sectionNameForList = this.dataElementsControlDetailsItemPanel
        .filter((element) => {
          return element.SectionType === SectionType.Collections;
        })
        .map((ele) => ele.SectionName);

      this.sectionName = this.dataElementsControlDetailsItemPanel
        .filter((element) => {
          return element.SectionType !== SectionType.Collections;
        })
        .map((ele) => ele.SectionName);

      this.sectionKeyItemsForList = this.dataElementsControlDetailsItemPanel
        .filter((element) => {
          return element.SectionType === SectionType.Collections;
        })
        .map((ele) => ele.SectionKey);

      this.sectionKeyItems = this.dataElementsControlDetailsItemPanel
        .filter((element) => {
          return element.SectionType !== SectionType.Collections;
        })
        .map((ele) => ele.SectionKey);

      this.addOptionInDropDown(this.dataElementsControlDetailsItemPanel);
      setTimeout(() => {
        this.isShowContent = true;
        this.isLoading = false;
      }, 0);

      this.generateSubmissionFormGroup();
    });
  }

  showFAC() {
    const ctrlFAC = this.getFAC();
    if (ctrlFAC) {
      if (['FAC', 'Treaty FAC'].includes(this.getValueByName('ReInsurance'))) {
        ctrlFAC[0].isOpen = true;
      } else {
        ctrlFAC[0].isOpen = false;
      }
    }
  }

  private getFAC() {
    return this.dataElementsControlDetailsItemPanel.filter((ele) => {
      return ele.SectionKey === 'FAC';
    });
  }

  showOutToMarketCarrier() {
    const outOfCarrier = this.getOutToMarketCarrier();
    if (outOfCarrier) {
      outOfCarrier[0].isOpen = true;
      const outofCarrierCntrl: any = outOfCarrier[0].DataElementsDetails.sort((a: any, b: any) => {
        return a.DisplayOrder - b.DisplayOrder;
      });

      const outToMarketCarrier: any = this.getValueByName('OutToMarketCarrier');
      // const selected = otmSelected.split(',');
      const count = outToMarketCarrier.length;
      let iteration = 0;
      const columns = 4;
      let setvalue = 1;
      let selctedvalueindex = 0;

      outofCarrierCntrl.forEach((element) => {
        iteration++;
        element.IsVisible = iteration <= columns * count ? true : false;
        this.setEnableOrDisable(element.ControlName, element.IsVisible ? true : false);

        if (iteration === 1 || iteration === 5 || iteration === 9) {
          element.DataLabel = element.DataLabel;
          this.setValueByName(element.ControlName, outToMarketCarrier[selctedvalueindex]);
        } else {
          this.setValueByName(element.ControlName, '');
          element.DataLabel = element.DataLabel;
          element.IsReadonly = false;
        }

        if (setvalue === 4) {
          selctedvalueindex++;
          setvalue = 1;
        } else {
          setvalue++;
        }
      });
    }
  }

  private getOutToMarketCarrier() {
    return this.dataElementsControlDetailsItemPanel.filter((ele) => {
      return ele.SectionKey === 'OTM';
    });
  }

  private getPMSection() {
    return this.dataElementsControlDetailsItemPanel.filter((ele) => {
      return ele.SectionKey === 'PM';
    });
  }

  async resetSubmissionForm() {
    try {
      this.reloadSubmissionPage(true);
    } catch (error) {
      console.error(error);
    }
  }

  resetPMAndOTM() {
    const outToMarketCarrier: any = this.getValueByName('OutToMarketCarrier');
    if (outToMarketCarrier && outToMarketCarrier.length > 0) {
      const outOfCarrier = this.getOutToMarketCarrier();
      if (outOfCarrier) {
        outOfCarrier[0].isOpen = false;
      }
    }
    const postmortem = this.getPMSection();
    if (postmortem) {
      if ([Status.Lost, Status.QuotedLost, Status.TargetClosed, Status.Declined].includes(this.getStatusValue())) {
        postmortem[0].isOpen = true;
      } else {
        postmortem[0].isOpen = false;
      }
    }
  }

  private loadCFAndStatus() {
    this.confidanceFactorlookup = this.lookup
      .filter((c) => {
        return c.ControlName === 'ConfidenceFactor';
      })
      .map((filter) => ({
        text: filter.DataText,
        value: filter.DataValue,
      }));
    this.loadConfidenceFactorByStatus();
    // load Status
    this.getStatusLookup();
  }

  private getStatusLookup() {
    this.statusLookup = this.lookup
      .filter((c) => {
        return c.ControlName === 'Status';
      })
      .map((filter) => ({
        text: filter.DataText,
        value: filter.DataValue,
      }));
    // this.populateStatusByType();
    this.loadStatusByTypeForROTR(true);
  }

  private addOptionInDropDown(obj: any) {
    obj.forEach((ele) => {
      const cntrlList: any = ele.DataElementsDetails.filter((element) => {
        return element.ControlType === 'dropdown' || element.ControlType === 'combodropdown' || element.ControlType === 'radio';
      });

      cntrlList.forEach((element) => {
        element.Options = this.getFilterLookupData(element);
      });
      if (ele.DataElementsGroupDetails && ele.DataElementsGroupDetails.length > 0) {
        this.addOptionInDropDownGroup(ele.DataElementsGroupDetails);
      }
    });
  }

  private addOptionInDropDownGroup(obj: any) {
    obj.forEach((ele) => {
      const cntrlList: any = ele.DataElementsDetails.filter((element) => {
        return element.ControlType === 'dropdown' || element.ControlType === 'combodropdown' || element.ControlType === 'radio';
      });

      cntrlList.forEach((element) => {
        element.Options = this.getFilterLookupData(element);
      });
    });
  }

  getFilterLookupData(ctrl): FilterType[] {
    if (this.lookup) {
      const options: any = this.lookup
        .filter((c) => {
          return c.ControlName.toLowerCase() === ctrl.ControlName.toLowerCase();
        })
        .map((filter) => ({ text: filter.DataText, value: filter.DataValue }));
      return options;
      // return options.sort((a: any, b: any) => {
      //   return a.DisplayOrder - b.DisplayOrder;
      // });
    }
  }

  private generatePayload() {
    if (this.recordNumber > 0 && this.userID && this.routedFrom === undefined) {
      return {
        UserID: this.userID,
        RecordNumber: this.recordNumber,
        RoutedFrom: '',
      };
    } else {
      if (this.storedFilters) {
        return {
          UserID: this.user.UserID || '',
          Division: this.storedFilters.Division ? this.storedFilters.Division[0] : '',
          Unit: this.storedFilters.Unit ? this.storedFilters.Unit[0] : '',
          Segment: this.storedFilters.Segment ? this.storedFilters.Segment[0] : '',
          RecordNumber: this.recordNumber ? this.recordNumber : 0,
          GeniusPipeID: this.storedFilters.GeniusPipeID ? this.storedFilters.GeniusPipeID : 0,
          RoutedFrom: this.routedFrom,
        };
      } else {
        return {};
      }
    }
  }

  onBlurMethod(ctrl: DataElementsDetails) {
    if (ctrl && Helper.isStringNotNullAndEmpty(ctrl.SearchValue)) {
      ctrl.SearchValue = '';
    }
  }

  updateErrorWarning() {
    try {
      this.submissionFormGroup.statusChanges.subscribe((status) => {
        if (this.submitted) {
          this.setErrorWarning();
          this.setErrorWarningForCollections();
        }
      });
    } catch (error) {
      console.error(error);
    }
  }

  saveSubmissionControlData(action) {
    try {
      console.log(this.submissionSaveItem);
      if (action === 'save') {
        this.submitted = true;
        if (this.submissionFormGroup.invalid) {
          this.setErrorWarning();
          this.setErrorWarningForCollections();
          this.cdRef.detectChanges();
          return;
        }
        this.submitted = false;
        if (this.isRecordExists && !this.submissionFormGroup.dirty) {
          this.notifier.showWarning('No changes found!!!', 10);
        } else {
          this.saveSubmission();
        }
      }
    } catch (error) {
      throw error;
    }
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach((field) => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
        control.updateValueAndValidity();
      }
    });
  }

  private async saveSubmission() {
    // console.warn(this.submissionSaveItem);
    await this.syncSaveSubmission();
    if (Helper.isStringNotNullAndEmpty(this.submissionSaveItem.ParentItem.UserID)) {
      let dialogRef = this.dialog.open(InputFormPopupComponent, {
        data: {
          loader: true,
        },
      });

      this.inputPageService.saveSubmission(this.submissionSaveItem).subscribe(
        (savedData: SubmissionSaveOutputModel) => {
          dialogRef.close();
          if (savedData.ErrorLogID > 0) {
            this.showErrorDialog(savedData.ErrorLogID);
          } else {
            this.updateSubmissionHeaderModel(savedData);
            this.showSubmissionSuccessDialog();
          }
        },
        () => {
          dialogRef.close();
          this.showErrorDialog();
        }
      );
    } else {
      this.notifier.showWarning('Session Expired!!!', 10);
    }
  }

  private showSubmissionSuccessDialog() {
    let dialogRef = this.dialog.open(InputFormPopupComponent, {
      data: {
        Message: 'Submission updated Successfully !',
        IsSuccess: true,
        loader: false,
        RecordNumber: this.recordNumber,
        Action: 'Save',
        OkLabel: this.routedFrom === RoutedFrom.SelectUnit ? 'Stay' : 'Ok',
        RedirectLabel: this.routedFrom === RoutedFrom.SelectUnit ? 'Go to Insured Search' : '',
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      this.submissionFormGroup.markAsPristine();
      this.submissionFormGroup.markAsUntouched();
      // this.handleNavigation();
      if (result && result === 'close') {
        // this.closeInputPage();
      } else if (result && result > 0) {
        console.warn(result);
        this.filters.InsulLogic = 'Y';
        this.filters.RecordNo = result;
        // this.filters.moreFilters = {
        // 	RecordNo: result,
        // 	Currency: [this.user.PreferredCurrency || 'USD'],
        // };
        this.router.navigate(['/tracking-and-reporting/insured-search'], {
          queryParams: {
            filters: this.filterWatch.create(this.filters),
            showBrowseBy: true,
          },
        });
      }
    });
  }

  private showErrorDialog(errorLogID: number = 0) {
    const dialogRef = this.dialog.open(InputFormPopupComponent, {
      data: {
        Message: 'Error in saving the submission !',
        IsSuccess: false,
        loader: false,
        RecordNumber: 0,
        Action: 'Save',
        OkLabel: 'Ok',
      },
    });

    dialogRef.afterClosed().subscribe((action) => {
      if (action === 'Notify') {
        //Send Email Here
        this.sendErrorEmail(errorLogID);
      }
    });
  }

  sendErrorEmail(errorLogID) {
    const payload = {
      UserID: this.user.UserID,
      EmailID: this.user.Email,
      ErrorLogID: errorLogID,
      ErrorSourceName: 'Submission',
    };
    this.inputPageService.sendErrorEmail(payload).subscribe(
      (data: any) => {
        console.log(data);
      },
      () => {
        console.error('An error occured while sending mail');
      }
    );
  }

  private updateSubmissionHeaderModel(savedData: SubmissionSaveOutputModel) {
    if (savedData && savedData.RecordNumber > 0) {
      this.recordNumber = savedData.RecordNumber;
      this.submissionSaveItem.ParentItem.RecordNumber = this.recordNumber;
      this.inputPageHeader.RecordNumber = this.recordNumber;
      this.inputPageHeader.RecordNumberYN = 'Y';
      this.inputPageHeader.AuditTrailYN = 'Y';
      this.inputPageHeader.EscalateYN = 'Y';
      if (this.inputPageHeader.SubmissionIDYN === 'N') {
        this.inputPageHeader.SubmissionIDYN = savedData.SubmissionID ? 'Y' : 'N';
        this.inputPageHeader.SubmissionID = this.inputPageHeader.SubmissionIDYN === 'Y' ? savedData.SubmissionID : '';
      }
      if (this.inputPageHeader.ScheduleNumberYN === 'N') {
        this.inputPageHeader.ScheduleNumberYN = savedData.ScheduleNumber > 0 ? 'Y' : 'N';
        this.inputPageHeader.ScheduleNumber = this.inputPageHeader.ScheduleNumberYN === 'Y' ? savedData.ScheduleNumber : 0;
      }
    }
    this.setHeaderLinkStyle();
  }

  private async syncSaveSubmission() {
    await this.setSaveForecastType();

    this.dataElementsControlDetailsItemPanel.forEach((dataElementItems) => {
      if (dataElementItems.DataElementsDetails && dataElementItems.DataElementsDetails.length > 0) {
        this.setParentChildValue(dataElementItems.DataElementsDetails);
      }
      if (dataElementItems.DataElementsGroupDetails && dataElementItems.DataElementsGroupDetails.length > 0) {
        dataElementItems.DataElementsGroupDetails.forEach((dataElementGroupItems) => {
          if (dataElementGroupItems.DataElementsDetails && dataElementGroupItems.DataElementsDetails.length > 0) {
            this.setParentChildValue(dataElementGroupItems.DataElementsDetails);
          }
        });
      }
    });

    this.setSaveConfidenceFactor();
    if (this.isAviationExists) {
      this.setCollectionDeletedDetails('AviationDetails', 'AVNAviationID');
    }
  }

  private async setSaveForecastType() {
    if (['M', 'C'].includes(this.getValueByName('ForecastType'))) {
      if (this.submissionSaveItem.BuildOutScheduleItems && this.submissionSaveItem.BuildOutScheduleItems.length === 0 && this.buildOutScheduleItems.length > 0) {
        await this.setBuildOutScheduleItems();
      }
    } else {
      this.submissionSaveItem.BuildOutScheduleItems = [];
    }
  }

  private setParentChildValue(dataElementsDetails: DataElementsDetails[]) {
    dataElementsDetails.forEach((field) => {
      if (field.ControlType !== ControlType.InputHyperLink && field.ControlType !== ControlType.InputMailLink && field.ControlType !== ControlType.HeaderLabel && field.ControlType !== ControlType.InputAutoComplete && field.ControlType !== ControlType.RowIndicator) {
        if (field.SectionType === SectionType.Collections) {
          this.setSaveCollections(field);
        } else {
          let target = this.submissionFormGroup.value[field.ControlName];
          // const target = this.submissionFormGroup.getRawValue()[field.ControlName];
          // console.log(field.ControlName + ' : ' + target);
          if (!field.IsVisible) {
            target = '';
            console.log(field.ControlName + '(IsVisible=false):' + target);
          }

          if (this.isRecordExists) {
            this.setControlValueForSave(field, target);
          } else {
            Helper.isStringNotNullAndEmpty(target) && this.setControlValueForSave(field, target);
          }
        }
      } else if (field.ControlType === ControlType.InputAutoComplete) {
        if (field.ControlName === 'LoginName') {
          this.submissionSaveItem.ParentItem.LoginName = this.loginName;
        } else if (field.ControlName === 'UnderwriterAssistant') {
          this.setUAValueInSaveModel(field);
        }
      }
    });
  }

  private setSaveCollections(field: DataElementsDetails) {
    const collections = this.submissionFormGroup.value[field.SectionKey];
    if (collections && collections[field.SectionKey]) {
      if (field.SectionKey === 'ConstPolicyDetails') {
        if (this.isValidConstruction()) {
          this.submissionSaveItem.ConstructionPolicyDetails = collections[field.SectionKey];
        }
      } else {
        collections[field.SectionKey].forEach((element, rowIndex) => {
          console.log(field.ControlName + ':' + element[field.ControlName]);
          const target = element[field.ControlName];
          const id = element['AVNAviationID'];
          const rowIndicator = id !== null && id > 0 ? 'U_' + id : 'I_' + rowIndex;
          if (this.isRecordExists) {
            this.setControlValueForSave(field, target, rowIndicator);
          } else {
            Helper.isStringNotNullAndEmpty(target) && this.setControlValueForSave(field, target, rowIndicator);
          }
        });
      }
    }
  }

  private setSaveConfidenceFactor() {
    if (Helper.isStringNotNullAndEmpty(this.getValueByName('ConfidenceFactor'))) {
      if ([Status.Declined, Status.Lost, Status.QuotedLost].includes(this.StatusValue)) {
        this.submissionSaveItem.ParentItem.ConfidenceFactor = 1;
      } else if (this.StatusValue === Status.Bound) {
        this.submissionSaveItem.ParentItem.ConfidenceFactor = 10;
      }
    }
  }

  // private async syncSaveSubmissionOld() {
  //   if (['M', 'C'].includes(this.getValueByName('ForecastType'))) {
  //     if (
  //       this.submissionSaveItem.BuildOutScheduleItems &&
  //       this.submissionSaveItem.BuildOutScheduleItems.length === 0 &&
  //       this.buildOutScheduleItems.length > 0
  //     ) {
  //       await this.setBuildOutScheduleItems();
  //     }
  //   } else {
  //     this.submissionSaveItem.BuildOutScheduleItems = [];
  //   }

  //   this.DataElementsAllDetails.sort((a: any, b: any) => {
  //     return a.SectionKey - b.SectionKey;
  //   }).forEach((field) => {
  //     if (
  //       field.ControlType !== ControlType.InputHyperLink &&
  //       field.ControlType !== ControlType.InputMailLink &&
  //       field.ControlType !== ControlType.HeaderLabel &&
  //       field.ControlType !== ControlType.InputAutoComplete &&
  //       field.ControlType !== ControlType.RowIndicator
  //     ) {
  //       if (field.SectionType === SectionType.Collections) {
  //         const collections = this.submissionFormGroup.value[field.SectionKey];
  //         if (collections && collections[field.SectionKey]) {
  //           if (field.SectionKey === 'ConstPolicyDetails') {
  //             if (this.isValidConstruction()) {
  //               this.submissionSaveItem.ConstructionPolicyDetails =
  //                 collections[field.SectionKey];
  //             }
  //           } else {
  //             collections[field.SectionKey].forEach((element, rowIndex) => {
  //               console.log(
  //                 field.ControlName + ':' + element[field.ControlName]
  //               );
  //               const target = element[field.ControlName];
  //               const id = element['AVNAviationID'];
  //               const rowIndicator =
  //                 id !== null && id > 0 ? 'U_' + id : 'I_' + rowIndex;
  //               if (this.isRecordExists) {
  //                 this.setControlValueForSave(field, target, rowIndicator);
  //               } else {
  //                 Helper.isStringNotNullAndEmpty(target) &&
  //                   this.setControlValueForSave(field, target, rowIndicator);
  //               }
  //             });
  //           }
  //         }
  //       } else {
  //         const target = this.submissionFormGroup.value[field.ControlName];
  //         // const target = this.submissionFormGroup.getRawValue()[field.ControlName];
  //         // console.log(field.ControlName + ' : ' + target);
  //         if (this.isRecordExists) {
  //           this.setControlValueForSave(field, target);
  //         } else {
  //           Helper.isStringNotNullAndEmpty(target) &&
  //             this.setControlValueForSave(field, target);
  //         }
  //       }
  //     } else if (field.ControlType === ControlType.InputAutoComplete) {
  //       if (field.ControlName === 'LoginName') {
  //         this.submissionSaveItem.ParentItem.LoginName = this.loginName;
  //       } else if (field.ControlName === 'UnderwriterAssistant') {
  //         this.setUAValueInSaveModel(field);
  //       }
  //     }
  //   });

  //   if (
  //     Helper.isStringNotNullAndEmpty(this.getValueByName('ConfidenceFactor'))
  //   ) {
  //     if (
  //       [Status.Declined, Status.Lost, Status.QuotedLost].includes(
  //         this.StatusValue
  //       )
  //     ) {
  //       this.submissionSaveItem.ParentItem.ConfidenceFactor = 1;
  //     } else if (this.StatusValue === Status.Bound) {
  //       this.submissionSaveItem.ParentItem.ConfidenceFactor = 10;
  //     }
  //   }

  //   if (this.isAviationExists) {
  //     this.setCollectionDeletedDetails('AviationDetails', 'AVNAviationID');
  //   }
  // }

  private setUAValueInSaveModel(field: DataElementsDetails) {
    if (field.ControlName === 'UnderwriterAssistant') {
      this.submissionSaveItem.ParentItem.UnderwriterAssistant = '';
      if (this.isRecordExists) {
        this.setControlValueForSave(field, this.underwriterAssistant);
      } else {
        Helper.isStringNotNullAndEmpty(this.underwriterAssistant) && this.setControlValueForSave(field, this.underwriterAssistant);
      }
    }
  }

  private setCollectionDeletedDetails(sectionKey: string, keyControlName: string) {
    if (this.isRecordExists && this.collectionDeletedItems && this.collectionDeletedItems.length > 0) {
      const fieldId: DataElementsDetails[] = this.DataElementsAllDetails.filter((element) => element.SectionType === 'Collections' && element.ControlName === keyControlName);
      if (fieldId && fieldId.length > 0 && this.collectionDeletedItems.length > 0) {
        const rowIndicator = 'D';
        const rowSelectedValue = this.collectionDeletedItems
          .filter((ele) => {
            return ele.sectionKey === sectionKey;
          })
          .map((item) => item.id)
          .toString();
        this.setControlValueForSave(fieldId[0], rowSelectedValue, rowIndicator);
      }
    }
  }

  private async setBuildOutScheduleItems() {
    this.submissionSaveItem.BuildOutScheduleItems = [];
    let recordExistsCount = 0;
    const filteredBOList: BuildOutScheduleItems[] = this.buildOutScheduleItems.filter((ele) => {
      return ele.RecordNumber > 0;
    });
    if (filteredBOList && filteredBOList.length > 0) {
      recordExistsCount = filteredBOList.length;
    }

    if (this.isRecordExists && recordExistsCount > 0) {
      const filteredBOS: BuildOutScheduleItems[] = this.buildOutScheduleItems.filter((ele) => {
        return ele.RecordNumber === this.submissionSaveItem.ParentItem.RecordNumber;
      });
      if (filteredBOS != null && filteredBOS.length > 0) {
        this.setMonthYearForecast(filteredBOS[0].AccountingMonth, filteredBOS[0].AccountingYear);
        this.setValueByName('Forecast', filteredBOS[0].Forecast);
      }
      this.setBaseRecordFlag();
      this.submissionSaveItem.BuildOutScheduleItems = this.buildOutScheduleItems.filter((filter) => {
        return filter.RecordNumber !== this.submissionSaveItem.ParentItem.RecordNumber;
      });
    } else {
      if (this.getValueByName('ForecastType') === 'M') {
        const accountingMonth = this.datepipe.transform(this.getDateValueByName('EffectiveDate'), 'MMMM');
        const accountingYear = this.datepipe.transform(this.getDateValueByName('EffectiveDate'), 'yyyy');
        this.setMonthYearForecast(accountingMonth, accountingYear);
        this.setValueByName('Forecast', this.getForecastByMonthYear());
      } else {
        this.setMonthYearForecast(this.buildOutScheduleItems[0].AccountingMonth, this.buildOutScheduleItems[0].AccountingYear);
        this.setValueByName('Forecast', this.getForecastByMonthYear());
      }
      this.setBaseRecordFlag();
      this.submissionSaveItem.BuildOutScheduleItems = this.buildOutScheduleItems.filter((element) => {
        return !(element.AccountingMonth === this.getValueByName('AccountingMonth') && element.AccountingYear === String(this.getValueByName('AccountingYear')) && element.Forecast === this.getNumValueByName('Forecast'));
      });
    }
    if (this.isValidConstruction() && this.submissionSaveItem.BuildOutScheduleItems.length > 0) {
      this.submissionSaveItem.BuildOutScheduleItems = this.submissionSaveItem.BuildOutScheduleItems.filter((item) => item.Forecast > 0);
    }
  }

  setTotalProjectPremiumVisibility() {
    if (Helper.isStringNotNullAndEmpty(this.getValueByName('ForecastType')) && this.getValueByName('ForecastType') !== 'A') {
      this.setControlVisibility('TotalProjectPremium', true);
    } else {
      this.setControlVisibility('TotalProjectPremium');
    }
  }

  setTotalProjectPremium() {
    if (this.buildOutScheduleItems && this.buildOutScheduleItems) {
      let totalForecastValue: number = this.buildOutScheduleItems
        .map((element) => element.Forecast)
        .reduce((a, b) => {
          return a + b;
        });
      this.setValueByName('TotalProjectPremium', totalForecastValue);
    }
  }

  private setMonthYearForecast(accountingMonth, accountingYear) {
    if (Helper.isStringNotNullAndEmpty(accountingMonth)) {
      this.setValueByName('AccountingMonth', this.buildOutScheduleItems[0].AccountingMonth);
    }
    if (Helper.isStringNotNullAndEmpty(accountingYear)) {
      this.setValueByName('AccountingYear', this.buildOutScheduleItems[0].AccountingYear);
    }
  }

  private setBaseRecordFlag() {
    const monthYear = this.buildOutScheduleItems
      .map((element) => ({
        MonthYear: this.datepipe.transform(new Date(element.AccountingMonth + element.AccountingYear), 'yyyy-MM-dd'),
      }))
      .sort((a: any, b: any) => {
        return a.MonthYear - b.MonthYear;
      });
    if (monthYear && monthYear.length > 0) {
      const objIndex = this.buildOutScheduleItems.findIndex((element) => this.datepipe.transform(new Date(element.AccountingMonth + element.AccountingYear), 'yyyy-MM-dd') === monthYear[0].MonthYear);
      this.buildOutScheduleItems[objIndex].BaseRecordFlag = 1;
      if (monthYear[0].MonthYear === this.datepipe.transform(new Date(this.getValueByName('AccountingMonth') + this.getValueByName('AccountingYear')), 'yyyy-MM-dd')) {
        this.submissionSaveItem.CommonDetails.BaseRecordFlag = 1;
      } else {
        this.submissionSaveItem.CommonDetails.BaseRecordFlag = 0;
      }
    }
  }

  private getForecastByMonthYear(): number {
    const filteredBuildOutSchedule: BuildOutScheduleItems[] = this.buildOutScheduleItems.filter((ele) => {
      return ele.AccountingMonth === this.getValueByName('AccountingMonth') && ele.AccountingYear === String(this.getValueByName('AccountingYear'));
    });
    if (filteredBuildOutSchedule != null && filteredBuildOutSchedule.length > 0) {
      return filteredBuildOutSchedule[0].Forecast;
    } else {
      return 0;
    }
  }

  setErrorWarning() {
    if (this.sectionKeyItems) {
      this.sectionKeyItems.forEach((sectionKey) => {
        const controlDetails = this.DataElementsAllDetails.filter((element) => {
          return element.SectionKey === sectionKey;
        });

        if (controlDetails) {
          const cntrl = controlDetails.filter((cnt) => {
            return cnt.ControlName !== null && cnt.ControlName === cnt.ControlName && cnt.SectionKey === sectionKey && this.submissionFields[cnt.ControlName].invalid === true;
          });

          if (cntrl && cntrl.length > 0) {
            const errorMessage = cntrl.map((ele) => ele.DataLabel).join(', ');
            this.setHeaderErrorMessage(sectionKey, cntrl[0].SectionType, errorMessage, true);
          } else {
            this.setHeaderErrorMessage(sectionKey, controlDetails[0].SectionType, '');
          }
        }
      });
    }
  }

  setErrorWarningForCollections() {
    if (this.sectionKeyItemsForList) {
      console.log(this.sectionKeyItemsForList);
      this.sectionKeyItemsForList.forEach((sectionKey) => {
        const controlDetails = this.DataElementsAllDetails.filter((element) => {
          return element.SectionKey === sectionKey;
        });
        const collectionDetails = this.submissionCollectionFields(sectionKey).get(sectionKey) as FormArray;
        if (controlDetails && collectionDetails) {
          const totalRecords = collectionDetails.length;
          let errorMessage = '';
          for (let rowIndex = 0; rowIndex < totalRecords; rowIndex++) {
            const cntrl = controlDetails.filter((cnt) => {
              return cnt.ControlName !== null && cnt.ControlName === cnt.ControlName && collectionDetails.controls[rowIndex].get(cnt.ControlName).invalid === true;
            });
            if (cntrl && cntrl.length > 0 && rowIndex === 0) {
              errorMessage = cntrl.map((ele) => ele.DataLabel).join(', ') + ' from row ' + (rowIndex + 1);
            } else if (cntrl && cntrl.length > 0 && rowIndex > 0) {
              errorMessage += ' ' + cntrl.map((ele) => ele.DataLabel).join(', ') + ' from row ' + (rowIndex + 1);
            }
          }
          if (Helper.isStringNotNullAndEmpty(errorMessage)) {
            this.setHeaderErrorMessage(sectionKey, controlDetails[0].SectionType, errorMessage, true);
          } else {
            this.setHeaderErrorMessage(sectionKey, controlDetails[0].SectionType, errorMessage);
          }
        }
      });
    }
  }

  private setHeaderErrorMessage(sectionKey: string, sectionType: string, errorMessage: string, isErrorExist: Boolean = false) {
    const cntllist = this.getValidationAttribute(sectionKey, sectionType);
    cntllist.isValidationErrorExist = isErrorExist;
    cntllist.validationErrorSummary = isErrorExist ? 'Please fill in ' + errorMessage : '';
  }

  private getValidationAttribute(sectionKey: string, sectionType: string) {
    let cntllist;
    switch (sectionType) {
      case SectionType.Primary:
        cntllist = this.dataElementsControlDetailsItem.filter((ele) => {
          return ele.SectionKey === sectionKey;
        });
        break;
      case SectionType.Secondary:
        cntllist = this.dataElementsControlDetailsItemPanel.filter((ele) => {
          return ele.SectionKey === sectionKey;
        });
      case SectionType.Collections:
        cntllist = this.dataElementsControlDetailsItemPanel.filter((ele) => {
          return ele.SectionKey === sectionKey;
        });
        break;
    }

    if (cntllist && cntllist.length > 0) {
      return cntllist[0];
    }
  }

  handleNavigation() {
    this.submissionFormGroup.markAsPristine();
    this.submissionFormGroup.markAsUntouched();
    this.router.navigate(['/dashboard/tracker-queue']);
  }

  handleTransferRecord() {
    // Below data needs to be supplied from MetadataDetailsItem
    if (this.MetadataDetails) {
      const payload = <ReportsHeaderModel>{
        RecordNo: this.MetadataDetails.RecordNumber ? this.MetadataDetails.RecordNumber : 0,
        CompanyName: [this.MetadataDetails.Company ? this.MetadataDetails.Company : ''],
        Division: [this.MetadataDetails.Division ? this.MetadataDetails.Division : ''],
        Unit: [this.MetadataDetails.Unit ? this.MetadataDetails.Unit : ''],
        Segment: [this.MetadataDetails.Segment ? this.MetadataDetails.Segment : ''],
        UnderwriterName: [this.user.UserID],
      };
      const serializedFilters = this.filterWatch.serializeFromPayload(payload);
      this.router.navigate(['/submission/transfer-record'], {
        queryParams: { filters: this.filterWatch.create(serializedFilters) },
      });
    }
  }

  handleSelectedDnBCompanyDetails(dnbSelectedDetails) {
    if (dnbSelectedDetails[0].CompanyName === 'No Match') {
      this.removeValidators(DBLookupControlList);
      this.setValueByName('DBNumber', 'NM');
      this.setReadOnlyByName('DBSIC', false);
      this.submissionFormGroup.controls['DBNumber'].markAsDirty();
    } else {
      this.addValidators(DBLookupControlList);
      this.submissionFormGroup.patchValue({
        InsuredName: dnbSelectedDetails[0].CompanyName,
        DBNumber: dnbSelectedDetails[0].PrimaryDUNS,
        InsuredAddress1: dnbSelectedDetails[0].Address,
        InsuredCity: dnbSelectedDetails[0].City,
        InsuredZIPCode: dnbSelectedDetails[0].Zip,
        InsuredStateProvince: dnbSelectedDetails[0].State,
        NAICSCode: dnbSelectedDetails[0].NAICSCode,
        DBSIC: dnbSelectedDetails[0].SICCode,
        // RiskSICCode: dnbSelectedDetails[0].SICCode,
        CommercialCreditScore: dnbSelectedDetails[0].CCS,
      });
      if (!Helper.isStringNotNullAndEmpty(this.getValueByName('RiskSICCode'))) {
        this.setValueByName('RiskSICCode', dnbSelectedDetails[0].SICCode);
      }
      this.setReadOnlyByName('DBSIC', true);
      this.submissionFormGroup.controls['InsuredZIPCode'].markAsDirty();
    }
  }

  setDBLookupMandatory() {
    if (this.getValueByName('DBNumber') === 'NM') {
      this.removeValidators(DBLookupControlList);
    } else {
      this.addValidators(DBLookupControlList);
    }
  }

  showDnBCompanyDetailsSearch(ctrl): void {
    this.dnbInsuredStateItem.CompanyName = this.getValueByName('InsuredName');
    this.dnbInsuredStateItem.StateProvince = this.getValueByName('InsuredStateProvince');
    this.dnbInsuredStateItem.UserID = this.user.UserID;
    const dialogRef = this.dialog.open(SubmissionDnBLookupComponent, {
      width: '1110px',
      data: this.dnbInsuredStateItem,
      hasBackdrop: true,
      backdropClass: 'backdropBackground',
    });

    dialogRef.afterClosed().subscribe((dnbSelectedDetails) => {
      if (dnbSelectedDetails) {
        this.handleSelectedDnBCompanyDetails(dnbSelectedDetails);
      }
    });
  }

  showPASValidationDialog(): void {
    if (this.pasValidationCR()) {
      const dialogRef = this.dialog.open(PasvalidationDialogComponent, {
        width: '510px',
        data: this.pasDialogDetails,
        hasBackdrop: true,
        backdropClass: 'backdropBackground',
      });

      dialogRef.afterClosed().subscribe((result) => {
        if (result && result === 'Refresh') {
          this.submissionFormGroup.patchValue({
            BrokerState: this.MetadataDetails.PASProducerState,
            Brokerage: this.MetadataDetails.PASProducerName,
            BrokerCity: this.MetadataDetails.PASProducerCity,
            BrokerRegion: this.MetadataDetails.PASProducerRegion,
            BrokerBranch: this.MetadataDetails.PASProducerBranch,
            CreditedRegion: this.MetadataDetails.PASProducerRegion,
            CreditedBranch: this.MetadataDetails.PASProducerBranch,
          });
        } else if (result && result === 'Search') {
          this.showProducerSearch();
        } else if (result && result === 'Retain History') {
          // this.setValueByName('RetainHistoryCheck', 'true');
        }
      });
    }
  }

  pasValidationCR() {
    if (this.isRecordExists) {
      const isPASCodeInactive = this.MetadataDetails.IsPASCodeInactive;
      const isPASAttributeChanged = this.MetadataDetails.IsPASAttributeChanged;
      const pasDateCheck = this.MetadataDetails.PASDateCheck;
      let retainHistoryCheck = 'true';
      // S-R-C S-RH-C R-RH-C S-C
      retainHistoryCheck = 'false';
      if (isPASCodeInactive === 'true' && pasDateCheck === 'false') {
        if (retainHistoryCheck === 'false') {
          this.pasDialogDetails.ActionType = 'S-C';
          this.pasDialogDetails.Message = 'Producer code is no longer active.Please Search & select new producer code';
          this.pasDialogDetails.Title = 'Refresh and Producer Search';
        } else {
          this.pasDialogDetails.ActionType = 'S-RH-C';
          this.pasDialogDetails.Message = 'Producer code is no longer active.  Do you want to update the Producer Code or Retain Historical producer information?';
          this.pasDialogDetails.Title = 'Refresh and Producer Search';
        }
      } else if (isPASCodeInactive === 'true' && pasDateCheck === 'true') {
        this.pasDialogDetails.ActionType = 'S-C';
        this.pasDialogDetails.Message = 'Producer code is no longer active.Please Search & select new producer code';
        this.pasDialogDetails.Title = 'Refresh and Producer Search';
      } else if (isPASAttributeChanged === 'true' && pasDateCheck === 'false') {
        if (retainHistoryCheck === 'false') {
          this.pasDialogDetails.ActionType = 'S-R-C';
          this.pasDialogDetails.Message = 'Producer attributes in Tracker do not match those of PAS Producer Code [' + this.getValueByName('ProducerCode') + ']. You may refresh Tracker based on the selected code OR search for a new Producer Code.';
          this.pasDialogDetails.Title = 'Refresh and Producer Search';
        } else {
          this.pasDialogDetails.ActionType = 'R-RH-C';
          this.pasDialogDetails.Message = 'Producer attributes in Tracker do not match those of PAS Producer Code [' + this.getValueByName('ProducerCode') + ']. Update attributes by Refreshing the data or Retain historical producer information.';
          this.pasDialogDetails.Title = 'Refresh and Producer Search';
        }
      } else if (isPASAttributeChanged === 'true' && pasDateCheck === 'true') {
        this.pasDialogDetails.ActionType = 'Refresh and Producer Search';
        this.pasDialogDetails.Message = 'Producer attributes in Tracker do not match those of PAS Producer Code [' + this.getValueByName('ProducerCode') + ']. You may refresh Tracker based on the selected code OR search for a new Producer Code.';
        this.pasDialogDetails.Title = 'S-R-C';
      }
      return false;
    } else {
      return false;
    }
  }

  // handleSubmissionCopyDelete($event) {
  //   switch ($event.Action) {
  //     case 'Delete confirm':
  //       this.handleDeleteSubmission();
  //       break;
  //     case 'Copy confirm':
  //       this.handleCopySubmission($event.Type);
  //       break;
  //   }
  // }

  showConfirmationCopyDelete(action) {
    // const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
    //   width: '510px',
    //   data: {
    //     Action: action,
    //     label: action,
    //     Message: '',
    //     IsTarget: this.setCopyTargetStatus(action),
    //   },
    //   hasBackdrop: true,
    //   backdropClass: 'backdropBackground',
    // });

    // dialogRef.afterClosed().subscribe((result) => {
    //   if (Helper.isStringNotNullAndEmpty(result)) {
    //     this.handleSubmissionCopyDelete(result);
    //   }
    // });
    if (action === 'Delete') {
      const deleteRequest: CopyDeleteRequestModel = {
        Source: 'SUBMISSION',
        UserID: this.user.UserID,
        RecordNumber: this.recordNumber,
      };
      this.copyDeleteService.showConfirmationDelete(deleteRequest);
    } else if (action === 'Copy') {
      const copyRequest: CopyDeleteRequestModel = {
        Source: 'SUBMISSION',
        UserID: this.user.UserID,
        RecordNumber: this.recordNumber,
        Company: this.companyValue,
        Status: this.StatusValue,
        LinkedRecordNumber: this.MetadataDetails.LinkedRecordNumber,
      };
      this.copyDeleteService.showConfirmationCopy(copyRequest);
    }
  }

  // private setCopyTargetStatus(action: string): boolean {
  //   if (action === 'Copy' && !this.isLinkedRecord && [Status.Target, Status.TargetClosed].includes(this.StatusValue) && ['Major Accounts Division', 'Commercial Insurance Division', 'Small Retail Division'].includes(this.companyValue)) {
  //     return true;
  //   } else {
  //     return false;
  //   }
  // }

  // get isLinkedRecord() {
  //   if (this.MetadataDetails && this.MetadataDetails.LinkedRecordNumber > 0) {
  //     return true;
  //   } else {
  //     return false;
  //   }
  // }

  setProducerDetails(producerDetails) {
    this.submissionFormGroup.patchValue({
      ProducerCode: producerDetails.ProducerCode,
      BrokerState: producerDetails.BrokerState,
      Brokerage: producerDetails.Brokerage,
      BrokerCity: producerDetails.BrokerCity,
      BrokerRegion: producerDetails.BrokerRegion,
      BrokerBranch: producerDetails.BrokerBranch,
      CreditedRegion: producerDetails.BrokerRegion,
      CreditedBranch: producerDetails.BrokerBranch,
    });
    this.submissionFormGroup.controls['Brokerage'].markAsDirty();
  }

  showProducerSearch(): void {
    const dialogRef = this.dialog.open(SubmissionProducerLookupComponent, {
      width: '1110px',
      data: this.generatePayload(),
      hasBackdrop: true,
      backdropClass: 'backdropBackground',
    });

    dialogRef.afterClosed().subscribe((producerSearchDetails) => {
      if (producerSearchDetails) {
        this.setProducerDetails(producerSearchDetails);
      }
    });
  }

  // handleDeleteSubmission() {
  //   let dialogRef = this.dialog.open(InputFormPopupComponent, {
  //     data: {
  //       loader: true,
  //     },
  //   });
  //   this.reportingService.deleteTransactionByRecordNo(this.inputPageHeader.RecordNumber, this.user.UserID).subscribe((data: any) => {
  //     dialogRef.close();
  //     dialogRef = this.dialog.open(InputFormPopupComponent, {
  //       data: {
  //         Message: data != null ? 'Record deleted Successfully !' : 'There is an issue while deleting the record!!!',
  //         IsSuccess: data != null ? true : false,
  //         loader: false,
  //         RecordNumber: 0,
  //         Action: 'Delete',
  //         OkLabel: 'Ok',
  //         RedirectLabel: '',
  //       },
  //     });
  //     dialogRef.afterClosed().subscribe((result) => {
  //       if (result && result === 'close') {
  //         this.closeInputPage();
  //       }
  //     });
  //   });
  // }

  // handleCopySubmission(type: string = '') {
  //   let dialogRef = this.dialog.open(InputFormPopupComponent, {
  //     data: {
  //       loader: true,
  //     },
  //   });
  //   if (type === 'Target') {
  //     this.reportingService.copySubmission(this.inputPageHeader.RecordNumber, this.user.UserID).subscribe((data: any) => {
  //       dialogRef.close();
  //       this.copySuccessDialog(dialogRef, data, type);
  //     });
  //   } else if (type === 'Submission') {
  //     this.reportingService.copyLinkedSubmission(this.inputPageHeader.RecordNumber, this.user.UserID).subscribe((data: any) => {
  //       dialogRef.close();
  //       this.copySuccessDialog(dialogRef, data, type);
  //     });
  //   }
  // }

  // private copySuccessDialog(dialogRef, data: any, type: string = '') {
  //   dialogRef = this.dialog.open(InputFormPopupComponent, {
  //     data: {
  //       Message: data != null && data > 0 ? 'Record Copied Successfully !' : 'There is an occured while copying the record!!!',
  //       IsSuccess: data != null && data > 0 ? true : false,
  //       loader: false,
  //       RecordNumber: data != null && data > 0 ? data : 0,
  //       Action: 'Copy',
  //       // OkLabel: (type === 'Target') ? 'Stay' : 'Ok',
  //       OkLabel: 'Stay',
  //       RedirectLabel: 'Go to this Record',
  //     },
  //   });
  //   dialogRef.afterClosed().subscribe((result) => {
  //     if (result && result === 'close') {
  //       this.closeInputPage();
  //     } else if (result && result === 'stay') {
  //       if (type === 'Submission') {
  //         this.reloadByLinkedRecordNumber();
  //       } else {
  //         // this.closeInputPage();
  //       }
  //     } else if (result && result > 0) {
  //       this.openRecordInNewTab(data);
  //       if (type === 'Submission') {
  //         this.reloadByLinkedRecordNumber();
  //       }
  //     }
  //   });
  // }

  copySuccessAction(result) {
    if (result && result.Action === 'close') {
      this.closeInputPage();
    } else if (result && result.Action === 'stay') {
      if (result.Type === 'Submission') {
        this.reloadByLinkedRecordNumber();
      }
    } else if (result && result.RecordNumber > 0) {
      this.openRecordInNewTab(result.RecordNumber);
      if (result.Type === 'Submission') {
        this.reloadByLinkedRecordNumber();
      }
    }
  }

  reloadByLinkedRecordNumber() {
    if (this.recordNumber > 0) {
      this.submissionFormGroup.markAsPristine();
      this.submissionFormGroup.markAsUntouched();
      const payload = <ReportsHeaderModel>{
        Division: [],
        Unit: [],
        Segment: [],
        UserID: this.user.UserID,
        UnderwriterName: [this.user.UserID],
        RecordNo: this.recordNumber,
        GeniusPipeID: this.storedFilters.GeniusPipeID ? this.storedFilters.GeniusPipeID : 0,
        IsGenius: this.storedFilters.GeniusPipeID > 0 ? 'Y' : 'N',
      };
      const serializedFilters = this.filterWatch.serializeFromPayload(payload);
      this.router.routeReuseStrategy.shouldReuseRoute = () => false;
      this.router.onSameUrlNavigation = 'reload';
      this.router.navigate(['/submission/input-page'], {
        queryParams: {
          filters: this.filterWatch.create(serializedFilters),
          routedFrom: this.routedFrom,
        },
      });
    }
  }

  handleLayerDetails(): void {
    const dialogRef = this.dialog.open(LayerDetailsComponent, {
      width: '1110px',
      data: { RecordNumber: this.recordNumber, UserID: this.user.UserID },
      hasBackdrop: true,
      backdropClass: 'backdropBackground',
    });

    dialogRef.afterClosed().subscribe((layerDetails) => {
      if (layerDetails) {
        for (let controlIndex = 1; controlIndex <= 7; controlIndex++) {
          CanadaLayerControls.forEach((element) => {
            const controlName = element + controlIndex;
            if (layerDetails[controlName] !== null && layerDetails[controlName] !== '') {
              if (this.checkChildItemExists(controlName)) {
                const filteredChildItem = this.submissionSaveItem.ChildItem.filter((child) => {
                  return child.ControlName === controlName;
                });
                if (filteredChildItem && filteredChildItem[0]) {
                  filteredChildItem[0].SelectedValue = layerDetails[controlName];
                }
              } else {
                const list: any = this.submissionSaveItem.ChildItem;
                list.push({
                  ControlName: controlName,
                  SelectedValue: layerDetails[controlName],
                  TableIndicator: 'FCLD',
                });
                this.submissionSaveItem.ChildItem = list;
              }
            }
          });
        }
      }
    });
  }

  getEscalationDetails() {
    this.escalationDetails$ = this.inputPageService.getEscalationDetails(this.user.UserID, this.inputPageHeader.RecordNumber).subscribe((data: EscalationDetailItem) => {
      this.escalationDetailItem = data !== null ? data : null;
    });
  }

  getBuildOutScheduleDetails() {
    this.buildOutSchedule$ = this.inputPageService.getBuildOutScheduleDetails(this.user.UserID, this.inputPageHeader.RecordNumber).subscribe((data: BuildOutScheduleItems[]) => {
      this.buildOutScheduleItems = data !== null ? data : null;
    });
  }

  getSubmissionHelperDetails(payload, controlName = '') {
    this.helperDetails$ = this.inputPageService.getSubmissionHelperDetails(payload).subscribe((data: SubmissionHelperResponseItem) => {
      if (data && data !== null) {
        this.assignHelperMethodControlValue(payload, data, controlName);
      }
    });
  }

  private assignHelperMethodControlValue(payload: any, data: SubmissionHelperResponseItem, controlName) {
    switch (payload.HelperMethodName) {
      case HelperMethodName.IndustryDescriptionAndPortfolioByRiskSIC:
        {
          if (Helper.isStringNotNullAndEmpty(data.PrimaryIndustry)) {
            this.setValueByName('PrimaryIndustry', data.PrimaryIndustry);
          }
          if (Helper.isStringNotNullAndEmpty(data.RiskSICDescription)) {
            this.setValueByName('RiskSICDescription', data.RiskSICDescription);
          }
          if (Helper.isStringNotNullAndEmpty(data.PortFolioClass)) {
            this.setValueByName('PortFolioClass', data.PortFolioClass);
          }
        }
        break;
      case HelperMethodName.RegionByBranch:
        {
          if (controlName === 'BrokerBranch') {
            if (Helper.isStringNotNullAndEmpty(data.BrokerRegion)) {
              this.setValueByName('BrokerRegion', data.BrokerRegion);
            } else {
              this.setValueByName('BrokerRegion', '');
            }
          } else if (controlName === 'CreditedBranch') {
            if (Helper.isStringNotNullAndEmpty(data.BrokerRegion)) {
              this.setValueByName('CreditedRegion', data.BrokerRegion);
            } else {
              this.setValueByName('CreditedRegion', '');
            }
          }
        }
        break;
      case HelperMethodName.ServiceRegionByServiceBranch:
        {
          if (Helper.isStringNotNullAndEmpty(data.ServiceRegion)) {
            this.setValueByName('ServiceRegion', data.ServiceRegion);
          } else {
            this.setValueByName('ServiceRegion', '');
          }
        }
        break;
      case HelperMethodName.PortfolioByNAICS:
        {
          if (Helper.isStringNotNullAndEmpty(data.PortFolioClass)) {
            this.setValueByName('PortFolioClass', data.PortFolioClass);
          }
        }
        break;
      case HelperMethodName.RehIndicator:
        {
          if (data.REHIndicator !== null) {
            this.setValueByName('REHIndicator', String(data.REHIndicator));
          }
        }
        break;
      case HelperMethodName.DNBSICDescription:
        {
          if (Helper.isStringNotNullAndEmpty(data.DnBSICDescription)) {
            this.setValueByName('DnBSICDescription', data.DnBSICDescription);
          }
        }
        break;
      case HelperMethodName.PortfolioByLOB:
        {
          if (Helper.isStringNotNullAndEmpty(data.PortFolioClass)) {
            this.setValueByName('PortFolioClass', data.PortFolioClass);
          }
        }
        break;
      case HelperMethodName.UWRegionByUWBranchDesc:
        {
          if (Helper.isStringNotNullAndEmpty(data.UWRegion)) {
            this.setValueByName('UWRegion', data.UWRegion);
          }
        }
        break;
      case HelperMethodName.IndustryPracticeDetails:
        {
          if (Helper.isStringNotNullAndEmpty(data.IndustryPractice)) {
            this.setValueByName('IndustryPractice', data.IndustryPractice);
          }
          if (Helper.isStringNotNullAndEmpty(data.IndustryPracticeDescription)) {
            this.setValueByName('IndustryPracticeDescription', data.IndustryPracticeDescription);
          }
        }
        break;
      case HelperMethodName.TargetTypeByInsuredName:
        {
          if (Helper.isStringNotNullAndEmpty(data.TargetType)) {
            if (this.getValueByName('Type') === Type.New || this.getValueByName('Type') === '') {
              this.setValueByName('TargetType', data.TargetType);
            }
          }
        }
        break;
      case HelperMethodName.RateAndExposureChange:
        {
          this.setValueByName('RateChange', data.RateChange);
          this.setValueByName('ExposureChange', data.ExposureChange);
        }
        break;
      case HelperMethodName.NetForecast:
        {
          // Calculate
          this.setValueByName('NetForecast', data.NetForecast);
        }
        break;
      case HelperMethodName.ExpNetForecast:
        {
          // Calculate
          this.setValueByName('ExpiringNetForecast', data.ExpiringNetForecast);
        }
        break;
      default:
        break;
    }
  }

  private getElementsByName(controlName) {
    const controlDetails = this.getSectionNameByControl(controlName);
    if (controlDetails) {
      let filteredDataElements: DataElementsControlDetailsItem[];
      switch (controlDetails.SectionType) {
        case SectionType.Primary:
          filteredDataElements = this.dataElementsControlDetailsItem
            .filter((ele) => {
              return ele.SectionName === controlDetails.SectionName;
            })
            .filter((elementDetail) => {
              return elementDetail.DataElementsDetails;
            });
          break;
        case SectionType.Secondary:
          if (controlDetails.ControlGroupIndicator > 0) {
            filteredDataElements = this.dataElementsControlDetailsItemPanel
              .filter((ele) => {
                return ele.SectionName === controlDetails.SectionName;
              })
              .filter((elementDetail) => {
                return elementDetail.DataElementsGroupDetails;
              });
          } else {
            filteredDataElements = this.dataElementsControlDetailsItemPanel
              .filter((ele) => {
                return ele.SectionName === controlDetails.SectionName;
              })
              .filter((elementDetail) => {
                return elementDetail.DataElementsDetails;
              });
          }
          break;
      }

      if (filteredDataElements && filteredDataElements.length > 0 && controlDetails.ControlGroupIndicator > 0) {
        let filteredcntllist;
        filteredDataElements[0].DataElementsGroupDetails.forEach((element) => {
          const cntllist = element.DataElementsDetails.filter((cnt) => cnt.ControlName === controlName && cnt.TableIndicator === controlDetails.TableIndicator);
          if (cntllist && cntllist.length > 0) {
            filteredcntllist = cntllist;
          }
        });
        return filteredcntllist;
      } else {
        return filteredDataElements[0].DataElementsDetails.filter((cnt) => cnt.ControlName === controlName && cnt.TableIndicator === controlDetails.TableIndicator);
      }
    }
  }

  private setControlValueForSave(field: DataElementsDetails, target: any, rowIndicator: string = 'S') {
    if (field) {
      if (field.TableIndicator === 'P') {
        this.submissionSaveItem.ParentItem[field.ControlName] = this.formatSSSelectedValue(field, target);
      } else {
        if (this.isChildItemExists(field.ControlName, rowIndicator)) {
          const filteredChildItem = this.submissionSaveItem.ChildItem.filter((child) => {
            return child.ControlName === field.ControlName;
          });
          if (filteredChildItem && filteredChildItem[0]) {
            filteredChildItem[0].SelectedValue = this.formatSSSelectedValue(field, target);
          }
        } else {
          const list: any = this.submissionSaveItem.ChildItem;
          list.push({
            ControlName: field.ControlName,
            SelectedValue: this.formatSSSelectedValue(field, target),
            TableIndicator: field.TableIndicator,
            RowIndicator: rowIndicator,
          });
          this.submissionSaveItem.ChildItem = list;
        }
      }
    }
  }

  private isChildItemExists(controlName: string, rowIndicator: string) {
    const filteredChildItem = this.submissionSaveItem.ChildItem.filter((child) => {
      return child.ControlName === controlName && child.RowIndicator === rowIndicator;
    });
    if (filteredChildItem && filteredChildItem[0]) {
      return true;
    } else {
      return false;
    }
  }

  private formatSSSelectedValue(field, target) {
    if (Helper.isStringNotNullAndEmpty(field.ControlType) && field.ControlType.toLowerCase() !== 'combodropdown' && Helper.isStringNotNullAndEmpty(target)) {
      if (field.ControlType.toLowerCase() === 'inputmoney' || field.ControlType.toLowerCase() === 'inputabsmoney') {
        return Helper.removeComma(target);
      } else if (field.ControlType.toLowerCase() === 'inputpercentage') {
        return Helper.removePercentage(target);
      } else if (field.ControlType.toLowerCase() === 'checkbox') {
        return this.translateCheckboxValue({ field, target });
      } else if (field.ControlType.toLowerCase() === 'inputdate') {
        return (target = moment(target).format('MM/DD/YYYY'));
      } else if (field.ControlType.toLowerCase() === 'combodropdown') {
        return (target = target.toString());
      } else if (field.ControlType.toLowerCase() === 'dropdown' && field.ControlName === 'Privacy') {
        return (target = target === '' ? 2 : target === '2' ? '0' : target === '1' ? 1 : target);
      } else {
        return target;
      }
    } else if (Helper.isStringNotNullAndEmpty(field.ControlType) && field.ControlType.toLowerCase() === 'combodropdown' && Helper.isStringArrayNotNullAndEmpty(target)) {
      if (Helper.isStringNotNullAndEmpty(field.PatternTypeName)) {
        return target.join(field.PatternTypeName);
      } else {
        return target.toString();
      }
    } else {
      return target;
    }
  }

  translateCheckboxValue({ field, target }: { field: any; target: any }) {
    if (field.PatternTypeName === CheckboxTransPattern.YesNo) {
      return Boolean(target) ? 'Yes' : 'No';
    } else if (field.PatternTypeName === CheckboxTransPattern.YN) {
      return Boolean(target) ? 'Y' : 'N';
    } else if (field.PatternTypeName === CheckboxTransPattern.RegisteredNo) {
      return Boolean(target) ? 'Registered' : 'No';
    } else {
      return Boolean(target) ? 1 : 0;
    }
  }

  private checkChildItemExists(controlName) {
    const filteredChildItem = this.submissionSaveItem.ChildItem.filter((child) => {
      return child.ControlName === controlName;
    });
    if (filteredChildItem && filteredChildItem[0]) {
      return true;
    } else {
      return false;
    }
  }

  calculateNetForecast(controlName) {
    let helperFilterItem: SubmissionHelperFilterItem;
    helperFilterItem = this.setHelperFilterDefaultPayload(helperFilterItem);
    delete helperFilterItem.Division;
    delete helperFilterItem.RiskSICCode;
    if (controlName === 'NetForecast' && Helper.isStringNotNullAndEmpty(this.getValueByName('Segment')) && Helper.isStringNotNullAndEmpty(this.getValueByName('Forecast'))) {
      helperFilterItem = {
        ...helperFilterItem,
        HelperMethodName: HelperMethodName.NetForecast,
        PortFolioClass: this.getValueByName('PortFolioClass'),
        Forecast: this.getValueByName('Forecast'),
      };
      this.getSubmissionHelperDetails(helperFilterItem);
    } else if (controlName === 'ExpiringNetForecast' && Helper.isStringNotNullAndEmpty(this.getValueByName('Segment')) && Helper.isStringNotNullAndEmpty(this.getValueByName('BasePremium'))) {
      helperFilterItem = {
        ...helperFilterItem,
        HelperMethodName: HelperMethodName.ExpNetForecast,
        PortFolioClass: this.getValueByName('PortFolioClass'),
        BasePremium: this.getValueByName('BasePremium'),
      };
      this.getSubmissionHelperDetails(helperFilterItem);
    }
  }

  getSubmissionHelper(controlName) {
    let helperFilterItem: SubmissionHelperFilterItem;
    helperFilterItem = this.setHelperFilterDefaultPayload(helperFilterItem);
    switch (controlName) {
      case 'RiskSICCode':
        if (Helper.isStringNotNullAndEmpty(this.getValueByName('RiskSICCode'))) {
          helperFilterItem = {
            ...helperFilterItem,
            HelperMethodName: HelperMethodName.IndustryDescriptionAndPortfolioByRiskSIC,
          };
          delete helperFilterItem.Division;
          delete helperFilterItem.Segment;
          this.getSubmissionHelperDetails(helperFilterItem);
        }
        break;
      case 'BrokerBranch':
      case 'CreditedBranch':
        if ((controlName === 'BrokerBranch' && Helper.isStringNotNullAndEmpty(this.getValueByName('BrokerBranch'))) || (controlName === 'CreditedBranch' && Helper.isStringNotNullAndEmpty(this.getValueByName('CreditedBranch')))) {
          helperFilterItem = {
            ...helperFilterItem,
            HelperMethodName: HelperMethodName.RegionByBranch,
            BrokerBranch: controlName === 'BrokerBranch' ? this.getValueByName('BrokerBranch') : controlName === 'CreditedBranch' ? this.getValueByName('CreditedBranch') : '',
          };
          delete helperFilterItem.Division;
          delete helperFilterItem.Unit;
          delete helperFilterItem.Segment;
          delete helperFilterItem.RiskSICCode;
          this.getSubmissionHelperDetails(helperFilterItem, controlName);
        }
        break;
      case 'ServiceBranch':
        if (Helper.isStringNotNullAndEmpty(this.getValueByName('ServiceBranch'))) {
          helperFilterItem = {
            ...helperFilterItem,
            HelperMethodName: HelperMethodName.ServiceRegionByServiceBranch,
            ServiceBranch: this.getValueByName('ServiceBranch'),
          };
          delete helperFilterItem.Division;
          delete helperFilterItem.Unit;
          delete helperFilterItem.Segment;
          delete helperFilterItem.RiskSICCode;
          this.getSubmissionHelperDetails(helperFilterItem);
        }
        break;
      case 'RiskNAIC':
        if (helperFilterItem.Division === 'Property & Specialty - Major' && helperFilterItem.Unit === 'Property' && helperFilterItem.Segment === 'Property - National Accounts' && !Helper.isStringNotNullAndEmpty(this.getValueByName('PortFolioClass'))) {
          const riskCode = this.getValueByName('RiskNAIC');
          if (riskCode) {
            helperFilterItem = {
              ...helperFilterItem,
              HelperMethodName: HelperMethodName.PortfolioByNAICS,
              RiskNAIC: riskCode,
            };
            delete helperFilterItem.Division;
            delete helperFilterItem.Unit;
            delete helperFilterItem.RiskSICCode;
            this.getSubmissionHelperDetails(helperFilterItem);
          }
        }
        break;
      case 'DBSIC':
        if (Helper.isStringNotNullAndEmpty(this.getValueByName('DBSIC'))) {
          helperFilterItem = {
            ...helperFilterItem,
            HelperMethodName: HelperMethodName.DNBSICDescription,
            DBSIC: this.getValueByName('DBSIC'),
          };
          delete helperFilterItem.Division;
          delete helperFilterItem.Unit;
          delete helperFilterItem.Segment;
          delete helperFilterItem.RiskSICCode;
          this.getSubmissionHelperDetails(helperFilterItem);
        }
        break;
      case 'UWBranch':
        if (Helper.isStringNotNullAndEmpty(this.getValueByName('UWBranch'))) {
          helperFilterItem = {
            ...helperFilterItem,
            HelperMethodName: HelperMethodName.UWRegionByUWBranchDesc,
            UWBranch: this.getValueByName('UWBranch'),
          };
          delete helperFilterItem.Division;
          delete helperFilterItem.Unit;
          delete helperFilterItem.Segment;
          delete helperFilterItem.RiskSICCode;
          this.getSubmissionHelperDetails(helperFilterItem);
        } else if (Helper.isStringNotNullAndEmpty(this.getValueByName('UWRegion'))) {
          this.setValueByName('UWRegion', '');
        }
        break;
      case 'InsuredName':
        if (Helper.isStringNotNullAndEmpty(this.getValueByName('InsuredName'))) {
          helperFilterItem = {
            ...helperFilterItem,
            HelperMethodName: HelperMethodName.TargetTypeByInsuredName,
            InsuredName: this.getValueByName('InsuredName'),
          };
          delete helperFilterItem.Division;
          delete helperFilterItem.Unit;
          delete helperFilterItem.Segment;
          delete helperFilterItem.RiskSICCode;
          this.getSubmissionHelperDetails(helperFilterItem);
        }
        break;
      default:
        break;
    }

    if (controlName === 'Segment' || controlName === 'RiskSICCode') {
      const rehIndicator = this.getValueByName('REHIndicator');
      if (Helper.isStringNotNullAndEmpty(rehIndicator)) {
        if (this.getValueByName('Segment') && Helper.isStringNotNullAndEmpty(this.getValueByName('RiskSICCode'))) {
          helperFilterItem = this.setHelperFilterDefaultPayload(helperFilterItem);
          helperFilterItem = {
            ...helperFilterItem,
            HelperMethodName: HelperMethodName.RehIndicator,
          };
          this.getSubmissionHelperDetails(helperFilterItem);
        }
      }
    }

    if ((controlName === 'Segment' || controlName === 'Product' || controlName === 'PrimaryIndustry' || controlName === 'PrimaryExcess') && Helper.isStringNotNullAndEmpty(this.getValueByName('PortFolioClass'))) {
      if (this.getValueByName('Segment') && Helper.isStringNotNullAndEmpty(this.getValueByName('Product')) && Helper.isStringNotNullAndEmpty(this.getValueByName('PrimaryIndustry')) && Helper.isStringNotNullAndEmpty(this.getValueByName('PrimaryExcess'))) {
        helperFilterItem = this.setHelperFilterDefaultPayload(helperFilterItem);
        helperFilterItem = {
          ...helperFilterItem,
          HelperMethodName: HelperMethodName.PortfolioByLOB,
          Product: this.getValueByName('Product'),
          PrimaryIndustry: this.getValueByName('PrimaryIndustry'),
          PrimaryExcess: this.getValueByName('PrimaryExcess'),
        };
        delete helperFilterItem.Division;
        delete helperFilterItem.RiskSICCode;
        this.getSubmissionHelperDetails(helperFilterItem);
      }
    }

    if (controlName === 'Segment' || controlName === 'RiskSICCode' || controlName === 'PortFolioClass' || controlName === 'PrimaryIndustry' || controlName === 'NAICSCode' || controlName === 'UCCCode' || controlName === 'MarketingProgramCode') {
      if (Helper.isStringNotNullAndEmpty(this.getValueByName('RiskSICCode'))) {
        helperFilterItem = this.setHelperFilterDefaultPayload(helperFilterItem);
        helperFilterItem = {
          ...helperFilterItem,
          HelperMethodName: HelperMethodName.IndustryPracticeDetails,
          PortFolioClass: this.getValueByName('PortFolioClass'),
          PrimaryIndustry: this.getValueByName('PrimaryIndustry'),
          NAICSCode: this.getValueByName('NAICSCode'),
          UCCCode: this.getValueByName('UCCCode'),
          MarketingProgramCode: this.getValueByName('MarketingProgramCode'),
        };
        delete helperFilterItem.Division;
        this.getSubmissionHelperDetails(helperFilterItem);
      }
    }

    if (controlName === 'Forecast' || controlName === 'BasePremium' || controlName === 'RateMod' || controlName === 'Type') {
      if (Helper.isStringNotNullAndEmpty(this.getValueByName('Forecast')) && Helper.isStringNotNullAndEmpty(this.getValueByName('BasePremium')) && Helper.isStringNotNullAndEmpty(this.getValueByName('RateMod')) && Helper.isStringNotNullAndEmpty(this.getValueByName('Type')) && this.getValueByName('Type') === Type.Renewal) {
        helperFilterItem = {
          UserID: this.user.UserID,
          HelperMethodName: HelperMethodName.RateAndExposureChange,
          Forecast: this.getValueByName('Forecast'),
          BasePremium: this.getValueByName('BasePremium'),
          RateMod: this.getNumValueByName('RateMod'),
          Type: this.getValueByName('Type'),
        };
        this.getSubmissionHelperDetails(helperFilterItem);
      }
    }
  }

  private setHelperFilterDefaultPayload(helperFilterItem: SubmissionHelperFilterItem) {
    helperFilterItem = {
      UserID: this.user.UserID,
      Division: this.getValueByName('Division'),
      Unit: this.getValueByName('Unit'),
      Segment: this.getValueByName('Segment'),
      RiskSICCode: this.getValueByName('RiskSICCode'),
    };
    return helperFilterItem;
  }

  private getChildControlValue(controlName) {
    const controlDetails = this.getSectionNameByControl(controlName);
    if (controlDetails) {
      const filteredChildItem = this.submissionSaveItem.ChildItem.filter((child) => {
        return child.ControlName === controlName && child.TableIndicator === controlDetails.TableIndicator;
      });
      if (filteredChildItem && filteredChildItem[0]) {
        return filteredChildItem[0].SelectedValue;
      } else {
        return '';
      }
    }
  }

  closeInputPage() {
    if (this.routedFrom === RoutedFrom.SelectUnit) {
      window.history.back();
    } else {
      window.close();
    }
  }

  openAuditDialog() {
    const dialogRef = this.dialog.open(SubmissionAuditTrailDetailsComponent, {
      width: '1110px',
      data: {
        UserID: this.user.UserID,
        RecordNumber: this.inputPageHeader.RecordNumber,
      },
      // hasBackdrop: true,
      backdropClass: 'backdropBackground',
    });

    dialogRef.afterClosed().subscribe(() => {
      console.log('The Audit dialog was closed');
    });
  }

  openEscalateDialog() {
    const dialogRef = this.dialog.open(SubmissionEscalationDetailComponent, {
      width: '410px',
      data: {
        EscalationDetail: this.escalationDetailItem,
        RecordNumber: this.inputPageHeader.RecordNumber,
        ReadOnly: this.inputPageFooter.SaveYN === 'N' ? true : false,
      },
      // hasBackdrop: true,
      backdropClass: 'backdropBackground',
    });

    dialogRef.afterClosed().subscribe((escalationDetails) => {
      if (escalationDetails) {
        this.submissionSaveItem.ParentItem.IsEscalate = escalationDetails.IsEscalate;
        this.submissionSaveItem.ParentItem.EscalateComments = escalationDetails.EscalateComments;
      }
    });
  }

  openBuildOutScheduleDialog() {
    if (this.getDifferenceInMonths()) {
      this.setReadOnlyByName('AccountingYear', true);
      this.setReadOnlyByName('AccountingMonth', true);
      this.setReadOnlyByName('Forecast', true);
      const dialogRef = this.dialog.open(BuildOutScheduleComponent, {
        width: '390px',
        data: {
          PageType: this.submissionSaveItem.CommonDetails.SubmissionPageType,
          RecordNumber: this.inputPageHeader.RecordNumber,
          ForecastType: this.getValueByName('ForecastType'),
          EffectiveDate: this.getDateValueByName('EffectiveDate'),
          ExpirationDate: this.getDateValueByName('ExpirationDate'),
          BuildOutSchedule: this.recordNumber === 0 ? this.buildOutScheduleItems.filter((element) => element.Forecast > 0) : this.buildOutScheduleItems,
          // UserId: this.user.UserID,
        },
        backdropClass: 'backdropBackground',
      });

      dialogRef.afterClosed().subscribe((buildOutScheduleSaveData: BuildOutScheduleItems[]) => {
        if (buildOutScheduleSaveData) {
          this.buildOutScheduleItems = buildOutScheduleSaveData;
          console.log({ buildOutScheduleSaveData });
          if (['M', 'C'].includes(this.getValueByName('ForecastType'))) {
            this.setBuildOutScheduleItems();
            this.setTotalProjectPremium();
          }
        }
      });
    }
  }

  handleBuildOutSchedule() {
    this.setCustomErrors('EffectiveDate', '');
    if (Helper.isStringNotNullAndEmpty(this.getValueByName('EffectiveDate')) && Helper.isStringNotNullAndEmpty(this.getValueByName('ExpirationDate'))) {
      if (this.getDateValueByName('EffectiveDate') >= this.getDateValueByName('ExpirationDate')) {
        const message = 'Effective Date should be less than Expiration date.';
        this.setValueByName('ForecastType', 'A');
        this.setCustomErrors('EffectiveDate', message);
      } else {
        if (['M', 'C'].includes(this.getValueByName('ForecastType'))) {
          if (this.submissionFields['EffectiveDate'].valid && this.submissionFields['ExpirationDate'].valid) {
            this.effectiveAndExpirationChange();
          }
        } else {
          this.setReadOnlyByName('AccountingYear', false);
          this.setReadOnlyByName('AccountingMonth', false);
          this.setReadOnlyByName('Forecast', false);
          this.submissionSaveItem.BuildOutScheduleItems = [];
        }
      }
    }
  }

  effectiveAndExpirationChange() {
    const effectiveDate = this.getControlDetailsByName('EffectiveDate');
    const expirationDate = this.getControlDetailsByName('ExpirationDate');
    if (effectiveDate && Helper.isStringNotNullAndEmpty(effectiveDate[0].SelectedValues) && expirationDate && Helper.isStringNotNullAndEmpty(expirationDate[0].SelectedValues)) {
      if (this.effectiveAndExpirationValidtion(effectiveDate[0].SelectedValues, expirationDate[0].SelectedValues)) {
        const message = 'If the Effective date and/or Expiration date is changed,\nthen the existing Premium Schedule would get changed.\n Do you wish to continue?';
        this.showConfirmDialog(message, 'Ok');
      } else {
        this.openBuildOutScheduleDialog();
      }
    } else {
      this.openBuildOutScheduleDialog();
    }
  }

  private getDifferenceInMonths(): boolean {
    if (['Wrap Up', 'Maintenance Wrap Up'].includes(this.getSegmentValue())) {
      const monthDifference = Helper.toNumber(Helper.dateDifference('m', this.getValueByName('EffectiveDate'), this.getValueByName('ExpirationDate')));
      if (monthDifference === 0) {
        const message = 'Monthly Premium Schedule is not required for a single month.';
        this.notifier.showError(message);
        return false;
      } else {
        return true;
      }
    } else {
      return true;
    }
  }

  private effectiveAndExpirationValidtion(effectiveDate, expirationDate): boolean {
    const effectiveDatePrevious = this.datepipe.transform(effectiveDate, 'MM-dd-yyyy');
    const effectiveDateNew = this.datepipe.transform(this.getValueByName('EffectiveDate'), 'MM-dd-yyyy');
    const expirationDatePrevious = this.datepipe.transform(expirationDate, 'MM-dd-yyyy');
    const expirationDateNew = this.datepipe.transform(this.getValueByName('ExpirationDate'), 'MM-dd-yyyy');
    if (effectiveDatePrevious !== effectiveDateNew || expirationDatePrevious !== expirationDateNew) {
      return true;
    } else {
      return false;
    }
  }

  private showConfirmDialog(message: string, action: string = 'MSG') {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '510px',
      data: {
        Action: action,
        label: action,
        Message: message,
      },
      hasBackdrop: true,
      backdropClass: 'backdropBackground',
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result && Helper.isStringNotNullAndEmpty(result.Action)) {
        if (result.Action === 'Ok confirm') {
          this.openBuildOutScheduleDialog();
        }
      }
    });
  }

  openContactSearchDialog(controlName) {
    const dialogRef = this.dialog.open(SubmissionContactSearchComponent, {
      width: '1110px',
      data: {
        ControlName: controlName,
        UserId: this.user.UserID,
        ContactSearchFilter: this.contactSearchFilter,
      },
      backdropClass: 'backdropBackground',
    });

    dialogRef.afterClosed().subscribe((contactDetails: SubmissionContactDetails) => {
      if (contactDetails) {
        this.setContactDetailsValue(contactDetails.ContactDetails[0], contactDetails.ControlName);
      }
    });
  }

  openContactSearchMiniDialog(controlName) {
    const dialogRef = this.dialog.open(SubmissionContactSearchMiniComponent, {
      width: '660px',
      data: {
        ContactDetails: this.contactSearchDetails,
        UserId: this.user.UserID,
        ControlName: controlName,
      },
      backdropClass: 'backdropBackground',
    });

    dialogRef.afterClosed().subscribe((contactDetails: SubmissionContactDetails) => {
      if (contactDetails) {
        this.setContactDetailsValue(contactDetails.ContactDetails[0], contactDetails.ControlName);
      }
    });
  }

  getContactsDetails(controlName: string = '', isSearch: boolean = false) {
    try {
      if (isSearch) {
        this.dialogLoading = this.dialog.open(InputFormPopupComponent, {
          data: {
            loader: true,
          },
        });
      }
      this.contactSearchService
        .contactDetails(this.contactSearchFilter)
        .pipe(
          finalize(() => {
            if (isSearch) {
              this.dialogLoading.close();
            }
          })
        )
        .subscribe(
          (data: ContactDetailsResponse) => {
            if (data !== null) {
              this.contactSearchDetails = data.ContactSearchInfoModels;
              if (isSearch) {
                this.openContactSearchMiniDialog(controlName);
              } else {
                this.updateCRMGUID(controlName);
              }
            } else {
              this.resetCRMGUID(controlName);
              this.contactSearchDetails = null;
            }
          },
          (err) => {
            console.error({ err });
            this.resetCRMGUID(controlName);
            this.contactSearchDetails = null;
          }
        );
    } catch (error) {
      console.error({ error });
    }
  }

  private updateCRMGUID(controlName: string) {
    if (controlName === 'BrokerEmail') {
      this.MetadataDetails.ContactCRMGUID = this.contactSearchDetails ? this.contactSearchDetails[0].ContactGUID : '';
    } else if (controlName === 'UWEmail') {
      this.MetadataDetails.UWCRMGUID = this.contactSearchDetails ? this.contactSearchDetails[0].ContactGUID : '';
      // this.contactSearchFilter.FullName = this.uwFullName; // this.getValueByName('LoginName');
      // this.contactSearchFilter.Email = this.uwEmail; // this.getValueByName('UWEmail');
      // if (
      //   this.contactSearchDetails[0].FullName.toLowerCase() ===
      //     this.contactSearchFilter.FullName.toLowerCase() &&
      //   this.contactSearchDetails[0].Email.toLowerCase() === this.contactSearchFilter.Email.toLowerCase()
      // ) {
      //   this.MetadataDetails.UWCRMGUID = this.contactSearchDetails
      //     ? this.contactSearchDetails[0].ContactGUID
      //     : '';
      // }
    } else if (controlName === 'UAEmail') {
      this.MetadataDetails.UACRMGUID = this.contactSearchDetails ? this.contactSearchDetails[0].ContactGUID : '';
    }
  }

  private resetCRMGUID(controlName: string = '') {
    if (['ContactFirst', 'ContactLast', 'BrokerEmail'].includes(controlName)) {
      this.MetadataDetails.ContactCRMGUID = '';
    } else if (['LoginName', 'UWEmail'].includes(controlName)) {
      this.MetadataDetails.UWCRMGUID = '';
    } else if (['UnderwriterAssistant', 'UAEmail'].includes(controlName)) {
      this.MetadataDetails.UACRMGUID = '';
    }
  }

  handleContactSearch(controlName) {
    this.setContactSearchFilters(controlName);
    if ((Helper.isStringNotNullAndEmpty(this.contactSearchFilter.FirstName) && Helper.isStringNotNullAndEmpty(this.contactSearchFilter.LastName)) || Helper.isStringNotNullAndEmpty(this.contactSearchFilter.FullName) || Helper.isStringNotNullAndEmpty(this.contactSearchFilter.Email)) {
      this.getContactsDetails(controlName, true);
    }
  }

  private setContactDetailsValue(contactDetails: ContactDetails, controlName: string = '') {
    if (['ContactFirst', 'ContactLast', 'BrokerEmail'].includes(controlName)) {
      this.MetadataDetails.ContactCRMGUID = contactDetails.ContactGUID;
      this.submissionFormGroup.patchValue(
        {
          ContactFirst: contactDetails.FirstName,
          ContactLast: contactDetails.LastName,
          BrokerEmail: contactDetails.Email,
        },
        { emitEvent: false }
      );
    } else if (['LoginName', 'UWEmail'].includes(controlName)) {
      this.MetadataDetails.UWCRMGUID = contactDetails.ContactGUID;
      this.setUnderwriterLogin(contactDetails.FullName, false, true);
      this.setValueByNameNoEvent('UWEmail', contactDetails.Email);
    } else if (['UnderwriterAssistant', 'UAEmail'].includes(controlName)) {
      this.MetadataDetails.UACRMGUID = contactDetails.ContactGUID;
      this.setUnderwriterAssistant(contactDetails.FullName, false);
      this.setValueByNameNoEvent('UAEmail', contactDetails.Email);
    }
  }

  setCRMGUID() {
    if (this.MetadataDetails) {
      this.contactSearchDetails = null;
      this.MetadataDetails.ContactCRMGUID = '';
      this.MetadataDetails.UACRMGUID = '';
      if (this.isRecordExists) {
        this.setContactSearchFilters('BrokerEmail');
        if (Helper.isStringNotNullAndEmpty(this.contactSearchFilter.FirstName) || Helper.isStringNotNullAndEmpty(this.contactSearchFilter.LastName) || Helper.isStringNotNullAndEmpty(this.contactSearchFilter.Email)) {
          this.contactSearchDetails = null;
          this.getContactsDetails('BrokerEmail', false);
        }
      }
    }
  }

  private setUWCRMGUID() {
    if (this.MetadataDetails) {
      this.contactSearchDetails = null;
      this.MetadataDetails.UWCRMGUID = '';
      this.setContactSearchFilters('UWEmail');
      if (Helper.isStringNotNullAndEmpty(this.contactSearchFilter.FullName) || Helper.isStringNotNullAndEmpty(this.contactSearchFilter.Email)) {
        this.contactSearchDetails = null;
        this.getContactsDetails('UWEmail', false);
      }
    }
  }

  private setUACRMGUID() {
    if (this.MetadataDetails) {
      this.contactSearchDetails = null;
      this.MetadataDetails.UACRMGUID = '';
      this.setContactSearchFilters('UAEmail');
      if (Helper.isStringNotNullAndEmpty(this.contactSearchFilter.FullName) || Helper.isStringNotNullAndEmpty(this.contactSearchFilter.Email)) {
        this.contactSearchDetails = null;
        this.getContactsDetails('UAEmail', false);
      }
    }
  }

  private setContactSearchFilters(controlName: string) {
    this.resetFilterControl();
    if (['ContactFirst', 'ContactLast', 'BrokerEmail'].includes(controlName)) {
      this.contactSearchFilter.FirstName = this.getValueByName('ContactFirst');
      this.contactSearchFilter.LastName = this.getValueByName('ContactLast');
      this.contactSearchFilter.Email = this.getValueByName('BrokerEmail');
      this.contactSearchFilter.SubmissionSearchType = 'PRODUCER';
    } else if (['LoginName', 'UWEmail'].includes(controlName)) {
      this.contactSearchFilter.FullName = this.uwFullName;
      this.contactSearchFilter.Email = this.getValueByName('UWEmail');
      this.contactSearchFilter.SubmissionSearchType = 'UW';
    } else if (['UnderwriterAssistant', 'UAEmail'].includes(controlName)) {
      this.contactSearchFilter.FullName = this.uaFullName;
      this.contactSearchFilter.Email = this.getValueByName('UAEmail');
      this.contactSearchFilter.SubmissionSearchType = 'UA';
    }
  }

  resetFilterControl() {
    this.contactSearchFilter = {
      ProducerRegion: [],
      ProducerBranch: [],
      ContactType: [],
      RelationshipType: [],
      ChubbMarketSegment: [],
      Status: [],
      ContactName: '',
      AccountName: '',
      AccountType: '',
      Email: '',
      FirstName: '',
      LastName: '',
      FullName: '',
      SubmissionSearchType: '',
      PageNumber: 1,
      PageSize: 0,
      SortBy: 'FullName',
      OrderBy: '',
      IndustrySpecialization: [],
      ProductSpecialization: [],
      Cornerstone: [],
    };
  }

  openOutlookEmail(emailTo) {
    if (Helper.isStringNotNullAndEmpty(emailTo)) {
      location.href = 'mailto:' + emailTo.trim();
    }
  }

  openDialog(ctrl, action: string = '') {
    if (ctrl) {
      if (ctrl.ControlName === 'ProducerCode') {
        this.showProducerSearch();
      } else if (ctrl.ControlName === 'DBNumber') {
        this.showDnBCompanyDetailsSearch(ctrl);
      } else if (ctrl === 'ProducerCode') {
        this.showPASValidationDialog();
      } else if (ctrl === 'Copy') {
        this.showConfirmationCopyDelete('Copy');
      } else if (ctrl === 'Delete') {
        this.showConfirmationCopyDelete('Delete');
      } else if (ctrl.ControlName === 'OutToMarketCarrier') {
        this.showOutToMarketCarrier();
      } else if (ctrl.ControlName === 'Unit') {
        this.handleTransferRecord();
      } else if (ctrl.ControlName === 'LayerDetails') {
        this.handleLayerDetails();
      } else if (ctrl.ControlName === 'FAC') {
        this.showFAC();
      } else if (ctrl.ControlName === 'BrokerEmail' || ctrl.ControlName === 'UWEmail' || ctrl.ControlName === 'UAEmail') {
        this.setContactSearchFilters(ctrl.ControlName);
        if (action === 'Search') {
          this.openContactSearchDialog(ctrl.ControlName);
        } else if (action === 'Email') {
          this.openOutlookEmail(this.getValueByName(ctrl.ControlName));
        } else if (action === 'Dynamics') {
          this.openAttendee(ctrl.ControlName);
        }
      } else if (ctrl.ControlName === 'ForecastType') {
        this.handleBuildOutSchedule();
      }
    }
  }

  saveComments(ctrl: DataElementsDetails) {
    if (ctrl.ControlName === 'Comments') {
      const payload = {
        RecordNumber: this.recordNumber,
        UserID: this.user.UserID,
        Comments: this.getValueByName('Comments'),
      };
      this.inputPageService.saveSubmissionComments(payload).subscribe(
        (data) => {
          if (data != null) {
            this.notifier.showSuccess('The comments has been updated sucessfully');
          } else {
            this.notifier.showError('Update Failed');
          }
        },
        (err) => {
          console.error(err.error);
        }
      );
    }
  }

  openAttendee(controlName) {
    let attendeeId = '';
    if (controlName === 'BrokerEmail') {
      attendeeId = this.MetadataDetails.ContactCRMGUID;
    } else if (controlName === 'UWEmail') {
      attendeeId = this.MetadataDetails.UWCRMGUID;
    } else if (controlName === 'UAEmail') {
      attendeeId = this.MetadataDetails.UACRMGUID;
    }
    if (Helper.isStringNotNullAndEmpty(attendeeId)) {
      this.modalService.openBrowserWindow(UrlHelper.dynamicsEditContactUrl(attendeeId));
    }
  }

  private onStatusChange(isOnload: boolean = false) {
    if (!isOnload) {
      this.loadConfidenceFactorByStatus();
      this.setStatusandPostMortem();
      this.targetEffectiveDtValidation();
      this.prsValidation();
      this.publicEntityValidation();
      this.validateMetricsStatus();
      this.validateOccurance();
      this.validateMedRisk();
      this.capitalRiskValidation();
      this.validationRiskNAIC();
      this.validateBrokerCode();
      this.pmlValidationByProduct();
      this.mfgMandatoryValidation();
      this.setMandatoryByStatusAH();
      this.validateBoundQuotedSubDateAH();
      this.setMandatoryByStatusAndType();
      if (this.isAviationExists) {
        this.setValidatorsByStatus();
      }
    }
    this.setMandatoryByStatus();
    this.setStatusTooltip();
    this.setValueByPolicyStatus();
    this.validationPostMortem();
    this.validateCompetition();
    this.setAuditableFrequencyMandatory();
  }

  private onTypeChange(isOnload: boolean = false) {
    if (!isOnload) {
      this.setStatusandPostMortem();
      this.setMandatoryByStatusAndType();
      this.targetEffectiveDtValidation();
      this.validateOccurance();
      this.validateMedRisk();
      this.capitalRiskValidation();
      this.disp();
      this.getSubmissionHelper('InsuredName');
      this.loadStatusByTypeForROTR();
    }
    this.hideCalculate('Type');
    // this.populateStatusByType();
  }

  loadConfidenceFactorByStatus() {
    if (this.confidanceFactorlookup) {
      const cntl = this.getElementsByName('ConfidenceFactor');
      if (cntl) {
        let filterlist;
        if ([Status.Target, Status.TargetClosed].includes(this.StatusValue)) {
          if (['Major Accounts Division', 'Commercial Insurance Division'].includes(this.getValueByName('Company'))) {
            filterlist = this.confidanceFactorlookup.filter((option) => {
              return option.value <= 3;
            });
          } else {
            this.resetConfidenceFactorValue();
            filterlist = this.confidanceFactorlookup.filter((option) => {
              return option.value > 0 && option.value <= 3;
            });
          }
        } else {
          if (['Major Accounts Division', 'Commercial Insurance Division'].includes(this.getValueByName('Company'))) {
            filterlist = this.confidanceFactorlookup;
          } else {
            this.resetConfidenceFactorValue();
            filterlist = this.confidanceFactorlookup.filter((option) => {
              return option.value > 0;
            });
          }
        }
        cntl[0].Options = filterlist;
      }
    }
  }

  private resetConfidenceFactorValue() {
    if (this.getNumValueByName('ConfidenceFactor') === 0) {
      this.setValueByName('ConfidenceFactor', '');
    }
  }

  setValueByPolicyStatus() {
    // OnClientSelectedIndexChanged_ctl_Policy_status
    if (!this.isValidConstruction()) {
      // this.setValueByName('ConfidenceFactor', '');
      if (this.isValidStatus(Status.Target) || this.isValidStatus(Status.TargetClosed)) {
        if (!Helper.isStringNotNullAndEmpty(this.getValueByName('Type'))) {
          this.setValueByName('Type', Type.New);
        }
        // this.setReadOnlyByName('BasePremium', true);
        this.setEnableOrDisable('BasePremium', false);
        this.hideExpiringNetForecast = false;
        if (this.isRecordExists) {
          this.setReadOnlyByName('AccountingYear', true);
        } else {
          this.setReadOnlyByName('AccountingYear', false);
        }
        // } else {
        // this.hideExpiringNetForecast = true;
        // this.hideCalculate('Type');
        // // this.setReadOnlyByName('BasePremium', false);
        // this.setEnableOrDisable('BasePremium', true);
        // this.setReadOnlyByName('AccountingYear', false);
      }
      // LoadConfidence
      this.setConfidenceByStatus();

      if (this.isValidCanada()) {
        if (this.isValidUnit('Penn Millers') && (this.isValidDivision('Package') || this.isValidDivision('Comp')) && this.isValidStatus(Status.Declined)) {
          this.setControlVisibility('PostMortemDeclinedLostReason', true);
        } else if (this.isValidUnit('Penn Millers') && (this.isValidDivision('Package') || this.isValidDivision('Comp')) && !this.isValidStatus(Status.Declined)) {
          this.setControlVisibility('PostMortemDeclinedLostReason', false);
        }
      } else if (this.isValidAandH()) {
        this.callPolicyExtended();
      } else if (this.isValidConstruction()) {
      } else {
        if (this.isValidStatus(Status.Quoted)) {
          this.setValueByName('DatePresented', Helper.setDateNow());
          this.setValueByName('QuotedDate', Helper.setDateNow());
        }
        if (this.isValidStatus(Status.QuotedLost) || this.isValidStatus(Status.Lost) || this.isValidStatus(Status.Declined)) {
          this.setValueByName('DateClosed', Helper.setDateNow());
        }
      }
      this.netforecastMandate();
    }
    this.mandateExpNetForecast();
  }

  private setConfidenceByStatus() {
    if ((this.isValidStatus(Status.Lost) || this.isValidStatus(Status.QuotedLost) || this.isValidStatus(Status.Declined)) && !this.isValidInputPageName(InputPageName.InputChubb)) {
      this.setValueByName('ConfidenceFactor', '1');
    } else if (this.isValidStatus(Status.Bound) && !this.isValidInputPageName(InputPageName.InputChubb)) {
      this.setValueByName('ConfidenceFactor', '10');
    } else if (this.isValidStatus(Status.Target) || this.isValidStatus(Status.TargetClosed)) {
      if (![0, 1, 2, 3].includes(this.getNumValueByName('ConfidenceFactor'))) {
        this.setValueByName('ConfidenceFactor', '');
      }
    }
  }

  netforecastMandate() {
    if (!this.isValidStatus(Status.Target) && !this.isValidStatus(Status.TargetClosed) && !IsCIGroup.some((division) => division === this.getValueByName('Division'))) {
      this.setMandatoryByName('NetForecast', true);
    } else {
      this.setMandatoryByName('NetForecast');
    }
  }

  mandateExpNetForecast() {
    if (!this.isValidStatus(Status.Target) && !this.isValidStatus(Status.TargetClosed) && this.isValidType(Type.Renewal) && !this.isValidInputPageName(InputPageName.InputChubb) && !IsCIGroup.some((division) => division === this.getValueByName('Division'))) {
      this.setMandatoryByName('ExpiringNetForecast', true);
    } else {
      this.setMandatoryByName('ExpiringNetForecast');
    }
  }

  setCommentsSaveIconVisibility() {
    const ctrl = this.getElementsByName('Comments');
    if (this.isRecordExists && ctrl && ctrl.length > 0) {
      if (this.submissionFormGroup.get('Comments').dirty && Helper.isStringNotNullAndEmpty(this.getValueByName('Comments')) && this.getValueByName('Comments') !== this.getOrginalValueByControlName('Comments')) {
        ctrl[0].IsHyperLink = true;
      } else {
        ctrl[0].IsHyperLink = false;
      }
    }
  }

  setForecastTooltip() {
    const ctrl = this.getElementsByName('Forecast');
    if (ctrl) {
      if (this.isValidUnit('High Net Worth')) {
        ctrl[0].HyperLinkTooltip = 'Submission is declined. Change Forecast to $0';
        ctrl[0].IsHyperLink = true;
        ctrl[0].HyperLinkIconType = 'tooltip';
      }
    }
  }

  setUWRegionTooltip() {
    const ctrl = this.getElementsByName('UWRegion');
    if (ctrl) {
      if (this.isValidSegment('Affluent')) {
        ctrl[0].HyperLinkTooltip = 'As a general rule: \n * Eastern Region = New York \n * Central Region = Chicago \n * Western Region = Los Angeles';
        ctrl[0].IsHyperLink = true;
        ctrl[0].HyperLinkIconType = 'tooltip';
      }
    }
  }

  setStatusTooltip() {
    const ctrl = this.getElementsByName('Status');
    if (ctrl) {
      const controlValue = this.StatusValue;
      if (this.isValidUnit('High Net Worth') && Helper.isStringNotNullAndEmpty(controlValue)) {
        ctrl[0].IsHyperLink = true;
        ctrl[0].HyperLinkIconType = 'tooltip';
        if (controlValue === Status.Target) {
          ctrl[0].HyperLinkTooltip = 'Use for prospect accounts for which no submission has been received';
        } else if (controlValue === Status.Pending) {
          ctrl[0].HyperLinkTooltip = 'Submission is awaiting the Table set';
        } else if (controlValue === Status.Declined) {
          ctrl[0].HyperLinkTooltip = 'Submission is declined. Change Forecast to $0';
        } else if (controlValue === Status.Working) {
          ctrl[0].HyperLinkTooltip = 'When an account is approved to quote and is with Underwriting or Agency Services';
        } else if (controlValue === Status.Lost) {
          ctrl[0].HyperLinkTooltip = 'Producer withdraws quote request before account is quoted. Change Forecast to $0';
        } else if (controlValue === Status.Quoted) {
          ctrl[0].HyperLinkTooltip = 'When UW delivers quotes to Producer. Update Forecast with actual quoted premium.';
        } else if (controlValue === Status.QuotedLost) {
          ctrl[0].HyperLinkTooltip = 'UW receives confirmation account is lost';
        } else if (controlValue === Status.Bound) {
          ctrl[0].HyperLinkTooltip = 'UW receives confirmation account is bound';
        } else {
          ctrl[0].HyperLinkTooltip = '';
          ctrl[0].IsHyperLink = null;
        }
      } else {
        ctrl[0].HyperLinkTooltip = '';
        ctrl[0].IsHyperLink = null;
      }
    }
  }

  prsValidation() {
    if (this.isValidInputPage()) {
      if (this.isValidStatus(Status.Quoted)) {
        this.setMandatoryByName('QuotedDate', true);
      } else {
        this.setMandatoryByName('QuotedDate');
      }

      if (this.isValidStatus(Status.Quoted) || this.isValidStatus(Status.QuotedLost) || this.isValidStatus(Status.Bound)) {
        this.setMandatoryByName('DatePresented', true);
      } else {
        this.setMandatoryByName('DatePresented');
      }

      if (this.isValidStatus(Status.Lost) || this.isValidStatus(Status.QuotedLost) || this.isValidStatus(Status.Declined)) {
        this.setMandatoryByName('DateClosed', true);
      } else {
        this.setMandatoryByName('DateClosed');
      }
    }
  }

  publicEntityValidation() {
    if (this.isValidInputPage() && this.isValidInputPageName(InputPageName.InputPublicEntity)) {
      if (this.isValidStatus(Status.Bound)) {
        this.setMandatoryByName('PolicySymbol', true);
      } else {
        this.setMandatoryByName('PolicySymbol');
      }

      if (this.isValidStatus(Status.Bound) && this.isValidPortFolioClass('Group Risks')) {
        this.setMandatoryByNumValue('AverageMemberOccurrenceLimit');
      }
    }
  }

  mfgMandatoryValidation() {
    if (this.isValidInputPageName(InputPageName.InputMFG)) {
      this.netforecastMandate();
      //   if (
      //     !this.isValidStatus(Status.Target) &&
      //     !this.isValidStatus(Status.TargetClosed) &&
      //     IsCIGroup.some(
      //       (division) => division === this.getValueByName('Division')
      //     )
      //   ) {
      //     this.setMandatoryByName('NetForecast', true);
      //   } else {
      //     this.setMandatoryByName('NetForecast');
      //   }
    }
  }

  mfgCustomValidation() {
    if (!this.isValidAandH() && !this.isValidConstruction()) {
      if (this.isValidInputPageName(InputPageName.InputMFG)) {
        // MGLRiskPremium && BoatClubPremium controls not applicable for Sub_group/Unit 'Canada Prof Risk'
        let totalValue = 0;
        totalValue =
          this.getNumWithabsValueByName('PackagePremium') +
          this.getNumWithabsValueByName('AutoPremium') +
          this.getNumWithabsValueByName('MarinePremium') +
          this.getNumWithabsValueByName('BuildersRiskPremium') +
          this.getNumWithabsValueByName('OtherPremium') +
          (this.isValidCanada() ? 0 : this.getNumWithabsValueByName('MGLRiskPremium')) +
          (this.isValidCanada() ? 0 : this.getNumWithabsValueByName('BoatClubPremium'));

        if ((this.isValidSegment('Commercial - MFG') || this.isValidCanada()) && this.getNumWithabsValueByName('Forecast') !== totalValue) {
          const message = 'Total of coverage premiums must equal Forecast.';
          this.setCustomErrors('Forecast', message);
        } else {
          this.setCustomErrors('Forecast', '');
        }
      }
    }
  }

  foreignPolValidation() {
    if (this.isValidInputPageName(InputPageName.InputProperty) && !this.isValidAandH() && !this.isValidConstruction()) {
      this.setCustomErrors('USBOrLADGWP', '');
      if (this.getValueByName('ChubbIssuedForeignPolicies') === '1' && Helper.isStringNotNullAndEmpty(this.getValueByName('USBOrLADGWP'))) {
        if (Helper.toNumber(this.getValueByName('USBOrLADGWP')) === 0) {
          const message = 'Foreign Admitted Premium should be greater than 0.';
          this.setCustomErrors('USBOrLADGWP', message);
        } else {
          this.setCustomErrors('USBOrLADGWP', '');
        }
      }

      if (this.getValueByName('ChubbIssuedForeignPolicies') === '1') {
        this.setEnableOrDisable('USBOrLADGWP', true);
      } else {
        this.setUISDIC();
        this.setValueByName('USBOrLADGWP', '');
        this.setEnableOrDisable('USBOrLADGWP', false);
      }
    }
  }

  setUISDIC() {
    if (this.isValidInputPageName(InputPageName.InputProperty)) {
      if (Helper.isNumberNotNullAndEmpty(this.getNumValueByName('Forecast'))) {
        const uisdicPremium = this.getNumValueByName('Forecast') - this.getNumWithabsValueByName('USBOrLADGWP');
        this.setValueByName('USDICPremium', uisdicPremium);
      }
    }
  }

  capitalRiskValidation() {
    if (!this.isValidAandH() && !this.isValidConstruction()) {
      if (this.isValidInputPageName(InputPageName.InputCapitalRisk)) {
        if (!this.isValidSegment('Traditional E&O') && this.isValidStatus(Status.Bound)) {
          if (this.isValidType(Type.Renewal)) {
            this.setMandatoryMSGByName('ExpiringPolicyNumber', 'Replacing Policy # is required for Bound Renewals.', true);
          } else {
            this.setOrgMandatoryMSGByName('ExpiringPolicyNumber');
          }

          if (this.isValidProduct('IMI') || this.isValidProduct('VCPE')) {
            this.setMandatoryByName('BlendedCoverage', true);
          } else {
            this.setMandatoryByName('BlendedCoverage');
          }

          this.addValidators(['RevenueAmount', 'AssetsInMillion', 'TradedStatus', 'Limit', 'Retention', 'MarketCapInMillion']);
          this.setNumCustomErrorsIfEmptyOrZero('RevenueAmount', 'Revenue should be greater than 0.');
          this.setNumCustomErrorsIfEmptyOrZero('AssetsInMillion', 'Assets should be greater than 0.');
          this.setNumCustomErrorsIfEmptyOrZero('TradedStatus', 'Please select Traded Status.');
          this.setNumCustomErrorsIfEmptyOrZero('Limit', 'Please select Limit should be greater than 0');
          this.setNumCustomErrorsIfEmptyOrZero('Retention', 'Please select Retention/Underlying should be greater than 0.');
          this.setNumCustomErrorsIfEmptyOrZero('MarketCapInMillion', 'Please select Market Cap should be greater than 0.');
        } else {
          this.removeValidators(['RevenueAmount', 'AssetsInMillion', 'TradedStatus', 'Limit', 'Retention', 'MarketCapInMillion']);
          this.setCustomErrors('RevenueAmount', '');
          this.setCustomErrors('AssetsInMillion', '');
          this.setCustomErrors('TradedStatus', '');
          this.setCustomErrors('Limit', '');
          this.setCustomErrors('Retention', '');
          this.setCustomErrors('MarketCapInMillion', '');
        }

        if (!this.isValidSegment('Traditional E&O')) {
          this.setMandatoryByName('InsuredStateProvince', true);
        } else {
          this.setMandatoryByName('InsuredStateProvince');
        }

        const layerStatus = this.getValueByName('LayerStatus');
        if (layerStatus === Status.Lost || layerStatus === Status.Declined || layerStatus === Status.QuotedLost || layerStatus === Status.Bound) {
          this.setMandatoryByName('SuccessfulCarrier', true);
        } else {
          this.setMandatoryByName('SuccessfulCarrier');
        }
      }
    }
  }

  aogDateValidation() {
    this.policyEffAndExpDateValidation();
  }

  private policyEffAndExpDateValidation(isLessThanOrEqual = false) {
    this.setCustomErrors('EffectiveDate', '');
    if (Helper.isStringNotNullAndEmpty(this.getValueByName('EffectiveDate')) && Helper.isStringNotNullAndEmpty(this.getValueByName('ExpirationDate'))) {
      this.setCustomErrors('EffectiveDate', '');
      if ((!isLessThanOrEqual && this.getDateValueByName('EffectiveDate') > this.getDateValueByName('ExpirationDate')) || (isLessThanOrEqual && this.getDateValueByName('EffectiveDate') >= this.getDateValueByName('ExpirationDate'))) {
        const messageLessThanOrEqual = 'Effective Date should be less than or equal to Expiration date.';
        const message = 'Effective Date should be less than Expiration date.';
        this.setCustomErrors('EffectiveDate', isLessThanOrEqual ? messageLessThanOrEqual : message);
      } else {
        this.setCustomErrors('EffectiveDate', '');
      }
    }
  }

  // cyenceRangeValidation(controlName) {
  //   if (
  //     this.getValueByName(controlName) >= 100 &&
  //     this.getValueByName(controlName) <= 999
  //   ) {
  //     return this.setReturnError('');
  //   } else {
  //     const message =
  //       'Please Enter a value between 100 and 999 for' + controlName + '.';
  //     return this.setReturnError(message);
  //   }
  // }

  // dealPercentValidation() {
  //   if (
  //     this.getValueByName('DealPercent') >= 1 &&
  //     this.getValueByName('DealPercent') <= 100
  //   ) {
  //     return this.setReturnError('');
  //   } else {
  //     const message = 'Maximum permissible value is 100.';
  //     return this.setReturnError(message);
  //   }
  // }

  targetEffectiveDtValidation() {
    if (this.getStatusValue() === Status.Target && (this.getValueByName('Type') === Type.New || this.getValueByName('Type') === Type.Renewal)) {
      if (Helper.isStringNotNullAndEmpty(this.getValueByName('EffectiveDate'))) {
        const dt2 = new Date();
        const dt1 = new Date(this.getValueByName('EffectiveDate'));
        const dateDiff = Math.floor((Date.UTC(dt1.getFullYear(), dt1.getMonth(), dt1.getDate()) - Date.UTC(dt2.getFullYear(), dt2.getMonth(), dt2.getDate())) / (1000 * 60 * 60 * 24));
        if (dateDiff < -90) {
          this.setValueByName('Status', Status.TargetClosed);
        }
      }
    }
  }

  mpCodeValidation() {
    const marketingProgramCode = this.getValueByName('MarketingProgramCode');
    if (Helper.isStringNotNullAndEmpty(marketingProgramCode)) {
      const numbers = /^[0-9]+$/;
      const message = 'Marketing program code';
      if ((marketingProgramCode.length === 3 && marketingProgramCode.match(numbers)) || marketingProgramCode === 'N/A') {
        this.setCustomErrors('marketingProgramCode', '');
      } else {
        this.setCustomErrors('marketingProgramCode', message + ' is not in a valid format. Valid format examples (048 or 007 or N/A)');
      }
    }
  }

  mnCodeValidation() {
    const mnCode = this.getValueByName('MNCode');
    if (mnCode) {
      const letterMN = /^MN[0]?[0-9]+$/;
      const letterFN = /^FN[0]?[0-9]+$/;
      if ((mnCode.length === 7 && mnCode.match(letterMN)) || (mnCode.length === 7 && mnCode.match(letterFN)) || mnCode === 'N/A') {
        this.setCustomErrors('MNCode', '');
      } else {
        this.setCustomErrors('MNCode', Constants.MNCodeValidationMessage);
      }
    }
  }

  confidentialityAgreement() {
    if (Helper.isStringNotNullAndEmpty(this.getValueByName('ConfidentialityAgreement')) && this.getValueByName('ConfidentialityAgreement') === 'Yes') {
      const dialogRef = this.dialog.open(SubmissionMessageDialogComponent, {
        width: '550px',
        height: '310px',
        // hasBackdrop: true,
        backdropClass: 'backdropBackground',
      });

      dialogRef.afterClosed().subscribe(() => {
        console.log('The dialog was closed');
      });
    }
  }

  setNetForecast() {
    // NOT APPLICABLE FOR CANADA
    if (this.isValidUnit('Property') && (this.isValidSegment('Engineering') || this.isValidSegment('Property - National Accounts'))) {
      const netForecast = this.getNumValueByName('Forecast') - (this.getNumValueByName('GrossFACPremium') + this.getNumValueByName('FrontingFee'));
      if (netForecast !== null && netForecast > 0) {
        this.setValueByName('NetForecast', netForecast);
      }
    } else if (this.isValidUnit('AFS')) {
      if (Helper.isNumberNotNullAndEmpty(this.getNumValueByName('Forecast'))) {
        this.setValueByName('NetForecast', this.getNumValueByName('Forecast'));
      }
    }
  }

  frontFeeValid() {
    if (Helper.isNumberNotNullAndEmpty(this.getNumValueByName('FrontingFee'))) {
      if (this.getValueByName('FrontingFee').indexOf('.') === this.getValueByName('FrontingFee').length - 1) {
        const formattedValue = this.getValueByName('FrontingFee') + '00';
        this.setValueByName('FrontingFee', formattedValue);
      }
    }
  }

  policyTypeValidation(controlName) {
    if (!this.isValidCanada()) {
      this.setCustomErrors(controlName, '');
      const policyTypeName = controlName === Constants.PolicyNo ? 'PolicyType' : 'ExpiringPolicyType';
      const policyNo = this.getValueByName(controlName);
      if (policyNo === '') {
        this.setValueByNameNoEvent(policyTypeName, '');
      }
      const validLetters = /^[A-Za-z]+$/;
      const unitSelectedValue = this.getValueByName('Unit');
      const segmentSelectedValue = this.getValueByName('Segment');
      if ((!PolicyTypeValUnit.some((unit) => unit === unitSelectedValue) && !PolicyTypeValSegment.some((segment) => segment === segmentSelectedValue)) || this.isValidAandH() || this.isValidConstruction()) {
        if (Helper.isStringNotNullAndEmpty(policyNo)) {
          const pad = '0000000';
          const ans = policyNo.length <= 12 ? pad.substring(0, 12 - policyNo.length) + policyNo : '';
          const rep = ans !== '' && ans.length === 12 ? policyNo.replace(policyNo, ans) : '';

          if (policyNo.length === 9 && policyNo[0].match(validLetters) && isNaN(policyNo)) {
            this.setValueByNameNoEvent(policyTypeName, 'L-ACE');
          } else if (policyNo.length === 13 && policyNo[0].match(validLetters) && isNaN(policyNo) && policyNo.indexOf(' ') === 9) {
            this.setValueByNameNoEvent(policyTypeName, 'L-ACE');
          } else if (rep.length === 12 && !isNaN(rep)) {
            this.setValueByNameNoEvent(policyTypeName, 'L-Chubb');
            this.setValueByNameNoEvent(controlName, rep);
          } else {
            this.setValueByNameNoEvent(policyTypeName, '');
            const messagePrefix = controlName === Constants.PolicyNo ? 'Policy Number' : 'Expiring Policy Number';
            this.setCustomErrors(controlName, this.isValidStatus(Status.Bound) ? messagePrefix + ' is not in a valid format. Valid policy format examples (G28202751 001 or G28202751 or 000081596308)' : '');
          }
        }
      }
    }
  }

  policyNumberValidation(policyTypeName) {
    if (this.isValidCanada()) {
      this.policyNoPatternValidation();
    } else {
      const policyNumberName = policyTypeName === 'PolicyType' ? Constants.PolicyNo : 'ExpiringPolicyNumber';
      this.setCustomErrors(policyNumberName, '');
      const policyNumberValue = this.getValueByName(policyNumberName);
      const messageControlName = policyTypeName === 'PolicyType' ? 'Policy Number' : 'Expiring Policy Number';
      const validLetters = /^[A-Za-z]+$/;

      if ((!PolicyTypeValUnit.filter((f) => f !== 'Canada Property').some((unit) => unit === this.getValueByName('Unit')) && !PolicyTypeValSegment.filter((f) => f !== 'Programs').some((segment) => segment === this.getValueByName('Segment'))) || (this.isValidAandH() && this.isValidStatus(Status.Bound)) || this.isValidConstruction()) {
        this.setMandatoryByName(policyNumberName, false);
        if (Helper.isStringNotNullAndEmpty(this.getValueByName(policyTypeName)) && Helper.isStringNotNullAndEmpty(this.getValueByName(policyNumberName))) {
          this.setMandatoryByName(policyNumberName, true);
          if (this.getValueByName(policyTypeName) === 'L-ACE') {
            if (policyNumberValue.length === 9) {
              if (!policyNumberValue[0].match(validLetters) || !isNaN(policyNumberValue)) {
                this.setCustomErrors(policyNumberName, messageControlName + ' is not in a valid format. Valid policy format examples (G28202751 001 or G28202751)');
              }
            } else if (policyNumberValue.length === 13 && !this.isValidAandH()) {
              if (!policyNumberValue[0].match(validLetters) || !isNaN(policyNumberValue) || !(policyNumberValue.indexOf(' ') === 9)) {
                this.setCustomErrors(policyNumberName, messageControlName + ' is not in a valid format. Valid policy format examples (G28202751 001 or G28202751)');
              }
            } else {
              this.setCustomErrors(policyNumberName, messageControlName + this.isValidAandH() ? ' is not in a valid format. Valid policy format example (G28202751' : ' is not in a valid format. Valid policy format examples (G28 202751001 or G28202751)');
            }
          } else if (this.getValueByName(policyTypeName) === 'L-Chubb') {
            if (policyNumberValue.length === 12) {
              if (isNaN(policyNumberValue)) {
                this.setCustomErrors(policyNumberName, messageControlName + ' is not in a valid format. Valid policy format example (000081596308)');
              }
            } else {
              this.setCustomErrors(policyNumberName, messageControlName + ' is not in a valid format. Valid policy format example (000081596308)');
            }
          }
        }
      }
    }
  }

  setType() {
    if (this.isValidAandH() && this.getValueByName('PolicyNo') === 'PROGRMBUS') {
      this.setValueByNameNoEvent(Constants.PolicyNo, Type.Other);
    }
  }

  private policyNoPatternValidation() {
    if (this.isValidStatus(Status.Bound) && this.isValidUnit('Penn Millers') && !Helper.isStringNotNullAndEmpty(this.getValueByName(Constants.PolicyNo))) {
      this.setCustomErrors(Constants.PolicyNo, 'This Policy is Bound. Please Enter a  Policy Number.');
    } else {
      this.setCustomErrors(Constants.PolicyNo, '');
    }

    // const pattern = '[A-z]{3}[0-9]{7}';
    // const policyNo = this.getValueByName(Constants.PolicyNo);
    // if (this.getValueByName(Constants.PolicyNo).length !== 10 ||
    //   policyNo.exec(pattern) === null) {
    //   this.setCustomErrors(
    //     Constants.PolicyNo,
    //     'This Policy is Bound. Please Enter a  Policy Number in correct format (3 Alphabets and 7 Numbers with out space).'
    //   );
    // } else {
    //   this.setCustomErrors(Constants.PolicyNo, '');
    // }
  }

  maHideVisibleOnLoad() {
    if (this.isRecordExists) {
      if (this.getValueByName('MergersAndAcquisitionsYN') === 'Yes') {
        this.setControlVisibility('FirmType', true);
        if (this.getValueByName('FirmType') === 'Private Equity') {
          this.setControlVisibility('PrivateEquityFirm', true);
          this.setControlVisibility('RetroDatePE', true);
        } else {
          this.setControlVisibility('PrivateEquityFirm');
          this.setControlVisibility('RetroDatePE');
        }
      }
    } else {
      this.setValueByName('MergersAndAcquisitionsYN', 'No');
      this.setControlVisibility('FirmType');
      this.setControlVisibility('PrivateEquityFirm');
      this.setControlVisibility('RetroDatePE');
    }
  }

  maHideVisible() {
    if (this.getValueByName('MergersAndAcquisitionsYN') === 'Yes') {
      this.setControlVisibility('FirmType', true);
      this.setValueByName('FirmType', 'Non-Private Equity');
    } else {
      this.setControlVisibility('FirmType');
      this.setValueByName('FirmType', '');
    }
  }

  maRetroDateHideVisible() {
    if (this.getValueByName('FirmType') === 'Private Equity') {
      this.setControlVisibility('PrivateEquityFirm', true);
      if (this.isValidUnit('Environmental')) {
        this.setControlVisibility('RetroDatePE');
        this.setValueByName('RetroDatePE', '');
        this.removeValidators(['RetroDatePE']);
      } else {
        this.setControlVisibility('RetroDatePE', true);
        this.addValidators(['RetroDatePE']);
      }
    } else {
      this.setControlVisibility('RetroDatePE');
      this.setControlVisibility('PrivateEquityFirm');
      this.setValueByName('RetroDatePE', '');
      this.setValueByName('PrivateEquityFirm', '');
      this.removeValidators(['RetroDatePE', 'PrivateEquityFirm']);
    }
  }

  hideCalculate(controlName) {
    this.hideNetForecast = false;
    this.hideExpiringNetForecast = false;
    if (this.isValidUnit('Property') && (this.isValidSegment('Engineering') || this.isValidSegment('Property - National Accounts'))) {
      this.hideNetForecast = false;
      this.hideExpiringNetForecast = false;
    } else if (this.isValidUnit('AFS')) {
      this.hideNetForecast = false;
      this.hideExpiringNetForecast = false;
    } else {
      this.hideNetForecast = true;
      if (this.isValidType(Type.New) || this.isValidType(Type.Other)) {
        this.hideExpiringNetForecast = false;
      } else {
        this.hideExpiringNetForecast = true;
      }
    }

    if (controlName === 'Type' && (this.isValidType(Type.New) || this.isValidType(Type.Other))) {
      this.hideNetForecast = true;
      this.hideExpiringNetForecast = false;
      this.setReadOnlyByName('BasePremium', true);
      this.setEnableOrDisable('BasePremium', false);
    } else {
      this.hideNetForecast = true;
      this.hideExpiringNetForecast = true;
      this.setReadOnlyByName('BasePremium');
      this.setEnableOrDisable('BasePremium', true);
    }
  }

  policyTermTypeVisible() {
    if (this.isValidUnit('Aerospace')) {
      const cntrlPolicyTermType = this.getElementsByName('PolicyTermType');
      const cntrlMultiCodes = this.getElementsByName('MultiCodes');
      if (cntrlPolicyTermType && cntrlMultiCodes) {
        if (this.getValueByName('PolicyTerm') === '2 Year' || this.getValueByName('PolicyTerm') === '3 Year') {
          cntrlPolicyTermType[0].IsVisible = true;
          cntrlMultiCodes[0].IsVisible = true;
          this.setValueByName('MultiCodes', '1');
          this.setEnableOrDisable('PolicyTermType', true);
          this.setEnableOrDisable('MultiCodes', true);
          this.setMandatoryByName('PolicyTermType', true);
          this.setMandatoryByName('MultiCodes', true);
        } else {
          cntrlPolicyTermType[0].IsVisible = false;
          cntrlMultiCodes[0].IsVisible = false;
          this.setValueByName('PolicyTermType', '');
          this.setValueByName('MultiCodes', '');
          this.setEnableOrDisable('PolicyTermType');
          this.setEnableOrDisable('MultiCodes');
          this.setMandatoryByName('PolicyTermType', false);
          this.setMandatoryByName('MultiCodes', false);
        }
      }
    }
  }

  outToMarketIndicator() {
    if (this.isValidInputPageName(InputPageName.InputMedRisk) && this.isValidSegment('Medical Liability') && Helper.isStringNotNullAndEmpty(this.getValueByName('OutToMarketIndicator'))) {
      if (this.isValidType(Type.New)) {
        this.setValueByName('OutToMarketIndicator', 'N/A');
      } else {
        this.setValueByName('OutToMarketIndicator', '');
      }
    }
  }

  sumGrossFACPremium() {
    if (this.isValidUnit('Property') && this.isValidSegment('Property - National Accounts')) {
      const grossFACPremium: number = this.getNumValueByName('SurplusShare') + this.getNumValueByName('AffiliatedFacility') + this.getNumValueByName('NonAffiliatedFacility') + this.getNumValueByName('BandMFacility');
      this.setValueByName('GrossFACPremium', grossFACPremium);
    }
  }

  setUserIdAndCurrentDate(controlName) {
    const userIdDateControls: any = UserIdDateControls.filter((cnt) => cnt.CheckControl === controlName);
    if (userIdDateControls && userIdDateControls.length > 0) {
      const isChecked: boolean = this.getValueByName(controlName);
      this.setValueByName(userIdDateControls[0].LoginIdControl, isChecked ? this.user.UserID : '');
      this.setValueByName(userIdDateControls[0].DateControl, isChecked ? Helper.setDateNow() : '');
      this.getDiffDays();
    }
  }

  getDiffDays() {
    if (GetDiffDaysInputPageName.some((pageName) => pageName === this.getInputPageName()) && this.isValidSegment('E&O')) {
      let policyIssuedDate: any = this.getValueByName('PolicyIssuedDate');
      if (Helper.isStringNotNullAndEmpty(this.getValueByName('EffectiveDate')) && Helper.isStringNotNullAndEmpty(policyIssuedDate)) {
        const oneday = 1000 * 60 * 60 * 24;
        policyIssuedDate = new Date(policyIssuedDate);
        const effectiveDate: any = new Date(this.getValueByName('EffectiveDate'));
        let diff: any = policyIssuedDate.getTime() - effectiveDate.getTime();
        diff = Math.round(diff / oneday);
        this.setValueByName('IssDtEffDtDifference', diff);
      } else {
        this.setValueByName('IssDtEffDtDifference', '');
      }
    }
  }

  cuwValidation() {
    if (!IsCIGroup.some((division) => division === this.getValueByName('Division'))) {
      this.setMandatoryByName('NetForecast', true);
    }
    const controlList = ['ConfidenceFactor', 'UWRegion', 'UWBranch', 'Forecast', 'Status', 'Type', 'CreditedRegion', 'CreditedBranch', 'EffectiveDate', 'ExpirationDate'];
    this.addValidators(controlList);
    this.policyEffAndExpDateValidation(true);
  }

  pmlValidationByPrivacy() {
    if (this.isValidInputPage() && this.isValidInputPageName(InputPageName.Inputpml)) {
      if (
        Helper.isStringNotNullAndEmpty(this.getValueByName('Privacy')) &&
        this.getValueByName('Privacy') === '1'
        // Boolean(this.getValueByName('Privacy')) === true
      ) {
        this.setMandatoryByName('DBFLimit', true);
        this.setNumCustomErrorsIfEmptyOrZero('DBFLimit', 'Please enter Default DBF Limit.');
        this.setMandatoryByName('DBTOption', true);
        if (this.getValueByName('DBTOption') === Constants.Y) {
          this.setMandatoryByName('DBTLimit', true);
          this.setNumCustomErrorsIfEmptyOrZero('DBTLimit', 'Please enter DBT Limit.');
          this.setMandatoryByName('SidecarOption', true);
        } else {
          this.setMandatoryByName('DBTLimit');
          this.setNumCustomErrorsIfEmptyOrZero('DBTLimit', '');
          this.setMandatoryByName('SidecarOption');
        }
      } else {
        this.setMandatoryByName('DBFLimit');
        this.setNumCustomErrorsIfEmptyOrZero('DBFLimit', '');
        this.setMandatoryByName('DBTOption');
        this.setMandatoryByName('DBTLimit');
        this.setNumCustomErrorsIfEmptyOrZero('DBTLimit', '');
        this.setMandatoryByName('SidecarOption');
      }
    }
  }

  pmlValidationByProduct() {
    if (this.isValidInputPage() && this.isValidInputPageName(InputPageName.Inputpml)) {
      if (this.isValidProduct('REA')) {
        this.setPMLMandatory('Classes', true);
      } else {
        this.setPMLMandatory('Classes');
      }

      if (this.isValidProduct('Architects and Engineers') || this.isValidProduct('MPL')) {
        if (this.isValidStatus('Bound') || this.isValidStatus('Declined') || this.isValidStatus('Lost') || this.isValidStatus('Quoted') || this.isValidStatus('Quoted-Lost')) {
          this.setMandatoryByName('Service1', true);
          if (this.isValidProduct('Architects and Engineers')) {
            this.setMandatoryByName('ProjectType1', true);
          } else {
            this.setMandatoryByName('ProjectType1');
          }
        } else {
          this.setMandatoryByName('Service1');
        }
      }
    }
  }

  private setPMLMandatory(keyName, isMandatory = false) {
    PMLControls.filter((cnt) => cnt.KeyName === keyName)[0].ControlName.forEach((element) => {
      this.setMandatoryByName(element, isMandatory);
    });
  }

  capitalRiskDisplay() {
    this.setControlVisibility('BlendedCoverage', true);
    this.setControlVisibility('InvestmentBankRevenue', true);
    this.setControlVisibility('USEmployeeCount', true);
    this.setControlVisibility('ERISAExposure', true);
    this.setControlVisibility('FundedStatus', true);
    this.setControlVisibility('PlanType', true);
    this.setControlVisibility('PlanAssets', true);
    this.setControlVisibility('FormNumber', true);
    this.setControlVisibility('AnnualAggregate', true);
    this.setControlVisibility('DropDown', true);
    this.setControlVisibility('MarketCapInMillion', true);
    this.setControlVisibility('EmployeeCount', true);
    this.setControlVisibility('ClassCode', true);
    this.setControlVisibility('BasePremium', true);
    this.setControlVisibility('Ticker', true);
    this.setControlVisibility('IncomeTrust', true);
    this.setControlVisibility('UnderlyingCarrier', true);
  }

  changeCaption() {
    if (this.isValidInputPageName(InputPageName.InputCapitalRisk) && (this.isValidProduct('Crime') || this.isValidProduct('FI Bond'))) {
      this.setDataLabelByName('Limit', 'Fidelity Limit');
      this.setDataLabelByName('ExpiringLimit', 'Exp. Fidelity Limit');
      this.setDataLabelByName('Retention', 'Deductible/Attachment');
      this.setDataLabelByName('ExpiringRetention', 'Exp. Deductible/Attachment');
    } else {
      this.setDataLabelByName('Limit', 'Limit');
      this.setDataLabelByName('ExpiringLimit', 'Exp. Limit');
      this.setDataLabelByName('Retention', 'Retention/Underlying');
      this.setDataLabelByName('ExpiringRetention', 'Exp. Retention/Underlying');
    }
  }

  disp() {
    if (this.isValidInputPageName(InputPageName.InputCapitalRisk)) {
      this.setControlVisibility('ClassCode');
      if (this.isValidSubSegment('Private/NFP')) {
        this.setControlVisibility('Ticker');
        this.setControlVisibility('IncomeTrust');
        this.setControlVisibility('MarketCapInMillion');
      } else {
        this.setControlVisibility('Ticker', true);
        this.setControlVisibility('IncomeTrust', true);
        this.setControlVisibility('MarketCapInMillion', true);
      }

      if (this.isValidSubSegment('Financial Institutions') && (this.isValidProduct('D&O') || this.isValidProduct('D&O A-Side') || this.isValidProduct('PCP - D&O') || this.isValidProduct('NFP - D&O'))) {
        this.setControlVisibility('InvestmentBankRevenue', true);
      } else {
        this.setControlVisibility('InvestmentBankRevenue');
      }

      if (this.isValidProduct('Crime') || this.isValidProduct('EPL') || this.isValidProduct('NFP - Crime') || this.isValidProduct('NFP - EP') || this.isValidProduct('PCP - EP')) {
        this.setControlVisibility('EmployeeCount', true);
      } else {
        this.setControlVisibility('EmployeeCount');
      }

      if (this.isValidProduct('EPL') || this.isValidProduct('NFP - EP') || this.isValidProduct('PCP - EP')) {
        this.setControlVisibility('USEmployeeCount', true);
      } else {
        this.setControlVisibility('USEmployeeCount');
      }

      if (this.isValidProduct('Fiduciary') || this.isValidProduct('PCP - Fiduciary') || this.isValidProduct('NFP - Fiduciary')) {
        this.setControlVisibility('PlanType', true);
        this.setControlVisibility('PlanAssets', true);
        this.setControlVisibility('FundedStatus', true);
        this.setControlVisibility('ERISAExposure', true);
      } else {
        this.setControlVisibility('PlanType');
        this.setControlVisibility('PlanAssets');
        this.setControlVisibility('FundedStatus');
        this.setControlVisibility('ERISAExposure');
      }

      if (this.isValidProduct('FI Bond')) {
        this.setControlVisibility('AnnualAggregate', true);
        this.setControlVisibility('DropDown', true);
        this.setControlVisibility('FormNumber', true);
      } else {
        this.setControlVisibility('AnnualAggregate');
        this.setControlVisibility('DropDown');
        this.setControlVisibility('FormNumber');
      }

      if (this.isValidProduct('IMI') || this.isValidProduct('VCPE') || this.isValidProduct('NFP - EP') || this.isValidProduct('PCP - EP') || this.isValidProduct('NFP - D&O') || this.isValidProduct('PCP - D&O') || this.isValidProduct('NFP - Fiduciary') || this.isValidProduct('PCP - Fiduciary')) {
        this.setControlVisibility('BlendedCoverage', true);
      } else {
        this.setControlVisibility('BlendedCoverage');
      }

      if (this.isValidType(Type.New)) {
        this.setControlVisibility('AdjustedExpiring');
        this.setControlVisibility('ExpiringAnnualizedPremium');
        this.setControlVisibility('ExpiringLimit');
        this.setControlVisibility('ExpiringRetention');
        this.setControlVisibility('BasePremium');
      } else {
        this.setControlVisibility('AdjustedExpiring', true);
        this.setControlVisibility('ExpiringAnnualizedPremium', true);
        this.setControlVisibility('ExpiringLimit', true);
        this.setControlVisibility('ExpiringRetention', true);
        this.setControlVisibility('BasePremium', true);
      }

      if (this.getValueByName('PrimaryExcess') === 1) {
        this.setControlVisibility('UnderlyingLimit');
        this.setControlVisibility('UnderlyingRetention');
        this.setControlVisibility('UnderlyingPremium');
        this.setControlVisibility('UnderlyingCarrier');
      } else {
        this.setControlVisibility('UnderlyingLimit', true);
        this.setControlVisibility('UnderlyingRetention', true);
        this.setControlVisibility('UnderlyingPremium', true);
        this.setControlVisibility('UnderlyingCarrier', true);
      }
      this.changeCaption();
    }

    // if (this.isValidInputPageName(InputPageName.InputMedRisk)) {
    //   this.outToMarketIndicator();
    // }
    this.mandateExpNetForecast();
  }

  showPCP() {
    if ((!this.isValidSegment('Professional Liability') && !this.isValidSegment('Major - Professional Liability') && !this.isValidSegment('Commercial - Professional Liability')) || this.isValidCanada()) {
      if (this.isValidSegment('Major - Private Company/NFP') || this.isValidSegment('Commercial - Private Company/NFP') || this.isValidSegment('Agribusiness Financial Lines') || this.isValidCanada()) {
        this.setControlVisibility('DNOSideALimit', true);
        this.setControlVisibility('EPCSideALimit', true);
      } else {
        this.setControlVisibility('DNOSideALimit');
        this.setControlVisibility('EPCSideALimit');
      }
    }
  }

  showFISections() {
    if (this.isValidSegment('FI') || this.isValidSegment('Management Liability') || this.isValidSegment('Major - Management Liability') || this.isValidSegment('Commercial - Management Liability') || this.isValidSegment('Major - Financial Institutions') || (this.isValidSegment('FI') && this.isValidCanada())) {
      this.setControlVisibility('NewExcessAttachment', true);
      this.setControlVisibility('ExpiringExcessAttachment', true);
      this.setControlVisibility('Blendedproduct');
      this.setControlVisibility('Blended');
      if (this.isValidSegment('FI')) {
        this.setControlVisibility('CompanyType', true);
      } else {
        this.setControlVisibility('CompanyType');
      }
      this.setDataLabelByName('Retention', 'New Primary Retention');
      this.setDataLabelByName('ExpiringRetention', 'Expiring Primary Retention');
    } else if ((!this.isValidSegment('Professional Liability') && !this.isValidSegment('Major - Professional Liability') && !this.isValidSegment('Commercial - Professional Liability')) || this.isValidCanada()) {
      this.setControlVisibility('NewExcessAttachment');
      this.setControlVisibility('ExpiringExcessAttachment');
      this.setControlVisibility('Blendedproduct');
      this.setControlVisibility('Blended');
      this.setControlVisibility('CompanyType');
      this.setDataLabelByName('Retention', 'New Retention or Attachment');
      this.setDataLabelByName('ExpiringRetention', 'Exp-Retention or Attachment');
    }
  }

  showSections() {
    if (this.isValidProduct('MPL - Employed Lawyer') || this.isValidProduct('MPL')) {
      PMLControls.filter((ele) => ele.KeyName !== 'Others' && ele.KeyName !== 'Others-Common' && ele.KeyName !== 'Company').forEach((cntl) => {
        if (cntl.KeyName === 'Services') {
          cntl.ControlName.forEach((element) => {
            this.setControlVisibility(element, true);
          });
        } else {
          cntl.ControlName.forEach((element) => {
            this.setControlVisibility(element);
          });
        }
      });
    } else if (this.isValidProduct('Architects and Engineers')) {
      PMLControls.filter((ele) => ele.KeyName !== 'Others' && ele.KeyName !== 'Others-Common' && ele.KeyName !== 'Company').forEach((cntl) => {
        if (cntl.KeyName === 'Classes') {
          cntl.ControlName.forEach((element) => {
            this.setControlVisibility(element);
          });
        } else {
          cntl.ControlName.forEach((element) => {
            this.setControlVisibility(element, true);
          });
        }
      });
    } else if (this.isValidProduct('REA')) {
      PMLControls.filter((ele) => ele.KeyName !== 'Others' && ele.KeyName !== 'Others-Common' && ele.KeyName !== 'Company').forEach((cntl) => {
        if (cntl.KeyName === 'Classes') {
          cntl.ControlName.forEach((element) => {
            this.setControlVisibility(element, true);
          });
        } else {
          cntl.ControlName.forEach((element) => {
            this.setControlVisibility(element);
          });
        }
      });
    } else {
      PMLControls.filter((ele) => ele.KeyName !== 'Others' && ele.KeyName !== 'Others-Common' && ele.KeyName !== 'Company').forEach((cntl) => {
        cntl.ControlName.forEach((element) => {
          this.setControlVisibility(element);
        });
      });
    }
  }

  resetSections() {
    PMLControls.filter((ele) => ele.KeyName !== 'Others' && ele.KeyName !== 'Others-Common').forEach((cntl) => {
      cntl.ControlName.forEach((element) => {
        this.setValueByName(element, '');
      });
    });
  }

  pmlDisplay() {
    if (this.isValidCanada()) {
      PMLControls.filter((ele) => {
        return ele.KeyName !== 'Others-Common';
      }).forEach((cntl) => {
        cntl.ControlName.forEach((element) => {
          this.setControlVisibility(element);
        });
      });
    } else {
      PMLControls.filter((ele) => {
        return ele.KeyName === 'Others-Common' || ele.KeyName === 'Services' || ele.KeyName === 'Company';
      }).forEach((cntl) => {
        cntl.ControlName.forEach((element) => {
          this.setControlVisibility(element);
        });
      });
      if (this.isValidSegment('Major - Private Company/NFP') && this.isValidSegment('Commercial - Private Company/NFP') && this.isValidSegment('Agribusiness Financial Lines')) {
        PMLControls.filter((ele) => {
          return ele.KeyName === 'Type' || ele.KeyName === 'Classes';
        }).forEach((cntl) => {
          cntl.ControlName.forEach((element) => {
            this.setControlVisibility(element);
          });
        });
      }
      if (this.isValidSegment('Professional Liability') && this.isValidSegment('Major - Professional Liability') && this.isValidSegment('Commercial - Professional Liability')) {
        PMLControls.filter((ele) => {
          return ele.KeyName === 'Others';
        }).forEach((cntl) => {
          cntl.ControlName.forEach((element) => {
            this.setControlVisibility(element);
          });
        });
      }
    }
  }

  displayDataLimit() {
    const dataBreachLimit = this.getValueByName('DataBreachFundInsideTheLimit');
    if (dataBreachLimit === 'Yes') {
      this.setControlVisibility('DataBreachFundLimit', true);
      this.setControlVisibility('LossOfTechSupporExclusion', true);
    } else {
      this.setControlVisibility('DataBreachFundLimit');
      this.setControlVisibility('LossOfTechSupporExclusion');
    }
  }

  displayCloud() {
    if (Helper.isStringNotNullAndEmpty(this.getValueByName('Privacy')) && this.getValueByName('Privacy') === '1') {
      // Yes
      PMLControls.filter((ele) => {
        return ele.KeyName === 'Others-Common';
      }).forEach((cntl) => {
        cntl.ControlName.forEach((element) => {
          this.setControlVisibility(element, true);
        });
      });
    } else {
      PMLControls.filter((ele) => {
        return ele.KeyName === 'Others-Common';
      }).forEach((cntl) => {
        cntl.ControlName.forEach((element) => {
          this.setControlVisibility(element);
        });
      });
    }

    if ((this.isValidCanada() || this.isValidProduct('Privacy Protection') || this.isValidProduct('Technology') || this.isValidProduct('Digitechpro') || this.isValidProduct('Technology - Digital DNA')) && Helper.isStringNotNullAndEmpty(this.getValueByName('Privacy')) && this.getValueByName('Privacy') === '1') {
      PMLCloudControls.forEach((element) => {
        this.setControlVisibility(element, true);
      });
    } else {
      PMLCloudControls.forEach((element) => {
        this.setControlVisibility(element);
      });
    }
  }

  viewCloud(privacy) {
    if (!this.isValidCanada()) {
      if (privacy === '1') {
        // Yes:1 => 1
        PMLControls.filter((ele) => {
          return ele.KeyName === 'Others-Common';
        }).forEach((cntl) => {
          cntl.ControlName.forEach((element) => {
            this.setControlVisibility(element, true);
          });
        });
      } else if (privacy === '2') {
        // No:0 => 2
        PMLControls.filter((ele) => {
          return ele.KeyName === 'Others-Common';
        }).forEach((cntl) => {
          cntl.ControlName.forEach((element) => {
            this.setControlVisibility(element, true);
          });
        });
      } else {
        PMLControls.filter((ele) => {
          return ele.KeyName === 'Others-Common';
        }).forEach((cntl) => {
          cntl.ControlName.forEach((element) => {
            this.setControlVisibility(element);
          });
        });
      }
    }

    if (privacy === '1') {
      // Yes:1 => 1
      PMLCloudControls.forEach((element) => {
        this.setControlVisibility(element, true);
      });
    } else {
      PMLCloudControls.forEach((element) => {
        this.setControlVisibility(element);
      });
    }
  }

  setSymbol() {
    if (this.isValidInputPageName(InputPageName.InputCapitalRisk)) {
      // Not a Valid Segment, hence commented below code
      // if (Helper.isStringNotNullAndEmpty(this.getValueByName('PolicyNo'))) {
      //   if (this.isValidSegment('E&O')) {
      //     this.setValueByName(Constants.PolicyNo, '');
      //     this.setReadOnlyByName(Constants.PolicyNo);
      //     return;
      //   } else {
      //     this.setReadOnlyByName(Constants.PolicyNo, true);
      //   }
      // }
      const polNoExists = Helper.isStringNotNullAndEmpty(this.getValueByName('PolicyNo')) ? this.getValueByName('PolicyNo').substr(0, 1) : '';
      if ((this.isValidProduct('D&O') || this.isValidProduct('D&O A-Side') || this.isValidProduct('PCP - D&O') || this.isValidProduct('NFP - D&O')) && ((this.isValidCanada() && polNoExists !== 'G') || !this.isValidCanada())) {
        if (this.isValidSubSegment('Commercial') || this.isValidSubSegment('US Public') || this.isValidSubSegment('Private/NFP')) {
          this.setValueByNameNoEvent(Constants.PolicyNo, 'DO');
        } else if (this.isValidSubSegment('Middle Market')) {
          this.setValueByNameNoEvent(Constants.PolicyNo, 'DOM');
        } else if (this.isValidSubSegment('Financial Institutions')) {
          this.setValueByNameNoEvent(Constants.PolicyNo, 'DOF');
        }
      } else if (this.isValidProduct('Fiduciary') || this.isValidProduct('PCP - Fiduciary') || this.isValidProduct('NFP - Fiduciary')) {
        this.setValueByNameNoEvent(Constants.PolicyNo, 'FID');
      } else if (this.isValidProduct('FI Bond')) {
        this.setValueByNameNoEvent(Constants.PolicyNo, 'FIB');
      } else if (this.isValidProduct('EPL')) {
        this.setValueByNameNoEvent(Constants.PolicyNo, 'EPL');
      } else if (this.isValidProduct('K&R')) {
        this.setValueByNameNoEvent(Constants.PolicyNo, 'KRE');
      } else if (this.isValidProduct('Crime')) {
        this.setValueByNameNoEvent(Constants.PolicyNo, 'CRM');
      } else if (this.isValidProduct('CODA')) {
        this.setValueByNameNoEvent(Constants.PolicyNo, 'CODA');
      } else if (this.isValidProduct('IMI')) {
        this.setValueByNameNoEvent(Constants.PolicyNo, 'IMI');
      } else if (this.isValidProduct('VCPE')) {
        this.setValueByNameNoEvent(Constants.PolicyNo, 'VCPE');
      }

      if (!Helper.isStringNotNullAndEmpty(this.getValueByName('Product')) || !Helper.isStringNotNullAndEmpty(this.getValueByName('SubSegment'))) {
        this.setValueByNameNoEvent(Constants.PolicyNo, '');
      }

      if (Helper.isStringNotNullAndEmpty(this.getValueByName('PolicyNo'))) {
        const policyNumberLength = this.getValueByName('PolicyNo').length;
        const policyNumber = this.getValueByName('PolicyNo').substr(policyNumberLength - 6, policyNumberLength);

        if (policyNumber.length > 5) {
          this.setValueByNameNoEvent(Constants.PolicyNo, this.getValueByName('PolicyNo') + policyNumber);
        } else {
          this.setValueByNameNoEvent(Constants.PolicyNo, this.getValueByName('PolicyNo') + 'XXXXXX');
        }
      }
    }
  }

  setSymbolByPrimaryExcess() {
    if (this.isValidInputPageName(InputPageName.InputCapitalRisk)) {
      if (this.getValueByName('PrimaryExcess') === 0 && !this.isValidProduct('CODA') && Helper.isStringNotNullAndEmpty(this.getValueByName('PolicyNo'))) {
        this.setValueByNameNoEvent(Constants.PolicyNo, this.getValueByName('PolicyNo') + 'X');
      }

      if (this.getValueByName('PrimaryExcess') === 1) {
        this.setDataLabelByName('Retention', 'Retention');
        this.setDataLabelByName('ExpiringRetention', 'Exp. Retention');
      } else {
        this.setDataLabelByName('Retention', 'Underlying');
        this.setDataLabelByName('ExpiringRetention', 'Exp. Underlying');
      }
    }
  }

  getAnnualPremium() {
    if (this.isValidInputPageName(InputPageName.InputCapitalRisk)) {
      if (Helper.isStringNotNullAndEmpty(this.getDateValueByName('EffectiveDate')) && Helper.isStringNotNullAndEmpty(this.getDateValueByName('ExpirationDate')) && Helper.isStringNotNullAndEmpty(this.getNumValueByName('Forecast'))) {
        const dateDifference: number = Helper.toNumber(Helper.dateDifference('d', this.getDateValueByName('EffectiveDate'), this.getDateValueByName('ExpirationDate')));
        if (dateDifference > 0) {
          const annPremimun = (this.getNumValueByName('Forecast') / dateDifference) * 365;
          this.setValueByName('AnnualizedPremium', annPremimun);
        } else {
          this.setValueByName('AnnualizedPremium', 0);
        }
      } else {
        this.setValueByName('AnnualizedPremium', 0);
      }
    }
  }

  validationRiskNAIC() {
    if (this.isValidInputPage()) {
      if ((this.isValidInputPageName(InputPageName.InputProperty) || this.isValidInputPageName(InputPageName.InputSpecialtyProducts)) && this.isValidSegment('Property - National Accounts')) {
        if (!this.isValidStatus(Status.Target) && !this.isValidStatus(Status.TargetClosed)) {
          this.setMandatoryByName('RiskNAIC', true);
        } else {
          this.setMandatoryByName('RiskNAIC');
        }
      }
    }
  }

  validateSixdigit() {
    if (((this.isValidInputPageName(InputPageName.InputProperty) || this.isValidInputPageName(InputPageName.InputSpecialtyProducts)) && this.isValidSegment('Property - National Accounts')) || this.isValidCanada()) {
      if (!Helper.isStringNotNullAndEmpty(this.getValueByName('RiskNAIC')) && this.getValueByName('RiskNAIC').length !== 6) {
        this.setCustomErrors('RiskNAIC', 'Risk NAIC should be six digits.');
      } else {
        this.setCustomErrors('RiskNAIC', '');
      }
    }
  }

  validateSixdigitNAICCode() {
    if (this.isValidInputPage()) {
      if (this.isValidInputPageName(InputPageName.InputProperty) || this.isValidInputPageName(InputPageName.InputSpecialtyProducts) || this.isValidInputPageName(InputPageName.InputGlobalSolution) || this.isValidInputPageName(InputPageName.InputWeather)) {
        if (this.isValidUnit('Property') && (this.isValidSegment('Property - National Accounts') || this.isValidSegment('Terror') || this.isValidSegment('Specialty Cat') || this.isValidSegment('Property Cashflow') || this.isValidSegment('Engineering'))) {
          if (this.getValueByName('NAICSCode').length !== 6) {
            this.setCustomErrors('NAICSCode', 'D&B NAICS Code should be six digits.');
          } else {
            this.setCustomErrors('NAICSCode', '');
          }
        }
      }
    }
  }

  validateMandatoryNAICCode() {
    if (this.isValidInputPageName(InputPageName.InputProperty) || this.isValidInputPageName(InputPageName.InputSpecialtyProducts) || this.isValidInputPageName(InputPageName.InputGlobalSolution) || this.isValidInputPageName(InputPageName.InputWeather)) {
      if (this.isValidUnit('Property') && (this.isValidSegment('Property - National Accounts') || this.isValidSegment('Terror') || this.isValidSegment('Specialty Cat') || this.isValidSegment('Property Cashflow') || this.isValidSegment('Engineering'))) {
        this.setMandatoryByName('NAICSCode', true);
      } else {
        this.setMandatoryByName('NAICSCode');
      }
    }
  }

  validateBrokerCode() {
    this.setCustomErrors('ProducerCode', '');
    const messageSufix = this.isValidAandH() || this.isValidConstruction() ? 'Producer Code' : 'Broker Code';
    if ((this.isValidStatus(Status.Bound) && !this.isValidCanada()) || this.isValidCanada()) {
      if (Helper.isStringNotNullAndEmpty(this.getValueByName('ProducerCode')) && this.getValueByName('ProducerCode').length !== 6) {
        this.setCustomErrors('ProducerCode', `Please enter a valid ${messageSufix}.`);
      } else {
        if (!this.isValidCanada() && (!Helper.isStringNotNullAndEmpty(this.getValueByName('ProducerCode')) || this.getValueByName('ProducerCode') === 'YYYYYY' || this.getValueByName('ProducerCode') === '000000')) {
          this.setCustomErrors('ProducerCode', `Please enter a ${messageSufix} when status is Bound.`);
        }
      }
    }

    if (this.isValidAandH() && this.isValidStatus(Status.Bound)) {
      if (this.getValueByName('') === 'Non-Licensed Producer') {
        this.setCustomErrors('Brokerage', 'Brokerage may not be Non-Licensed Producer when status is Bound');
      } else {
        this.setCustomErrors('Brokerage', '');
      }
    }
  }

  validateMetricsStatus() {
    if (!this.isValidAandH() && !this.isValidConstruction()) {
      if (['Canada A&H', 'Canada ARM', 'Canada Casualty', 'Canada Prof Risk', 'Canada Prog & Package', 'Canada Property & Marine'].includes(this.getValueByName('Unit'))) {
        if (this.isValidStatus(Status.Quoted) || this.isValidStatus(Status.QuotedLost)) {
          if (Helper.isStringNotNullAndEmpty(this.getValueByName('CanadaPCQuotedCheck')) && Boolean(this.getValueByName('CanadaPCQuotedCheck')) === true && Helper.isStringNotNullAndEmpty(this.getValueByName('CanadaPCQuotedDate'))) {
            this.setCustomErrors('CanadaPCQuotedDate', '');
          } else {
            this.setCustomErrors('CanadaPCQuotedDate', 'Please enter Quoted Date when status is Quoted or Quoted-Lost');
          }
        } else if (this.isValidStatus(Status.Bound)) {
          if (Helper.isStringNotNullAndEmpty(this.getValueByName('CanadaPCQuoteAcceptanceCheck')) && Boolean(this.getValueByName('CanadaPCQuoteAcceptanceCheck')) === true && Helper.isStringNotNullAndEmpty(this.getValueByName('CanadaPCQuoteAcceptanceDate'))) {
            this.setCustomErrors('CanadaPCQuoteAcceptanceDate', '');
          } else {
            this.setCustomErrors('CanadaPCQuoteAcceptanceDate', 'Please enter Quote Acceptance Date when status is Bound');
          }
        }
      }
    }
  }

  displayCtrlPortfolio() {
    if (this.isValidUnit('Medical-Risk') || this.isValidUnit('Life Sciences')) {
      // this.setValueByName('IncorporationType', '');
      if (Helper.isStringNotNullAndEmpty(this.getValueByName('PortFolioClass'))) {
        this.setControlVisibility('IncorporationType', true);
      } else {
        this.setControlVisibility('IncorporationType');
        this.setValueByName('IncorporationType', '');
      }
    }

    if (this.isValidUnit('Medical-Risk')) {
      // this.setValueByName('GLCyberTreatment', '');
      // this.setValueByName('PLCyberTreatment', '');
      if (DisplayCtrlPortfolio.some((porfolio) => porfolio === this.getValueByName('PortFolioClass'))) {
        this.setControlVisibilityByKey(this.getValueByName('PortFolioClass'));
      } else {
        this.setControlVisibilityByKey('All-Medical-Risk');
      }

      if (this.isValidPortFolioClass('LTC') && this.isValidSegment('Facilities')) {
        this.setControlVisibilityByKey(this.getValueByName('PortFolioClass') + '-' + this.getValueByName('Segment'));
      }
    } else if (this.isValidUnit('Life Sciences')) {
      this.setValueByName('TypeofProduct', '');
      if (this.isValidPortFolioClass('Sold Products') || this.isValidPortFolioClass('Clinical Trials')) {
        this.setControlVisibilityByKey(this.getValueByName('PortFolioClass'));
      } else {
        this.setControlVisibilityByKey('All-LifeSciences');
      }
    }
  }

  validateMedRisk() {
    if (this.isValidUnit('Medical-Risk') && this.isValidStatus(Status.Bound) && (this.isValidType(Type.New) || this.isValidType(Type.Renewal))) {
      switch (this.getValueByName('PortFolioClass')) {
        case 'Facilities Excess':
          this.setLCGLPLMandatory(true, true, true);
          break;
        case 'Facilities Primary':
          this.setLCGLPLMandatory(false, true, true);
          break;
        case 'LTC':
          this.setLCGLPLMandatory(false, true, true);
          if (this.isValidSegment('Facilities')) {
            if (!Helper.isStringNotNullAndEmpty(this.getValueByName('PLTrigger'))) {
              this.setMandatoryMSGByName('PLTrigger', 'Please select PL Trigger when portfolio class is ' + this.getValueByName('PortFolioClass'), true);
            } else {
              this.setOrgMandatoryMSGByName('PLTrigger');
            }
          }
          break;
        case 'Physicians':
          this.setLCGLPLMandatory(false, false, true);
          break;
        case 'MCO':
          this.setLCGLPLMandatory(false, false, true);
          if (!Helper.isStringNotNullAndEmpty(this.getValueByName('TypeofMCO'))) {
            this.setMandatoryMSGByName('TypeofMCO', 'Please select Type of MCO when portfolio class is' + this.getValueByName('PortFolioClass'), true);
          } else {
            this.setOrgMandatoryMSGByName('TypeofMCO');
          }
      }
    }

    if (this.isValidUnit('Life Sciences') && this.isValidStatus(Status.Bound) && (this.isValidType(Type.New) || this.isValidType(Type.Renewal))) {
      if (this.isValidPortFolioClass('Sold Products') || this.isValidPortFolioClass('Clinical Trials')) {
        if (!Helper.isStringNotNullAndEmpty(this.getValueByName('TypeofProduct'))) {
          this.setMandatoryMSGByName('TypeofProduct', 'Please select Type of Product when portfolio class is Sold Products', true);
        } else {
          this.setOrgMandatoryMSGByName('TypeofProduct');
        }

        if (this.isValidPortFolioClass('Clinical Trials')) {
          if (!Helper.isStringNotNullAndEmpty(this.getValueByName('NoofParticipant'))) {
            this.setMandatoryMSGByName('NoofParticipant', 'Please enter No. of Participants when portfolio class is Clinical Trials', true);
          } else {
            this.setOrgMandatoryMSGByName('NoofParticipant');
          }
          if (!Helper.isStringNotNullAndEmpty(this.getValueByName('TypeofTrial'))) {
            this.setMandatoryMSGByName('TypeofTrial', 'Please select Type of Trial when portfolio class is Clinical Trials', true);
          } else {
            this.setOrgMandatoryMSGByName('TypeofTrial');
          }
        }
      }
    }

    if ((this.isValidUnit('Life Sciences') || this.isValidUnit('Medical-Risk')) && this.isValidStatus(Status.Bound) && (this.isValidType(Type.New) || this.isValidType(Type.Renewal))) {
      if (Helper.isStringNotNullAndEmpty(this.getValueByName('Product'))) {
        if (this.isValidUnit('Medical-Risk')) {
          if (!Helper.isStringNotNullAndEmpty(this.getValueByName('GLShared'))) {
            this.setMandatoryMSGByName('GLShared', 'Please select GL Shared? when product is ' + this.getValueByName('Product'), true);
          } else {
            this.setOrgMandatoryMSGByName('GLShared');
          }
        }

        if (!Helper.isStringNotNullAndEmpty(this.getValueByName('TotalPolicyAggregate'))) {
          this.setMandatoryMSGByName('TotalPolicyAggregate', 'Please enter Total Policy Aggregate when product is ' + this.getValueByName('Product'), true);
        } else {
          this.setOrgMandatoryMSGByName('TotalPolicyAggregate');
        }

        if (Helper.isStringNotNullAndEmpty(this.getValueByName('PortFolioClass')) && !Helper.isStringNotNullAndEmpty(this.getValueByName('IncorporationType'))) {
          this.setMandatoryMSGByName('IncorporationType', 'Please enter Total Policy Aggregate when product is ' + this.getValueByName('PortFolioClass'), true);
        } else {
          this.setOrgMandatoryMSGByName('IncorporationType');
        }
      }
    }
  }

  private setLCGLPLMandatory(isLC: boolean, isGL: boolean, isPL: boolean) {
    if (isLC && !Helper.isStringNotNullAndEmpty(this.getValueByName('LeadCapacity'))) {
      this.setMandatoryMSGByName('LeadCapacity', 'Please select Lead/Capacity when portfolio class is ' + this.getValueByName('PortFolioClass'), true);
    } else {
      this.setOrgMandatoryMSGByName('LeadCapacity');
    }

    if (isGL && !Helper.isStringNotNullAndEmpty(this.getValueByName('GLCyberTreatment'))) {
      this.setMandatoryMSGByName('GLCyberTreatment', 'Please select GL Cyber Treatment when portfolio class is ' + this.getValueByName('PortFolioClass'), true);
    } else {
      this.setOrgMandatoryMSGByName('GLCyberTreatment');
    }

    if (isPL && !Helper.isStringNotNullAndEmpty(this.getValueByName('PLCyberTreatment'))) {
      this.setMandatoryMSGByName('PLCyberTreatment', 'Please select PL Cyber Treatment when portfolio class is ' + this.getValueByName('PortFolioClass'), true);
    } else {
      this.setOrgMandatoryMSGByName('PLCyberTreatment');
    }
  }

  displayCtrlProduct() {
    if (this.isValidUnit('Life Sciences') || this.isValidUnit('Medical-Risk')) {
      if (Helper.isStringNotNullAndEmpty(this.getValueByName('Product'))) {
        if (this.isValidUnit('Medical-Risk')) {
          this.setControlVisibility('GLShared', true);
          this.setControlVisibility('TotalPolicyAggregate', true);
        } else {
          this.setControlVisibility('GLShared');
          this.setControlVisibility('TotalPolicyAggregate', true);
        }
      } else {
        this.setControlVisibility('GLShared');
        this.setControlVisibility('TotalPolicyAggregate');
        this.setValueByName('GLShared', '');
        this.setValueByName('TotalPolicyAggregate', '');
      }
    }
  }

  validateOccurance() {
    if ((this.isValidUnit('Life Sciences') || this.isValidUnit('Medical-Risk')) && this.isValidStatus(Status.Bound) && (this.isValidType(Type.New) || this.isValidType(Type.Renewal))) {
      this.setMandatoryMSGByName('NewAggregateAttachment', 'Please enter New Aggregate Attachment when status is Bound', true);
      this.setMandatoryMSGByName('ExpiringAggregateAttachment', 'Please enter Exp Aggregate Attachment when status is Bound', true);
      this.setMandatoryMSGByName('NewPerOccurrenceAttachment', 'Please enter New Per Occurrence Attachment when status is Bound', true);
      this.setMandatoryMSGByName('ExpiringPerOccurrenceAttachment', 'Please enter Exp Per Occurrence Attachment when status is Bound', true);
    } else {
      this.setOrgMandatoryMSGByName('NewAggregateAttachment');
      this.setOrgMandatoryMSGByName('ExpiringAggregateAttachment');
      this.setOrgMandatoryMSGByName('NewPerOccurrenceAttachment');
      this.setOrgMandatoryMSGByName('ExpiringPerOccurrenceAttachment');
    }
  }

  setPolicyRISCNAICValues() {
    if (this.isValidSegment('Property - National Accounts')) {
      if (!Helper.isStringNotNullAndEmpty(this.getValueByName('RiskSICCode'))) {
        this.setValueByName('RiskSICCode', this.getValueByName('DBSIC'));
      }
      if (!Helper.isStringNotNullAndEmpty(this.getValueByName('RiskNAIC'))) {
        this.setValueByName('RiskNAIC', this.getValueByName('NAICSCode'));
      }
      // SetPortfolioClassBasedOnNAIC()
      // this.getSubmissionHelper('RiskNAIC');
    }
  }

  handleOk() {
    this.messageHandler = null;
  }

  amountSubjectVisibleOrHide(isOnLoad: boolean = false) {
    if (this.getValueByName('LowerDeductibleWording') === '1') {
      this.setControlVisibility('AmountSubject', true);
    } else {
      this.setControlVisibility('AmountSubject');
      this.setValueByName('AmountSubject', '');
    }

    if (isOnLoad && (this.isRecordExists || !this.isValidStatus(Status.Bound))) {
      this.setControlVisibility('AmountSubject');
      this.setValueByName('AmountSubject', '');
    }
  }

  aggDeductibleVisibleOrHide(isOnLoad: boolean = false) {
    if (this.getValueByName('AggregateDeductible') === '1') {
      this.setControlVisibility('AggregateDeductibleValue', true);
      this.setControlVisibility('MaintenanceDeductibleValue', true);
    } else {
      this.setControlVisibility('AggregateDeductibleValue');
      this.setControlVisibility('MaintenanceDeductibleValue');
      this.setValueByName('AggregateDeductibleValue', '');
      this.setValueByName('MaintenanceDeductibleValue', '');
    }

    if (isOnLoad && (this.isRecordExists || !this.isValidStatus(Status.Bound))) {
      this.setControlVisibility('AggregateDeductibleValue');
      this.setControlVisibility('MaintenanceDeductibleValue');
      this.setValueByName('AggregateDeductibleValue', '');
      this.setValueByName('MaintenanceDeductibleValue', '');
    }
  }

  getPortFolioClassByProducts() {
    if (!this.isValidAandH() && !this.isValidConstruction()) {
      if (this.isValidInputPageName(InputPageName.Inputpml)) {
        if (Helper.isStringNotNullAndEmpty(this.getValueByName('Product'))) {
          this.showSections();
          this.resetSections();
          // In Tracker 1 used ShowCloudDetails both displayCloud & ShowCloudDetails logic are same hence used displayCloud method.
          this.displayCloud();
        }
        if (Helper.isStringNotNullAndEmpty(this.getValueByName('Segment'))) {
          this.showFISections();
          this.showPCP();
          // setCustSegDefaults() : This logic should be moved to save submission parent sp
        }
      }

      if (this.isValidInputPageName(InputPageName.InputInMarine) || (this.isValidInputPageName(InputPageName.InputWholesaleProf) && this.isValidUnit('Inland Marine') && !this.isValidCanada())) {
        if (this.isValidProduct('BR Project Specific')) {
          this.setValueByName('NonRenewable', true);
        } else {
          this.setValueByName('NonRenewable', false);
        }
      }
    }
  }

  setSelfAuditValue() {
    if (Helper.isStringNotNullAndEmpty(this.getValueByName('SelfAuditCheck')) && Boolean(this.getValueByName('SelfAuditCheck')) === true) {
      this.setValueByName('SelfAudit', Helper.setDateNow());
    } else {
      this.setValueByName('SelfAudit', '');
    }
  }

  private resetMandatory() {
    ResetMandatoryControlList.forEach((element) => {
      this.setOrgMandatoryMSGByName(element);
    });
  }

  validationOnSave() {
    this.resetMandatory();
    // ToDo:Insured Details Mandatory check
    // MNCodeValidation() handled during mn code control value change
    // targetEffectiveDtValidation handled during status, type and effective date control value change
    // this.setMandatoryByStatus();
    // this.setMandatoryByInputPageName();
    // this.validateBrokerCode();
    // this.validateMetricsStatus();
    // this.validateMedRisk();
    // this.validateOccurance();
    // this.setDateValueValidation();
  }

  private setDateValueValidation() {
    let dateReceivedValue: Date = null;
    const cntrlSubmissionReceived = this.getElementsByName('SubmissionReceived');
    const cntrlCanadaProfSubmissionReceivedDate = this.getElementsByName('CanadaProfSubmissionReceivedDate');
    const cntrlCanadaPCSubmissionReceivedDate = this.getElementsByName('CanadaPCSubmissionReceivedDate');
    if (cntrlSubmissionReceived) {
      dateReceivedValue = this.getDateValueByName('SubmissionReceived');
    } else if (cntrlCanadaProfSubmissionReceivedDate) {
      dateReceivedValue = this.getDateValueByName('CanadaProfSubmissionReceivedDate');
    } else if (cntrlCanadaPCSubmissionReceivedDate) {
      dateReceivedValue = this.getDateValueByName('CanadaPCSubmissionReceivedDate');
    }
    const quoteByDateValue = this.getDateValueByName('QuoteByDate');
    const completeSubmissionReceivedValue = this.getDateValueByName('CompleteSubmissionReceived');
    let quoteDateValue: Date = null;
    const cntrlQuotedDate = this.getElementsByName('QuotedDate');
    const cntrlCanadaPCQuotedDate = this.getElementsByName('CanadaPCQuotedDate');
    const cntrlQuoteDate = this.getElementsByName('QuoteDate');
    if (cntrlQuotedDate) {
      quoteDateValue = this.getDateValueByName('QuotedDate');
    } else if (cntrlCanadaPCQuotedDate) {
      quoteDateValue = this.getDateValueByName('CanadaPCQuotedDate');
    } else if (cntrlQuoteDate) {
      quoteDateValue = this.getDateValueByName('QuoteDate');
    }
    let boundDateValue: Date = null;
    const cntrlBoundDate = this.getElementsByName('BoundDate');
    const cntrlBinderIssuedDate = this.getElementsByName('BinderIssuedDate');
    if (cntrlBoundDate) {
      boundDateValue = this.getDateValueByName('BoundDate');
    } else if (cntrlBinderIssuedDate) {
      boundDateValue = this.getDateValueByName('BinderIssuedDate');
    }
    let mailDateValue: Date = null;
    const cntrlMailedDate = this.getElementsByName('MailedDate');
    const cntrlPolicySentDate = this.getElementsByName('PolicySentDate');
    if (cntrlMailedDate) {
      mailDateValue = this.getDateValueByName('MailedDate');
    } else if (cntrlPolicySentDate) {
      mailDateValue = this.getDateValueByName('PolicySentDate');
    }
    let policyIssueDateValue: Date = null;
    const cntrlPolicyIssuedDate = this.getElementsByName('PolicyIssuedDate');
    if (cntrlPolicyIssuedDate) {
      policyIssueDateValue = this.getDateValueByName('PolicyIssuedDate');
    }

    if (this.compareDateValue(dateReceivedValue, quoteByDateValue, true)) {
      const message = 'Quote by Date cannot be less than Date Received/Submission Received.';
      this.setCustomErrors('QuoteByDate', message);
    } else {
      this.setCustomErrors('QuoteByDate', '');
    }

    if (this.compareDateValue(dateReceivedValue, completeSubmissionReceivedValue)) {
      const message = 'Complete Submission Received Date cannot be less than Date Received/Submission Received.';
      this.setCustomErrors('CompleteSubmissionReceived', message);
    } else {
      this.setCustomErrors('CompleteSubmissionReceived', '');
    }

    this.setCustomErrors('QuoteDate', '');
    if (this.compareDateValue(dateReceivedValue, quoteDateValue, true)) {
      const message = 'Quote Date cannot be less than Date Received/Submission Received.';
      this.setCustomErrors('QuoteDate', message);
    }
    if (this.compareDateValue(completeSubmissionReceivedValue, quoteDateValue, true)) {
      const message = 'Quote Date cannot be less than Complete Submission Received.';
      this.setCustomErrors('QuoteDate', message);
    }

    this.setCustomErrors('BoundDate', '');
    if (this.compareDateValue(dateReceivedValue, boundDateValue)) {
      const message = 'Bound Date cannot be less than Date Received/Submission Received.';
      this.setCustomErrors('BoundDate', message);
    }
    if (this.compareDateValue(completeSubmissionReceivedValue, boundDateValue)) {
      const message = 'Bound Date cannot be less than Complete Submission Received.';
      this.setCustomErrors('BoundDate', message);
    }
    if (this.compareDateValue(quoteDateValue, boundDateValue)) {
      const message = 'Bound Date cannot be less than Quote Date.';
      this.setCustomErrors('BoundDate', message);
    }

    this.setCustomErrors('MailedDate', '');
    if (this.compareDateValue(dateReceivedValue, mailDateValue, true)) {
      const message = 'Mail Date/Policy Sent cannot be less than Date Received/Submission Received.';
      this.setCustomErrors('MailedDate', message);
    }
    if (this.compareDateValue(completeSubmissionReceivedValue, mailDateValue, true)) {
      const message = 'Mail Date/Policy Sent cannot be less than Complete Submission Received.';
      this.setCustomErrors('MailedDate', message);
    }
    if (this.compareDateValue(quoteDateValue, mailDateValue, true)) {
      const message = 'Mail Date/Policy Sent cannot be less than Quote Date.';
      this.setCustomErrors('MailedDate', message);
    }
    if (this.compareDateValue(boundDateValue, mailDateValue, true)) {
      const message = 'Mail Date/Policy Sent cannot be less than Bound Date.';
      this.setCustomErrors('MailedDate', message);
    }

    this.setCustomErrors('PolicyIssuedDate', '');
    if (this.compareDateValue(dateReceivedValue, policyIssueDateValue)) {
      const message = 'Issued Date cannot be less than Date Received/Submission Received.';
      this.setCustomErrors('PolicyIssuedDate', message);
    }
    if (this.compareDateValue(completeSubmissionReceivedValue, policyIssueDateValue)) {
      const message = 'Issued Date cannot be less than Complete Submission Received.';
      this.setCustomErrors('PolicyIssuedDate', message);
    }
    if (this.compareDateValue(quoteDateValue, policyIssueDateValue)) {
      const message = 'Issued Date cannot be less than Quote Date.';
      this.setCustomErrors('PolicyIssuedDate', message);
    }
    if (this.compareDateValue(boundDateValue, policyIssueDateValue)) {
      const message = 'Issued Date cannot be less than Bound Date.';
      this.setCustomErrors('PolicyIssuedDate', message);
    }
  }

  private compareDateValue(dateValue1, dateValue2, isFullYear: Boolean = false): Boolean {
    if (Helper.isStringNotNullAndEmpty(dateValue1) && Helper.isStringNotNullAndEmpty(dateValue2)) {
      if (isFullYear && dateValue1 > dateValue2 && Helper.getFullYearByValue(dateValue2) >= 2000) {
        return true;
      } else if (!isFullYear && dateValue1 > dateValue2) {
        if (dateValue1 > dateValue2) {
          return true;
        }
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

  private setMandatoryByUnitSegment() {
    if ((this.isValidUnit('Advantage') || this.isValidUnit('DBA') || this.isValidUnit('CMP') || this.isValidUnit('Casualty Cashflow')) && (this.isValidSegment('Casualty Cashflow') || this.isValidSegment('CMP') || this.isValidSegment('Package') || this.isValidSegment('Mini-CMP') || this.isValidSegment('DBA'))) {
      this.setMandatoryByName('Auditable', true);
      this.setMandatoryByName('AuditableFrequency', true);
    }
  }

  private setMandatoryByInputPageName() {
    if (!this.isValidInputPageName(InputPageName.InputAOG) || this.isValidAandH()) {
      // customValidation()
      if (['Canada Property', 'A&H', 'Construction'].includes(this.getValueByName('Unit')) || this.isValidAandH()) {
        this.setMandatoryByName('EffectiveDate', true);
        this.setMandatoryByName('ExpirationDate', true);
        this.targetEffectiveDtValidation();
      }
    } else if (this.isValidInputPageName(InputPageName.InputAOG)) {
      this.aogDateValidation();
    }
    if (this.isValidInputPageName(InputPageName.InputCapitalRisk)) {
      this.capitalRiskValidation();
    }
    this.foreignPolValidation();
    // Moved this method to validation on load and change
    // if (this.isValidInputPageName(InputPageName.InputMFG)) {
    //   this.mfgValidation();
    // }
    if (this.isValidInputPageName(InputPageName.InputPublicEntity)) {
      this.publicEntityValidation();
    }
    // Moved below validation to on change of status, product and privacy
    // if (this.isValidInputPageName(InputPageName.Inputpml)) {
    //   this.pmlValidationByPrivacy();
    //   this.pmlValidationByProduct();
    // }
    // this.validationRiskNAIC();
    // this.validateSixdigitNAICCode();
    if (this.isValidInputPageName(InputPageName.InputPRS)) {
      this.prsValidation();
    }
    if (this.isValidInputPageName(InputPageName.InputMedRisk)) {
      if (this.isValidUnit('Medical-Risk') && this.isValidSegment('Wholesale-Facilities')) {
        this.setControlVisibilityByKey(this.getUnitValue() + '-' + this.getSegmentValue());
        if (this.isValidType(Type.Renewal)) {
          this.setMandatoryByName('ERC', true);
        }
        if (this.isValidStatus(Status.Bound)) {
          this.setMandatoryByName('NoOfLocationsPolicyAggregate', true);
        }
      } else {
        this.setControlVisibilityByKey('All-' + this.getUnitValue() + '-' + this.getSegmentValue());
      }
    }

    if (this.isValidInputPageName(InputPageName.InputChubb)) {
      // This can be moved to on load of control
      const inputChubbControlList = ['PortFolioClass', 'BrokerRegion', 'CreditedRegion', 'PrimaryIndustry', 'BrokerState', 'BrokerCity', 'PolicyNo', 'EffectiveDate', 'ExpirationDate', 'Product', 'Brokerage', 'Segment', 'SubSegment', 'UWRegion', 'QuoteByDate', 'CompleteSubmissionReceived', 'QuoteDate', 'BoundDate', 'MailedDate'];
      inputChubbControlList.forEach((element) => {
        this.setMandatoryByName(element, true);
      });
    }
  }

  private setMandatoryByStatus() {
    if (!this.isValidStatus(Status.Target) && !this.isValidStatus(Status.TargetClosed) && !this.isValidUnit('USUS')) {
      this.setControlMandatoryByKey('NTTC', true);
      if (!IsCIGroup.some((division) => division === this.getValueByName('Division')) && this.getNumValueByName('AccountingYear') >= 2008) {
        this.setMandatoryByName('SubSegment', true);
      } else {
        this.setMandatoryByName('SubSegment');
      }

      if (!this.isValidInputPageName(InputPageName.InputWholesaleEnv) && !this.isValidInputPageName(InputPageName.InputExcessCasualty)) {
        const cntrlPrimaryIndustry = this.getElementsByName('PrimaryIndustry');
        if (cntrlPrimaryIndustry && cntrlPrimaryIndustry[0].IsVisible === true) {
          this.setMandatoryByName('PrimaryIndustry', true);
        } else {
          this.setMandatoryByName('PrimaryIndustry');
        }
      }
    } else {
      this.setControlMandatoryByKey('NTTC');
      this.setMandatoryByName('SubSegment');
      this.setMandatoryByName('PrimaryIndustry');
    }

    if (this.isValidStatus(Status.Bound)) {
      if (this.isValidUnit('Canada Casualty') && this.isValidSegment('Major - Casualty')) {
        this.setMandatoryByName('GLAttachment', true);
        this.setMandatoryByName('AutoAttachment', true);
        this.setMandatoryByName('AutoAttachment', true);
      } else {
        this.setMandatoryByName('GLAttachment');
        this.setMandatoryByName('AutoAttachment');
        this.setMandatoryByName('ProductsAttachment');
      }

      if ((!this.isValidSegment('D&O') && !this.isValidInputPageName(InputPageName.InputChubb)) || this.isValidUnit('Penn Millers')) {
        this.setMandatoryMSGByName('PolicyNo', 'This Policy is Bound. Please Enter a Policy Number.', true);
      } else {
        this.setOrgMandatoryMSGByName('PolicyNo');
      }

      if (this.isValidUnit('Canada Casualty') && ['Automobile', 'Environmental', 'International Advantage', 'Casualty'].includes(this.getValueByName('Segment'))) {
        this.setMandatoryByName('Monoline', true);
      } else {
        this.setMandatoryByName('Monoline');
      }

      if ((this.isValidUnit('Canada Casualty') && this.isValidSegment('Automobile')) || (this.isValidUnit('Canada Property & Marine') && this.isValidSegment('Property'))) {
        this.setMandatoryByName('ClassCode', true);
      } else {
        this.setMandatoryByName('ClassCode');
      }

      this.setMandatoryByUnitSegment();
      this.setMandatoryForDataLimit();
      if (this.isValidUnit('Canada Casualty') && (this.isValidSegment('Casualty') || this.isValidSegment('Automobile') || this.isValidSegment('Environmental'))) {
        this.setMandatoryByName('Exposure', true);
        this.setMandatoryByName('CanadaExposureType', true);
      } else {
        this.setMandatoryByName('Exposure');
        this.setMandatoryByName('CanadaExposureType');
      }
      // if (!this.isValidUnit('Canada Property') &&
      //   !this.isValidUnit('Canada Prof Risk') && !this.isValidUnit('Canada Property & Marine') &&
      //   !this.isValidUnit('Canada Programs') && !this.isValidUnit('Canada Casualty') &&
      //   !this.isValidUnit('Canada ARM') && !this.isValidUnit('Canada A&H') &&
      //   !this.isValidSegment('Chubb Canada Package') && !this.isValidSegment('Chubb Canada GL') &&
      //   !this.isValidSegment('Chubb Canada Property') && !this.isValidSegment('Commercial - Environmental') &&
      //   !this.isValidSegment('Major - Environmental') && !this.isValidSegment('Canada Commercial Surety') &&
      //   !this.isValidSegment('Commercial Surety') && !this.isValidSegment('Canada Construction Surety') &&
      //   !this.isValidSegment('Programs')) {
      // }
      this.setMandatoryByName('LowerDeductibleWording', true);
      this.setMandatoryByName('AmountSubject', true);
      this.setMandatoryForAggDeductible();
      if (this.isValidUnit('Property') && this.isValidSegment('Engineering')) {
        this.setMandatoryByName('ContractNumber', true);
      }
      if (this.isValidDivision('Environmental - Commercial') || this.isValidDivision('Environmental - Major')) {
        this.setMandatoryByName('RiskSICCode', true);
      } else {
        this.setMandatoryByName('RiskSICCode');
      }
    } else {
      this.setMandatoryByName('LowerDeductibleWording');
      this.setMandatoryByName('AmountSubject');
    }

    if ([Status.Target, Status.TargetClosed].includes(this.getStatusValue())) {
      this.setMandatoryByName('InsuredName', true);
      this.setMandatoryByName('InsuredStateProvince', true);
      this.setMandatoryByName('InsuredAddress1', true);
      this.setMandatoryByName('InsuredCity', true);
      this.setMandatoryByName('ConfidenceFactor', true);
      this.setMandatoryByName('Type', true);
      if (!this.isValidAandH() && !this.isValidConstruction()) {
        this.setControlMandatoryByKey('TTC', true);
      }

      if (!this.isValidDivision('Surety - Major')) {
        this.setMandatoryByName('AccountingMonth', true);
      } else {
        this.setMandatoryByName('AccountingMonth');
      }
      if (this.isValidUnit('Wholesale-Environmental')) {
        this.setMandatoryByName('SubSegment', true);
      } else {
        this.setMandatoryByName('SubSegment');
      }
    } else {
      this.setMandatoryByName('InsuredName');
      this.setMandatoryByName('InsuredStateProvince');
      this.setMandatoryByName('InsuredAddress1');
      this.setMandatoryByName('InsuredCity');
      this.setMandatoryByName('ConfidenceFactor');
      this.setMandatoryByName('Type');
      this.setControlMandatoryByKey('TTC', false);
    }

    if (!this.isValidStatus(Status.Target) && !this.isValidStatus(Status.TargetClosed)) {
      this.setMandatoryByName('AccountingMonth', true);
      // this.setMandatoryByStatusAndType();
      if (this.isValidUnit('Property') && (this.isValidSegment('Property - National Accounts') || this.isValidSegment('Terror'))) {
        this.setMandatoryByName('PropertyProgramStructure', true);
        this.setMandatoryByName('DirectAssumed', true);
        this.setMandatoryByName('NAICSCode', true);
        if (this.isValidSegment('Property - National Accounts')) {
          this.setMandatoryByName('IncumbentProgramStructure', true);
        } else {
          this.setMandatoryByName('IncumbentProgramStructure', false);
        }
      } else {
        this.setMandatoryByName('PropertyProgramStructure');
        this.setMandatoryByName('DirectAssumed');
        this.setMandatoryByName('IncumbentProgramStructure');
        this.setMandatoryByName('NAICSCode');
      }
    } else {
      this.setMandatoryByName('AccountingMonth');
      this.setMandatoryByName('PropertyProgramStructure');
      this.setMandatoryByName('DirectAssumed');
      this.setMandatoryByName('IncumbentProgramStructure');
      this.setMandatoryByName('NAICSCode');
    }
  }

  private setMandatoryByStatusAndType() {
    if (!this.isValidStatus(Status.Target) && !this.isValidStatus(Status.TargetClosed) && !this.isValidAandH()) {
      this.setMandatoryByName('AccountingMonth', true);
      if (this.isValidType(Type.New) && (!((this.isValidUnit('Wholesale-Environmental') && !this.isValidSegment('Environmental')) || TTCNUnitSegment.some((us) => us === this.getValueByName('Unit') + '-' + this.getValueByName('Segment'))) || this.isValidCanada() || this.isValidConstruction())) {
        this.setMandatoryByName('SubmissionReceived', true);
      } else {
        this.setMandatoryByName('SubmissionReceived');
      }
    } else {
      this.setMandatoryByName('AccountingMonth');
      this.setMandatoryByName('SubmissionReceived');
    }
    if (this.getValueByName('Type') === Type.New) {
      this.setControlVisibility('TargetType', true);
    } else {
      this.setControlVisibility('TargetType', false);
    }
  }

  private setControlMandatoryByKey(keyName, isMandatory: boolean = false) {
    ControlDetails.filter((cnt) => cnt.KeyName === keyName)
      .filter((elementDetail) => {
        return elementDetail.ElementsDetails;
      })
      .forEach((cnt) => {
        cnt.ElementsDetails.forEach((ele) => {
          // console.log(ele.ControlName);
          ele.ControlName.forEach((element) => {
            this.setMandatoryByName(element, isMandatory);
          });
        });
      });
  }

  setMandatoryForDataLimit() {
    if (this.isValidStatus(Status.Bound) && this.isValidUnit('Professional and Management Liability') && this.isValidSegment('Professional Liability')) {
      const dataBreachLimit = this.getChildControlValue('DataBreachFundInsideTheLimit');
      if (dataBreachLimit === 'Yes') {
        this.setMandatoryByName('DataBreachFundLimit', true);
        this.setMandatoryByName('LossOfTechSupporExclusion', true);
      } else {
        this.setMandatoryByName('DataBreachFundLimit');
        this.setMandatoryByName('LossOfTechSupporExclusion');
      }
    }
  }

  setMandatoryForAggDeductible() {
    if (this.getChildControlValue('AggregateDeductible') === Constants.Yes) {
      this.setMandatoryByName('AggregateDeductibleValue', true);
      this.setMandatoryByName('MaintenanceDeductibleValue', true);
    } else {
      this.setMandatoryByName('AggregateDeductibleValue');
      this.setMandatoryByName('MaintenanceDeductibleValue');
    }
  }

  validateControlValueByName(controlName) {
    const controlList = ['Brokerage', 'BasePremium', 'Forecast', 'Limit', 'RiskSICCode'];
    if (controlList.some((cnt) => cnt === controlName)) {
      let message = '';
      this.setCustomErrors(controlName, message);
      switch (controlName) {
        case 'Brokerage':
          if (Helper.isStringNotNullAndEmpty(this.getValueByName('Brokerage'))) {
            if (this.getValueByName('Brokerage').length < 2) {
              message = 'Please enter at least 2 characters in the "Producer" field.';
              this.setCustomErrors(controlName, message);
            }
          }
          break;
        case 'BasePremium':
          if (Helper.isStringNotNullAndEmpty(this.getNumValueByName('BasePremium'))) {
            if (this.getNumValueByName('BasePremium') < 0) {
              message = 'Please enter at least 0 in the "Base or Expiring Premium" field.';
              this.setCustomErrors(controlName, message);
            }
          }
          break;
        case 'Forecast':
          if (Helper.isStringNotNullAndEmpty(this.getNumValueByName('Forecast'))) {
            if (this.getNumValueByName('Forecast') < 0) {
              message = 'Please enter at least 0 in the "Forecast" field.';
              this.setCustomErrors(controlName, message);
            }
          }
          break;
        case 'Limit':
          if (!this.isValidStatus(Status.Target) && !this.isValidStatus(Status.TargetClosed) && !this.isValidUnit('USUS')) {
            if (!this.isValidInputPageName(InputPageName.InputProperty) && !this.isValidInputPageName(InputPageName.InputSpecialtyProducts) && !this.isValidInputPageName(InputPageName.InputGlobalSolution) && !this.isValidInputPageName(InputPageName.InputWeather)) {
              if (this.isValidUnit('Property') && (this.isValidSegment('Property - National Accounts') || this.isValidSegment('Terror') || this.isValidSegment('Specialty Cat') || this.isValidSegment('Property Cashflow') || this.isValidSegment('Engineering')) && !Helper.isStringNotNullAndEmpty(this.getNumValueByName('Limit'))) {
                if (this.getNumValueByName('Limit') <= 0) {
                  message = 'New Limit field should be greater than Zero.';
                  this.setCustomErrors(controlName, message);
                }
              }
            }
          } else {
            this.setCustomErrors(controlName, '');
          }
          break;
        case 'RiskSICCode':
          if (this.isValidStatus(Status.Bound) && (this.isValidDivision('Environmental - Commercial') || this.isValidDivision('Environmental - Major'))) {
            if (Helper.isStringNotNullAndEmpty(this.getNumValueByName('RiskSICCode'))) {
              if (this.getValueByName('RiskSICCode') === '9999') {
                message = '9999 is not a valid Risk SIC Code';
              }
            } else {
              message = 'Please select RISK SIC Code';
            }
            this.setCustomErrors(controlName, message);
          }
          break;
        default:
          break;
      }
    }
  }

  setTRIAPremiumMandatoryByTRIA() {
    if (this.getValueByName('TRIAPurchased') === 'Yes') {
      this.setMandatoryByName('TRIAPremium', true);
    } else {
      this.setMandByName('TRIAPremium', false);
    }
  }

  private isValidPortFolioClass(portFolioClass) {
    if (this.getValueByName('PortFolioClass') === portFolioClass) {
      return true;
    } else {
      return false;
    }
  }

  private isValidType(type) {
    if (this.getValueByName('Type') === type) {
      return true;
    } else {
      return false;
    }
  }

  private isValidStatus(status) {
    if (this.getStatusValue() === status) {
      return true;
    } else {
      return false;
    }
  }

  handleNextTerm() {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '510px',
      data: {
        Action: 'NextTerm',
        label: 'Ok',
        Message: '',
      },
      hasBackdrop: true,
      backdropClass: 'backdropBackground',
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result && Helper.isStringNotNullAndEmpty(result.Action)) {
        const statusSelectedValue = this.StatusValue;
        if (Helper.isStringNotNullAndEmpty(statusSelectedValue)) {
          if (statusSelectedValue === Status.Pending) {
            this.setValueByNameNoEvent('Status', Status.Declined);
          } else if (statusSelectedValue === Status.Working) {
            this.setValueByNameNoEvent('Status', Status.Lost);
          } else if (statusSelectedValue === Status.Quoted) {
            this.setValueByNameNoEvent('Status', Status.QuotedLost);
          } else if (statusSelectedValue === Status.Target) {
            this.setValueByNameNoEvent('Status', Status.TargetClosed);
          }
          this.setStatusandPostMortem();
        }
      }
    });
  }

  private setStatusandPostMortem() {
    const statusValue = this.StatusValue;
    this.setPMControlVisibility(statusValue);
    if (Helper.isStringNotNullAndEmpty(statusValue) && [Status.Declined, Status.Lost, Status.QuotedLost, Status.TargetClosed].includes(statusValue)) {
      this.reportingService
        // .getLostReasonByStatus(statusValue)
        .getLostReasonByStatusUnitsSegments(statusValue, this.UnitValue, this.SegmentValue)
        .subscribe((data: any) => {
          if (data !== null) {
            this.lostReasonList = data.sort((a: any, b: any) => {
              return a.text - b.text;
            });
          } else {
            this.lostReasonList = [];
          }
          const cntl = this.getElementsByName('LostReason');
          if (cntl) {
            cntl[0].Options = this.lostReasonList;
          }
        });
    }
  }

  private setPMControlVisibility(statusValue: string) {
    if ((statusValue === Status.Lost || statusValue === Status.QuotedLost) && (this.getValueByName('Type') === Type.New || this.getValueByName('Type') === Type.Renewal)) {
      this.setControlVisibilityByKey('PM-LQL');
      this.fillPostmortemDefault();
      this.setPMSectionVisibility('PM-LQL', true);
    } else if (statusValue === Status.TargetClosed && (this.getValueByName('Type') === Type.New || this.getValueByName('Type') === Type.Renewal)) {
      this.setControlVisibilityByKey('PM-TC');
      this.setPMSectionVisibility('PM-TC', true);
    } else if (
      (statusValue === Status.Declined && PostMortemPageName.some((pagename) => pagename === this.MetadataDetails.InputPage)) ||
      (statusValue === Status.Declined && ((this.isValidUnit('Advantage') && this.isValidSegment('Mini-CMP')) || (this.isValidUnit('DBA') && this.isValidSegment('DBA')) || (this.isValidUnit('Advantage') && this.isValidSegment('Express')) || (this.isValidUnit('Canada ARM') && this.isValidSegment('Canada ARM'))))
    ) {
      this.setControlVisibilityByKey('PM-D');
      this.setPMSectionVisibility('PM-D', true);
    } else {
      this.setControlVisibilityByKey('PM-All');
      this.setPMSectionVisibility('PM-All', false);
    }
  }

  private setPMSectionVisibility(keyName: string, isVisible: boolean = false) {
    const postmortem: DataElementsControlDetailsItem[] = this.getPMSection();
    if (postmortem && postmortem.length > 0) {
      postmortem[0].isOpen = isVisible;
      postmortem[0].IsExpanded = isVisible;
    }
  }

  validationPostMortem() {
    // SUGANE: NEED TO CHECK BOTH INPUT PAGE AND CANADA WITH ANAND
    // if (this.isValidInputPageName(InputPageName.InputPRS) &&
    //   (
    //     this.isValidStatus(Status.Lost) ||
    //     this.isValidStatus(Status.QuotedLost) ||
    //     this.isValidStatus(Status.Declined)
    //   )) {
    //   this.setMandatoryByName('LostReason', true);
    // } else {
    //   this.setMandatoryByName('LostReason');
    // }

    if (this.isValidStatus(Status.Lost) || this.isValidStatus(Status.QuotedLost)) {
      this.setMandatoryByName('PostMortemSuccessfullCarrier', true);
      this.setMandatoryByName('AccountInMarket');
      this.setMandatoryByName('LostReason');
    } else if (this.isValidStatus(Status.TargetClosed)) {
      this.setMandatoryByName('AccountInMarket', true);
      this.setMandatoryByName('LostReason', true);
      this.setMandatoryByName('PostMortemSuccessfullCarrier');
    }
  }

  fillReasons() {
    if (this.getValueByName('AccountInMarket') === 'No') {
      // '7' : Loyalty to Incumbent;
      this.setValueByName('LostReason', ['Loyalty to Incumbent']);
    }
  }

  fillPostmortemDefault() {
    this.setValueByNameNoEvent('PostMortemSuccessfullCarrier', this.getValueByName('Incumbent'));
    this.setValueByNameNoEvent('PostMortemSuccessfullProducer', this.getValueByName('Brokerage'));
  }

  auditFreqOtherEnable() {
    if (this.getValueByName('Auditable') === 'Yes' && this.getValueByName('AuditableFrequency') === 'Other') {
      this.setControlVisibility('AuditableFrequencyDetail', true);
    } else {
      this.setControlVisibility('AuditableFrequencyDetail', false);
    }
  }

  datesValidationAH() {
    if (this.isValidAandH()) {
      const quoteDate = this.getDateValueByName('QuotedDate');
      const boundDate = this.getDateValueByName('BoundDate');
      const mailDate = this.getDateValueByName('MailedDate');
      let today = new Date();
      if (!this.isValidStatus(Status.Bound) && Helper.isStringNotNullAndEmpty(this.getValueByName('BoundDate'))) {
        this.setCustomErrors('BoundDate', 'Bound Date cannot be entered until status is Bound.');
      } else {
        this.setCustomErrors('BoundDate', '');
      }

      if (boundDate > today) {
        this.setCustomErrors('BoundDate', 'Bound Date should be less than or equal to Current date.');
      } else {
        this.setCustomErrors('BoundDate', '');
      }

      if (quoteDate > today) {
        this.setCustomErrors('QuotedDate', 'Quote Date should be less than or equal to Current date.');
      } else {
        this.setCustomErrors('QuotedDate', '');
      }

      if (boundDate > mailDate || mailDate > today) {
        this.setCustomErrors('MailedDate', 'Mail Date should be equal to or greater than Bound date, and equal or less than Current Date.');
      } else {
        this.setCustomErrors('MailedDate', '');
      }
    }
  }

  customValidationAH() {
    this.validateBoundQuotedSubDateAH();
    this.validatePolicyNoAH();
    this.setMandatoryByStatusAH();
  }

  private setMandatoryByStatusAH() {
    if (this.isValidAandH()) {
      const controlsList = ['TPA', 'NoOfLives', 'PolicyTerm', 'BillingMethod', 'BillingFrequency', 'PoliticalEvacuation', 'AHWarRisk', 'Auditable'];
      if (this.isValidStatus(Status.Bound)) {
        controlsList.forEach((ele) => {
          this.setMandatoryByName(ele, true);
        });
      } else {
        controlsList.forEach((ele) => {
          this.setMandatoryByName(ele, false);
        });
      }
    }
  }

  private setAuditableFrequencyMandatory() {
    if (this.getValueByName('Auditable') === 'Yes' && this.isValidStatus(Status.Bound)) {
      this.setMandatoryByName('AuditableFrequency', true);
    } else {
      this.setMandatoryByName('AuditableFrequency', false);
    }
  }

  private setAssistanceProviderMandatory() {
    if (Boolean(this.getValueByName('Services')) === true) {
      this.setMandatoryByName('AssistanceProvider', true);
    } else {
      this.setMandatoryByName('AssistanceProvider', false);
    }
  }

  private validatePolicyNoAH() {
    if (this.isValidAandH()) {
      this.setCustomErrors(Constants.PolicyNo, '');
      if ([Type.New, Type.Renewal].includes(this.getValueByName('Type')) && this.isValidStatus(Status.Bound)) {
        if (Helper.isStringNotNullAndEmpty(this.getValueByName(Constants.PolicyNo))) {
          if (this.getValueByName(Constants.PolicyNo).length !== 12 && this.getValueByName(Constants.PolicyNo).length !== 9) {
            this.setCustomErrors(Constants.PolicyNo, 'Please Enter valid 9 or 12 characters Policy Number.');
          } else if (this.getValueByName(Constants.PolicyNo).length === 9 && this.getValueByName(Constants.PolicyNo).charAt(0) !== 'N') {
            this.setCustomErrors(Constants.PolicyNo, 'Please Enter valid 9 characters Policy Number starting with character N.');
          } else if (this.getValueByName(Constants.PolicyNo).length === 12 && this.getValueByName(Constants.PolicyNo).substring(0, 4) !== '0000') {
            this.setCustomErrors(Constants.PolicyNo, 'Please Enter valid 12 digits Policy Number starting with 0000.');
          }
        }
      } else if (this.getValueByName('Type') === Type.Other && this.isValidStatus(Status.Bound)) {
        if (Helper.isStringNotNullAndEmpty(this.getValueByName(Constants.PolicyNo))) {
          if (this.getValueByName(Constants.PolicyNo) !== 'PROGRMBUS' && this.getValueByName(Constants.PolicyNo) !== 'BULK' && this.getValueByName(Constants.PolicyNo).length !== 9) {
            this.setCustomErrors(Constants.PolicyNo, 'Please Enter valid 9 characters Policy Number or ProgrmBus or Bulk.');
          }
        }
      }
    }
  }

  private validateBoundQuotedSubDateAH() {
    if (this.isValidAandH()) {
      if (![Status.Pending, Status.Working, Status.Target, Status.TargetClosed].includes(this.getStatusValue())) {
        this.setMandatoryByName('SubmissionReceived', true);
      } else {
        this.setMandatoryByName('SubmissionReceived', false);
      }

      if ([Status.Quoted, Status.QuotedLost, Status.Bound].includes(this.getStatusValue())) {
        if (Helper.isStringNotNullAndEmpty(this.getValueByName('QuotedDate'))) {
          if (this.getDateValueByName('QuotedDate') < this.getDateValueByName('SubmissionReceived')) {
            this.setCustomErrors('QuotedDate', 'Quoted Date cannot be less than Submission Recieved Date.');
          } else {
            this.setCustomErrors('QuotedDate', '');
          }
        } else {
          this.setMandatoryByName('QuotedDate', true);
        }
      } else {
        this.setMandatoryByName('QuotedDate', false);
      }

      if (this.getStatusValue() === Status.Bound) {
        const boundDate = this.getDateValueByName('BoundDate');
        const quotedDate = this.getDateValueByName('QuotedDate');
        const submissionReceivedDate = this.getDateValueByName('SubmissionReceived');
        if (Helper.isStringNotNullAndEmpty(this.getValueByName('BoundDate'))) {
          if (boundDate < quotedDate || boundDate < submissionReceivedDate) {
            this.setCustomErrors('BoundDate', 'Bound date should not be less than Quoted Date or Submission Recieved Date.');
          } else {
            this.setCustomErrors('BoundDate', '');
          }
        } else {
          this.setMandatoryByName('BoundDate', true);
        }
      } else {
        this.setMandatoryByName('BoundDate', false);
      }
    }
  }

  disp1() {
    if (this.getValueByName('ConfidenceFactor') === '1' && this.getStatusValue() === Status.Target && this.getValueByName('Company') === 'Major Accounts Division') {
      this.setValueByNameNoEvent('Status', Status.TargetClosed);
    }
  }

  constructionDisplay() {
    if (this.isValidSegment('Wrap Up') || this.isValidSegment('Maintenance Wrap Up')) {
      if (this.getValueByName('WrapupType') === 'Standard') {
        this.setReadOnlyByName('Forecast', true);
        this.setEnableOrDisable('Forecast', false);
      } else {
        this.setReadOnlyByName('Forecast', false);
        this.setEnableOrDisable('Forecast', true);
      }
    }
  }

  validateCompetition() {
    if ([Status.Quoted, Status.QuotedLost, Status.Bound].includes(this.getStatusValue()) && ['Standard', 'Rolling'].includes(this.getValueByName('WrapupType'))) {
      this.setMandatoryByName('PrimaryCompetition', true);
    } else {
      this.setMandatoryByName('PrimaryCompetition', false);
    }
  }

  productChangeAH() {
    if (this.isValidConstruction()) {
      if (this.isValidSegment('Wrap Up') && this.isValidProduct('GL')) {
        this.setEnableOrDisable('OpsExtention', true);
        if (this.getValueByName('OpsExtention') === '0') {
          this.setValueByName('OpsExtention', '');
        }
      } else {
        this.setValueByName('OpsExtention', 0);
        this.setEnableOrDisable('OpsExtention', false);
      }
      this.setEnableOrDisable('ProductLimit', false);
      this.setEnableOrDisable('ExpiringProductLimit', false);
      if (this.isValidProduct('AL')) {
        this.setValueByName('ExposureType', 'Fleet Size');
      } else if (this.isValidProduct('GL')) {
        this.setValueByName('ExposureType', 'Payroll');
        this.setEnableOrDisable('ProductLimit', true);
        this.setEnableOrDisable('ExpiringProductLimit', true);
      } else if (this.isValidProduct('WC')) {
        this.setValueByName('ExposureType', 'Payroll');
      } else if (this.isValidProduct('Clash')) {
        this.setValueByName('ExposureType', '');
      }
    }
  }

  // private aviationCustomValidation() {
  //   this.sharedServiceSub$ = this.sharedService
  //     .setSubmissionValueChanges()
  //     .subscribe((controlName) => {
  //       if (
  //         controlName === 'TotalProgramPremium' ||
  //         controlName === 'All-Aviation'
  //       ) {
  //         const totalProgramPremium = this.aviationPolicyDetails.getTotalProgramPremium();
  //         this.setValueByName('TotalProgramPremium', totalProgramPremium);
  //         this.setReadOnlyByName('TotalProgramPremium', true);
  //       }
  //       if (controlName === 'Forecast' || controlName === 'All-Aviation') {
  //         const totalForecast = this.aviationPolicyDetails.getGrossForecast();
  //         this.setValueByName('Forecast', totalForecast);
  //         this.setReadOnlyByName('Forecast', true);
  //       }
  //       if (controlName === 'NetForecast' || controlName === 'All-Aviation') {
  //         const netForecast = this.aviationPolicyDetails.getNetForecast();
  //         this.setValueByName('NetForecast', netForecast);
  //         this.setReadOnlyByName('NetForecast', true);
  //       }
  //       if (controlName === 'Aviation') {
  //         this.aviationPolicyDetails.setValidatorsByStatus(this.StatusValue);
  //       }
  //     });
  // }

  public get companyValue() {
    return this.getValueByName('Company');
  }

  public get UnitValue() {
    return this.getValueByName('Unit');
  }

  public get SegmentValue() {
    return this.getValueByName('Segment');
  }

  public get DivisionValue() {
    return this.getValueByName('Division');
  }

  public get StatusValue() {
    return this.getValueByName('Status');
  }

  public get TypeValue() {
    return this.getValueByName('Type');
  }

  getUnitValue(): string {
    return this.getValueByName('Unit');
  }

  getSegmentValue(): string {
    return this.getValueByName('Segment');
  }

  getStatusValue() {
    return this.getValueByName('Status');
  }

  private isValidInputPage(): boolean {
    if (!this.isValidCanada() && !this.isValidAandH() && !this.isValidConstruction()) {
      return true;
    } else {
      return false;
    }
  }

  private isValidConstruction(): boolean {
    if (this.isValidUnit('Construction') && ['Wrap Up', 'Maintenance Wrap Up', 'Contractors'].includes(this.getSegmentValue())) {
      return true;
    } else {
      return false;
    }
  }

  private isValidAandH(): boolean {
    if (['A&H', 'Affinity Markets', 'Program Business', 'Retail Business'].includes(this.getUnitValue())) {
      return true;
    } else {
      return false;
    }
  }

  private isValidCanada(): boolean {
    if (this.isValidUnit('Canada Prof Risk') && !this.isValidSegment('Commercial - Professional Liability') && !this.isValidSegment('Major - Professional Liability')) {
      return true;
    } else {
      return false;
    }
  }

  private isValidUnit(unit) {
    if (this.getValueByName('Unit') === unit) {
      return true;
    } else {
      return false;
    }
  }

  private isValidProduct(product) {
    if (this.getValueByName('Product') === product) {
      return true;
    } else {
      return false;
    }
  }

  private isValidDivision(division) {
    if (this.getValueByName('Division') === division) {
      return true;
    } else {
      return false;
    }
  }

  private isValidSegment(segment) {
    if (this.getValueByName('Segment') === segment) {
      return true;
    } else {
      return false;
    }
  }

  private isValidSubSegment(subSegment) {
    if (this.getValueByName('SubSegment') === subSegment) {
      return true;
    } else {
      return false;
    }
  }

  private setDataLabelByName(controlName: string, dataLabel: string) {
    const cntrl = this.getElementsByName(controlName);
    if (cntrl) {
      cntrl[0].DataLabel = dataLabel;
    }
  }

  private setReadOnlyByName(controlName: string, isReadonly: boolean = false) {
    const cntrl = this.getElementsByName(controlName);
    if (cntrl) {
      cntrl[0].IsReadonly = isReadonly;
      // this.setEnableOrDisable(controlName, !isEditable);
    }
  }

  private setMandatoryMSGByName(controlName: string, message: string, isMandatory: boolean = false) {
    const cntrl = this.getElementsByName(controlName);
    if (cntrl) {
      this.setMandatoryByName(controlName, isMandatory);
      cntrl[0].ValidationMessage = message;
    }
  }

  private setControlVisibility(controlName: string, isVisible: boolean = false) {
    const cntrl = this.getElementsByName(controlName);
    if (cntrl && cntrl.length > 0) {
      cntrl[0].IsVisible = isVisible;
      this.setEnableOrDisable(controlName, isVisible);
    }
  }

  private setControlVisibilityByKey(keyName) {
    ControlDetails.filter((cnt) => cnt.KeyName === keyName)
      .filter((elementDetail) => {
        return elementDetail.ElementsDetails;
      })
      .forEach((cnt) => {
        cnt.ElementsDetails.forEach((ele) => {
          ele.ControlName.forEach((element) => {
            this.setControlVisibility(element, ele.IsVisible);
            if (!ele.IsVisible) {
              if (element === 'PLCyberTreatment') {
                this.setValueByName(element, 'Excluded with BI Carveback');
              } else {
                this.setValueByName(element, '');
              }
            }
          });
        });
      });
  }

  private getInputPageName() {
    if (this.MetadataDetails) {
      return this.MetadataDetails.InputPage;
    } else {
      return '';
    }
  }

  private isValidInputPageName(pageName: InputPageName) {
    if (this.MetadataDetails && this.MetadataDetails.InputPage === pageName) {
      return true;
    } else {
      return false;
    }
  }

  get isRecordExists() {
    if (this.inputPageHeader && this.inputPageHeader.RecordNumberYN === 'Y') {
      return true;
    } else {
      return false;
    }
  }

  get isCollectionExists() {
    if (this.sectionKeyItemsForList && this.sectionKeyItemsForList.length > 0) {
      return true;
    } else {
      return false;
    }
  }

  get isAviationExists() {
    if (this.sectionKeyItemsForList && this.sectionKeyItemsForList.length > 0 && this.sectionKeyItemsForList.some((key) => key === 'AviationDetails')) {
      return true;
    } else {
      return false;
    }
  }

  private getSectionNameByControl(controlName: string): DataElementsDetails {
    const sectionName = this.DataElementsAllDetails.filter((section) => section.ControlName === controlName);
    if (sectionName !== null && sectionName.length > 0) {
      // console.log(sectionName[0]);
      return sectionName[0];
    }
  }

  private getOrginalValueByControlName(controlName: string): string {
    const ctrlDataElements: DataElementsDetails[] = this.DataElementsAllDetails.filter((ctrl) => ctrl.ControlName === controlName);
    if (ctrlDataElements && ctrlDataElements.length > 0) {
      return ctrlDataElements[0].SelectedValues;
    } else {
      return '';
    }
  }

  private setMandatoryByNumValue(controlName: string) {
    const controlValue = this.getValueByName(controlName);
    if (!Helper.isNumberNotNullAndEmpty(controlValue)) {
      this.setMandatoryByName(controlName, true);
    } else {
      this.setMandatoryByName(controlName);
    }
  }

  private setMandatoryByName(controlName: string, isMandatory: boolean = false) {
    if (isMandatory) {
      this.addValidators([controlName]);
    } else {
      if (!this.getOrgMandatoryByName(controlName)) {
        this.removeValidators([controlName]);
      }
    }
  }

  private setOrgMandatoryByName(controlName: string, isMandatory: boolean = false) {
    if (isMandatory) {
      this.addValidators([controlName]);
    } else {
      if (!this.getOrgMandatoryByName(controlName)) {
        this.removeValidators([controlName]);
      }
    }
  }

  private setMandByName(controlName: string, isMandatory: boolean = false) {
    if (isMandatory) {
      this.addValidators([controlName]);
    } else {
      this.removeValidators([controlName]);
    }
  }

  private setOrgMandatoryMSGByName(controlName: string) {
    const isRequired = this.getOrgMandatoryByName(controlName);
    this.setMandatoryByName(controlName, isRequired);
    const message = this.getOrgMandatoryMSGByName(controlName);
    this.setMandatoryMSGByName(controlName, message);
  }

  private getOrgMandatoryMSGByName(controlName): string {
    const cntllist = this.getControlDetailsByName(controlName);
    if (cntllist && cntllist[0]) {
      return cntllist[0].ValidationMessage;
    } else {
      return '';
    }
  }

  private getOrgMandatoryByName(controlName): boolean {
    const cntllist = this.getControlDetailsByName(controlName);
    if (cntllist && cntllist[0]) {
      return cntllist[0].IsRequired;
    } else {
      return false;
    }
  }

  private getControlValueByName(controlName): any {
    try {
      const cntllist: DataElementsDetails[] = this.DataElementsAllDetails.filter((field) => {
        return field.ControlName === controlName;
      });
      if (cntllist && cntllist.length > 0) {
        return cntllist[0].SelectedValues;
      } else {
        return '';
      }
    } catch (error) {
      console.log(error);
    }
  }

  private getControlDetailsByName(controlName): DataElementsDetails[] {
    const cntllist: DataElementsDetails[] = this.DataElementsAllDetails.filter((field) => {
      return field.ControlName === controlName;
    });
    return cntllist;
  }

  private setValueByName(controlName, controlValue) {
    if (this.submissionFields[controlName]) {
      this.submissionFields[controlName].setValue(controlValue);
    }
  }

  private setValueByNameNoEvent(controlName, controlValue) {
    if (this.submissionFields[controlName]) {
      this.submissionFormGroup.get(controlName).setValue(controlValue, {
        emitEvent: false,
      });
    }
  }

  private getNumWithabsValueByName(controlName) {
    return Math.abs(this.getNumValueByName(controlName));
  }

  private getNumValueByName(controlName): number {
    if (this.submissionFields[controlName]) {
      return Helper.isNumberNotNullAndEmpty(this.submissionFields[controlName].value) ? Number.parseInt(this.submissionFields[controlName].value) : 0;
    } else {
      return 0;
    }
  }

  private getDateValueByName(controlName) {
    if (this.submissionFields[controlName] && Helper.isStringNotNullAndEmpty(this.submissionFields[controlName].value)) {
      return new Date(this.submissionFields[controlName].value);
    } else {
      return null;
    }
  }

  private getValueByName(controlName) {
    if (this.submissionFields[controlName] && Helper.isStringNotNullAndEmpty(this.submissionFields[controlName].value)) {
      return this.submissionFields[controlName].value;
    } else {
      return '';
    }
  }

  private setCollectionValueByName(controlName, controlValue, rowIndex, isEmitEvent: boolean = false) {
    const sectionKey = this.getSectionKeyByName(controlName);
    if (this.collectionsControls(sectionKey) && this.collectionsControls(sectionKey).controls[rowIndex].get(controlName)) {
      this.collectionsControls(sectionKey)
        .controls[rowIndex].get(controlName)
        .setValue(controlValue, {
          emitEvent: isEmitEvent,
        });
    }
  }

  private getCollectionValueByName(controlName, rowIndex) {
    const sectionKey = this.getSectionKeyByName(controlName);
    if (this.collectionsControls(sectionKey) && this.collectionsControls(sectionKey).controls[rowIndex].get(controlName)) {
      return this.collectionsControls(sectionKey).controls[rowIndex].get(controlName).value;
    } else {
      return '';
    }
  }

  private getCollectionNumValueByName(controlName, rowIndex): number {
    const controlValue = this.getCollectionValueByName(controlName, rowIndex);
    if (Helper.isNumberNotNullAndEmpty(controlValue)) {
      return Number(controlValue);
    } else {
      return 0;
    }
  }

  private removeValidators(controlList: any[]) {
    controlList.forEach((element) => {
      if (this.submissionFields[element]) {
        this.submissionFields[element].clearValidators();
        this.submissionFields[element].updateValueAndValidity({
          emitEvent: false,
        });
      }
    });
  }

  private addValidators(controlList: any[]) {
    controlList.forEach((element) => {
      if (this.submissionFields[element]) {
        this.submissionFields[element].setValidators([Validators.required]);
        this.submissionFields[element].updateValueAndValidity({
          emitEvent: false,
        });
      }
    });
  }

  setNumCustomErrorsIfEmptyOrZero(controlName: string, message: string) {
    if (Helper.isNumberNotNullAndEmpty(this.getValueByName(controlName))) {
      this.setCustomErrors(controlName, '');
    } else {
      this.setCustomErrors(controlName, message);
    }
  }

  setCustomErrors(controlName, message: string = '') {
    if (this.submissionFields[controlName]) {
      if (message === '') {
        this.submissionFields[controlName].setErrors(null);
      } else {
        this.submissionFields[controlName].setErrors({
          isInValid: true,
          customMessage: message,
        });
      }
    }
  }

  setReturnError(message: string = '') {
    return message === ''
      ? null
      : {
          isInValid: true,
          customMessage: message,
        };
  }

  private isControlExists(controlName) {
    if (this.submissionFields[controlName]) {
      return true;
    } else {
      return false;
    }
  }

  private setEnableOrDisable(controlName, isEnable: boolean = false) {
    if (this.submissionFields[controlName]) {
      if (isEnable) {
        this.submissionFields[controlName].enable({
          emitEvent: false,
        });
      } else {
        this.setValueByNameNoEvent(controlName, '');
        this.submissionFields[controlName].disable({
          emitEvent: false,
        });
      }
    }
  }

  handleValueChange(controlValue) {
    console.warn(controlValue);
    console.warn('Triggered handle Value Change Method: ' + controlValue);
  }

  setReadOnly(formControl: AbstractControl, isReadonly: boolean) {
    (<any>formControl).nativeElement.readOnly = isReadonly;
  }

  toDate(value, format): string {
    try {
      const inputDateValue = value.includes('12:00AM') ? value.replace('12:00AM', '12:00 AM') : value;
      return this.datepipe.transform(new Date(inputDateValue), format);
    } catch (error) {
      throw error;
    }
  }

  setStep(index: number) {
    this.step = index;
  }

  nextStep() {
    this.step++;
  }

  prevStep() {
    this.step--;
  }

  endStep() {
    this.step = 0;
  }

  reloadSubmissionPage(isSubmissionReset: boolean = false) {
    if ((this.storedFilters && Helper.isStringNotNullAndEmpty(this.SegmentValue)) || isSubmissionReset) {
      const message = isSubmissionReset ? 'Are you sure want reset?' : 'Changing the segment will require Page reload causing unsaved data to be lost. Kindly confirm if you would like to proceed ?';
      const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
        width: '510px',
        data: {
          Action: 'Ok',
          label: 'Ok',
          Message: message,
        },
        hasBackdrop: true,
        backdropClass: 'backdropBackground',
      });

      dialogRef.afterClosed().subscribe((result) => {
        if (result && Helper.isStringNotNullAndEmpty(result.Action)) {
          if (result.Action === 'Ok confirm') {
            this.submissionFormGroup.markAsPristine();
            this.submissionFormGroup.markAsUntouched();
            const payload = <ReportsHeaderModel>{
              Division: [this.DivisionValue],
              Unit: [this.UnitValue],
              Segment: [this.SegmentValue],
              UserID: this.user.UserID,
              UnderwriterName: [this.user.UserID],
              RecordNo: this.storedFilters.RecordNo ? this.storedFilters.RecordNo : 0,
              GeniusPipeID: this.storedFilters.GeniusPipeID ? this.storedFilters.GeniusPipeID : 0,
              IsGenius: this.storedFilters.GeniusPipeID > 0 ? 'Y' : 'N',
              DYN: this.storedFilters.DYN,
              IYN: this.storedFilters.IYN,
              LYNE: this.storedFilters.LYNE,
            };
            console.log({ payload });
            const serializedFilters = this.filterWatch.serializeFromPayload(payload);
            this.router.routeReuseStrategy.shouldReuseRoute = () => false;
            this.router.onSameUrlNavigation = 'reload';
            this.router.navigate(['/submission/input-page'], {
              queryParams: {
                filters: this.filterWatch.create(serializedFilters),
                routedFrom: this.routedFrom,
              },
            });
          }
        }
      });
    }
  }

  openLinkedRecord() {
    if (this.MetadataDetails && this.MetadataDetails.LinkedRecordNumber > 0) {
      this.submissionFormGroup.markAsPristine();
      this.submissionFormGroup.markAsUntouched();
      return this.openRecordInNewTab(this.MetadataDetails.LinkedRecordNumber);
    }
  }

  openRecordInNewTab(recordNumber: Number = 0) {
    const payload = <ReportsHeaderModel>{
      Division: [],
      Unit: [],
      Segment: [],
      UserID: this.user.UserID,
      UnderwriterName: [this.user.UserID],
      RecordNo: recordNumber,
      GeniusPipeID: this.storedFilters.GeniusPipeID ? this.storedFilters.GeniusPipeID : 0,
      IsGenius: this.storedFilters.GeniusPipeID > 0 ? 'Y' : 'N',
    };
    const serializedFilters = this.filterWatch.serializeFromPayload(payload);
    const filters = this.filterWatch.create(serializedFilters);
    const url = UrlHelper.submissionPageLink(filters, this.routedFrom);
    window.open(url, '_blank');
    return;
  }

  // patternValidator(controlName: string): ValidatorFn {
  //   return (control: AbstractControl): { [key: string]: any } => {
  //     if (!control.value) {
  //       return null;
  //     }
  //     if (controlName === 'MNCode') {
  //       return this.mnCodeValidation();
  //     } else if (
  //       controlName === 'CyenceOverall' ||
  //       controlName === 'CyenceMotivation' ||
  //       controlName === 'CyenceSophistication'
  //     ) {
  //       return this.cyenceRangeValidation(controlName);
  //     } else if (controlName === 'DealPercent') {
  //       return this.dealPercentValidation();
  //     }
  //   };
  // }
}
