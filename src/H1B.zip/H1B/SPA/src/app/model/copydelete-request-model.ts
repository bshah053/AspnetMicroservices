export interface CopyDeleteRequestModel {
  Source: string;
  UserID: string;
  RecordNumber: Number;
  Action?: string;
  Type?: string;
  Status?: string;
  Company?: string;
  LinkedRecordNumber?: Number;
}
