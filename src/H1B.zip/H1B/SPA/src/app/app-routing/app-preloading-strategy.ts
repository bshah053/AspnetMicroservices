import { Route, PreloadingStrategy } from '@angular/router';
import { Observable, timer, of } from 'rxjs';
import { mergeMap } from 'rxjs/operators';
import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class AppPreloadingStrategy implements PreloadingStrategy {
  preload(route: Route, load: () => Observable<any>): Observable<any> {
    if (route.data && route.data.preload) {
      console.log(
        'preload called on ' +
          route.path +
          ' with a delay of ' +
          route.data.delay
      );
      return timer(route.data.delay).pipe(
        mergeMap((_) => {
          console.log('Loading now ' + route.path + ' module');
          return load();
        })
      );
    } else {
      console.log('no preload for the path ' + route.path);
      return of(null);
    }
  }
}
