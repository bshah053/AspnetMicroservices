export interface LayerDetailsItem {
  CommonDetails: CommonLayerDetails;
  DataDetailsElements: LayerDataDetailsElements[];
  LayerDetails: LayerDetails[];
}

export interface LayerDataDetailsElements {
  LayerDetailName: string;
  LayerDataElementsDetails: LayerDetailsDataElements[];
}

export interface LayerDetailsDataElements {
  ControlId: number;
  LayerDetailName: string;
  ControlName: string;
  DataLabel: string;
  ControlType: string;
  TableIndicator: string;
  SelectedValues: string;
  EditableYN: string;
  AuditableYN: string;
  VisibleYN: string;
  MandatoryYN: string;
  DisplayOrder: number;
  MaxLength: number;
  MinLength: number;
  MaxValue: number;
  MinValue: number;
  ControlHint: string;
  ValidationMessage: string;
}

export interface CommonLayerDetails {
  RecordNumber: number;
}

export interface LayerDetails {
  LayerDetail: string;
  LayerNumber: number;
  ACESharePercentage: number;
  TotalLayerPremium: number;
  TotalLayerLimit: number;
  TotalLayerAttachment: number;
  TotalLayerBenchmarkPremium: number;
  TotalLayerAdjustedExpiringPremium: number;
  TotalLayerTIV: number;
  ExpiringTIV: number;
  CurrentRate: number;
  ExpiringRate: number;
  ACEShareExpiringPremium: number;
  ACEParticipation: number;
  ACELayerPremium: number;
  ACELayerBenchmarkPremium: number;
  ACELayerAdjustedExpiringPremium: number;
}
