import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MsalGuard } from '@azure/msal-angular';

import { SubmissionTransferRecordComponent } from './submission-transfer-record/submission-transfer-record.component';
import { InputPageComponent } from './input-page.component';
import { SelectUnitSegmentComponent } from './select-unit-segment/select-unit-segment.component';
import { SubmissionGuardService } from './services/submission-guard.service';
import { UwGeniusQueueDetailsComponent } from './uw-genius-queue-details/uw-genius-queue-details.component';
import { UwGeniusQueueComponent } from './uw-genius-queue/uw-genius-queue.component';
import { SubmissionLoadResolver } from './services/submission-load-resolver.service';

const routes: Routes = [
	{
		path: '',
		canActivate: [MsalGuard],
		canActivateChild: [MsalGuard],
		children: [
			{
				path: 'input-page',
				// canActivate: [MsalGuard],
				canDeactivate: [SubmissionGuardService],
				resolve: {
					submissionLoad: SubmissionLoadResolver,
				},
				runGuardsAndResolvers: 'always',
				component: InputPageComponent,
			},
			{
				path: 'transfer-record',
				// canActivate: [MsalGuard],
				component: SubmissionTransferRecordComponent,
			},
			{
				path: 'select-unit-segment',
				// canActivate: [MsalGuard],
				component: SelectUnitSegmentComponent,
			},
			{
				path: 'uw-genius-queue',
				// canActivate: [MsalGuard],
				component: UwGeniusQueueComponent,
			},
			{
				path: 'uw-genius-queue-details',
				// canActivate: [MsalGuard],
				component: UwGeniusQueueDetailsComponent,
			},
		],
	},
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule],
	providers: [SubmissionLoadResolver],
})
export class InputPageRoutingModule {}
