import {
  ChangeDetectorRef,
  Component,
  Inject,
  OnChanges,
  OnInit,
  SimpleChange,
} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { combineLatest, Observable } from 'rxjs';
import { Select } from '@ngxs/store';
import { User } from 'user/user.model';
import { UserState } from 'user/user.store';
import {
  FilterType,
  ReportingService,
} from 'tracking-reporting/services/reporting.service';
import { ListItem } from 'shared/radio-list/radio-list.component';
import { FilterWatchService } from 'services/filter-watch.service';
import { ReportsHeaderModel } from 'tracking-reporting/reports/reports-header/store/reports-header.model';
import { RoutedFrom } from 'shared/utilities';

export interface TransferInfoDetails {
  RecordNumber: number;
  Companies: string;
  Divisions: string;
  Units: string;
  Segments: string;
  Underwriters: string;
}

@Component({
  selector: 'cb-submission-transfer-record',
  templateUrl: './submission-transfer-record.component.html',
  styleUrls: ['./submission-transfer-record.component.scss'],
})
export class SubmissionTransferRecordComponent implements OnInit, OnChanges {
  @Select(UserState) public user$: Observable<User>;
  user: User;
  companyFilters: Array<ListItem> = [];
  divisionFilters: Array<ListItem> = [];
  unitFilters: Array<ListItem> = [];
  segmentFilters: Array<ListItem> = [];
  underwriterFilters: Array<ListItem> = [];
  transferInfoDetails: Partial<TransferInfoDetails> = {};
  updatedDetails: Partial<TransferInfoDetails> = {};
  _updatedCompanies: Array<string> = [];
  _updatedDivisions: Array<string> = [];
  _updatedUnits: Array<string> = [];
  _updatedSegments: Array<string> = [];
  _updatedUnderwriters: Array<string> = [];
  recordNumber;

  constructor(
    @Inject(ReportingService) private reportingService: ReportingService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private cdRef: ChangeDetectorRef,
    @Inject(FilterWatchService) private filterWatch: FilterWatchService
  ) {
    combineLatest([this.user$]).subscribe(([user]) => {
      this.user = user;
    });
  }

  ngOnInit() {
    this.activatedRoute.queryParams.subscribe((params) => {
      if (params.filters) {
        const storedFilters = this.filterWatch.getByHash(params.filters);
        this.transferInfoDetails = {
          RecordNumber: storedFilters.RecordNo,
          Companies: storedFilters.CompanyName[0],
          Divisions: storedFilters.Division[0],
          Units: storedFilters.Unit[0],
          Segments: storedFilters.Segment[0],
          Underwriters: storedFilters.UnderwriterName[0],
        };
      }
    });

    if (this.user.UserID) {
      this.getCompany(this.user.UserID);
    }
  }

  ngOnChanges(
    changes: { [key in keyof SubmissionTransferRecordComponent]: SimpleChange }
  ) {
    if (changes.transferInfoDetails !== undefined) {
      if (changes.transferInfoDetails.currentValue.Underwriters) {
        this.getUnderwriters();
      }
      if (changes.transferInfoDetails.currentValue.Divisions) {
        if (this.user && this.user.UserID) {
          this.getUnits();
          this.getSegments();
        }
      }
      if (changes.transferInfoDetails.currentValue.Units) {
        this.getSegments();
      }
    }
  }

  get updatedCompanies(): Array<string> {
    return (this._updatedCompanies = this.filter([
      this.updatedDetails.Companies || this.transferInfoDetails.Companies,
    ]));
  }

  set updatedCompanies(value) {
    this._updatedCompanies = value;
  }

  handleCompaniesChange([prev, companies]) {
    this.updatedDetails.Companies = companies || prev;
    if (this.updatedCompanies.length === 0) {
      this.updatedDivisions = [];
      this.updatedUnits = [];
      this.updatedSegments = [];
    }
    this.getDivisions();
    this.getUnits();
    this.getSegments();
  }

  get updatedDivisions(): Array<string> {
    return (this._updatedDivisions = this.filter([
      this.updatedDetails.Divisions || this.transferInfoDetails.Divisions,
    ]));
  }

  set updatedDivisions(value) {
    this._updatedDivisions = value;
  }

  handleDivisionsChange([prev, division]) {
    this.updatedDetails.Divisions = division || prev;
    if (this.updatedDivisions.length === 0) {
      this.updatedUnits = [];
      this.updatedSegments = [];
    }
    this.getUnits();
    this.getSegments();
  }

  get updatedUnits(): Array<string> {
    return (this._updatedUnits = this.filter([
      this.updatedDetails.Units || this.transferInfoDetails.Units,
    ]));
  }

  set updatedUnits(value) {
    this._updatedUnits = value;
  }

  handleUnitsChange([prev, unit]) {
    this.updatedDetails.Units = unit || prev;
    if (this.updatedUnits.length === 0) {
      this.updatedSegments = [];
    }
    this.getSegments();
  }

  get updatedSegments(): Array<string> {
    return (this._updatedSegments = this.filter([
      this.updatedDetails.Segments || this.transferInfoDetails.Segments,
    ]));
  }

  set updatedSegments(value) {
    this._updatedSegments = value;
  }

  handleSegmentsChange([prev, segment]) {
    this.updatedDetails.Segments = segment || prev;
    if (this.updatedSegments.length === 0) {
      console.log(this.updatedSegments);
    }
  }

  get updatedUnderwriters(): Array<string> {
    return (this._updatedUnderwriters = this.filter([
      this.updatedDetails.Underwriters || this.transferInfoDetails.Underwriters,
    ]));
  }

  set updatedUnderwriters(value) {
    this._updatedUnderwriters = value;
  }

  handleUnderwritersChange([prev, underwriters]) {
    this.updatedDetails.Underwriters = underwriters || prev;
  }

  getUnderwriters() {
    this.reportingService
      .getUnderwriters(this.updatedUnderwriters)
      .subscribe((data: Array<FilterType>) => {
        this.underwriterFilters = data;
        this.detectChanges();
      });
  }

  getCompany(userID) {
    this.reportingService
      .getCompanyFilters(userID)
      .subscribe((data: Array<ListItem>) => {
        this.companyFilters = data;
        this.detectChanges();
        this.fetchCompaniesSubUnits();
      });
  }

  getDivisions() {
    this.reportingService
      .getCompanyDivisions(this.updatedCompanies, this.user.UserID)
      .subscribe(
        (data: Array<ListItem>) => {
          this.divisionFilters = data;
          this.updatedDivisions = this.checkSelected(
            this.updatedDivisions,
            this.divisionFilters
          );
          this.detectChanges();
        },
        (_) => {
          this.divisionFilters = [];
          this.updatedDivisions = [];
          this.detectChanges();
        }
      );
  }

  getUnits() {
    this.reportingService
      .getDivisionUnits(
        this.updatedCompanies,
        this.updatedDivisions,
        this.user.UserID
      )
      .subscribe(
        (data: Array<ListItem>) => {
          this.unitFilters = data;
          this.updatedUnits = this.checkSelected(
            this.updatedUnits,
            this.unitFilters
          );
          this.detectChanges();
        },
        (_) => {
          this.unitFilters = [];
          this.updatedUnits = [];
          this.detectChanges();
        }
      );
  }

  getSegments() {
    this.reportingService
      .getDivisionUnitsSegments(
        this.updatedCompanies,
        this.updatedDivisions,
        this.updatedUnits,
        this.user.UserID
      )
      .subscribe(
        (data: Array<ListItem>) => {
          this.segmentFilters = data;
          this.updatedSegments = this.checkSelected(
            this.updatedSegments,
            this.segmentFilters
          );
          this.detectChanges();
        },
        () => {
          this.segmentFilters = [];
          this.updatedSegments = [];
          this.detectChanges();
        }
      );
  }

  private filter(list: any[]) {
    return list.filter((i) => !!i);
  }

  private checkSelected(selection: string[], collection: ListItem[]): string[] {
    return selection.filter((i: string) => {
      return collection.filter((s: ListItem) => s.value === i).length;
    });
  }

  private fetchCompaniesSubUnits() {
    this.getDivisions();
    this.getUnits();
    this.getSegments();
    this.getUnderwriters();
  }

  private detectChanges() {
    if (!this.cdRef['destroyed']) {
      this.cdRef.detectChanges();
    }
  }

  navigateToInputPage() {
    const payload = <ReportsHeaderModel>{
      CompanyName: this.updatedCompanies,
      Division: this.updatedDivisions,
      Unit: this.updatedUnits,
      Segment: this.updatedSegments,
      UnderwriterName: this.updatedUnderwriters,
      RecordNo: this.transferInfoDetails.RecordNumber,
    };

    const serializedFilters = this.filterWatch.serializeFromPayload(payload);
    this.router.navigate(['/submission/input-page'], {
      queryParams: {
        filters: this.filterWatch.create(serializedFilters),
        routedFrom: RoutedFrom.Transfer,
      },
    });
  }

  handleTransferClose() {
    history.back();
  }
}
