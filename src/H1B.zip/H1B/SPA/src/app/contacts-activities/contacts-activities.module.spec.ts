import { ContactsActivitiesModule } from './contacts-activities.module';

describe('ContactsActivitiesModule', () => {
  let contactsActivitiesModule: ContactsActivitiesModule;

  beforeEach(() => {
    contactsActivitiesModule = new ContactsActivitiesModule();
  });

  it('should create an instance', () => {
    expect(contactsActivitiesModule).toBeTruthy();
  });
});
