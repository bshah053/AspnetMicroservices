import { LogLevel, Configuration, BrowserCacheLocation } from '@azure/msal-browser';
import { environment } from 'environments/environment';

const isIE = window.navigator.userAgent.indexOf('MSIE ') > -1 || window.navigator.userAgent.indexOf('Trident/') > -1;

export const msalConfig: Configuration = {
	auth: {
		clientId: environment.clientId,
		authority: environment.authority,
		redirectUri: environment.redirectUrl,
		postLogoutRedirectUri: environment.redirectUrl,
		navigateToLoginRequestUrl: true,
	},
	cache: {
		cacheLocation: BrowserCacheLocation.SessionStorage,
		storeAuthStateInCookie: true, // set to true for IE 11
	},
	system: {
		loggerOptions: {
			loggerCallback(logLevel: LogLevel, message: string) {
				console.log(message);
			},
			logLevel: LogLevel.Info,
			piiLoggingEnabled: false,
		},
	},
};

export const protectedResources = {
	userProfileApi: {
		endpoint: environment.apiUrl + '/api/userprofile',
		scopes: ['user.read', 'profile', 'User.Read'],
	},
};

export const loginRequest = {
	scopes: ['user.read', 'profile', 'User.Read', 'email'],
};
