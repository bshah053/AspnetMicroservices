import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { RenewalsRatioComponent } from './renewals-ratio.component';

describe('RenewalsRatioComponent', () => {
	let component: RenewalsRatioComponent;
	let fixture: ComponentFixture<RenewalsRatioComponent>;

	beforeEach(
		waitForAsync(() => {
			TestBed.configureTestingModule({
				declarations: [RenewalsRatioComponent],
			}).compileComponents();
		})
	);

	beforeEach(() => {
		fixture = TestBed.createComponent(RenewalsRatioComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
