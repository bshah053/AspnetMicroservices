import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ErrorHandler, NgModule } from '@angular/core';
import { ChartsModule } from 'ng2-charts';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { IPublicClientApplication, PublicClientApplication, InteractionType } from '@azure/msal-browser';
import { MsalGuard, MsalInterceptor, MsalBroadcastService, MsalInterceptorConfiguration, MsalModule, MsalService, MSAL_GUARD_CONFIG, MSAL_INSTANCE, MSAL_INTERCEPTOR_CONFIG, MsalGuardConfiguration, MsalRedirectComponent } from '@azure/msal-angular';
import { FlexLayoutModule } from '@angular/flex-layout';
import { AgGridModule } from 'ag-grid-angular';
import { NgxsLoggerPluginModule } from '@ngxs/logger-plugin';
import { NgxsModule } from '@ngxs/store';
import { NgxScrollTopModule } from 'ngx-scrolltop';
// import { CookieService } from 'ngx-cookie-service';
import { VirtualScrollerModule } from 'ngx-virtual-scroller';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';

import { AppRoutingModule } from './app-routing.module';
import { MaterialModule } from './material-module';
import { SharedModule } from './shared/shared.module';
import { DashboardModule } from './dashboard/dashboard.module';
import { AppComponent } from './app.component';
import { AppStore } from './app.store';
import { ModalService } from './shared/modal/modal.service';
import { TrackerQueueRendererComponent } from './dashboard/tracker-queue/tracker-queue-renderer/tracker-queue-renderer.component';
import { PageNotFoundComponent } from './pagenotfound/pagenotfound.component';
import { HttpErrorInterceptor } from './errors/http-error.interceptor';
import { GlobalErrorHandler } from './errors/global-error-handler';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { msalConfig, loginRequest, protectedResources } from './auth-config';
import { CoreModule } from './core/core.module';

export function MSALInstanceFactory(): IPublicClientApplication {
  return new PublicClientApplication(msalConfig);
}

export function MSALInterceptorConfigFactory(): MsalInterceptorConfiguration {
  const protectedResourceMap = new Map<string, Array<string>>();
  protectedResourceMap.set('https://graph.microsoft.com/v1.0/me', ['user.read']);
  // protectedResourceMap.set(protectedResources.userProfileApi.endpoint, protectedResources.userProfileApi.scopes);

  return {
    interactionType: InteractionType.Redirect,
    protectedResourceMap,
  };
}

export function MSALGuardConfigFactory(): MsalGuardConfiguration {
  return {
    interactionType: InteractionType.Redirect,
    authRequest: loginRequest,
    loginFailedRoute: '/login-failed',
  };
}

@NgModule({
  declarations: [AppComponent, TrackerQueueRendererComponent, PageNotFoundComponent, LandingPageComponent],
  imports: [
    CommonModule,
    BrowserAnimationsModule,
    BrowserModule,
    FlexLayoutModule,
    AppRoutingModule,
    HttpClientModule,
    MsalModule,
    AgGridModule.withComponents([TrackerQueueRendererComponent]),
    ChartsModule,
    NgxsModule.forRoot(AppStore),
    NgxsLoggerPluginModule.forRoot(),
    VirtualScrollerModule,
    NgxScrollTopModule,
    DashboardModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    SharedModule,
    MatInputModule,
    CoreModule,
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: MsalInterceptor,
      multi: true,
    },
    {
      provide: MSAL_INSTANCE,
      useFactory: MSALInstanceFactory,
    },
    {
      provide: MSAL_GUARD_CONFIG,
      useFactory: MSALGuardConfigFactory,
    },
    {
      provide: MSAL_INTERCEPTOR_CONFIG,
      useFactory: MSALInterceptorConfigFactory,
    },
    MsalService,
    MsalGuard,
    MsalBroadcastService,
    HttpClientModule,
    // CookieService,
    ModalService,
    { provide: ErrorHandler, useClass: GlobalErrorHandler },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpErrorInterceptor,
      multi: true,
    },
  ],
  bootstrap: [AppComponent, MsalRedirectComponent],
})
export class AppModule {}
