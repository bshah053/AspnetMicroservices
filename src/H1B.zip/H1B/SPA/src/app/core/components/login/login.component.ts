import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngxs/store';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { UserService } from 'user/user.service';
import { SharedService } from 'services/shared.service';
import { SetUser } from 'user/user.actions';
import { User } from 'user/user.model';
import { NavigationService } from 'services/navigation.service';

@Component({
  selector: 'cb-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  loading = false;
  submitted = false;
  emailId: string = '';
  error = '';
  user: User;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private userService: UserService,
    private store: Store,
    // private sharedService: SharedService,
    private navigation: NavigationService
  ) {
    // this.sharedService.sendHeaderVisibilityStatus(true);
  }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      emailId: ['', [Validators.required, Validators.email]],
    });
  }

  get loginFields() {
    return this.loginForm.controls;
  }

  onSubmit() {
    this.submitted = true;
    this.error = '';
    if (this.loginForm.invalid) {
      return;
    }
    this.loading = true;
    this.userService.getUserProfile(this.loginFields.emailId.value).subscribe(
      (data: User) => {
        this.user = data;
        if (data && data !== null) {
          // this.sharedService.sendHeaderVisibilityStatus(false);
          this.store.dispatch(new SetUser(this.user));
          this.router.navigate(['/dashboard']);
        } else {
          // Redirect to unauthorized page
          this.navigation.toUnAuthorized();
        }
      },
      (err) => {
        this.loading = false;
        if (err.status === 404) {
          this.error = 'Plesae enter valid email address!!!.';
        } else {
          this.error = 'An Error Occurred while processing your request.';
        }
      }
    );
  }
}
