export class DnBInsuredStateItem {
  UserID?: string;
  CompanyName?: string = '';
  StateProvince?: string = '';
}
