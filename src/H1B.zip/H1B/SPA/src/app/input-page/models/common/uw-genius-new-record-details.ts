export interface UWGeniusNewRecordDetails {
  Division: string;
  Unit: string;
  Segment: string;
  RedirectTo: string;
  EditableAccessCount?: number;
}
