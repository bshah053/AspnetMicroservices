import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { ContactSearchService } from '../contact-search.service';

type ListItem = {
  text: string;
  value: string;
};

@Component({
  selector: 'cb-branch-menu',
  templateUrl: './branch-menu.component.html',
  styleUrls: ['./branch-menu.component.scss'],
})
export class BranchMenuComponent implements OnInit {
  @Output() selectionChange = new EventEmitter<string[]>();
  @Input() name = 'Branch';
  @Input() selectedItems: string[] = [];
  producerBranchesList: ListItem[] = [];

  constructor(private contactSearch: ContactSearchService) {}

  ngOnInit() {
    this.producerBranches();
  }

  producerBranches() {
    this.contactSearch
      .producerBranches()
      .subscribe(
        (data: ListItem[]) => (this.producerBranchesList = data),
        (err) => console.error('Error loading branch types', err)
      );
  }

  handleProducerBranchChange(value: string[]) {
    this.selectionChange.next(value);
  }
}
