const express = require('express');

const notes = require('./dynamics/notes.json');
const tasks = require('./dynamics/tasks.json');
const completedactivities = require('./dynamics/completed-activities.json');
const completedactivitiesWithPaging = require('./dynamics/completed-activities-with-paging.json');
const appointments = require('./dynamics/appointments.json');
const contacts = require('./dynamics/contacts.json');
const chubbemployeecontacts = require('./dynamics/chubbemployeecontacts');

module.exports = function dynamicsRoutes() {
  const router = express.Router();

  router.post('/producers/notes', (req, res) => {
    return res.json(notes.data);
  });
  router.post('/producers/appointments', (req, res) => {
    return res.json(appointments.data);
  });
  router.post('/producers/contacts', (req, res) => {
    return res.json(contacts.data);
  });
  router.post('/producers/tasks', (req, res) => {
    return res.json(tasks.data);
  });
  router.post('/producers/completedactivities', (req, res) => {
    return res.json(completedactivities.data);
  });
  router.post('/customer/completedactivities', (req, res) => {
    return res.json(completedactivities.data);
  });
  router.post('/customers/completedactivities', (req, res) => {
    return res.json(completedactivities.data);
  });
  router.post('/users/completedactivities', (req, res) => {
    return res.json(completedactivitiesWithPaging.data);
  });
  router.get(
    '/users/:user_id/appointments/:page_index/:page_size',
    (req, res) => {
      return res.json(appointments.data);
    }
  );
  router.get('/search/contacts/:page_index/:page_size', (req, res) => {
    return res.json(contacts.data);
  });
  router.get('/users/:user_id/tasks/:page_index/:page_size', (req, res) => {
    return res.json(tasks.data);
  });
  router.post('/search/activities', (req, res) =>
    res.json(completedactivitiesWithPaging.data)
  );
  router.get(
    '/search/chubbemployeecontacts/:page_index/:page_size',
    (req, res) => res.json(chubbemployeecontacts)
  );
  return router;
};
